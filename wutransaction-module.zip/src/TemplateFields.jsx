import React, { Component } from 'react';
import { withRouter } from "../utils/withRouter";
import { FloatingLabel, Form } from "react-bootstrap";

class TemplateFields extends Component {

    constructor(props) {
        super(props);
    }

    changeFieldValue(event) {
        console("event.target ", event.target);
    }

    render() {
        return (
            <div>
                {
                    this.props.templateFields.map((field, i) => {
                        console.log("field.fieldName ", field.fieldName);
                        
                        <Form.Group className="mb-2" controlId="grant_type">
                                                            <FloatingLabel
                                                                controlId="floatingInput"
                                                                label="Grant Type"
                                                                className="mb-3"
                                                            >
                                                            <Form.Control type="input" placeholder="Grant Type"/>
                                                            </FloatingLabel>
                                                        </Form.Group>
                    })}
                    
            </div>
        );
    }
}

export default withRouter(TemplateFields);