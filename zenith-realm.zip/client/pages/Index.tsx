import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import {
  FlaskConical,
  Settings,
  TestTube,
  Database,
  Link2,
  FileText,
  BarChart3,
  Play,
  CheckCircle,
  XCircle,
  Clock,
  Edit3,
  ChevronDown,
  Trash2
} from "lucide-react";

// Types for test cases
interface TestCase {
  id: string;
  name: string;
  description: string;
  status: "pass" | "fail" | "pending" | "running";
  selected: boolean;
  details?: {
    testToRun: string;
    expectedResults: string;
  };
}

interface TestCategory {
  id: string;
  name: string;
  testCases: TestCase[];
}

export default function Index() {
  // Environment state
  const [environment, setEnvironment] = useState({
    identifier: "",
    counterID: "",
    reference: ""
  });

  // Test cases state
  const [uiTestCategories, setUiTestCategories] = useState<TestCategory[]>([
    {
      id: "order-details",
      name: "Order Details",
      testCases: [
        { id: "od-1", name: "Validate order information display", description: "Test order data rendering", status: "pending", selected: false },
        { id: "od-2", name: "Order status updates", description: "Test real-time status changes", status: "pending", selected: false },
        { id: "od-3", name: "Order history navigation", description: "Test order history access", status: "pending", selected: false }
      ]
    },
    {
      id: "order-response",
      name: "Order Response",
      testCases: [
        { id: "or-1", name: "Success response handling", description: "Test positive order responses", status: "pending", selected: false },
        { id: "or-2", name: "Error response handling", description: "Test error scenarios", status: "pending", selected: false },
        { id: "or-3", name: "Timeout response handling", description: "Test timeout scenarios", status: "pending", selected: false }
      ]
    },
    {
      id: "create-order",
      name: "Create Order",
      testCases: [
        { id: "co-1", name: "Order form validation", description: "Test input validation", status: "pending", selected: false },
        { id: "co-2", name: "Order submission flow", description: "Test complete order creation", status: "pending", selected: false },
        { id: "co-3", name: "Order confirmation display", description: "Test confirmation UI", status: "pending", selected: false }
      ]
    },
    {
      id: "create-order-response",
      name: "Create Order Response",
      testCases: [
        { id: "cor-1", name: "Creation success response", description: "Test successful order creation", status: "pending", selected: false },
        { id: "cor-2", name: "Creation failure response", description: "Test failed order creation", status: "pending", selected: false },
        { id: "cor-3", name: "Partial order response", description: "Test partial completion", status: "pending", selected: false }
      ]
    }
  ]);

  const [backendTestCategories, setBackendTestCategories] = useState<TestCategory[]>([
    {
      id: "api-endpoints",
      name: "API Endpoints",
      testCases: [
        { id: "api-1", name: "GET orders endpoint", description: "Test orders retrieval", status: "pending", selected: false },
        { id: "api-2", name: "POST create order endpoint", description: "Test order creation API", status: "pending", selected: false },
        { id: "api-3", name: "PUT update order endpoint", description: "Test order updates", status: "pending", selected: false }
      ]
    },
    {
      id: "data-validation",
      name: "Data Validation",
      testCases: [
        { id: "dv-1", name: "Input sanitization", description: "Test data cleaning", status: "pending", selected: false },
        { id: "dv-2", name: "Schema validation", description: "Test data structure validation", status: "pending", selected: false },
        { id: "dv-3", name: "Business rule validation", description: "Test business logic", status: "pending", selected: false }
      ]
    },
    {
      id: "authentication",
      name: "Authentication",
      testCases: [
        { id: "auth-1", name: "Token validation", description: "Test JWT token validation", status: "pending", selected: false },
        { id: "auth-2", name: "Permission checks", description: "Test access control", status: "pending", selected: false },
        { id: "auth-3", name: "Session management", description: "Test session handling", status: "pending", selected: false }
      ]
    },
    {
      id: "performance",
      name: "Performance",
      testCases: [
        { id: "perf-1", name: "Response time validation", description: "Test API response times", status: "pending", selected: false },
        { id: "perf-2", name: "Load testing", description: "Test under high load", status: "pending", selected: false },
        { id: "perf-3", name: "Memory usage monitoring", description: "Test memory efficiency", status: "pending", selected: false }
      ]
    }
  ]);

  const [selectedTestCase, setSelectedTestCase] = useState<TestCase | null>(null);
  const [isEditingDetails, setIsEditingDetails] = useState(false);

  // Splunk queries state
  const [splunkQueries, setSplunkQueries] = useState([
    {
      id: "sq-1",
      name: "Order Processing Logs",
      partner: "Partner A",
      query: 'index=orders source="/var/log/orders.log" | search "order_id=' + (environment.identifier || '*') + '"',
      linkedTestCases: ["od-1", "co-2"],
      isActive: true
    },
    {
      id: "sq-2",
      name: "API Error Logs",
      partner: "Partner B",
      query: 'index=api_errors earliest=-1h | search level=ERROR',
      linkedTestCases: ["or-2", "api-1"],
      isActive: false
    }
  ]);

  const [editingSplunkQuery, setEditingSplunkQuery] = useState<any>(null);
  const [isAddingSplunkQuery, setIsAddingSplunkQuery] = useState(false);
  const [logOutput, setLogOutput] = useState<string[]>([
    "[2024-01-20 10:30:15] INFO: Test execution started",
    "[2024-01-20 10:30:16] DEBUG: Environment loaded - ID: " + (environment.identifier || 'not_set'),
    "[2024-01-20 10:30:17] INFO: PartnerOS connection established",
    "[2024-01-20 10:30:18] INFO: Running selected test cases...",
    "[2024-01-20 10:30:19] WARN: No test cases currently selected"
  ]);

  // PartnerOS connections state (now editable)
  const [partnerOSConnections, setPartnerOSConnections] = useState([
    {
      id: "pq-1",
      name: "PartnerOS Health Check",
      method: "GET",
      url: "https://api.partneros.com/health",
      linkedTestCases: ["od-1", "api-1"],
      headers: "Authorization: Bearer ${environment.identifier}",
      body: ""
    },
    {
      id: "pq-2",
      name: "Create Partner Order",
      method: "POST",
      url: "https://api.partneros.com/orders",
      linkedTestCases: ["co-2", "api-2"],
      headers: "Authorization: Bearer ${environment.identifier}\nContent-Type: application/json",
      body: '{\n  "counterID": "${environment.counterID}",\n  "reference": "${environment.reference}"\n}'
    },
    {
      id: "pq-3",
      name: "Get Order Status",
      method: "GET",
      url: "https://api.partneros.com/orders/{orderId}?ref=${environment.reference}",
      linkedTestCases: ["or-1", "dv-2"],
      headers: "Authorization: Bearer ${environment.identifier}",
      body: ""
    }
  ]);

  const [editingPartnerOSConnection, setEditingPartnerOSConnection] = useState<any>(null);
  const [isAddingPartnerOSConnection, setIsAddingPartnerOSConnection] = useState(false);
  const [modalNavigationSource, setModalNavigationSource] = useState<'main' | 'testcase'>('main');

  const toggleTestCase = (categories: TestCategory[], setCategories: React.Dispatch<React.SetStateAction<TestCategory[]>>, categoryId: string, testCaseId: string) => {
    setCategories(categories.map(category => 
      category.id === categoryId 
        ? {
            ...category,
            testCases: category.testCases.map(testCase =>
              testCase.id === testCaseId 
                ? { ...testCase, selected: !testCase.selected }
                : testCase
            )
          }
        : category
    ));
  };

  const openTestCaseDetails = (testCase: TestCase) => {
    setSelectedTestCase(testCase);
    setIsEditingDetails(true);
  };

  const saveTestCaseDetails = (details: { testToRun: string; expectedResults: string }) => {
    if (selectedTestCase) {
      const updateCategories = (categories: TestCategory[]) => 
        categories.map(category => ({
          ...category,
          testCases: category.testCases.map(testCase =>
            testCase.id === selectedTestCase.id 
              ? { ...testCase, details }
              : testCase
          )
        }));

      setUiTestCategories(updateCategories);
      setBackendTestCategories(updateCategories);
      setIsEditingDetails(false);
      setSelectedTestCase(null);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pass": return <CheckCircle className="h-4 w-4 text-green-500" />;
      case "fail": return <XCircle className="h-4 w-4 text-red-500" />;
      case "running": return <Clock className="h-4 w-4 text-blue-500 animate-spin" />;
      default: return <Clock className="h-4 w-4 text-gray-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pass": return "bg-green-100 text-green-800";
      case "fail": return "bg-red-100 text-red-800";
      case "running": return "bg-blue-100 text-blue-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getSelectedTestCaseIds = () => {
    const uiSelected = uiTestCategories.flatMap(cat =>
      cat.testCases.filter(tc => tc.selected).map(tc => tc.id)
    );
    const backendSelected = backendTestCategories.flatMap(cat =>
      cat.testCases.filter(tc => tc.selected).map(tc => tc.id)
    );
    return [...uiSelected, ...backendSelected];
  };

  const runSplunkQuery = (queryId: string) => {
    const query = splunkQueries.find(q => q.id === queryId);
    if (query) {
      // Replace environment variables in the query
      const processedQuery = query.query
        .replace(/\$\{environment\.identifier\}/g, environment.identifier || 'null')
        .replace(/\$\{environment\.counterID\}/g, environment.counterID || 'null')
        .replace(/\$\{environment\.reference\}/g, environment.reference || 'null');

      setLogOutput(prev => [
        ...prev,
        `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Running Splunk query: ${query.name}`,
        `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] DEBUG: Original Query: ${query.query}`,
        `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] DEBUG: Processed Query: ${processedQuery}`,
        `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Partner: ${query.partner}`,
        `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Environment: ID=${environment.identifier || 'not_set'}, Counter=${environment.counterID || 'not_set'}, Ref=${environment.reference || 'not_set'}`,
        `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Searching logs...`
      ]);

      // Simulate log results after a delay
      setTimeout(() => {
        setLogOutput(prev => [
          ...prev,
          `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] RESULT: Found 23 matching log entries`,
          `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Query execution completed`
        ]);
      }, 2000);
    }
  };

  const saveSplunkQuery = (queryData: any) => {
    if (editingSplunkQuery) {
      setSplunkQueries(prev => prev.map(q =>
        q.id === editingSplunkQuery.id ? { ...q, ...queryData } : q
      ));
    } else {
      const newQuery = {
        id: `sq-${Date.now()}`,
        isActive: false,
        ...queryData
      };
      setSplunkQueries(prev => [...prev, newQuery]);
    }
    setEditingSplunkQuery(null);
    setIsAddingSplunkQuery(false);
  };

  const deleteSplunkQuery = (queryId: string) => {
    setSplunkQueries(prev => prev.filter(q => q.id !== queryId));
  };

  // PartnerOS connection management functions
  const savePartnerOSConnection = (connectionData: any) => {
    if (editingPartnerOSConnection) {
      setPartnerOSConnections(prev => prev.map(conn =>
        conn.id === editingPartnerOSConnection.id ? { ...conn, ...connectionData } : conn
      ));
    } else {
      const newConnection = {
        id: `pq-${Date.now()}`,
        ...connectionData
      };
      setPartnerOSConnections(prev => [...prev, newConnection]);
    }
    setEditingPartnerOSConnection(null);
    setIsAddingPartnerOSConnection(false);
  };

  const deletePartnerOSConnection = (connectionId: string) => {
    setPartnerOSConnections(prev => prev.filter(conn => conn.id !== connectionId));
  };

  const runPartnerOSConnection = (connectionId: string) => {
    const connection = partnerOSConnections.find(conn => conn.id === connectionId);
    if (connection) {
      // Replace environment variables in the connection
      const processedUrl = connection.url
        .replace(/\$\{environment\.identifier\}/g, environment.identifier || 'null')
        .replace(/\$\{environment\.counterID\}/g, environment.counterID || 'null')
        .replace(/\$\{environment\.reference\}/g, environment.reference || 'null');

      const processedHeaders = connection.headers
        .replace(/\$\{environment\.identifier\}/g, environment.identifier || 'null')
        .replace(/\$\{environment\.counterID\}/g, environment.counterID || 'null')
        .replace(/\$\{environment\.reference\}/g, environment.reference || 'null');

      const processedBody = connection.body
        .replace(/\$\{environment\.identifier\}/g, environment.identifier || 'null')
        .replace(/\$\{environment\.counterID\}/g, environment.counterID || 'null')
        .replace(/\$\{environment\.reference\}/g, environment.reference || 'null');

      setLogOutput(prev => [
        ...prev,
        `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Running PartnerOS connection: ${connection.name}`,
        `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] DEBUG: ${connection.method} ${processedUrl}`,
        `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] DEBUG: Headers: ${processedHeaders}`,
        processedBody ? `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] DEBUG: Body: ${processedBody}` : '',
        `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Executing request...`
      ].filter(Boolean));

      // Simulate API response
      setTimeout(() => {
        setLogOutput(prev => [
          ...prev,
          `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] RESULT: HTTP 200 - Request successful`,
          `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: PartnerOS connection completed`
        ]);
      }, 1500);
    }
  };

  // Playwright test runner functions
  const [isRunningTests, setIsRunningTests] = useState(false);
  const [isRunningBackendTests, setIsRunningBackendTests] = useState(false);
  const [testResults, setTestResults] = useState<{[key: string]: any}>({});

  const runPlaywrightTests = async () => {
    const selectedTests = uiTestCategories.flatMap(category =>
      category.testCases.filter(tc => tc.selected)
    );

    if (selectedTests.length === 0) {
      setLogOutput(prev => [
        ...prev,
        `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] WARN: No UI test cases selected for execution`
      ]);
      return;
    }

    setIsRunningTests(true);

    // Update selected tests to running status
    setUiTestCategories(prev => prev.map(category => ({
      ...category,
      testCases: category.testCases.map(tc =>
        tc.selected ? { ...tc, status: "running" as const } : tc
      )
    })));

    setLogOutput(prev => [
      ...prev,
      `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Starting Playwright test execution`,
      `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Selected tests: ${selectedTests.map(t => t.id).join(', ')}`,
      `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Environment Variables:`,
      `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: - IDENTIFIER=${environment.identifier || 'not_set'}`,
      `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: - COUNTER_ID=${environment.counterID || 'not_set'}`,
      `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: - REFERENCE=${environment.reference || 'not_set'}`,
      `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Launching Python Playwright runner...`
    ]);

    // Simulate test execution
    for (let i = 0; i < selectedTests.length; i++) {
      const test = selectedTests[i];

      setTimeout(() => {
        setLogOutput(prev => [
          ...prev,
          `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Running test: ${test.name}`,
          `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] DEBUG: IDENTIFIER=${environment.identifier || 'not_set'} COUNTER_ID=${environment.counterID || 'not_set'} REFERENCE=${environment.reference || 'not_set'} pytest tests/ui/${test.id}.py --browser=chromium`
        ]);
      }, (i + 1) * 1000);

      setTimeout(() => {
        const success = Math.random() > 0.3; // 70% success rate for demo
        const status = success ? "pass" : "fail";

        setUiTestCategories(prev => prev.map(category => ({
          ...category,
          testCases: category.testCases.map(tc =>
            tc.id === test.id ? { ...tc, status } : tc
          )
        })));

        setLogOutput(prev => [
          ...prev,
          `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] ${success ? 'PASS' : 'FAIL'}: ${test.name} - ${success ? 'Test completed successfully' : 'Test failed with assertion error'}`
        ]);

        if (i === selectedTests.length - 1) {
          setTimeout(() => {
            setIsRunningTests(false);
            setLogOutput(prev => [
              ...prev,
              `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Playwright test execution completed`,
              `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Results summary available in Results tab`
            ]);
          }, 500);
        }
      }, (i + 2) * 1000);
    }
  };

  const runCategoryTests = (categoryId: string) => {
    const category = uiTestCategories.find(cat => cat.id === categoryId);
    if (!category) return;

    // Select all tests in this category
    setUiTestCategories(prev => prev.map(cat =>
      cat.id === categoryId
        ? {
            ...cat,
            testCases: cat.testCases.map(tc => ({ ...tc, selected: true }))
          }
        : cat
    ));

    // Run tests after a brief delay to allow UI update
    setTimeout(() => {
      runPlaywrightTests();
    }, 100);
  };

  // Backend test runner functions with Playwright automation
  const runBackendTests = async () => {
    const selectedTests = backendTestCategories.flatMap(category =>
      category.testCases.filter(tc => tc.selected)
    );

    if (selectedTests.length === 0) {
      setLogOutput(prev => [
        ...prev,
        `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] WARN: No backend test cases selected for execution`
      ]);
      return;
    }

    setIsRunningBackendTests(true);

    // Update selected tests to running status
    setBackendTestCategories(prev => prev.map(category => ({
      ...category,
      testCases: category.testCases.map(tc =>
        tc.selected ? { ...tc, status: "running" as const } : tc
      )
    })));

    setLogOutput(prev => [
      ...prev,
      `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: ======= BACKEND PLAYWRIGHT TEST EXECUTION STARTED =======`,
      `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Selected backend tests: ${selectedTests.map(t => t.id).join(', ')}`,
      `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Playwright Backend Automation Framework: Python + API Testing`,
      `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Environment Variables:`,
      `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: - IDENTIFIER=${environment.identifier || 'not_set'}`,
      `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: - COUNTER_ID=${environment.counterID || 'not_set'}`,
      `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: - REFERENCE=${environment.reference || 'not_set'}`,
      `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Launching headless Chromium for backend testing...`
    ]);

    // Execute tests sequentially
    for (let i = 0; i < selectedTests.length; i++) {
      const test = selectedTests[i];

      setTimeout(() => {
        setLogOutput(prev => [
          ...prev,
          `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: ===== EXECUTING PLAYWRIGHT BACKEND TEST: ${test.name} =====`,
          `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Test ID: ${test.id}`,
          `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Description: ${test.description}`,
          `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] DEBUG: IDENTIFIER=${environment.identifier || 'not_set'} COUNTER_ID=${environment.counterID || 'not_set'} REFERENCE=${environment.reference || 'not_set'} pytest tests/backend/${test.id}.py --browser=chromium --headless`,
          `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Initializing Playwright browser context for backend testing...`
        ]);

        // Find linked PartnerOS connections
        const linkedConnections = partnerOSConnections.filter(conn =>
          conn.linkedTestCases.includes(test.id)
        );

        // Find linked Splunk queries
        const linkedQueries = splunkQueries.filter(query =>
          query.linkedTestCases.includes(test.id)
        );

        setLogOutput(prev => [
          ...prev,
          `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Found ${linkedConnections.length} linked PartnerOS connections`,
          `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Found ${linkedQueries.length} linked Splunk queries`
        ]);

        // Execute linked PartnerOS connections
        linkedConnections.forEach((connection, connIndex) => {
          setTimeout(() => {
            const processedUrl = connection.url
              .replace(/\$\{environment\.identifier\}/g, environment.identifier || 'null')
              .replace(/\$\{environment\.counterID\}/g, environment.counterID || 'null')
              .replace(/\$\{environment\.reference\}/g, environment.reference || 'null');

            const processedHeaders = connection.headers
              .replace(/\$\{environment\.identifier\}/g, environment.identifier || 'null')
              .replace(/\$\{environment\.counterID\}/g, environment.counterID || 'null')
              .replace(/\$\{environment\.reference\}/g, environment.reference || 'null');

            setLogOutput(prev => [
              ...prev,
              `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: --- Playwright: Executing PartnerOS Connection: ${connection.name} ---`,
              `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] DEBUG: Creating new browser page for API testing`,
              `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] DEBUG: Playwright Request: ${connection.method} ${processedUrl}`,
              `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] DEBUG: Headers: ${processedHeaders}`,
              connection.body ? `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] DEBUG: Body: ${connection.body}` : '',
              `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Playwright: Making API request via browser context...`
            ].filter(Boolean));

            // Simulate Playwright API response
            setTimeout(() => {
              const success = Math.random() > 0.2; // 80% success rate
              setLogOutput(prev => [
                ...prev,
                `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Playwright: API request executed via browser context`,
                `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] ${success ? 'SUCCESS' : 'ERROR'}: PartnerOS ${connection.name} - ${success ? 'HTTP 200 OK' : 'HTTP 500 Internal Server Error'}`,
                success ?
                  `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] RESULT: Playwright validated response data structure` :
                  `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] ERROR: Playwright detected API failure - timeout or server error`,
                `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Playwright: Closing API request page context`
              ]);
            }, 500 + (connIndex * 300));
          }, 200 + (connIndex * 500));
        });

        // Execute linked Splunk queries
        linkedQueries.forEach((query, queryIndex) => {
          setTimeout(() => {
            const processedQuery = query.query
              .replace(/\$\{environment\.identifier\}/g, environment.identifier || 'null')
              .replace(/\$\{environment\.counterID\}/g, environment.counterID || 'null')
              .replace(/\$\{environment\.reference\}/g, environment.reference || 'null');

            setLogOutput(prev => [
              ...prev,
              `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: --- Playwright: Executing Splunk Query: ${query.name} ---`,
              `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] DEBUG: Playwright: Navigating to Splunk interface`,
              `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] DEBUG: Partner: ${query.partner}`,
              `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] DEBUG: Playwright: Injecting query: ${processedQuery}`,
              `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Playwright: Automated search execution for test case ${test.id}...`
            ]);

            // Simulate Playwright-automated Splunk query results
            setTimeout(() => {
              const logCount = Math.floor(Math.random() * 50) + 1;
              const hasErrors = Math.random() > 0.6;
              setLogOutput(prev => [
                ...prev,
                `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Playwright: Query execution completed`,
                `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] RESULT: Playwright extracted ${logCount} log entries for ${query.name}`,
                `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Playwright: Automated log analysis performed`,
                hasErrors ?
                  `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] WARN: Playwright detected ${Math.floor(Math.random() * 5) + 1} error entries in logs` :
                  `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Playwright: No errors found in automated log analysis`,
                `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Playwright: Closing Splunk browser session`
              ]);
            }, 800 + (queryIndex * 400));
          }, 1000 + (queryIndex * 600));
        });

        // Determine test result after all connections and queries
        setTimeout(() => {
          const success = Math.random() > 0.25; // 75% success rate
          const status = success ? "pass" : "fail";

          setBackendTestCategories(prev => prev.map(category => ({
            ...category,
            testCases: category.testCases.map(tc =>
              tc.id === test.id ? { ...tc, status } : tc
            )
          })));

          setLogOutput(prev => [
            ...prev,
            `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Playwright: Cleaning up browser contexts and resources`,
            `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] ${success ? 'PASS' : 'FAIL'}: Playwright Backend test ${test.name} - ${success ? 'All automated validations successful' : 'Playwright test failed validation checks'}`,
            `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Playwright: Browser session closed for test ${test.id}`,
            `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: ===== PLAYWRIGHT TEST ${test.id} COMPLETED =====`
          ]);

          // Complete the test execution when all tests are done
          if (i === selectedTests.length - 1) {
            setTimeout(() => {
              setIsRunningBackendTests(false);
              setLogOutput(prev => [
                ...prev,
                `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: ======= BACKEND PLAYWRIGHT TEST EXECUTION COMPLETED =======`,
                `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Total Playwright backend tests executed: ${selectedTests.length}`,
                `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Playwright automation framework: API testing + Log analysis`,
                `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: All browser contexts and resources cleaned up`,
                `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Results summary available in Results tab`
              ]);
            }, 500);
          }
        }, 2000 + (linkedConnections.length * 500) + (linkedQueries.length * 600));

      }, i * 4000); // Stagger each test by 4 seconds
    }
  };

  const runBackendCategoryTests = (categoryId: string) => {
    const category = backendTestCategories.find(cat => cat.id === categoryId);
    if (!category) return;

    // Select all tests in this category
    setBackendTestCategories(prev => prev.map(cat =>
      cat.id === categoryId
        ? {
            ...cat,
            testCases: cat.testCases.map(tc => ({ ...tc, selected: true }))
          }
        : cat
    ));

    // Run tests after a brief delay to allow UI update
    setTimeout(() => {
      runBackendTests();
    }, 100);
  };

  // Environment management functions
  const clearEnvironmentSettings = () => {
    setEnvironment({
      identifier: "",
      counterID: "",
      reference: ""
    });

    // Log the environment clear action
    setLogOutput(prev => [
      ...prev,
      `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Environment settings cleared`,
      `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: All environment variables reset to empty values`,
      `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: This will affect all connections, queries, and test executions`
    ]);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="bg-yellow-500 p-2 rounded-lg">
                <FlaskConical className="h-6 w-6 text-black" />
              </div>
              <div>
                <h1 className="text-xl font-semibold text-slate-900">Western Union PartnerIQ Test Suite</h1>
                <p className="text-sm text-slate-500">Comprehensive Testing Platform</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
                Western Union Ready
              </Badge>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs defaultValue="environment" className="space-y-6">
          <TabsList className="grid w-full grid-cols-6 lg:w-auto lg:grid-cols-6 h-auto p-1 bg-white border shadow-sm">
            <TabsTrigger value="environment" className="flex items-center gap-2 py-3 px-4 data-[state=active]:bg-yellow-500 data-[state=active]:text-black data-[state=active]:font-semibold data-[state=inactive]:bg-white data-[state=inactive]:text-slate-600">
              <Settings className="h-4 w-4" />
              <span className="hidden sm:inline">Environment</span>
            </TabsTrigger>
            <TabsTrigger value="ui-tests" className="flex items-center gap-2 py-3 px-4 data-[state=active]:bg-yellow-500 data-[state=active]:text-black data-[state=active]:font-semibold data-[state=inactive]:bg-white data-[state=inactive]:text-slate-600">
              <TestTube className="h-4 w-4" />
              <span className="hidden sm:inline">UI Tests</span>
            </TabsTrigger>
            <TabsTrigger value="backend-tests" className="flex items-center gap-2 py-3 px-4 data-[state=active]:bg-yellow-500 data-[state=active]:text-black data-[state=active]:font-semibold data-[state=inactive]:bg-white data-[state=inactive]:text-slate-600">
              <Database className="h-4 w-4" />
              <span className="hidden sm:inline">Backend Tests</span>
            </TabsTrigger>
            <TabsTrigger value="partneros" className="flex items-center gap-2 py-3 px-4 data-[state=active]:bg-yellow-500 data-[state=active]:text-black data-[state=active]:font-semibold data-[state=inactive]:bg-white data-[state=inactive]:text-slate-600">
              <Link2 className="h-4 w-4" />
              <span className="hidden sm:inline">PartnerOS</span>
            </TabsTrigger>
            <TabsTrigger value="logs" className="flex items-center gap-2 py-3 px-4 data-[state=active]:bg-yellow-500 data-[state=active]:text-black data-[state=active]:font-semibold data-[state=inactive]:bg-white data-[state=inactive]:text-slate-600">
              <FileText className="h-4 w-4" />
              <span className="hidden sm:inline">Logs</span>
            </TabsTrigger>
            <TabsTrigger value="results" className="flex items-center gap-2 py-3 px-4 data-[state=active]:bg-yellow-500 data-[state=active]:text-black data-[state=active]:font-semibold data-[state=inactive]:bg-white data-[state=inactive]:text-slate-600">
              <BarChart3 className="h-4 w-4" />
              <span className="hidden sm:inline">Results</span>
            </TabsTrigger>
          </TabsList>

          {/* Environment Details Tab */}
          <TabsContent value="environment">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="h-5 w-5" />
                  Environment Details
                </CardTitle>
                <CardDescription>
                  Configure your testing environment parameters
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-700">Identifier</label>
                    <Input
                      value={environment.identifier}
                      onChange={(e) => setEnvironment({ ...environment, identifier: e.target.value })}
                      placeholder="Enter environment identifier"
                      className="bg-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-700">Counter ID</label>
                    <Input
                      value={environment.counterID}
                      onChange={(e) => setEnvironment({ ...environment, counterID: e.target.value })}
                      placeholder="Enter counter ID"
                      className="bg-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-700">Reference</label>
                    <Input
                      value={environment.reference}
                      onChange={(e) => setEnvironment({ ...environment, reference: e.target.value })}
                      placeholder="Enter reference"
                      className="bg-white"
                    />
                  </div>
                </div>
                <div className="pt-4 border-t">
                  <div className="flex items-center justify-between">
                    <Button
                      variant="outline"
                      onClick={clearEnvironmentSettings}
                      className="text-red-600 border-red-300 hover:bg-red-50 font-semibold"
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Clear Environment Settings
                    </Button>
                    <Button className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold">
                      Save Environment Settings
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* UI Test Cases Tab */}
          <TabsContent value="ui-tests">
            <div className="space-y-6">
              {/* Test Runner Controls */}
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <TestTube className="h-5 w-5" />
                        Playwright Test Runner
                      </CardTitle>
                      <CardDescription>
                        Execute UI tests using Python Playwright automation
                      </CardDescription>
                    </div>
                    <div className="flex items-center gap-3">
                      <Badge className="bg-blue-100 text-blue-800">
                        Python + Playwright
                      </Badge>
                      <Button
                        onClick={runPlaywrightTests}
                        disabled={isRunningTests || uiTestCategories.flatMap(cat => cat.testCases).filter(tc => tc.selected).length === 0}
                        className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold disabled:bg-gray-400"
                      >
                        {isRunningTests ? (
                          <>
                            <Clock className="h-4 w-4 mr-2 animate-spin" />
                            Running Tests...
                          </>
                        ) : (
                          <>
                            <Play className="h-4 w-4 mr-2" />
                            Run Selected Tests
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-4 text-sm text-slate-600">
                    <div className="flex items-center gap-2">
                      <span>Selected Tests:</span>
                      <Badge variant="outline">
                        {uiTestCategories.flatMap(cat => cat.testCases).filter(tc => tc.selected).length}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2">
                      <span>Environment:</span>
                      <Badge variant="outline">
                        {environment.identifier || 'Default'}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2">
                      <span>Browser:</span>
                      <Badge variant="outline">Chromium</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Test Categories */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TestTube className="h-5 w-5" />
                    UI Test Cases
                  </CardTitle>
                  <CardDescription>
                    Manage and execute user interface test cases by category
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {uiTestCategories.map((category) => (
                      <Card key={category.id} className="border-slate-200">
                        <CardHeader className="pb-3">
                          <div className="flex items-center justify-between">
                            <CardTitle className="text-lg text-slate-800">{category.name}</CardTitle>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => runCategoryTests(category.id)}
                              disabled={isRunningTests}
                              className="text-yellow-600 border-yellow-300 hover:bg-yellow-50 font-semibold"
                            >
                              <Play className="h-3 w-3 mr-1" />
                              Run Category
                            </Button>
                          </div>
                          <div className="flex items-center gap-2 mt-2">
                            <Badge
                              variant="outline"
                              className="text-xs"
                            >
                              {category.testCases.filter(tc => tc.selected).length}/{category.testCases.length} selected
                            </Badge>
                            <Badge
                              className={`text-xs ${
                                category.testCases.every(tc => tc.status === 'pass') ? 'bg-green-100 text-green-800' :
                                category.testCases.some(tc => tc.status === 'fail') ? 'bg-red-100 text-red-800' :
                                category.testCases.some(tc => tc.status === 'running') ? 'bg-blue-100 text-blue-800' :
                                'bg-gray-100 text-gray-800'
                              }`}
                            >
                              {category.testCases.every(tc => tc.status === 'pass') ? 'All Passed' :
                               category.testCases.some(tc => tc.status === 'fail') ? 'Some Failed' :
                               category.testCases.some(tc => tc.status === 'running') ? 'Running' :
                               'Pending'}
                            </Badge>
                          </div>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          {category.testCases.map((testCase) => (
                            <div key={testCase.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border">
                              <div className="flex items-center gap-3">
                                <Checkbox
                                  checked={testCase.selected}
                                  onCheckedChange={() => toggleTestCase(uiTestCategories, setUiTestCategories, category.id, testCase.id)}
                                  disabled={isRunningTests}
                                />
                                <div className="flex-1 min-w-0">
                                  <p className="text-sm font-medium text-slate-900 truncate">{testCase.name}</p>
                                  <p className="text-xs text-slate-500 truncate">{testCase.description}</p>
                                  <p className="text-xs text-slate-400 font-mono">
                                    tests/ui/{testCase.id}.py
                                  </p>
                                </div>
                              </div>
                              <div className="flex items-center gap-2">
                                {getStatusIcon(testCase.status)}
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => openTestCaseDetails(testCase)}
                                  disabled={isRunningTests}
                                >
                                  <Edit3 className="h-3 w-3" />
                                </Button>
                              </div>
                            </div>
                          ))}
                          <div className="pt-2 border-t">
                            <div className="flex items-center justify-between text-xs text-slate-500">
                              <span>Pytest command:</span>
                              <code className="bg-slate-100 px-2 py-1 rounded">
                                pytest tests/ui/{category.id}/ --browser=chromium
                              </code>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Backend Test Cases Tab */}
          <TabsContent value="backend-tests">
            <div className="space-y-6">
              {/* Backend Test Runner Controls */}
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <Database className="h-5 w-5" />
                        Playwright Backend Test Runner
                      </CardTitle>
                      <CardDescription>
                        Execute automated backend tests using Playwright with integrated PartnerOS API testing and Splunk log analysis
                      </CardDescription>
                    </div>
                    <div className="flex items-center gap-3">
                      <Badge className="bg-purple-100 text-purple-800">
                        Playwright + API + Logs
                      </Badge>
                      <Button
                        onClick={runBackendTests}
                        disabled={isRunningBackendTests || backendTestCategories.flatMap(cat => cat.testCases).filter(tc => tc.selected).length === 0}
                        className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold disabled:bg-gray-400"
                      >
                        {isRunningBackendTests ? (
                          <>
                            <Clock className="h-4 w-4 mr-2 animate-spin" />
                            Running Playwright Tests...
                          </>
                        ) : (
                          <>
                            <Play className="h-4 w-4 mr-2" />
                            Run Playwright Tests
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-sm text-slate-600">
                    <div className="flex items-center gap-2">
                      <span>Selected Tests:</span>
                      <Badge variant="outline">
                        {backendTestCategories.flatMap(cat => cat.testCases).filter(tc => tc.selected).length}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2">
                      <span>PartnerOS Connections:</span>
                      <Badge variant="outline">
                        {partnerOSConnections.length} Available
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2">
                      <span>Splunk Queries:</span>
                      <Badge variant="outline">
                        {splunkQueries.filter(q => q.isActive).length} Active
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2">
                      <span>Environment:</span>
                      <Badge variant="outline">
                        {environment.identifier || 'Default'}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Backend Test Categories */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Database className="h-5 w-5" />
                    Backend Test Cases
                  </CardTitle>
                  <CardDescription>
                    Manage and execute Playwright-automated backend test cases with linked API connections and log queries
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {backendTestCategories.map((category) => (
                      <Card key={category.id} className="border-slate-200">
                        <CardHeader className="pb-3">
                          <div className="flex items-center justify-between">
                            <CardTitle className="text-lg text-slate-800">{category.name}</CardTitle>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => runBackendCategoryTests(category.id)}
                              disabled={isRunningBackendTests}
                              className="text-yellow-600 border-yellow-300 hover:bg-yellow-50 font-semibold"
                            >
                              <Play className="h-3 w-3 mr-1" />
                              Run Category
                            </Button>
                          </div>
                          <div className="flex items-center gap-2 mt-2">
                            <Badge
                              variant="outline"
                              className="text-xs"
                            >
                              {category.testCases.filter(tc => tc.selected).length}/{category.testCases.length} selected
                            </Badge>
                            <Badge
                              className={`text-xs ${
                                category.testCases.every(tc => tc.status === 'pass') ? 'bg-green-100 text-green-800' :
                                category.testCases.some(tc => tc.status === 'fail') ? 'bg-red-100 text-red-800' :
                                category.testCases.some(tc => tc.status === 'running') ? 'bg-blue-100 text-blue-800' :
                                'bg-gray-100 text-gray-800'
                              }`}
                            >
                              {category.testCases.every(tc => tc.status === 'pass') ? 'All Passed' :
                               category.testCases.some(tc => tc.status === 'fail') ? 'Some Failed' :
                               category.testCases.some(tc => tc.status === 'running') ? 'Running' :
                               'Pending'}
                            </Badge>
                          </div>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          {category.testCases.map((testCase) => {
                            const linkedConnections = partnerOSConnections.filter(conn =>
                              conn.linkedTestCases.includes(testCase.id)
                            );
                            const linkedQueries = splunkQueries.filter(query =>
                              query.linkedTestCases.includes(testCase.id)
                            );

                            return (
                              <div key={testCase.id} className="space-y-2">
                                <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border">
                                  <div className="flex items-center gap-3">
                                    <Checkbox
                                      checked={testCase.selected}
                                      onCheckedChange={() => toggleTestCase(backendTestCategories, setBackendTestCategories, category.id, testCase.id)}
                                      disabled={isRunningBackendTests}
                                    />
                                    <div className="flex-1 min-w-0">
                                      <p className="text-sm font-medium text-slate-900 truncate">{testCase.name}</p>
                                      <p className="text-xs text-slate-500 truncate">{testCase.description}</p>
                                    </div>
                                  </div>
                                  <div className="flex items-center gap-2">
                                    {getStatusIcon(testCase.status)}
                                    <Button
                                      size="sm"
                                      variant="ghost"
                                      onClick={() => openTestCaseDetails(testCase)}
                                      disabled={isRunningBackendTests}
                                    >
                                      <Edit3 className="h-3 w-3" />
                                    </Button>
                                  </div>
                                </div>

                                {/* Show linked connections and queries */}
                                <div className="ml-8 space-y-1">
                                  {linkedConnections.length > 0 && (
                                    <div className="flex items-center gap-2 text-xs text-slate-500">
                                      <Link2 className="h-3 w-3" />
                                      <span>PartnerOS Connections:</span>
                                      {linkedConnections.map(conn => (
                                        <Badge key={conn.id} variant="outline" className="text-xs">
                                          {conn.method} {conn.name}
                                        </Badge>
                                      ))}
                                    </div>
                                  )}
                                  {linkedQueries.length > 0 && (
                                    <div className="flex items-center gap-2 text-xs text-slate-500">
                                      <FileText className="h-3 w-3" />
                                      <span>Splunk Queries:</span>
                                      {linkedQueries.map(query => (
                                        <Badge key={query.id} variant="outline" className="text-xs">
                                          {query.name} ({query.partner})
                                        </Badge>
                                      ))}
                                    </div>
                                  )}
                                  {linkedConnections.length === 0 && linkedQueries.length === 0 && (
                                    <div className="text-xs text-amber-600">
                                      ⚠️ No linked connections or queries found
                                    </div>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                          <div className="pt-2 border-t">
                            <div className="flex items-center justify-between text-xs text-slate-500">
                              <span>Framework:</span>
                              <code className="bg-slate-100 px-2 py-1 rounded">
                                Playwright + API + Logs
                              </code>
                            </div>
                            <div className="flex items-center justify-between text-xs text-slate-500 mt-1">
                              <span>Test Path:</span>
                              <code className="bg-slate-100 px-2 py-1 rounded">
                                tests/backend/{category.id}/*.py
                              </code>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* PartnerOS Connection Tab */}
          <TabsContent value="partneros">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <Link2 className="h-5 w-5" />
                      PartnerOS Connections
                    </CardTitle>
                    <CardDescription>
                      Manage and execute API connections to PartnerOS endpoints
                    </CardDescription>
                  </div>
                  <Button
                    onClick={() => setIsAddingPartnerOSConnection(true)}
                    className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold"
                  >
                    + Add Connection
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {partnerOSConnections.map((connection) => (
                  <Card key={connection.id} className="border-slate-200">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="space-y-3 flex-1">
                          <div className="flex items-center gap-3">
                            <Badge className={`${connection.method === 'GET' ? 'bg-green-100 text-green-800' : connection.method === 'POST' ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800'}`}>
                              {connection.method}
                            </Badge>
                            <h3 className="font-semibold text-slate-900">{connection.name}</h3>
                          </div>
                          <div className="space-y-2">
                            <div>
                              <label className="text-xs font-medium text-slate-500">URL:</label>
                              <p className="text-sm text-slate-600 font-mono bg-slate-50 p-2 rounded border">
                                {connection.url}
                              </p>
                            </div>
                            {connection.headers && (
                              <div>
                                <label className="text-xs font-medium text-slate-500">Headers:</label>
                                <p className="text-sm text-slate-600 font-mono bg-slate-50 p-2 rounded border whitespace-pre-line">
                                  {connection.headers}
                                </p>
                              </div>
                            )}
                            {connection.body && (
                              <div>
                                <label className="text-xs font-medium text-slate-500">Body:</label>
                                <p className="text-sm text-slate-600 font-mono bg-slate-50 p-2 rounded border whitespace-pre-line">
                                  {connection.body}
                                </p>
                              </div>
                            )}
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs text-slate-500">Linked Test Cases:</span>
                            {connection.linkedTestCases.map((testCaseId) => (
                              <Badge key={testCaseId} variant="outline" className="text-xs">
                                {testCaseId}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <div className="flex items-center gap-2 ml-4">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setEditingPartnerOSConnection(connection)}
                          >
                            <Edit3 className="h-3 w-3" />
                          </Button>
                          <Button
                            size="sm"
                            onClick={() => runPartnerOSConnection(connection.id)}
                            className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold"
                          >
                            <Play className="h-3 w-3 mr-1" />
                            Run
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Backend Logs Tab */}
          <TabsContent value="logs">
            <div className="space-y-6">
              {/* Splunk Queries Management */}
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <FileText className="h-5 w-5" />
                        Splunk Query Management
                      </CardTitle>
                      <CardDescription>
                        Create and manage partner-specific Splunk queries linked to test cases
                      </CardDescription>
                    </div>
                    <Button
                      onClick={() => setIsAddingSplunkQuery(true)}
                      className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold"
                    >
                      + Add Query
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {splunkQueries.map((query) => (
                      <Card key={query.id} className="border-slate-200">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between">
                            <div className="space-y-3 flex-1">
                              <div className="flex items-center gap-3">
                                <h3 className="font-semibold text-slate-900">{query.name}</h3>
                                <Badge className="bg-purple-100 text-purple-800">
                                  {query.partner}
                                </Badge>
                                <Badge
                                  className={query.isActive ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}
                                >
                                  {query.isActive ? "Active" : "Inactive"}
                                </Badge>
                              </div>
                              <div className="bg-slate-50 p-3 rounded border font-mono text-sm">
                                {query.query}
                              </div>
                              <div className="flex items-center gap-2">
                                <span className="text-xs text-slate-500">Linked Test Cases:</span>
                                {query.linkedTestCases.map((testCaseId) => (
                                  <Badge key={testCaseId} variant="outline" className="text-xs">
                                    {testCaseId}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                            <div className="flex items-center gap-2 ml-4">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => setEditingSplunkQuery(query)}
                              >
                                <Edit3 className="h-3 w-3" />
                              </Button>
                              <Button
                                size="sm"
                                onClick={() => runSplunkQuery(query.id)}
                                className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold"
                              >
                                <Play className="h-3 w-3 mr-1" />
                                Run
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Live Log Output */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    Live Log Output
                  </CardTitle>
                  <CardDescription>
                    Real-time Splunk query results and system logs
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="bg-slate-900 text-green-400 p-4 rounded-lg font-mono text-sm min-h-[300px] max-h-[400px] overflow-y-auto">
                    <div className="space-y-1">
                      {logOutput.map((line, index) => (
                        <div
                          key={index}
                          className={`
                            ${line.includes('ERROR') ? 'text-red-400' : ''}
                            ${line.includes('WARN') ? 'text-yellow-400' : ''}
                            ${line.includes('RESULT') ? 'text-blue-400' : ''}
                          `}
                        >
                          {line}
                        </div>
                      ))}
                      <div className="text-gray-500 animate-pulse">█</div>
                    </div>
                  </div>
                  <div className="flex justify-between items-center mt-4">
                    <div className="text-sm text-slate-500">
                      Selected Test Cases: {getSelectedTestCaseIds().join(', ') || 'None'}
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setLogOutput(prev => prev.slice(0, 5))}
                    >
                      Clear Logs
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Results Tab */}
          <TabsContent value="results">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5" />
                  Test Results
                </CardTitle>
                <CardDescription>
                  Analysis and reporting of test execution results
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {/* Test Summary Stats */}
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <Card className="bg-green-50 border-green-200">
                      <CardContent className="p-4 text-center">
                        <div className="text-2xl font-bold text-green-700">12</div>
                        <div className="text-sm text-green-600">Passed</div>
                      </CardContent>
                    </Card>
                    <Card className="bg-red-50 border-red-200">
                      <CardContent className="p-4 text-center">
                        <div className="text-2xl font-bold text-red-700">3</div>
                        <div className="text-sm text-red-600">Failed</div>
                      </CardContent>
                    </Card>
                    <Card className="bg-blue-50 border-blue-200">
                      <CardContent className="p-4 text-center">
                        <div className="text-2xl font-bold text-blue-700">2</div>
                        <div className="text-sm text-blue-600">Running</div>
                      </CardContent>
                    </Card>
                    <Card className="bg-gray-50 border-gray-200">
                      <CardContent className="p-4 text-center">
                        <div className="text-2xl font-bold text-gray-700">8</div>
                        <div className="text-sm text-gray-600">Pending</div>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Results Table Placeholder */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Detailed Test Results</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="text-sm text-slate-500 text-center py-8">
                          Results will appear here after test execution...
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* PartnerOS Connection Editor Modal */}
        {(isAddingPartnerOSConnection || editingPartnerOSConnection) && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <Card className="w-full max-w-2xl max-h-[90vh] flex flex-col">
              <CardHeader className="flex-shrink-0">
                <CardTitle>
                  {editingPartnerOSConnection ? 'Edit PartnerOS Connection' : 'Add New PartnerOS Connection'}
                </CardTitle>
                <CardDescription>
                  Configure API connections to PartnerOS endpoints with environment variable support
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6 flex-1 overflow-y-auto">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Connection Name</label>
                    <Input
                      placeholder="Enter connection name..."
                      defaultValue={editingPartnerOSConnection?.name || ""}
                      id="connection-name"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">HTTP Method</label>
                    <select
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                      defaultValue={editingPartnerOSConnection?.method || "GET"}
                      id="connection-method"
                    >
                      <option value="GET">GET</option>
                      <option value="POST">POST</option>
                      <option value="PUT">PUT</option>
                      <option value="DELETE">DELETE</option>
                      <option value="PATCH">PATCH</option>
                    </select>
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">URL</label>
                  <Input
                    placeholder="https://api.partneros.com/... (use ${environment.identifier} for variables)"
                    defaultValue={editingPartnerOSConnection?.url || ""}
                    id="connection-url"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Headers (one per line)</label>
                  <textarea
                    className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    placeholder="Authorization: Bearer ${environment.identifier}&#10;Content-Type: application/json"
                    defaultValue={editingPartnerOSConnection?.headers || ""}
                    id="connection-headers"
                    rows={3}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Request Body (JSON)</label>
                  <textarea
                    className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    placeholder='{"counterID": "${environment.counterID}", "reference": "${environment.reference}"}'
                    defaultValue={editingPartnerOSConnection?.body || ""}
                    id="connection-body"
                    rows={4}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Linked Test Cases</label>
                  <div className="max-h-64 overflow-y-auto border rounded p-2 space-y-2">
                    {[...uiTestCategories, ...backendTestCategories].map(category => (
                      <Collapsible key={category.id} defaultOpen={true}>
                        <CollapsibleTrigger className="flex items-center justify-between w-full p-2 bg-slate-100 rounded hover:bg-slate-200 transition-colors">
                          <span className="text-sm font-medium text-slate-700">{category.name}</span>
                          <ChevronDown className="h-4 w-4 text-slate-500 transition-transform data-[state=open]:rotate-180" />
                        </CollapsibleTrigger>
                        <CollapsibleContent className="pt-2">
                          <div className="space-y-2 pl-4">
                            {category.testCases.map(tc => (
                              <div key={tc.id} className="flex items-center space-x-2">
                                <Checkbox
                                  id={`conn-link-${tc.id}`}
                                  defaultChecked={editingPartnerOSConnection?.linkedTestCases?.includes(tc.id)}
                                />
                                <label
                                  htmlFor={`conn-link-${tc.id}`}
                                  className="text-xs text-slate-600 cursor-pointer flex-1"
                                >
                                  {tc.name}
                                </label>
                              </div>
                            ))}
                          </div>
                        </CollapsibleContent>
                      </Collapsible>
                    ))}
                  </div>
                </div>
              </CardContent>
              <div className="flex-shrink-0 p-6 pt-0 border-t bg-white">
                <div className="flex justify-end gap-2">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setIsAddingPartnerOSConnection(false);
                      setEditingPartnerOSConnection(null);
                      if (modalNavigationSource === 'testcase' && selectedTestCase) {
                        setIsEditingDetails(true);
                      }
                      setModalNavigationSource('main');
                    }}
                  >
                    Cancel
                  </Button>
                  {editingPartnerOSConnection && (
                    <Button
                      variant="destructive"
                      onClick={() => {
                        deletePartnerOSConnection(editingPartnerOSConnection.id);
                        setEditingPartnerOSConnection(null);
                      }}
                    >
                      Delete
                    </Button>
                  )}
                  <Button
                    onClick={() => {
                      const connectionName = (document.getElementById('connection-name') as HTMLInputElement)?.value;
                      const connectionMethod = (document.getElementById('connection-method') as HTMLSelectElement)?.value;
                      const connectionUrl = (document.getElementById('connection-url') as HTMLInputElement)?.value;
                      const connectionHeaders = (document.getElementById('connection-headers') as HTMLTextAreaElement)?.value;
                      const connectionBody = (document.getElementById('connection-body') as HTMLTextAreaElement)?.value;

                      const linkedTestCases = [...uiTestCategories, ...backendTestCategories]
                        .flatMap(cat => cat.testCases)
                        .filter(tc => (document.getElementById(`conn-link-${tc.id}`) as HTMLInputElement)?.checked)
                        .map(tc => tc.id);

                      savePartnerOSConnection({
                        name: connectionName,
                        method: connectionMethod,
                        url: connectionUrl,
                        headers: connectionHeaders,
                        body: connectionBody,
                        linkedTestCases
                      });

                      if (modalNavigationSource === 'testcase' && selectedTestCase) {
                        setTimeout(() => {
                          setIsEditingDetails(true);
                        }, 100);
                      }
                      setModalNavigationSource('main');
                    }}
                    className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold"
                  >
                    Save Connection
                  </Button>
                </div>
              </div>
            </Card>
          </div>
        )}

        {/* Splunk Query Editor Modal */}
        {(isAddingSplunkQuery || editingSplunkQuery) && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <Card className="w-full max-w-2xl">
              <CardHeader>
                <CardTitle>
                  {editingSplunkQuery ? 'Edit Splunk Query' : 'Add New Splunk Query'}
                </CardTitle>
                <CardDescription>
                  Configure partner-specific Splunk queries for log analysis
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Query Name</label>
                    <Input
                      placeholder="Enter query name..."
                      defaultValue={editingSplunkQuery?.name || ""}
                      id="query-name"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Partner</label>
                    <Input
                      placeholder="Enter partner name..."
                      defaultValue={editingSplunkQuery?.partner || ""}
                      id="partner-name"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Splunk Query</label>
                  <textarea
                    className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    placeholder="Enter Splunk search query..."
                    defaultValue={editingSplunkQuery?.query || ""}
                    id="splunk-query"
                    rows={4}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Linked Test Cases</label>
                  <div className="max-h-64 overflow-y-auto border rounded p-2 space-y-2">
                    {[...uiTestCategories, ...backendTestCategories].map(category => (
                      <Collapsible key={category.id} defaultOpen={true}>
                        <CollapsibleTrigger className="flex items-center justify-between w-full p-2 bg-slate-100 rounded hover:bg-slate-200 transition-colors">
                          <span className="text-sm font-medium text-slate-700">{category.name}</span>
                          <ChevronDown className="h-4 w-4 text-slate-500 transition-transform data-[state=open]:rotate-180" />
                        </CollapsibleTrigger>
                        <CollapsibleContent className="pt-2">
                          <div className="space-y-2 pl-4">
                            {category.testCases.map(tc => (
                              <div key={tc.id} className="flex items-center space-x-2">
                                <Checkbox
                                  id={`link-${tc.id}`}
                                  defaultChecked={editingSplunkQuery?.linkedTestCases?.includes(tc.id)}
                                />
                                <label
                                  htmlFor={`link-${tc.id}`}
                                  className="text-xs text-slate-600 cursor-pointer flex-1"
                                >
                                  {tc.name}
                                </label>
                              </div>
                            ))}
                          </div>
                        </CollapsibleContent>
                      </Collapsible>
                    ))}
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="is-active"
                    defaultChecked={editingSplunkQuery?.isActive || false}
                  />
                  <label htmlFor="is-active" className="text-sm font-medium">
                    Make this query active
                  </label>
                </div>
                <div className="flex justify-end gap-2">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setIsAddingSplunkQuery(false);
                      setEditingSplunkQuery(null);
                      if (modalNavigationSource === 'testcase' && selectedTestCase) {
                        setIsEditingDetails(true);
                      }
                      setModalNavigationSource('main');
                    }}
                  >
                    Cancel
                  </Button>
                  {editingSplunkQuery && (
                    <Button
                      variant="destructive"
                      onClick={() => {
                        deleteSplunkQuery(editingSplunkQuery.id);
                        setEditingSplunkQuery(null);
                      }}
                    >
                      Delete
                    </Button>
                  )}
                  <Button
                    onClick={() => {
                      const queryName = (document.getElementById('query-name') as HTMLInputElement)?.value;
                      const partnerName = (document.getElementById('partner-name') as HTMLInputElement)?.value;
                      const splunkQuery = (document.getElementById('splunk-query') as HTMLTextAreaElement)?.value;
                      const isActive = (document.getElementById('is-active') as HTMLInputElement)?.checked;

                      const linkedTestCases = [...uiTestCategories, ...backendTestCategories]
                        .flatMap(cat => cat.testCases)
                        .filter(tc => (document.getElementById(`link-${tc.id}`) as HTMLInputElement)?.checked)
                        .map(tc => tc.id);

                      saveSplunkQuery({
                        name: queryName,
                        partner: partnerName,
                        query: splunkQuery,
                        linkedTestCases,
                        isActive
                      });

                      if (modalNavigationSource === 'testcase' && selectedTestCase) {
                        setTimeout(() => {
                          setIsEditingDetails(true);
                        }, 100);
                      }
                      setModalNavigationSource('main');
                    }}
                    className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold"
                  >
                    Save Query
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Enhanced Test Case Details Modal */}
        {isEditingDetails && selectedTestCase && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <Card className="w-full max-w-4xl max-h-[90vh] overflow-y-auto">
              <CardHeader>
                <CardTitle>Edit Test Case Details</CardTitle>
                <CardDescription>{selectedTestCase.name} - {selectedTestCase.description}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Test Case Details */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-slate-900">Test Case Configuration</h3>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Test Case to Run</label>
                      <textarea
                        className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                        placeholder="Enter detailed test case instructions..."
                        defaultValue={selectedTestCase.details?.testToRun || ""}
                        id="test-case-to-run"
                        rows={3}
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Expected Results</label>
                      <textarea
                        className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                        placeholder="Enter expected test results..."
                        defaultValue={selectedTestCase.details?.expectedResults || ""}
                        id="test-case-expected-results"
                        rows={3}
                      />
                    </div>
                  </div>

                  {/* Environment Variables Reference */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-slate-900">Environment Variables</h3>
                    <div className="bg-slate-50 p-3 rounded border space-y-2">
                      <p className="text-xs text-slate-600">Available for use in connections and queries:</p>
                      <div className="grid grid-cols-1 gap-1 font-mono text-xs">
                        <div><span className="text-blue-600">${`{environment.identifier}`}</span> = {environment.identifier || 'not_set'}</div>
                        <div><span className="text-blue-600">${`{environment.counterID}`}</span> = {environment.counterID || 'not_set'}</div>
                        <div><span className="text-blue-600">${`{environment.reference}`}</span> = {environment.reference || 'not_set'}</div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* PartnerOS Connections */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold text-slate-900">PartnerOS Connections</h3>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setModalNavigationSource('testcase');
                        setIsAddingPartnerOSConnection(true);
                        setIsEditingDetails(false);
                      }}
                      className="text-yellow-600 border-yellow-300 hover:bg-yellow-50"
                    >
                      + Add New Connection
                    </Button>
                  </div>
                  <div className="grid grid-cols-1 gap-3 max-h-48 overflow-y-auto">
                    {partnerOSConnections.map(connection => {
                      const isLinked = connection.linkedTestCases.includes(selectedTestCase.id);
                      return (
                        <div key={connection.id} className={`p-3 rounded border ${isLinked ? 'bg-yellow-50 border-yellow-200' : 'bg-slate-50'}`}>
                          <div className="flex items-start justify-between">
                            <div className="flex items-start gap-3">
                              <Checkbox
                                checked={isLinked}
                                onCheckedChange={(checked) => {
                                  if (checked) {
                                    // Add test case to connection's linked test cases
                                    setPartnerOSConnections(prev => prev.map(conn =>
                                      conn.id === connection.id
                                        ? { ...conn, linkedTestCases: [...conn.linkedTestCases, selectedTestCase.id] }
                                        : conn
                                    ));
                                  } else {
                                    // Remove test case from connection's linked test cases
                                    setPartnerOSConnections(prev => prev.map(conn =>
                                      conn.id === connection.id
                                        ? { ...conn, linkedTestCases: conn.linkedTestCases.filter(id => id !== selectedTestCase.id) }
                                        : conn
                                    ));
                                  }
                                }}
                                id={`conn-${connection.id}`}
                              />
                              <div className="space-y-1">
                                <div className="flex items-center gap-2">
                                  <Badge className={`${connection.method === 'GET' ? 'bg-green-100 text-green-800' : connection.method === 'POST' ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800'}`}>
                                    {connection.method}
                                  </Badge>
                                  <span className="font-medium text-sm">{connection.name}</span>
                                </div>
                                <p className="text-xs text-slate-500 font-mono">{connection.url}</p>
                              </div>
                            </div>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => {
                                setModalNavigationSource('testcase');
                                setEditingPartnerOSConnection(connection);
                                setIsEditingDetails(false);
                              }}
                            >
                              <Edit3 className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Splunk Queries */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold text-slate-900">Splunk Log Queries</h3>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setModalNavigationSource('testcase');
                        setIsAddingSplunkQuery(true);
                        setIsEditingDetails(false);
                      }}
                      className="text-purple-600 border-purple-300 hover:bg-purple-50"
                    >
                      + Add New Query
                    </Button>
                  </div>
                  <div className="grid grid-cols-1 gap-3 max-h-48 overflow-y-auto">
                    {splunkQueries.map(query => {
                      const isLinked = query.linkedTestCases.includes(selectedTestCase.id);
                      return (
                        <div key={query.id} className={`p-3 rounded border ${isLinked ? 'bg-purple-50 border-purple-200' : 'bg-slate-50'}`}>
                          <div className="flex items-start justify-between">
                            <div className="flex items-start gap-3">
                              <Checkbox
                                checked={isLinked}
                                onCheckedChange={(checked) => {
                                  if (checked) {
                                    // Add test case to query's linked test cases
                                    setSplunkQueries(prev => prev.map(q =>
                                      q.id === query.id
                                        ? { ...q, linkedTestCases: [...q.linkedTestCases, selectedTestCase.id] }
                                        : q
                                    ));
                                  } else {
                                    // Remove test case from query's linked test cases
                                    setSplunkQueries(prev => prev.map(q =>
                                      q.id === query.id
                                        ? { ...q, linkedTestCases: q.linkedTestCases.filter(id => id !== selectedTestCase.id) }
                                        : q
                                    ));
                                  }
                                }}
                                id={`query-${query.id}`}
                              />
                              <div className="space-y-1">
                                <div className="flex items-center gap-2">
                                  <Badge className="bg-purple-100 text-purple-800">
                                    {query.partner}
                                  </Badge>
                                  <span className="font-medium text-sm">{query.name}</span>
                                  <Badge className={query.isActive ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"} >
                                    {query.isActive ? "Active" : "Inactive"}
                                  </Badge>
                                </div>
                                <p className="text-xs text-slate-500 font-mono truncate">{query.query}</p>
                              </div>
                            </div>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => {
                                setModalNavigationSource('testcase');
                                setEditingSplunkQuery(query);
                                setIsEditingDetails(false);
                              }}
                            >
                              <Edit3 className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex justify-end gap-2 pt-4 border-t">
                  <Button variant="outline" onClick={() => setIsEditingDetails(false)}>
                    Cancel
                  </Button>
                  <Button
                    onClick={() => {
                      const testToRun = (document.getElementById('test-case-to-run') as HTMLTextAreaElement)?.value;
                      const expectedResults = (document.getElementById('test-case-expected-results') as HTMLTextAreaElement)?.value;

                      saveTestCaseDetails({
                        testToRun: testToRun || "",
                        expectedResults: expectedResults || ""
                      });
                    }}
                    className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold"
                  >
                    Save Test Case
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </main>
    </div>
  );
}
