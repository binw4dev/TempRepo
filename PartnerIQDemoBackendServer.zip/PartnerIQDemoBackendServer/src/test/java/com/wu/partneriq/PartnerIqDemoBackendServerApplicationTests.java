package com.wu.partneriq;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PartnerIqDemoBackendServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
