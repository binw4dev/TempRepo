package com.wu.partneros.mock.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wu.partneriq.util.FileUtils;
import com.wu.partneros.metadata.sdk.model.CreateOrderRequestFields;
import com.wu.partneros.metadata.sdk.model.QuoteResponse;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.io.IOException;

@Service
public class PartnerOSMetadataService {
    public QuoteResponse getPricingQuoteMetadata(String module, String path) {
        try {
            if (module.equalsIgnoreCase("Pricing_Quote") &&
                    path.equalsIgnoreCase("Quote")) {

                File file = ResourceUtils.getFile("payload/json/partneros/partneros_getmetadata_pricing_quote_reply.json");
                String jsonStr = FileUtils.readFileToOneLineString(file);
                ObjectMapper mapper = new ObjectMapper();
                QuoteResponse quoteResponse = mapper.readValue(jsonStr, QuoteResponse.class);
                return quoteResponse;
            } else {
                return null;
            }
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public QuoteResponse getOrderCreateMetadata(CreateOrderRequestFields createOrderRequest) {
        try {
            File file = ResourceUtils.getFile("payload/json/partneros/partneros_getmetadata_order_create_reply.json");
            String jsonStr = FileUtils.readFileToOneLineString(file);
            ObjectMapper mapper = new ObjectMapper();
            QuoteResponse quoteResponse = mapper.readValue(jsonStr, QuoteResponse.class);
            return quoteResponse;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
