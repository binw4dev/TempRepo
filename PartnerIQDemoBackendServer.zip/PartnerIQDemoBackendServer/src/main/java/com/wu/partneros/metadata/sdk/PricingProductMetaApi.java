package com.wu.partneros.metadata.sdk;

import com.wu.partneros.metadata.ApiClient;
import com.wu.partneros.metadata.sdk.model.QuoteResponse;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.client.WebClient.ResponseSpec;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@jakarta.annotation.Generated(value = "org.openapitools.codegen.languages.JavaClientCodegen", date = "2025-07-17T08:39:17.325515300+08:00[Asia/Shanghai]", comments = "Generator version: 7.14.0")
public class PricingProductMetaApi {
    private ApiClient apiClient;

    public PricingProductMetaApi() {
        this(new ApiClient());
    }

    public PricingProductMetaApi(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    public ApiClient getApiClient() {
        return apiClient;
    }

    public void setApiClient(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    
    /**
     * 
     * This API facilitates the partner to get the metadata required for the API. It provides the list of fields mandatory and optional
     * <p><b>200</b> - successful operation
     * <p><b>400</b> - Bad Request
     * <p><b>500</b> - Internal Server Error
     * @param module The module parameter
     * @param path The path parameter
     * @return QuoteResponse
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    private ResponseSpec pricingMetaRequestCreation(@jakarta.annotation.Nullable String module, @jakarta.annotation.Nullable String path) throws WebClientResponseException {
        Object postBody = null;
        // create path and map variables
        final Map<String, Object> pathParams = new HashMap<String, Object>();

        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, String> cookieParams = new LinkedMultiValueMap<String, String>();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();

        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "module", module));
        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "path", path));
        
        final String[] localVarAccepts = { 
            "application/json"
        };
        final List<MediaType> localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        final String[] localVarContentTypes = { };
        final MediaType localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[] {  };

        ParameterizedTypeReference<QuoteResponse> localVarReturnType = new ParameterizedTypeReference<QuoteResponse>() {};
        return apiClient.invokeAPI("/v1/partneros/meta/pricing/quote", HttpMethod.GET, pathParams, queryParams, postBody, headerParams, cookieParams, formParams, localVarAccept, localVarContentType, localVarAuthNames, localVarReturnType);
    }

    /**
     * 
     * This API facilitates the partner to get the metadata required for the API. It provides the list of fields mandatory and optional
     * <p><b>200</b> - successful operation
     * <p><b>400</b> - Bad Request
     * <p><b>500</b> - Internal Server Error
     * @param module The module parameter
     * @param path The path parameter
     * @return QuoteResponse
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    public Mono<QuoteResponse> pricingMeta(@jakarta.annotation.Nullable String module, @jakarta.annotation.Nullable String path) throws WebClientResponseException {
        ParameterizedTypeReference<QuoteResponse> localVarReturnType = new ParameterizedTypeReference<QuoteResponse>() {};
        return pricingMetaRequestCreation(module, path).bodyToMono(localVarReturnType);
    }

    /**
     * 
     * This API facilitates the partner to get the metadata required for the API. It provides the list of fields mandatory and optional
     * <p><b>200</b> - successful operation
     * <p><b>400</b> - Bad Request
     * <p><b>500</b> - Internal Server Error
     * @param module The module parameter
     * @param path The path parameter
     * @return ResponseEntity&lt;QuoteResponse&gt;
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    public Mono<ResponseEntity<QuoteResponse>> pricingMetaWithHttpInfo(@jakarta.annotation.Nullable String module, @jakarta.annotation.Nullable String path) throws WebClientResponseException {
        ParameterizedTypeReference<QuoteResponse> localVarReturnType = new ParameterizedTypeReference<QuoteResponse>() {};
        return pricingMetaRequestCreation(module, path).toEntity(localVarReturnType);
    }

    /**
     * 
     * This API facilitates the partner to get the metadata required for the API. It provides the list of fields mandatory and optional
     * <p><b>200</b> - successful operation
     * <p><b>400</b> - Bad Request
     * <p><b>500</b> - Internal Server Error
     * @param module The module parameter
     * @param path The path parameter
     * @return ResponseSpec
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    public ResponseSpec pricingMetaWithResponseSpec(@jakarta.annotation.Nullable String module, @jakarta.annotation.Nullable String path) throws WebClientResponseException {
        return pricingMetaRequestCreation(module, path);
    }
}
