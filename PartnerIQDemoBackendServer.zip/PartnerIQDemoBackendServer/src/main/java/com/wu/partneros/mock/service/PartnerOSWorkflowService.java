package com.wu.partneros.mock.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wu.partneriq.util.FileUtils;
import com.wu.partneros.workflow.sdk.model.WorkflowResponse;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.io.IOException;

@Service
public class PartnerOSWorkflowService {
    public WorkflowResponse getWorkflow(String productName) {
        try {
            if(productName.equalsIgnoreCase("SENDMONEY")) {
                File file = ResourceUtils.getFile("payload/json/partneros/partneros_getworkflow_sendmoney_reply.json");
                String jsonStr = FileUtils.readFileToOneLineString(file);
                ObjectMapper mapper = new ObjectMapper();
                WorkflowResponse workflowResponse = mapper.readValue(jsonStr, WorkflowResponse.class);
                return workflowResponse;
            } else {
                return null;
            }
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
