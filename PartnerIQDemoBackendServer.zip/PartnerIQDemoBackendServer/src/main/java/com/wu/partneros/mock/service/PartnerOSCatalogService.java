package com.wu.partneros.mock.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wu.partneriq.util.FileUtils;
import com.wu.partneros.catalog.sdk.model.ModuleCatalogResponse;
import com.wu.partneros.catalog.sdk.model.ProductCatalogResponse;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.io.IOException;

@Service
public class PartnerOSCatalogService {
    public ProductCatalogResponse getProducts() {
        try {
            File file = ResourceUtils.getFile("payload/json/partneros/partneros_products_catalog_reply.json");
            String jsonStr = FileUtils.readFileToOneLineString(file);
            ObjectMapper mapper = new ObjectMapper();
            ProductCatalogResponse productCatalogResponse = mapper.readValue(jsonStr, ProductCatalogResponse.class);
            return productCatalogResponse;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public ModuleCatalogResponse getProductCatalog(String productName, String moduleName) {
        try {
            if(productName.equalsIgnoreCase("SENDMONEY") && moduleName.equalsIgnoreCase("Order")) {
                File file = ResourceUtils.getFile("payload/json/partneros/partneros_products_catalog_sendmoney_order_reply.json");
                String jsonStr = FileUtils.readFileToOneLineString(file);
                ObjectMapper mapper = new ObjectMapper();
                ModuleCatalogResponse moduleCatalogResponse = mapper.readValue(jsonStr, ModuleCatalogResponse.class);
                return moduleCatalogResponse;
            } else {
                return null;
            }
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
