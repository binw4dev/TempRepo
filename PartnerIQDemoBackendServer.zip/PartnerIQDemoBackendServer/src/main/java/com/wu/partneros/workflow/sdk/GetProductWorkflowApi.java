package com.wu.partneros.workflow.sdk;

import com.wu.partneros.workflow.ApiClient;
import com.wu.partneros.workflow.sdk.model.Product;
import com.wu.partneros.workflow.sdk.model.WorkflowResponse;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.client.WebClient.ResponseSpec;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@jakarta.annotation.Generated(value = "org.openapitools.codegen.languages.JavaClientCodegen", date = "2025-07-17T08:37:28.382603900+08:00[Asia/Shanghai]", comments = "Generator version: 7.14.0")
public class GetProductWorkflowApi {
    private ApiClient apiClient;

    public GetProductWorkflowApi() {
        this(new ApiClient());
    }

    public GetProductWorkflowApi(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    public ApiClient getApiClient() {
        return apiClient;
    }

    public void setApiClient(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    
    /**
     * 
     * This API facilitates the partner to search the list of the modules and their corresponding request fields and API details for a given product type and use case combination. It also provides if the response should be cached by partner and if so, for how much time.
     * <p><b>200</b> - Successful Operation
     * <p><b>400</b> - Bad Request
     * <p><b>500</b> - Internal Server Error
     * @param productName Name of the product to build the workflow API
     * @return WorkflowResponse
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    private ResponseSpec getProductWorkflowRequestCreation(@jakarta.annotation.Nullable Product productName) throws WebClientResponseException {
        Object postBody = null;
        // create path and map variables
        final Map<String, Object> pathParams = new HashMap<String, Object>();

        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, String> cookieParams = new LinkedMultiValueMap<String, String>();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();

        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "productName", productName));
        
        final String[] localVarAccepts = { 
            "application/json"
        };
        final List<MediaType> localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        final String[] localVarContentTypes = { };
        final MediaType localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[] {  };

        ParameterizedTypeReference<WorkflowResponse> localVarReturnType = new ParameterizedTypeReference<WorkflowResponse>() {};
        return apiClient.invokeAPI("/v1/partneros/workflow", HttpMethod.GET, pathParams, queryParams, postBody, headerParams, cookieParams, formParams, localVarAccept, localVarContentType, localVarAuthNames, localVarReturnType);
    }

    /**
     * 
     * This API facilitates the partner to search the list of the modules and their corresponding request fields and API details for a given product type and use case combination. It also provides if the response should be cached by partner and if so, for how much time.
     * <p><b>200</b> - Successful Operation
     * <p><b>400</b> - Bad Request
     * <p><b>500</b> - Internal Server Error
     * @param productName Name of the product to build the workflow API
     * @return WorkflowResponse
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    public Mono<WorkflowResponse> getProductWorkflow(@jakarta.annotation.Nullable Product productName) throws WebClientResponseException {
        ParameterizedTypeReference<WorkflowResponse> localVarReturnType = new ParameterizedTypeReference<WorkflowResponse>() {};
        return getProductWorkflowRequestCreation(productName).bodyToMono(localVarReturnType);
    }

    /**
     * 
     * This API facilitates the partner to search the list of the modules and their corresponding request fields and API details for a given product type and use case combination. It also provides if the response should be cached by partner and if so, for how much time.
     * <p><b>200</b> - Successful Operation
     * <p><b>400</b> - Bad Request
     * <p><b>500</b> - Internal Server Error
     * @param productName Name of the product to build the workflow API
     * @return ResponseEntity&lt;WorkflowResponse&gt;
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    public Mono<ResponseEntity<WorkflowResponse>> getProductWorkflowWithHttpInfo(@jakarta.annotation.Nullable Product productName) throws WebClientResponseException {
        ParameterizedTypeReference<WorkflowResponse> localVarReturnType = new ParameterizedTypeReference<WorkflowResponse>() {};
        return getProductWorkflowRequestCreation(productName).toEntity(localVarReturnType);
    }

    /**
     * 
     * This API facilitates the partner to search the list of the modules and their corresponding request fields and API details for a given product type and use case combination. It also provides if the response should be cached by partner and if so, for how much time.
     * <p><b>200</b> - Successful Operation
     * <p><b>400</b> - Bad Request
     * <p><b>500</b> - Internal Server Error
     * @param productName Name of the product to build the workflow API
     * @return ResponseSpec
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    public ResponseSpec getProductWorkflowWithResponseSpec(@jakarta.annotation.Nullable Product productName) throws WebClientResponseException {
        return getProductWorkflowRequestCreation(productName);
    }
}
