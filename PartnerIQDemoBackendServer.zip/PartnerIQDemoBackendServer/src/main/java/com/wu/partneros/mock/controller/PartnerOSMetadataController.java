package com.wu.partneros.mock.controller;

import com.wu.partneros.metadata.sdk.model.CreateOrderRequestFields;
import com.wu.partneros.metadata.sdk.model.QuoteResponse;
import com.wu.partneros.mock.service.PartnerOSMetadataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/v1/partneros/meta")
public class PartnerOSMetadataController {
    @Autowired
    PartnerOSMetadataService partnerOSMetadataService;

    @GetMapping("/pricing/quote")
    public QuoteResponse getPricingQuoteMetadata(@RequestParam(name = "module") String module,
                                          @RequestParam(name = "path") String path) {
        return partnerOSMetadataService.getPricingQuoteMetadata(module, path);
    }

    @PostMapping("/order/create")
    public QuoteResponse getOrderCreateMetadata(@RequestBody CreateOrderRequestFields createOrderRequest) {
        return partnerOSMetadataService.getOrderCreateMetadata(createOrderRequest);
    }
}
