package com.wu.partneros.mock.controller;

import com.wu.partneros.catalog.sdk.model.ModuleCatalogResponse;
import com.wu.partneros.catalog.sdk.model.ProductCatalogResponse;
import com.wu.partneros.mock.service.PartnerOSCatalogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/v1/partneros")
public class PartnerOSCatalogController {
    @Autowired
    PartnerOSCatalogService partnerOSCatalogService;

    @GetMapping("/products")
    public ProductCatalogResponse getProducts() {
        return partnerOSCatalogService.getProducts();
    }

    @GetMapping("/product/catalog")
    public ModuleCatalogResponse getProductCatalog(
            @RequestParam(name = "productName") String productName,
            @RequestParam(name = "moduleName") String moduleName) {
        return partnerOSCatalogService.getProductCatalog(productName, moduleName);
    }
}
