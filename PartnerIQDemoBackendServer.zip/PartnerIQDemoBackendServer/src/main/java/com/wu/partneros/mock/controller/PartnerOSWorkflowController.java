package com.wu.partneros.mock.controller;

import com.wu.partneros.mock.service.PartnerOSWorkflowService;
import com.wu.partneros.workflow.sdk.model.WorkflowResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/v1/partneros")
public class PartnerOSWorkflowController {
    @Autowired
    PartnerOSWorkflowService partnerOSWorkflowService;

    @GetMapping("/workflow")
    public WorkflowResponse getWorkflow(@RequestParam(name = "productName") String productName) {
        return partnerOSWorkflowService.getWorkflow(productName);
    }
}
