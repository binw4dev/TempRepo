package com.wu.partneriq.controller;

import com.wu.partneriq.service.MetadataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:3001"})
@RestController
@RequestMapping("/metadata")
public class MetadataController {
    @Autowired
    MetadataService metadataService;

    @GetMapping(path = "/cclist")
    public ResponseEntity<String> getCclist() {
        return metadataService.getCclist();
    }
}
