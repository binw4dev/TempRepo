
package com.wu.partneriq.model;

import java.util.LinkedHashMap;
import java.util.Map;
import jakarta.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import jakarta.validation.Valid;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "exchange_rate",
    "fix_on_send",
    "duplicate_detection_flag",
    "destination_country_currency",
    "stage_pay_fields",
    "recording_country_currency",
    "transaction_type",
    "expected_payout_location",
    "credit_debit_card_details",
    "originating_state",
    "originating_city",
    "mt_requested_status",
    "originating_country_currency",
    "payment_type",
    "pay_wo_id_indicator"
})
@Generated("jsonschema2pojo")
public class PaymentDetails2 {

    @JsonProperty("exchange_rate")
    private Double exchangeRate;
    @JsonProperty("fix_on_send")
    private String fixOnSend;
    @JsonProperty("duplicate_detection_flag")
    private String duplicateDetectionFlag;
    @JsonProperty("destination_country_currency")
    @Valid
    private DestinationCountryCurrency destinationCountryCurrency;
    @JsonProperty("stage_pay_fields")
    @Valid
    private StagePayFields stagePayFields;
    @JsonProperty("recording_country_currency")
    @Valid
    private RecordingCountryCurrency recordingCountryCurrency;
    @JsonProperty("transaction_type")
    private String transactionType;
    @JsonProperty("expected_payout_location")
    private String expectedPayoutLocation;
    @JsonProperty("credit_debit_card_details")
    @Valid
    private CreditDebitCardDetails creditDebitCardDetails;
    @JsonProperty("originating_state")
    private String originatingState;
    @JsonProperty("originating_city")
    private String originatingCity;
    @JsonProperty("mt_requested_status")
    private String mtRequestedStatus;
    @JsonProperty("originating_country_currency")
    @Valid
    private OriginatingCountryCurrency originatingCountryCurrency;
    @JsonProperty("payment_type")
    private String paymentType;
    @JsonProperty("pay_wo_id_indicator")
    private String payWoIdIndicator;
    @JsonIgnore
    @Valid
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("exchange_rate")
    public Double getExchangeRate() {
        return exchangeRate;
    }

    @JsonProperty("exchange_rate")
    public void setExchangeRate(Double exchangeRate) {
        this.exchangeRate = exchangeRate;
    }

    @JsonProperty("fix_on_send")
    public String getFixOnSend() {
        return fixOnSend;
    }

    @JsonProperty("fix_on_send")
    public void setFixOnSend(String fixOnSend) {
        this.fixOnSend = fixOnSend;
    }

    @JsonProperty("duplicate_detection_flag")
    public String getDuplicateDetectionFlag() {
        return duplicateDetectionFlag;
    }

    @JsonProperty("duplicate_detection_flag")
    public void setDuplicateDetectionFlag(String duplicateDetectionFlag) {
        this.duplicateDetectionFlag = duplicateDetectionFlag;
    }

    @JsonProperty("destination_country_currency")
    public DestinationCountryCurrency getDestinationCountryCurrency() {
        return destinationCountryCurrency;
    }

    @JsonProperty("destination_country_currency")
    public void setDestinationCountryCurrency(DestinationCountryCurrency destinationCountryCurrency) {
        this.destinationCountryCurrency = destinationCountryCurrency;
    }

    @JsonProperty("stage_pay_fields")
    public StagePayFields getStagePayFields() {
        return stagePayFields;
    }

    @JsonProperty("stage_pay_fields")
    public void setStagePayFields(StagePayFields stagePayFields) {
        this.stagePayFields = stagePayFields;
    }

    @JsonProperty("recording_country_currency")
    public RecordingCountryCurrency getRecordingCountryCurrency() {
        return recordingCountryCurrency;
    }

    @JsonProperty("recording_country_currency")
    public void setRecordingCountryCurrency(RecordingCountryCurrency recordingCountryCurrency) {
        this.recordingCountryCurrency = recordingCountryCurrency;
    }

    @JsonProperty("transaction_type")
    public String getTransactionType() {
        return transactionType;
    }

    @JsonProperty("transaction_type")
    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    @JsonProperty("expected_payout_location")
    public String getExpectedPayoutLocation() {
        return expectedPayoutLocation;
    }

    @JsonProperty("expected_payout_location")
    public void setExpectedPayoutLocation(String expectedPayoutLocation) {
        this.expectedPayoutLocation = expectedPayoutLocation;
    }

    @JsonProperty("credit_debit_card_details")
    public CreditDebitCardDetails getCreditDebitCardDetails() {
        return creditDebitCardDetails;
    }

    @JsonProperty("credit_debit_card_details")
    public void setCreditDebitCardDetails(CreditDebitCardDetails creditDebitCardDetails) {
        this.creditDebitCardDetails = creditDebitCardDetails;
    }

    @JsonProperty("originating_state")
    public String getOriginatingState() {
        return originatingState;
    }

    @JsonProperty("originating_state")
    public void setOriginatingState(String originatingState) {
        this.originatingState = originatingState;
    }

    @JsonProperty("originating_city")
    public String getOriginatingCity() {
        return originatingCity;
    }

    @JsonProperty("originating_city")
    public void setOriginatingCity(String originatingCity) {
        this.originatingCity = originatingCity;
    }

    @JsonProperty("mt_requested_status")
    public String getMtRequestedStatus() {
        return mtRequestedStatus;
    }

    @JsonProperty("mt_requested_status")
    public void setMtRequestedStatus(String mtRequestedStatus) {
        this.mtRequestedStatus = mtRequestedStatus;
    }

    @JsonProperty("originating_country_currency")
    public OriginatingCountryCurrency getOriginatingCountryCurrency() {
        return originatingCountryCurrency;
    }

    @JsonProperty("originating_country_currency")
    public void setOriginatingCountryCurrency(OriginatingCountryCurrency originatingCountryCurrency) {
        this.originatingCountryCurrency = originatingCountryCurrency;
    }

    @JsonProperty("payment_type")
    public String getPaymentType() {
        return paymentType;
    }

    @JsonProperty("payment_type")
    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    @JsonProperty("pay_wo_id_indicator")
    public String getPayWoIdIndicator() {
        return payWoIdIndicator;
    }

    @JsonProperty("pay_wo_id_indicator")
    public void setPayWoIdIndicator(String payWoIdIndicator) {
        this.payWoIdIndicator = payWoIdIndicator;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(PaymentDetails2.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("exchangeRate");
        sb.append('=');
        sb.append(((this.exchangeRate == null)?"<null>":this.exchangeRate));
        sb.append(',');
        sb.append("fixOnSend");
        sb.append('=');
        sb.append(((this.fixOnSend == null)?"<null>":this.fixOnSend));
        sb.append(',');
        sb.append("duplicateDetectionFlag");
        sb.append('=');
        sb.append(((this.duplicateDetectionFlag == null)?"<null>":this.duplicateDetectionFlag));
        sb.append(',');
        sb.append("destinationCountryCurrency");
        sb.append('=');
        sb.append(((this.destinationCountryCurrency == null)?"<null>":this.destinationCountryCurrency));
        sb.append(',');
        sb.append("stagePayFields");
        sb.append('=');
        sb.append(((this.stagePayFields == null)?"<null>":this.stagePayFields));
        sb.append(',');
        sb.append("recordingCountryCurrency");
        sb.append('=');
        sb.append(((this.recordingCountryCurrency == null)?"<null>":this.recordingCountryCurrency));
        sb.append(',');
        sb.append("transactionType");
        sb.append('=');
        sb.append(((this.transactionType == null)?"<null>":this.transactionType));
        sb.append(',');
        sb.append("expectedPayoutLocation");
        sb.append('=');
        sb.append(((this.expectedPayoutLocation == null)?"<null>":this.expectedPayoutLocation));
        sb.append(',');
        sb.append("creditDebitCardDetails");
        sb.append('=');
        sb.append(((this.creditDebitCardDetails == null)?"<null>":this.creditDebitCardDetails));
        sb.append(',');
        sb.append("originatingState");
        sb.append('=');
        sb.append(((this.originatingState == null)?"<null>":this.originatingState));
        sb.append(',');
        sb.append("originatingCity");
        sb.append('=');
        sb.append(((this.originatingCity == null)?"<null>":this.originatingCity));
        sb.append(',');
        sb.append("mtRequestedStatus");
        sb.append('=');
        sb.append(((this.mtRequestedStatus == null)?"<null>":this.mtRequestedStatus));
        sb.append(',');
        sb.append("originatingCountryCurrency");
        sb.append('=');
        sb.append(((this.originatingCountryCurrency == null)?"<null>":this.originatingCountryCurrency));
        sb.append(',');
        sb.append("paymentType");
        sb.append('=');
        sb.append(((this.paymentType == null)?"<null>":this.paymentType));
        sb.append(',');
        sb.append("payWoIdIndicator");
        sb.append('=');
        sb.append(((this.payWoIdIndicator == null)?"<null>":this.payWoIdIndicator));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

}
