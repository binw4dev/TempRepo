
package com.wu.partneriq.model;

import java.util.LinkedHashMap;
import java.util.Map;
import jakarta.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import jakarta.validation.Valid;
import jakarta.validation.constraints.DecimalMin;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "financials",
    "mtcn",
    "promotions",
    "receiver",
    "payment_details",
    "new_mtcn",
    "sender",
    "filing_date",
    "filing_time",
    "new_points_earned"
})
@Generated("jsonschema2pojo")
public class ConfirmOrderReply {

    @JsonProperty("financials")
    @Valid
    private Financials financials;
    @JsonProperty("mtcn")
    private Integer mtcn;
    @JsonProperty("promotions")
    @Valid
    private Promotions promotions;
    @JsonProperty("receiver")
    @Valid
    private Receiver receiver;
    @JsonProperty("payment_details")
    @Valid
    private PaymentDetails paymentDetails;
    @JsonProperty("new_mtcn")
    @DecimalMin("9223372036854775807")
    private Long newMtcn;
    @JsonProperty("sender")
    @Valid
    private Sender sender;
    @JsonProperty("filing_date")
    private String filingDate;
    @JsonProperty("filing_time")
    private String filingTime;
    @JsonProperty("new_points_earned")
    private Integer newPointsEarned;
    @JsonIgnore
    @Valid
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("financials")
    public Financials getFinancials() {
        return financials;
    }

    @JsonProperty("financials")
    public void setFinancials(Financials financials) {
        this.financials = financials;
    }

    @JsonProperty("mtcn")
    public Integer getMtcn() {
        return mtcn;
    }

    @JsonProperty("mtcn")
    public void setMtcn(Integer mtcn) {
        this.mtcn = mtcn;
    }

    @JsonProperty("promotions")
    public Promotions getPromotions() {
        return promotions;
    }

    @JsonProperty("promotions")
    public void setPromotions(Promotions promotions) {
        this.promotions = promotions;
    }

    @JsonProperty("receiver")
    public Receiver getReceiver() {
        return receiver;
    }

    @JsonProperty("receiver")
    public void setReceiver(Receiver receiver) {
        this.receiver = receiver;
    }

    @JsonProperty("payment_details")
    public PaymentDetails getPaymentDetails() {
        return paymentDetails;
    }

    @JsonProperty("payment_details")
    public void setPaymentDetails(PaymentDetails paymentDetails) {
        this.paymentDetails = paymentDetails;
    }

    @JsonProperty("new_mtcn")
    public Long getNewMtcn() {
        return newMtcn;
    }

    @JsonProperty("new_mtcn")
    public void setNewMtcn(Long newMtcn) {
        this.newMtcn = newMtcn;
    }

    @JsonProperty("sender")
    public Sender getSender() {
        return sender;
    }

    @JsonProperty("sender")
    public void setSender(Sender sender) {
        this.sender = sender;
    }

    @JsonProperty("filing_date")
    public String getFilingDate() {
        return filingDate;
    }

    @JsonProperty("filing_date")
    public void setFilingDate(String filingDate) {
        this.filingDate = filingDate;
    }

    @JsonProperty("filing_time")
    public String getFilingTime() {
        return filingTime;
    }

    @JsonProperty("filing_time")
    public void setFilingTime(String filingTime) {
        this.filingTime = filingTime;
    }

    @JsonProperty("new_points_earned")
    public Integer getNewPointsEarned() {
        return newPointsEarned;
    }

    @JsonProperty("new_points_earned")
    public void setNewPointsEarned(Integer newPointsEarned) {
        this.newPointsEarned = newPointsEarned;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(ConfirmOrderReply.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("financials");
        sb.append('=');
        sb.append(((this.financials == null)?"<null>":this.financials));
        sb.append(',');
        sb.append("mtcn");
        sb.append('=');
        sb.append(((this.mtcn == null)?"<null>":this.mtcn));
        sb.append(',');
        sb.append("promotions");
        sb.append('=');
        sb.append(((this.promotions == null)?"<null>":this.promotions));
        sb.append(',');
        sb.append("receiver");
        sb.append('=');
        sb.append(((this.receiver == null)?"<null>":this.receiver));
        sb.append(',');
        sb.append("paymentDetails");
        sb.append('=');
        sb.append(((this.paymentDetails == null)?"<null>":this.paymentDetails));
        sb.append(',');
        sb.append("newMtcn");
        sb.append('=');
        sb.append(((this.newMtcn == null)?"<null>":this.newMtcn));
        sb.append(',');
        sb.append("sender");
        sb.append('=');
        sb.append(((this.sender == null)?"<null>":this.sender));
        sb.append(',');
        sb.append("filingDate");
        sb.append('=');
        sb.append(((this.filingDate == null)?"<null>":this.filingDate));
        sb.append(',');
        sb.append("filingTime");
        sb.append('=');
        sb.append(((this.filingTime == null)?"<null>":this.filingTime));
        sb.append(',');
        sb.append("newPointsEarned");
        sb.append('=');
        sb.append(((this.newPointsEarned == null)?"<null>":this.newPointsEarned));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

}
