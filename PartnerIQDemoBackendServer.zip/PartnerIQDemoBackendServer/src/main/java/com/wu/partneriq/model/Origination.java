
package com.wu.partneriq.model;

import java.util.LinkedHashMap;
import java.util.Map;
import jakarta.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import jakarta.validation.Valid;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "country_iso_code",
    "currency_iso_code",
    "principal_amount"
})
@Generated("jsonschema2pojo")
public class Origination {

    @JsonProperty("country_iso_code")
    private String countryIsoCode;
    @JsonProperty("currency_iso_code")
    private String currencyIsoCode;
    @JsonProperty("principal_amount")
    private Integer principalAmount;
    @JsonIgnore
    @Valid
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("country_iso_code")
    public String getCountryIsoCode() {
        return countryIsoCode;
    }

    @JsonProperty("country_iso_code")
    public void setCountryIsoCode(String countryIsoCode) {
        this.countryIsoCode = countryIsoCode;
    }

    @JsonProperty("currency_iso_code")
    public String getCurrencyIsoCode() {
        return currencyIsoCode;
    }

    @JsonProperty("currency_iso_code")
    public void setCurrencyIsoCode(String currencyIsoCode) {
        this.currencyIsoCode = currencyIsoCode;
    }

    @JsonProperty("principal_amount")
    public Integer getPrincipalAmount() {
        return principalAmount;
    }

    @JsonProperty("principal_amount")
    public void setPrincipalAmount(Integer principalAmount) {
        this.principalAmount = principalAmount;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Origination.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("countryIsoCode");
        sb.append('=');
        sb.append(((this.countryIsoCode == null)?"<null>":this.countryIsoCode));
        sb.append(',');
        sb.append("currencyIsoCode");
        sb.append('=');
        sb.append(((this.currencyIsoCode == null)?"<null>":this.currencyIsoCode));
        sb.append(',');
        sb.append("principalAmount");
        sb.append('=');
        sb.append(((this.principalAmount == null)?"<null>":this.principalAmount));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

}
