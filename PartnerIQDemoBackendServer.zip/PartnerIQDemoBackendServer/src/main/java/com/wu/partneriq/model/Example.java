
package com.wu.partneriq.model;

import java.util.LinkedHashMap;
import java.util.Map;
import jakarta.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import jakarta.validation.Valid;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "quote-order-request",
    "quote-order-reply",
    "create-order-request",
    "create-order-reply",
    "confirm-order-request",
    "confirm-order-reply"
})
@Generated("jsonschema2pojo")
public class Example {

    @JsonProperty("quote-order-request")
    @Valid
    private QuoteOrderRequest quoteOrderRequest;
    @JsonProperty("quote-order-reply")
    @Valid
    private QuoteOrderReply quoteOrderReply;
    @JsonProperty("create-order-request")
    @Valid
    private CreateOrderRequest createOrderRequest;
    @JsonProperty("create-order-reply")
    @Valid
    private CreateOrderReply createOrderReply;
    @JsonProperty("confirm-order-request")
    @Valid
    private ConfirmOrderRequest confirmOrderRequest;
    @JsonProperty("confirm-order-reply")
    @Valid
    private ConfirmOrderReply confirmOrderReply;
    @JsonIgnore
    @Valid
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("quote-order-request")
    public QuoteOrderRequest getQuoteOrderRequest() {
        return quoteOrderRequest;
    }

    @JsonProperty("quote-order-request")
    public void setQuoteOrderRequest(QuoteOrderRequest quoteOrderRequest) {
        this.quoteOrderRequest = quoteOrderRequest;
    }

    @JsonProperty("quote-order-reply")
    public QuoteOrderReply getQuoteOrderReply() {
        return quoteOrderReply;
    }

    @JsonProperty("quote-order-reply")
    public void setQuoteOrderReply(QuoteOrderReply quoteOrderReply) {
        this.quoteOrderReply = quoteOrderReply;
    }

    @JsonProperty("create-order-request")
    public CreateOrderRequest getCreateOrderRequest() {
        return createOrderRequest;
    }

    @JsonProperty("create-order-request")
    public void setCreateOrderRequest(CreateOrderRequest createOrderRequest) {
        this.createOrderRequest = createOrderRequest;
    }

    @JsonProperty("create-order-reply")
    public CreateOrderReply getCreateOrderReply() {
        return createOrderReply;
    }

    @JsonProperty("create-order-reply")
    public void setCreateOrderReply(CreateOrderReply createOrderReply) {
        this.createOrderReply = createOrderReply;
    }

    @JsonProperty("confirm-order-request")
    public ConfirmOrderRequest getConfirmOrderRequest() {
        return confirmOrderRequest;
    }

    @JsonProperty("confirm-order-request")
    public void setConfirmOrderRequest(ConfirmOrderRequest confirmOrderRequest) {
        this.confirmOrderRequest = confirmOrderRequest;
    }

    @JsonProperty("confirm-order-reply")
    public ConfirmOrderReply getConfirmOrderReply() {
        return confirmOrderReply;
    }

    @JsonProperty("confirm-order-reply")
    public void setConfirmOrderReply(ConfirmOrderReply confirmOrderReply) {
        this.confirmOrderReply = confirmOrderReply;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Example.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("quoteOrderRequest");
        sb.append('=');
        sb.append(((this.quoteOrderRequest == null)?"<null>":this.quoteOrderRequest));
        sb.append(',');
        sb.append("quoteOrderReply");
        sb.append('=');
        sb.append(((this.quoteOrderReply == null)?"<null>":this.quoteOrderReply));
        sb.append(',');
        sb.append("createOrderRequest");
        sb.append('=');
        sb.append(((this.createOrderRequest == null)?"<null>":this.createOrderRequest));
        sb.append(',');
        sb.append("createOrderReply");
        sb.append('=');
        sb.append(((this.createOrderReply == null)?"<null>":this.createOrderReply));
        sb.append(',');
        sb.append("confirmOrderRequest");
        sb.append('=');
        sb.append(((this.confirmOrderRequest == null)?"<null>":this.confirmOrderRequest));
        sb.append(',');
        sb.append("confirmOrderReply");
        sb.append('=');
        sb.append(((this.confirmOrderReply == null)?"<null>":this.confirmOrderReply));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

}
