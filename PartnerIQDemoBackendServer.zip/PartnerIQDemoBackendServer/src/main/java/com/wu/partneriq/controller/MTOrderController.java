package com.wu.partneriq.controller;

import com.wu.partneriq.model.*;
import com.wu.partneriq.service.MTOrderService;
import com.wu.partneros.catalog.sdk.CatalogApiApi;
import com.wu.partneros.catalog.sdk.model.ProductCatalogResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/order")
public class MTOrderController {
    @Autowired
    MTOrderService mtOrderService;

    @PostMapping(path = "/quote")
    public ResponseEntity<QuoteOrderReply> quoteOrder(@RequestBody QuoteOrderRequest orderRequest) {
        return mtOrderService.quoteOrder(orderRequest);
    }

    @PostMapping(path = "/create")
    public ResponseEntity<CreateOrderReply> createOrder(@RequestBody CreateOrderRequest orderRequest) {
        return mtOrderService.createOrder(orderRequest);
    }

    @PostMapping(path = "/confirm")
    public ResponseEntity<ConfirmOrderReply> createOrder(@RequestBody ConfirmOrderRequest orderRequest) {
        return mtOrderService.confirmOrder(orderRequest);
    }

    @GetMapping(path = "/test/product/catalog")
    public Mono<ProductCatalogResponse> getProductCatalog() {
        CatalogApiApi api = new CatalogApiApi();
        return api.getProductCatalog();
    }
}
