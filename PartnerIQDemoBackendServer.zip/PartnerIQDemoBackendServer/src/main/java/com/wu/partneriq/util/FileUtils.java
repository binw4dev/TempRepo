package com.wu.partneriq.util;

import org.springframework.util.ResourceUtils;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FileUtils {
    public static String readFileToOneLineString(File srcFile) throws IOException {
        FileReader fr = new FileReader(srcFile);
        StringBuffer strBuf = new StringBuffer();
        BufferedReader br = new BufferedReader(fr);
        String line = "";
        while ((line = br.readLine()) != null) {
            strBuf.append(line.trim());
        }
        br.close();
        fr.close();
        return strBuf.toString();
    }

    public static final Function<Path, String> defaultFileReader = path -> {
        try {
            //return Files.readString(path, StandardCharsets.UTF_8);
            return readFileToOneLineString(path.toFile());
        } catch (IOException ioe) {
            throw new UncheckedIOException(ioe);
        }
    };

    public static void writeFileToPath(String filePath, String fileStr) {
        try {
            Files.writeString(Paths.get(filePath), fileStr, StandardOpenOption.CREATE_NEW);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static final BiConsumer<String, String> defaultFileWriter = (filePath, fileStr) -> {
        try {
            Files.writeString(Paths.get(filePath), fileStr, StandardOpenOption.CREATE_NEW);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    };

    public static Map<String, String> processFilesInPath(String filePath, Function<Path, String> fileReader) throws IOException {
        try (Stream<Path> paths = Files.walk(Paths.get(filePath))) {
            return paths
                    .filter(Files::isRegularFile)
                    .collect(Collectors.toMap(
                            path -> getFileNameNoExt(path.toFile()),
                            fileReader
                    ));
        } catch (IOException ioe) {
            throw new UncheckedIOException(ioe);
        }
    }

    public static String getFileNameNoExt(File file) {
        String filename = file.getName();
        if ((filename != null) && (filename.length() > 0)) {
            int dot = filename.lastIndexOf('.');
            if ((dot > -1) && (dot < (filename.length() - 1))) {
                return filename.substring(0, dot);
            }
        }
        return filename;
    }
}
