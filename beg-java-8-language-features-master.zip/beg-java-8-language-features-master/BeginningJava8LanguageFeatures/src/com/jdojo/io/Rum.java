// Rum.java
package com.jdojo.io;

public class Rum extends Drink {
	public Rum() {
		this.name = "Rum";
		this.price = 0.9;
	}
}
