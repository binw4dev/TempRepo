// Joiner.java
package com.jdojo.lambda;

@FunctionalInterface
public interface Joiner {
	String join(String s1, String s2);
}
