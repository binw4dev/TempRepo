// Sensitive.java
package com.jdojo.lambda;

public interface Sensitive {
	// It ia a marker interface. So, no method exists.
}
