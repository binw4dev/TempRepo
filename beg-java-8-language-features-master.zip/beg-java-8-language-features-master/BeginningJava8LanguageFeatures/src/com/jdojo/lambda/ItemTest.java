// ItemTest.java
package com.jdojo.lambda;

public class ItemTest {
	public static void main(String[] args) {
		Item apple = new Item("Apple", 0.75);
		apple.test();
	}
}
