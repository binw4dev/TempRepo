// Printer.java
package com.jdojo.lambda;

@FunctionalInterface
public interface Printer {
	void print(String msg);
}
