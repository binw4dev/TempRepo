// package-info.java
@Version(major=1, minor=0) 
package com.jdojo.annotation;
