import React, { useState, useEffect } from "react";
import { Container, Row, Col, Card } from "react-bootstrap";
import FolderTree from "./FolderTree";
import GridView from "./GridView";

const FileBrowser = () => {
    const [currentPath, setCurrentPath] = useState("generated-artifacts");
    const [items, setItems] = useState([]);

    const fetchFolder = async (path) => {
        const res = await fetch(`http://localhost:5000/list-dir?path=${encodeURIComponent(path)}`);
        const data = await res.json();
        setItems(data.items);
        setCurrentPath(data.currentPath);
    };

    //useEffect(() => {
        //fetchFolder(currentPath);
    //}, []);

    useEffect(() => {

        fetchFolder(currentPath);

        const intervalId = setInterval(() => {
            fetchFolder(currentPath);
        }, 5000);

        return () => clearInterval(intervalId);
    }, [currentPath]);

    const handleFolderClick = (folderName) => {
        const newPath = currentPath.endsWith("/")
            ? currentPath + folderName
            : currentPath + "/" + folderName;
        fetchFolder(newPath);
    };

    return (
        <Container>

            <Row>
                <Col md={12}>
                    <Card style={{ width: '100%', marginTop: '10px' }}>
                        <Card.Body>
                            <Card.Title style={{ fontSize: "16px", color: 'black', display: 'flex', justifyContent: "start" }}>
                                current path: {currentPath}
                            </Card.Title>
                            <div style={{ height: '250px', overflowY: 'auto' }}>
                                <GridView items={items} onFolderClick={handleFolderClick} />
                            </div>

                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </Container>
    );
};

export default FileBrowser;