import React, {Component} from 'react';
import logo from '../img/westernunion-logo.png';
import { Form } from 'react-bootstrap';

class Header extends Component {
    render() {
        return (
            <div style={{ backgroundColor: 'yellow', padding: '20px', display: 'flex', justifyContent: "start" }}>
                            <img src={logo} style={{ width: '180px', height: '43px' }}/>
                            <Form.Text style={{ marginLeft: '40px', fontFamily: 'URWGeometricSemiBold', fontSize: '30px', color: 'black' }}>PartnerIQ Demo Application</Form.Text>
                        </div>
        );
    }
}

export default Header;