import React, { useEffect, useState, useRef } from "react";
import TaskContainer from './TaskContainer';
import { withRouter } from "../utils/withRouter";
import { Button, Row, Col } from "react-bootstrap";
import FileBrowser from "./FileBrowser";


const Dashboard = () => {
    const [logs, setLogs] = useState([]);
    const logEndRef = useRef(null);

    useEffect(() => {
        if (logEndRef.current) {
            logEndRef.current.scrollIntoView({ behavior: 'smooth' });
        }
    }, [logs]);

    const printLog = (log) => {
        setLogs((prev) => [...prev, log]);
    };

    return (
        <div style={{ fontFamily: "URWGeometricRegular" }}>
            <Row>
                <Col sm={4}>
                    <div style={{ height: '700px', overflowY: 'auto' }}>
                        <TaskContainer title="1 - Create Backend"
                            taskUrl="http://localhost:5000/create-backend"
                            suffix="_create_backend"
                            printLog={printLog}
                            isDisabled={false} />
                        <TaskContainer title="2 - Create Frontend UI"
                            taskUrl="http://localhost:5000/create-frontend"
                            suffix="_create_frontend"
                            printLog={printLog}
                            isDisabled={false} />
                        <TaskContainer title="3 - Generate Service SDK"
                            taskUrl="http://localhost:5000/generate-sdk"
                            suffix="_generate_sdk"
                            printLog={printLog}
                            isDisabled={false} />
                    </div>
                </Col>
                <Col sm={8}>
                    <div style={{
                        height: "400px",
                        overflowY: "auto",
                        background: "#111",
                        color: "#0f0",
                        padding: "1em",
                        borderRadius: "8px"
                    }}>
                        {logs.map((log, idx) => (
                            <div key={idx} className="text-start">{log}</div>
                        ))}
                        <div ref={logEndRef} />
                    </div>
                    <div>
                        <FileBrowser />
                    </div>
                </Col>
            </Row>
        </div>
    );
};

export default withRouter(Dashboard);
