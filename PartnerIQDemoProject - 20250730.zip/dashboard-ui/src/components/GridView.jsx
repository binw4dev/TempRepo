import React from "react";
import { Card, Row, Col } from "react-bootstrap";
import { FolderFill, FileEarmarkText } from "react-bootstrap-icons";

//text-truncate

const GridView = ({ items, onFolderClick }) => {
  return (
    <Row className="mt-3">
      {items.map((item) => (
        <Col key={item.name} xs={6} sm={4} md={3} lg={2} className="mb-4">
          <Card
            onClick={() => {
              if (item.isDirectory) onFolderClick(item.name);
            }}
            className="text-center"
            style={{
              cursor: item.isDirectory ? "pointer" : "default",
              border: item.isDirectory ? "2px solid #0d6efd" : "1px solid #ccc",
              transition: "0.2s ease-in-out",
              height: "120px",
            }}
          >
            <Card.Body className="d-flex flex-column align-items-center justify-content-center">
              {item.isDirectory ? (
                <FolderFill size={36} color="#0d6efd" />
              ) : (
                <FileEarmarkText size={32} color="#6c757d" />
              )}
              <div className="mt-2 small w-100">{item.name}</div>
            </Card.Body>
          </Card>
        </Col>
      ))}
    </Row>
  );
};

export default GridView;