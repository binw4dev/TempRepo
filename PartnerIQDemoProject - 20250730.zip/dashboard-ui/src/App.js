import './App.css';
import { BrowserRouter as Router, Route, Routes, Navigate } from "react-router-dom";
import Header from "./components/Header";
import Dashboard from "./components/Dashboard";
import { Col, Container, Navbar, Row, Stack } from "react-bootstrap";


function App() {
  return (
    <div className="App">
      <Header />
      <Row>
        <Col sm="2">
          <Row>
            <Col>
              <Stack>
                <Navbar className="m-2">
                  <Container style={{ background: "round black" }}>
                    <Navbar.Brand href="/dashboard" style={{ fontSize: "medium", color: "yellow", fontFamily: "URWGeometricRegular", fontWeight: "bold" }} >
                      Dashboard
                    </Navbar.Brand>
                  </Container>
                </Navbar>
              </Stack>
            </Col>
          </Row>
        </Col>
        <Col sm="12">
          <Router>
            <div className="container">
              <Routes>
                <Route path="/dashboard" element={<Dashboard />} />
              </Routes>
            </div>
          </Router>
        </Col>
      </Row>
    </div>
  );
}

export default App;
