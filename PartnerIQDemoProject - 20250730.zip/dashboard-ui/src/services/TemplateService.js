import axios from "axios";

const TEMPLATE_SERVICE_BASE_URL = "http://localhost:8080/template";

class TemplateService {
    requestTemplate(templateRequest) {
        return axios.post(TEMPLATE_SERVICE_BASE_URL, templateRequest);
    }

    getCountryCurrencyList() {
        return axios.get(TEMPLATE_SERVICE_BASE_URL + "/cclist");
    }
}

export default new TemplateService();