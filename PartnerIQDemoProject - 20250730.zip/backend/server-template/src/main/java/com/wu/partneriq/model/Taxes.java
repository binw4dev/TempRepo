
package com.wu.partneriq.model;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import jakarta.validation.Valid;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "municipal_tax",
    "county_tax",
    "state_tax",
    "tax_worksheet",
    "tax_rate"
})
@Generated("jsonschema2pojo")
public class Taxes {

    @JsonProperty("municipal_tax")
    private Integer municipalTax;
    @JsonProperty("county_tax")
    private Integer countyTax;
    @JsonProperty("state_tax")
    private Integer stateTax;
    @JsonProperty("tax_worksheet")
    private String taxWorksheet;
    @JsonProperty("tax_rate")
    private Integer taxRate;
    @JsonIgnore
    @Valid
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("municipal_tax")
    public Integer getMunicipalTax() {
        return municipalTax;
    }

    @JsonProperty("municipal_tax")
    public void setMunicipalTax(Integer municipalTax) {
        this.municipalTax = municipalTax;
    }

    @JsonProperty("county_tax")
    public Integer getCountyTax() {
        return countyTax;
    }

    @JsonProperty("county_tax")
    public void setCountyTax(Integer countyTax) {
        this.countyTax = countyTax;
    }

    @JsonProperty("state_tax")
    public Integer getStateTax() {
        return stateTax;
    }

    @JsonProperty("state_tax")
    public void setStateTax(Integer stateTax) {
        this.stateTax = stateTax;
    }

    @JsonProperty("tax_worksheet")
    public String getTaxWorksheet() {
        return taxWorksheet;
    }

    @JsonProperty("tax_worksheet")
    public void setTaxWorksheet(String taxWorksheet) {
        this.taxWorksheet = taxWorksheet;
    }

    @JsonProperty("tax_rate")
    public Integer getTaxRate() {
        return taxRate;
    }

    @JsonProperty("tax_rate")
    public void setTaxRate(Integer taxRate) {
        this.taxRate = taxRate;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Taxes.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("municipalTax");
        sb.append('=');
        sb.append(((this.municipalTax == null)?"<null>":this.municipalTax));
        sb.append(',');
        sb.append("countyTax");
        sb.append('=');
        sb.append(((this.countyTax == null)?"<null>":this.countyTax));
        sb.append(',');
        sb.append("stateTax");
        sb.append('=');
        sb.append(((this.stateTax == null)?"<null>":this.stateTax));
        sb.append(',');
        sb.append("taxWorksheet");
        sb.append('=');
        sb.append(((this.taxWorksheet == null)?"<null>":this.taxWorksheet));
        sb.append(',');
        sb.append("taxRate");
        sb.append('=');
        sb.append(((this.taxRate == null)?"<null>":this.taxRate));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

}
