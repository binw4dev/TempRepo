package com.wu.partneriq.dto;

public class RespBean {
    private int status;
    private String message;
    private Object obj;

    public RespBean(int status, String message, Object obj) {
        this.status = status;
        this.message = message;
        this.obj = obj;
    }

    public static RespBean ok(String message, Object obj) {
        return new RespBean(200, message, obj);
    }

    public static RespBean error(int status, String message) {
        return new RespBean(status, message, null);
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Object getObj() {
        return obj;
    }

    public void setObj(Object obj) {
        this.obj = obj;
    }
}
