
package com.wu.partneriq.model;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import jakarta.validation.Valid;
import jakarta.validation.constraints.DecimalMin;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "address",
    "compliance_details",
    "contact_phone",
    "mobile_phone",
    "name",
    "preferred_customer",
    "email"
})
@Generated("jsonschema2pojo")
public class Sender {

    @JsonProperty("address")
    @Valid
    private Address address;
    @JsonProperty("compliance_details")
    @Valid
    private ComplianceDetails complianceDetails;
    @JsonProperty("contact_phone")
    @DecimalMin("9223372036854775807")
    private Long contactPhone;
    @JsonProperty("mobile_phone")
    @Valid
    private MobilePhone mobilePhone;
    @JsonProperty("name")
    @Valid
    private Name name;
    @JsonProperty("preferred_customer")
    private String preferredCustomer;
    @JsonProperty("email")
    private String email;
    @JsonIgnore
    @Valid
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("address")
    public Address getAddress() {
        return address;
    }

    @JsonProperty("address")
    public void setAddress(Address address) {
        this.address = address;
    }

    @JsonProperty("compliance_details")
    public ComplianceDetails getComplianceDetails() {
        return complianceDetails;
    }

    @JsonProperty("compliance_details")
    public void setComplianceDetails(ComplianceDetails complianceDetails) {
        this.complianceDetails = complianceDetails;
    }

    @JsonProperty("contact_phone")
    public Long getContactPhone() {
        return contactPhone;
    }

    @JsonProperty("contact_phone")
    public void setContactPhone(Long contactPhone) {
        this.contactPhone = contactPhone;
    }

    @JsonProperty("mobile_phone")
    public MobilePhone getMobilePhone() {
        return mobilePhone;
    }

    @JsonProperty("mobile_phone")
    public void setMobilePhone(MobilePhone mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    @JsonProperty("name")
    public Name getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(Name name) {
        this.name = name;
    }

    @JsonProperty("preferred_customer")
    public String getPreferredCustomer() {
        return preferredCustomer;
    }

    @JsonProperty("preferred_customer")
    public void setPreferredCustomer(String preferredCustomer) {
        this.preferredCustomer = preferredCustomer;
    }

    @JsonProperty("email")
    public String getEmail() {
        return email;
    }

    @JsonProperty("email")
    public void setEmail(String email) {
        this.email = email;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Sender.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("address");
        sb.append('=');
        sb.append(((this.address == null)?"<null>":this.address));
        sb.append(',');
        sb.append("complianceDetails");
        sb.append('=');
        sb.append(((this.complianceDetails == null)?"<null>":this.complianceDetails));
        sb.append(',');
        sb.append("contactPhone");
        sb.append('=');
        sb.append(((this.contactPhone == null)?"<null>":this.contactPhone));
        sb.append(',');
        sb.append("mobilePhone");
        sb.append('=');
        sb.append(((this.mobilePhone == null)?"<null>":this.mobilePhone));
        sb.append(',');
        sb.append("name");
        sb.append('=');
        sb.append(((this.name == null)?"<null>":this.name));
        sb.append(',');
        sb.append("preferredCustomer");
        sb.append('=');
        sb.append(((this.preferredCustomer == null)?"<null>":this.preferredCustomer));
        sb.append(',');
        sb.append("email");
        sb.append('=');
        sb.append(((this.email == null)?"<null>":this.email));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

}
