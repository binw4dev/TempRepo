
package com.wu.partneriq.model;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import jakarta.validation.Valid;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "snp_indicator",
    "staging_buffer"
})
@Generated("jsonschema2pojo")
public class StagePayFields {

    @JsonProperty("snp_indicator")
    private String snpIndicator;
    @JsonProperty("staging_buffer")
    private String stagingBuffer;
    @JsonIgnore
    @Valid
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("snp_indicator")
    public String getSnpIndicator() {
        return snpIndicator;
    }

    @JsonProperty("snp_indicator")
    public void setSnpIndicator(String snpIndicator) {
        this.snpIndicator = snpIndicator;
    }

    @JsonProperty("staging_buffer")
    public String getStagingBuffer() {
        return stagingBuffer;
    }

    @JsonProperty("staging_buffer")
    public void setStagingBuffer(String stagingBuffer) {
        this.stagingBuffer = stagingBuffer;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(StagePayFields.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("snpIndicator");
        sb.append('=');
        sb.append(((this.snpIndicator == null)?"<null>":this.snpIndicator));
        sb.append(',');
        sb.append("stagingBuffer");
        sb.append('=');
        sb.append(((this.stagingBuffer == null)?"<null>":this.stagingBuffer));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

}
