import './App.css';
import { useState, useEffect } from 'react';
import React, { createContext } from "react";
import { BrowserRouter } from 'react-router-dom';
import AnimatedRoutes from './AnimatedRoutes';

function App() {


  return (

    <BrowserRouter>
      <AnimatedRoutes />
    </BrowserRouter>

  );
}

export default App;
