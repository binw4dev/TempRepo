import requests
import json
import os

with open("send-money-builderio-block.json", "r", encoding="utf-8") as file:
    json_block = json.load(file)

builder_private_api_key = "bpk-e0df25b3469b41f5b6f34578a7f282c9"
builder_public_api_key = "a4fad860d1b74d92bfaf8afd475d9ec9"
MODEL_NAME = "send-money-page"

'''resp = requests.post(
    'https://builder.io/api/v1/write/send-money-page',
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {builder_private_api_key}"
    },
    json=json_block
)

print(resp.status_code)
print(resp.json())'''

PAGE_NAME = 'send-money-page'

url = f'https://cdn.builder.io/api/v1/html/{MODEL_NAME}?apiKey={builder_public_api_key}&url=/{PAGE_NAME}'

response = requests.get(url)

if response.status_code == 200:
    with open('downloaded-page.html', 'w', encoding='utf-8') as f:
        f.write(response.text)
    print("HTML page downloaded.")
else:
    print("Error:", response.status_code, response.text)