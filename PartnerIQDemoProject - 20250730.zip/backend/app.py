from flask import Flask, request, jsonify
from flask_socketio import SocketIO
from flask_cors import CORS
import subprocess
import threading
import time
import requests
import zipfile
import io
import os
import shutil
import openai
import re

app = Flask(__name__)

CORS(app)

socketio = SocketIO(app, cors_allowed_origins="*")

baseDir = "generated-artifacts"

def sync_progress(suffix, percent_point, sleep_time):
    total = 10
    percent = int(percent_point * 100 / total)
    socketio.emit("progress" + suffix, {"progress": percent, "message": f"{percent}% completed"})
    time.sleep(sleep_time)

def sync_progress_log(suffix, percent_point, log, sleep_time):
    total = 10
    percent = int(percent_point * 100 / total)
    socketio.emit("progress" + suffix, {"progress": percent, "message": f"{percent}% completed"})
    socketio.emit("log" + suffix, {"log": log})
    time.sleep(sleep_time)

def execCommand(command, cwd=None):
    print(f"\n Running: {command}")
    subprocess.run(command, shell=True, check=True, cwd=cwd)

def fetch_apidoc(swagger_url, output_dir, output_file, progress):
    os.makedirs(output_dir, exist_ok=True)
    try:
        log = f"Requesting api doc from url: {swagger_url}"
        sync_progress_log("_create_backend", progress, log, 1)

        #response = requests.get(swagger_url)
        #response.raise_for_status()  # Throw exception in case the status code is NOT 200

        file_path = os.path.join(output_dir, output_file)
        #with open(file_path, "w", encoding="utf-8") as f:
            #f.write(response.text)

        log = f"api doc saved to {file_path}"
        print(log)
        sync_progress_log("_create_backend", progress, log, 1)

    except requests.exceptions.RequestException as e:
        log = f"Failed to request api doc: {e}"
        print(f"Failed to download api doc: {e}")

## 1 - Create Backend
@app.route("/create-backend", methods=["POST"])
def create_backend():
    def run_task():
        # create java-based backend
        ## ===== Settings =====
        project_name = "PartnerIQDemoBackendServer"
        extract_to = baseDir
        spring_initializr_url = "https://start.spring.io/starter.zip"

        params = {
            "type": "maven-project",
            "language": "java",
            "bootVersion": "3.5.0",                 # Spring Boot version
            "baseDir": project_name,                # ZIP Path
            "groupId": "com.example",
            "artifactId": project_name,
            "name": project_name,
            "packageName": "com.wu.partneriq",
            "dependencies": "web,data-jpa,security,data-mongodb,mysql"
        }

        ## ===== Generate Java backend by Spring Initializr API =====
        sync_progress_log("_create_backend", 0, f"Creating Java-based backend application...", 1)

        response = requests.get(spring_initializr_url, params=params)
        if response.status_code == 200:
            # UNZIP to the project path
            with zipfile.ZipFile(io.BytesIO(response.content)) as zip_ref:
                zip_ref.extractall(extract_to)
            
            # Copy template files
            source_dir = os.path.abspath("server-template")
            target_dir = os.path.abspath(baseDir + "/PartnerIQDemoBackendServer")
            shutil.copytree(source_dir, target_dir, dirs_exist_ok=True)

            sync_progress_log("_create_backend", 3, f"Java-based backend application created successfully: {os.path.abspath(extract_to)}", 0)
        else:
            sync_progress_log("_create_backend", 3, f"Failed to create Java based backend application. Status code: {response.status_code}", 0)

        # create Javascript backend
        ## ===== Settings =====
        project_name = "partneriqdemobackendserverjs"
        target_dir = baseDir + "/"
        project_path = os.path.join(target_dir, project_name)
        dependencies = [
            "@testing-library/jest-dom@^5.17.0",
            "@testing-library/react@^13.4.0",
            "@testing-library/user-event@^13.5.0",
            "axios@^1.7.7",
            "bootstrap@^5.3.3",
            "prop-types@^15.8.1",
            "react@^18.3.1",
            "react-bootstrap@^2.10.5",
            "react-datepicker@^7.6.0",
            "react-dom@^18.3.1",
            "react-router-dom@^6.27.0",
            "react-scripts@5.0.1",
            "react-transition-group@^4.4.5",
            "web-vitals@^2.1.4",
            "wumodclient-ui@^0.1.49"
        ]

        ## create React project
        try:
            sync_progress_log("_create_backend", 3, f"Creating React-based backend application...", 0)

            process = subprocess.Popen(
                ["npx.cmd", "create-react-app", project_name],
                cwd=target_dir,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                universal_newlines=True,
                text=True,
                bufsize=1
            )

            sync_progress_log("_create_backend", 5, f"React-based backend application created successfully: {os.path.abspath(project_path)}", 0)

        except subprocess.CalledProcessError as e:
            log = f"Failed to create React app: {e}"
            sync_progress_log("_create_backend", 10, log, 0)
            exit(1)

        # Get PartnerOS API docs
        catalog_api_url = "https://swaggerhub.corpprod.awswuintranet.net/virts/wu-partner/partnerOS_workflow_v1_api/1.0.0"
        workflow_api_url = "https://swaggerhub.corpprod.awswuintranet.net/virts/wu-partner/partnerOS_workflow_v1_api/1.0.0"
        metadata_api_url = "https://swaggerhub.corpprod.awswuintranet.net/virts/wu-partner/partnerOS_meta_v1_api/1.0.0"

        output_dir = baseDir + "/api-docs"

        fetch_apidoc(catalog_api_url, output_dir, "catalog_api-docs_spec.json", 6)
        fetch_apidoc(workflow_api_url, output_dir, "workflow_api-docs_spec.json", 7)
        fetch_apidoc(metadata_api_url, output_dir, "metadata_api-docs_spec.json", 8)

        # Get backend API docs
        backend_api_url = "http://localhost:9091/v3/api-docs"

        fetch_apidoc(backend_api_url, output_dir, "backend_api-docs_spec.json", 9)

        log = f"Download PartnerOS api docs and backend api docs completed."
        sync_progress_log("_create_backend", 10, log, 0)

    threading.Thread(target=run_task).start()
    return jsonify({"status": "started"}), 200

@app.route("/create-frontend", methods=["POST"])
def create_frontend_app():
    def run_task():
        sync_progress_log("_create_frontend", 10, f"Create frontend app with the following steps:  ", 1)
        sync_progress_log("_create_frontend", 10, f"1. Got to Builder.io platform : https://builder.io/app/projects", 0)
        sync_progress_log("_create_frontend", 10, f"2. In the chat box, upload the backend API doc [backend_api-docs_spec.json]", 0)
        sync_progress_log("_create_frontend", 10, f"3. Copy the prompt from file [prompt-ui-design.txt] and paste in the chat box", 0)
        sync_progress_log("_create_frontend", 10, f"4. Submit and wait the frontend UI app generated", 0)
        sync_progress_log("_create_frontend", 10, f"5. Download the UI as a react project", 0)
        sync_progress_log("_create_frontend", 10, f"6. Extract the project in the path, run npm install, npm build and npm start", 0)

    threading.Thread(target=run_task).start()
    return jsonify({"status": "started"}), 200

@app.route("/generate-sdk", methods=["POST"])
def partneros_sdk():
    def run_task():
        catalog_sdk_command = "openapi-generator-cli generate -i ./" + baseDir + "/api-docs/catalog_api-docs_spec.json -g java -o ./" + baseDir + "/sdk/catalog-sdk --library webclient --api-package com.wu.partneros.catalog.sdk --model-package com.wu.partneros.catalog.sdk.model --skip-validate-spec --auth none --additional-properties=sourceFolder=src/main/java,java8=true,dateLibrary=java8,useTags=true,interfaceOnly=false,nullable=false,generateApis=true,generateApiDocumentation=false,generateApiTests=false,generateModels=true,generateModelDocumentation=false,generateModelTests=false,generateSupportingFiles=true,useSpringBoot3=true"
        workflow_sdk_command = "openapi-generator-cli generate -i ./" + baseDir + "/api-docs/workflow_api-docs_spec.json -g java -o ./" + baseDir + "/sdk/workflow-sdk --library webclient --api-package com.wu.partneros.workflow.sdk --model-package com.wu.partneros.workflow.sdk.model --skip-validate-spec --auth none --additional-properties=sourceFolder=src/main/java,java8=true,dateLibrary=java8,useTags=true,interfaceOnly=false,nullable=false,generateApis=true,generateApiDocumentation=false,generateApiTests=false,generateModels=true,generateModelDocumentation=false,generateModelTests=false,generateSupportingFiles=true,useSpringBoot3=true"
        metadata_sdk_command = "openapi-generator-cli generate -i ./" + baseDir + "/api-docs/metadata_api-docs_spec.json -g java -o ./" + baseDir + "/sdk/metadata-sdk --library webclient --api-package com.wu.partneros.metadata.sdk --model-package com.wu.partneros.metadata.sdk.model --skip-validate-spec --auth none --additional-properties=sourceFolder=src/main/java,java8=true,dateLibrary=java8,useTags=true,interfaceOnly=false,nullable=false,generateApis=true,generateApiDocumentation=false,generateApiTests=false,generateModels=true,generateModelDocumentation=false,generateModelTests=false,generateSupportingFiles=true,useSpringBoot3=true"
        backend_sdk_command = "openapi-generator-cli generate -i ./" + baseDir + "/api-docs/backend_api-docs_spec.json -g java -o ./" + baseDir + "/sdk/backend-sdk --library webclient --api-package com.wu.partneros.backend.sdk --model-package com.wu.partneros.backend.sdk.model --skip-validate-spec --auth none --additional-properties=sourceFolder=src/main/java,java8=true,dateLibrary=java8,useTags=true,interfaceOnly=false,nullable=false,generateApis=true,generateApiDocumentation=false,generateApiTests=false,generateModels=true,generateModelDocumentation=false,generateModelTests=false,generateSupportingFiles=true,useSpringBoot3=true"

        execCommand(catalog_sdk_command)
        log = f"PartnerOS Catalog SDK generated."
        sync_progress_log("_generate_sdk", 2, log, 1)

        execCommand(workflow_sdk_command)
        log = f"PartnerOS Workflow SDK generated."
        sync_progress_log("_generate_sdk", 5, log, 1)

        execCommand(metadata_sdk_command)
        log = f"PartnerOS Metadata SDK generated."
        sync_progress_log("_generate_sdk", 7, log, 1)

        execCommand(backend_sdk_command)
        log = f"Backend SDK generated."
        sync_progress_log("_generate_sdk", 10, log, 0)

    threading.Thread(target=run_task).start()
    return jsonify({"status": "started"}), 200

@app.route('/list-dir', methods=['GET'])
def list_directory():
    #base_dir = os.path.abspath('.')
    root_dir = os.path.abspath(baseDir)
    requested_path = request.args.get('path', '')
    #print(f"requested_path : {requested_path}")
    abs_path = os.path.abspath(os.path.join('.', requested_path))
    #print(f"abs_path : {abs_path}")
    EXCLUDE_FOLDERS = {"ui_template", ".git", "__pycache__", "ui_template"}

    path = request.args.get('path', '/')
    path = os.path.abspath(path)

    #base_dir = os.path.abspath(".")
    #if not path.startswith(base_dir):
        #return jsonify({"error": "Access denied"}), 403

    if not os.path.exists(requested_path) or not os.path.isdir(requested_path):
        return jsonify({"error": "Invalid path"}), 400

    try:
        items = []
        for entry in os.scandir(requested_path):
            if entry.name.startswith("."):
                continue  # ignore hidden files
            if entry.name in EXCLUDE_FOLDERS:
                continue  # ignore exclude files
            items.append({
                "name": entry.name,
                "isDirectory": entry.is_dir()
            })

        #print(f"root_dir : {root_dir}")

        # add the parent folder
        if abs_path != root_dir:
            items.insert(0, {
                "name": "..",
                "isDirectory": True
            })

        #print(f"items : {items}")

        if requested_path.endswith("..") :
            index = requested_path.rfind("/") 
            #print(f"index : {index}")
            if index != -1:
                index2 = requested_path.rfind("/", 0, index)
                requested_path = requested_path[:index2]

        #print(f"adjusted requested_path : {requested_path}")

        return jsonify({
            "currentPath": requested_path,
            "items": items
        })
    except Exception as e:
        print(f"error : {e}")
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    socketio.run(app, host="0.0.0.0", port=5000)