package com.wu.partneriq.controller;

import com.wu.partneriq.dto.RespBean;
import com.wu.partneriq.model.QuoteOrderReply;
import com.wu.partneriq.model.Sender;
import com.wu.partneriq.service.CustomerKYCService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:3001"})
@RestController
@RequestMapping("/customer")
public class CustomerKYCController {
    @Autowired
    CustomerKYCService customerKYCService;

    @GetMapping(path = "/kyc/lookup")
    public ResponseEntity<Sender> getCustomerKYCById(@RequestParam(name = "customerId") String customerId,
                                                     @RequestParam(name = "firstname") String firstname,
                                                     @RequestParam(name = "lastname")String lastname) {
        return customerKYCService.getCustomerKYCById(customerId, firstname, lastname);
    }

    @GetMapping(path = "/kyc/template")
    public ResponseEntity<String> getKycTemplate(@RequestParam(name = "countryCode") String countryCode) {
        return customerKYCService.getKycTemplate(countryCode);
    }
}
