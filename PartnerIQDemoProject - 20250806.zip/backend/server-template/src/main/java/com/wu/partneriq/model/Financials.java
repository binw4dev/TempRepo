
package com.wu.partneriq.model;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import jakarta.validation.Valid;
import jakarta.validation.constraints.DecimalMin;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "gross_total_amount",
    "money_transfer_limit",
    "pay_amount",
    "message_charge",
    "taxes",
    "destination_principal_amount",
    "originators_principal_amount",
    "originating_currency_principal",
    "plus_charges_amount",
    "tolls",
    "charges",
    "total_undiscounted_charges",
    "canadian_dollar_exchange_fee",
    "total_discounted_charges"
})
@Generated("jsonschema2pojo")
public class Financials {

    @JsonProperty("gross_total_amount")
    private Integer grossTotalAmount;
    @JsonProperty("money_transfer_limit")
    @DecimalMin("9223372036854775807")
    private Long moneyTransferLimit;
    @JsonProperty("pay_amount")
    private Integer payAmount;
    @JsonProperty("message_charge")
    private Integer messageCharge;
    @JsonProperty("taxes")
    @Valid
    private Taxes taxes;
    @JsonProperty("destination_principal_amount")
    private Integer destinationPrincipalAmount;
    @JsonProperty("originators_principal_amount")
    private Integer originatorsPrincipalAmount;
    @JsonProperty("originating_currency_principal")
    private String originatingCurrencyPrincipal;
    @JsonProperty("plus_charges_amount")
    private Integer plusChargesAmount;
    @JsonProperty("tolls")
    private Integer tolls;
    @JsonProperty("charges")
    private Integer charges;
    @JsonProperty("total_undiscounted_charges")
    private Integer totalUndiscountedCharges;
    @JsonProperty("canadian_dollar_exchange_fee")
    private Integer canadianDollarExchangeFee;
    @JsonProperty("total_discounted_charges")
    private Integer totalDiscountedCharges;
    @JsonIgnore
    @Valid
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("gross_total_amount")
    public Integer getGrossTotalAmount() {
        return grossTotalAmount;
    }

    @JsonProperty("gross_total_amount")
    public void setGrossTotalAmount(Integer grossTotalAmount) {
        this.grossTotalAmount = grossTotalAmount;
    }

    @JsonProperty("money_transfer_limit")
    public Long getMoneyTransferLimit() {
        return moneyTransferLimit;
    }

    @JsonProperty("money_transfer_limit")
    public void setMoneyTransferLimit(Long moneyTransferLimit) {
        this.moneyTransferLimit = moneyTransferLimit;
    }

    @JsonProperty("pay_amount")
    public Integer getPayAmount() {
        return payAmount;
    }

    @JsonProperty("pay_amount")
    public void setPayAmount(Integer payAmount) {
        this.payAmount = payAmount;
    }

    @JsonProperty("message_charge")
    public Integer getMessageCharge() {
        return messageCharge;
    }

    @JsonProperty("message_charge")
    public void setMessageCharge(Integer messageCharge) {
        this.messageCharge = messageCharge;
    }

    @JsonProperty("taxes")
    public Taxes getTaxes() {
        return taxes;
    }

    @JsonProperty("taxes")
    public void setTaxes(Taxes taxes) {
        this.taxes = taxes;
    }

    @JsonProperty("destination_principal_amount")
    public Integer getDestinationPrincipalAmount() {
        return destinationPrincipalAmount;
    }

    @JsonProperty("destination_principal_amount")
    public void setDestinationPrincipalAmount(Integer destinationPrincipalAmount) {
        this.destinationPrincipalAmount = destinationPrincipalAmount;
    }

    @JsonProperty("originators_principal_amount")
    public Integer getOriginatorsPrincipalAmount() {
        return originatorsPrincipalAmount;
    }

    @JsonProperty("originators_principal_amount")
    public void setOriginatorsPrincipalAmount(Integer originatorsPrincipalAmount) {
        this.originatorsPrincipalAmount = originatorsPrincipalAmount;
    }

    @JsonProperty("originating_currency_principal")
    public String getOriginatingCurrencyPrincipal() {
        return originatingCurrencyPrincipal;
    }

    @JsonProperty("originating_currency_principal")
    public void setOriginatingCurrencyPrincipal(String originatingCurrencyPrincipal) {
        this.originatingCurrencyPrincipal = originatingCurrencyPrincipal;
    }

    @JsonProperty("plus_charges_amount")
    public Integer getPlusChargesAmount() {
        return plusChargesAmount;
    }

    @JsonProperty("plus_charges_amount")
    public void setPlusChargesAmount(Integer plusChargesAmount) {
        this.plusChargesAmount = plusChargesAmount;
    }

    @JsonProperty("tolls")
    public Integer getTolls() {
        return tolls;
    }

    @JsonProperty("tolls")
    public void setTolls(Integer tolls) {
        this.tolls = tolls;
    }

    @JsonProperty("charges")
    public Integer getCharges() {
        return charges;
    }

    @JsonProperty("charges")
    public void setCharges(Integer charges) {
        this.charges = charges;
    }

    @JsonProperty("total_undiscounted_charges")
    public Integer getTotalUndiscountedCharges() {
        return totalUndiscountedCharges;
    }

    @JsonProperty("total_undiscounted_charges")
    public void setTotalUndiscountedCharges(Integer totalUndiscountedCharges) {
        this.totalUndiscountedCharges = totalUndiscountedCharges;
    }

    @JsonProperty("canadian_dollar_exchange_fee")
    public Integer getCanadianDollarExchangeFee() {
        return canadianDollarExchangeFee;
    }

    @JsonProperty("canadian_dollar_exchange_fee")
    public void setCanadianDollarExchangeFee(Integer canadianDollarExchangeFee) {
        this.canadianDollarExchangeFee = canadianDollarExchangeFee;
    }

    @JsonProperty("total_discounted_charges")
    public Integer getTotalDiscountedCharges() {
        return totalDiscountedCharges;
    }

    @JsonProperty("total_discounted_charges")
    public void setTotalDiscountedCharges(Integer totalDiscountedCharges) {
        this.totalDiscountedCharges = totalDiscountedCharges;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Financials.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("grossTotalAmount");
        sb.append('=');
        sb.append(((this.grossTotalAmount == null)?"<null>":this.grossTotalAmount));
        sb.append(',');
        sb.append("moneyTransferLimit");
        sb.append('=');
        sb.append(((this.moneyTransferLimit == null)?"<null>":this.moneyTransferLimit));
        sb.append(',');
        sb.append("payAmount");
        sb.append('=');
        sb.append(((this.payAmount == null)?"<null>":this.payAmount));
        sb.append(',');
        sb.append("messageCharge");
        sb.append('=');
        sb.append(((this.messageCharge == null)?"<null>":this.messageCharge));
        sb.append(',');
        sb.append("taxes");
        sb.append('=');
        sb.append(((this.taxes == null)?"<null>":this.taxes));
        sb.append(',');
        sb.append("destinationPrincipalAmount");
        sb.append('=');
        sb.append(((this.destinationPrincipalAmount == null)?"<null>":this.destinationPrincipalAmount));
        sb.append(',');
        sb.append("originatorsPrincipalAmount");
        sb.append('=');
        sb.append(((this.originatorsPrincipalAmount == null)?"<null>":this.originatorsPrincipalAmount));
        sb.append(',');
        sb.append("originatingCurrencyPrincipal");
        sb.append('=');
        sb.append(((this.originatingCurrencyPrincipal == null)?"<null>":this.originatingCurrencyPrincipal));
        sb.append(',');
        sb.append("plusChargesAmount");
        sb.append('=');
        sb.append(((this.plusChargesAmount == null)?"<null>":this.plusChargesAmount));
        sb.append(',');
        sb.append("tolls");
        sb.append('=');
        sb.append(((this.tolls == null)?"<null>":this.tolls));
        sb.append(',');
        sb.append("charges");
        sb.append('=');
        sb.append(((this.charges == null)?"<null>":this.charges));
        sb.append(',');
        sb.append("totalUndiscountedCharges");
        sb.append('=');
        sb.append(((this.totalUndiscountedCharges == null)?"<null>":this.totalUndiscountedCharges));
        sb.append(',');
        sb.append("canadianDollarExchangeFee");
        sb.append('=');
        sb.append(((this.canadianDollarExchangeFee == null)?"<null>":this.canadianDollarExchangeFee));
        sb.append(',');
        sb.append("totalDiscountedCharges");
        sb.append('=');
        sb.append(((this.totalDiscountedCharges == null)?"<null>":this.totalDiscountedCharges));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

}
