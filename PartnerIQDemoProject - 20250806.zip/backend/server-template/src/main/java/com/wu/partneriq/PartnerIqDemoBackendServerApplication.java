package com.wu.partneriq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PartnerIqDemoBackendServerApplication {
    public static void main(String... args) {
        SpringApplication.run(PartnerIqDemoBackendServerApplication.class, args);
    }
}
