
package com.wu.partneriq.model;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import jakarta.validation.Valid;
import jakarta.validation.constraints.DecimalMin;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "reason_for_sending",
    "address",
    "contact_phone",
    "mobile_phone",
    "name"
})
@Generated("jsonschema2pojo")
public class Receiver {

    @JsonProperty("reason_for_sending")
    private Integer reasonForSending;
    @JsonProperty("address")
    @Valid
    private Address address;
    @JsonProperty("contact_phone")
    @DecimalMin("9223372036854775807")
    private Long contactPhone;
    @JsonProperty("mobile_phone")
    @Valid
    private MobilePhone mobilePhone;
    @JsonProperty("name")
    @Valid
    private Name name;
    @JsonIgnore
    @Valid
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("reason_for_sending")
    public Integer getReasonForSending() {
        return reasonForSending;
    }

    @JsonProperty("reason_for_sending")
    public void setReasonForSending(Integer reasonForSending) {
        this.reasonForSending = reasonForSending;
    }

    @JsonProperty("address")
    public Address getAddress() {
        return address;
    }

    @JsonProperty("address")
    public void setAddress(Address address) {
        this.address = address;
    }

    @JsonProperty("contact_phone")
    public Long getContactPhone() {
        return contactPhone;
    }

    @JsonProperty("contact_phone")
    public void setContactPhone(Long contactPhone) {
        this.contactPhone = contactPhone;
    }

    @JsonProperty("mobile_phone")
    public MobilePhone getMobilePhone() {
        return mobilePhone;
    }

    @JsonProperty("mobile_phone")
    public void setMobilePhone(MobilePhone mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    @JsonProperty("name")
    public Name getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(Name name) {
        this.name = name;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Receiver.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("reasonForSending");
        sb.append('=');
        sb.append(((this.reasonForSending == null)?"<null>":this.reasonForSending));
        sb.append(',');
        sb.append("address");
        sb.append('=');
        sb.append(((this.address == null)?"<null>":this.address));
        sb.append(',');
        sb.append("contactPhone");
        sb.append('=');
        sb.append(((this.contactPhone == null)?"<null>":this.contactPhone));
        sb.append(',');
        sb.append("mobilePhone");
        sb.append('=');
        sb.append(((this.mobilePhone == null)?"<null>":this.mobilePhone));
        sb.append(',');
        sb.append("name");
        sb.append('=');
        sb.append(((this.name == null)?"<null>":this.name));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

}
