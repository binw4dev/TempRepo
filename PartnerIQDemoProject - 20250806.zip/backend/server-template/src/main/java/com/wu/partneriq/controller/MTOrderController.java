package com.wu.partneriq.controller;

import com.wu.partneriq.model.*;
import com.wu.partneriq.service.MTOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/order")
public class MTOrderController {
    @Autowired
    MTOrderService mtOrderService;

    @PostMapping(path = "/quote")
    public ResponseEntity<QuoteOrderReply> quoteOrder(@RequestBody QuoteOrderRequest orderRequest) {
        return mtOrderService.quoteOrder(orderRequest);
    }

    @PostMapping(path = "/create")
    public ResponseEntity<CreateOrderReply> createOrder(@RequestBody CreateOrderRequest orderRequest) {
        return mtOrderService.createOrder(orderRequest);
    }

    @PostMapping(path = "/confirm")
    public ResponseEntity<ConfirmOrderReply> createOrder(@RequestBody ConfirmOrderRequest orderRequest) {
        return mtOrderService.confirmOrder(orderRequest);
    }
}
