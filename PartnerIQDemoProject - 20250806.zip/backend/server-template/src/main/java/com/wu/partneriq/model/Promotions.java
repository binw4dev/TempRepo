
package com.wu.partneriq.model;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import jakarta.validation.Valid;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "promo_message",
    "promo_code_description",
    "sender_promo_code"
})
@Generated("jsonschema2pojo")
public class Promotions {

    @JsonProperty("promo_message")
    private String promoMessage;
    @JsonProperty("promo_code_description")
    private String promoCodeDescription;
    @JsonProperty("sender_promo_code")
    private String senderPromoCode;
    @JsonIgnore
    @Valid
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("promo_message")
    public String getPromoMessage() {
        return promoMessage;
    }

    @JsonProperty("promo_message")
    public void setPromoMessage(String promoMessage) {
        this.promoMessage = promoMessage;
    }

    @JsonProperty("promo_code_description")
    public String getPromoCodeDescription() {
        return promoCodeDescription;
    }

    @JsonProperty("promo_code_description")
    public void setPromoCodeDescription(String promoCodeDescription) {
        this.promoCodeDescription = promoCodeDescription;
    }

    @JsonProperty("sender_promo_code")
    public String getSenderPromoCode() {
        return senderPromoCode;
    }

    @JsonProperty("sender_promo_code")
    public void setSenderPromoCode(String senderPromoCode) {
        this.senderPromoCode = senderPromoCode;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Promotions.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("promoMessage");
        sb.append('=');
        sb.append(((this.promoMessage == null)?"<null>":this.promoMessage));
        sb.append(',');
        sb.append("promoCodeDescription");
        sb.append('=');
        sb.append(((this.promoCodeDescription == null)?"<null>":this.promoCodeDescription));
        sb.append(',');
        sb.append("senderPromoCode");
        sb.append('=');
        sb.append(((this.senderPromoCode == null)?"<null>":this.senderPromoCode));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

}
