import { useState, useEffect } from 'react';
import { ChevronDown, ChevronUp, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { cn } from '@/lib/utils';

interface FormData {
  [key: string]: string;
}

interface SectionState {
  [key: string]: boolean;
}

export default function Index() {
  const [currentTab, setCurrentTab] = useState(0);
  const [formData, setFormData] = useState<FormData>({});
  const [sectionExpanded, setSectionExpanded] = useState<SectionState>({});
  const [submittedTabs, setSubmittedTabs] = useState<boolean[]>([false, false, false]);
  const [showOutput, setShowOutput] = useState<boolean[]>([false, false, false]);

  const tabs = ['Pricing', 'Order Create', 'Order Confirm'];

  useEffect(() => {
    // Initialize first section of each tab as expanded
    setSectionExpanded({
      'Check Pricing Details': true,
      'Sender Details': true,
    });

    // Auto-fill fields with output sample data from previous tabs
    const autoFillData: FormData = {};

    // For Order Create tab, fill with Pricing tab output data
    if (showOutput[0]) {
      autoFillData['Exchange Rate'] = '1 USD = 20.15 MXN';
      autoFillData['Transfer Fee'] = '$4.99';
      autoFillData['Maximum Transfer Limit'] = '$10,000 USD per transaction';
    }

    // For Order Confirm tab, fill with Order Create tab output data
    if (showOutput[1]) {
      autoFillData['Exchange Rate'] = '1 USD = 20.15 MXN';
      autoFillData['Transfer Fee'] = '$4.99';
      autoFillData['Order Number'] = '1234567890';
    }

    setFormData(prev => ({ ...prev, ...autoFillData }));
  }, [showOutput]);

  const handleInputChange = (key: string, value: string) => {
    setFormData(prev => ({ ...prev, [key]: value }));
  };

  const toggleSection = (sectionTitle: string) => {
    setSectionExpanded(prev => ({
      ...prev,
      [sectionTitle]: !prev[sectionTitle]
    }));
  };

  const isFieldRequired = (field: any): boolean => {
    return field.required === "true" || field.required === true;
  };

  const validateTab = (tabIndex: number): boolean => {
    if (tabIndex === 0) {
      // Pricing tab validation
      const required = ['Payout Country', 'Payout Method', 'Send Amount'];
      return required.every(field => formData[field] && formData[field].trim() !== '');
    } else if (tabIndex === 1) {
      // Order Create tab validation
      const required = [
        'First Name', 'Paternal Name', 'Maternal Name', 'Phone Country Code', 'Phone Number',
        'Address Line 1', 'City', 'Postal Code', 'Country',
        'Date of Birth', 'Nationality', 'ID Type', 'ID Number', 'ID Expiration Date',
        'Occupation', 'Employer Name', 'Source of Funds',
        'Receiver First Name', 'Receiver Paternal Name', 'Receiver Maternal Name',
        'Transaction Payout Country', 'Transaction Payout Method', 'Transaction Send Amount'
      ];
      return required.every(field => formData[field] && formData[field].trim() !== '');
    }
    return true;
  };

  const handleSubmit = (tabIndex: number) => {
    const newSubmittedTabs = [...submittedTabs];
    const newShowOutput = [...showOutput];
    newSubmittedTabs[tabIndex] = true;
    newShowOutput[tabIndex] = true;
    setSubmittedTabs(newSubmittedTabs);
    setShowOutput(newShowOutput);
  };

  const handleContinue = (tabIndex: number) => {
    const nextTab = (tabIndex + 1) % tabs.length;
    setCurrentTab(nextTab);
  };

  const renderStepIndicator = () => (
    <div className="mb-8">
      <div className="flex items-center justify-center space-x-8">
        {tabs.map((tab, index) => (
          <div key={tab} className="flex items-center">
            <div className={cn(
              "w-10 h-10 rounded-full flex items-center justify-center text-sm font-medium border-2",
              index === currentTab 
                ? "bg-yellow-400 border-yellow-400 text-gray-900" 
                : index < currentTab || submittedTabs[index]
                ? "bg-green-500 border-green-500 text-white"
                : "bg-gray-100 border-gray-300 text-gray-500"
            )}>
              {index + 1}
            </div>
            <span className={cn(
              "ml-2 text-sm font-medium",
              index === currentTab ? "text-gray-900" : "text-gray-500"
            )}>
              {tab}
            </span>
            {index < tabs.length - 1 && (
              <div className={cn(
                "w-16 h-0.5 ml-4",
                index < currentTab || submittedTabs[index] ? "bg-green-500" : "bg-gray-300"
              )} />
            )}
          </div>
        ))}
      </div>
    </div>
  );

  const renderAmountField = (field: any, prefix = '') => (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
      <Select onValueChange={(value) => handleInputChange(`${prefix}${field.label} Currency`, value)}>
        <SelectTrigger>
          <SelectValue placeholder="Currency" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="USD">USD</SelectItem>
          <SelectItem value="EUR">EUR</SelectItem>
          <SelectItem value="GBP">GBP</SelectItem>
          <SelectItem value="MXN">MXN</SelectItem>
          <SelectItem value="INR">INR</SelectItem>
          <SelectItem value="CAD">CAD</SelectItem>
        </SelectContent>
      </Select>
      <div className="sm:col-span-2">
        <Input
          type="number"
          placeholder={field.placeholder || "0.00"}
          value={formData[`${prefix}${field.label}`] || ''}
          onChange={(e) => handleInputChange(`${prefix}${field.label}`, e.target.value)}
          step="0.01"
          min="0"
        />
      </div>
    </div>
  );

  const renderField = (field: any, prefix = '') => {
    const fieldKey = `${prefix}${field.label}`;
    
    if (field.type === 'subsection') {
      return (
        <div key={fieldKey} className="col-span-full">
          <h4 className="text-base font-semibold text-gray-900 mb-2">{field.label}</h4>
          {field.description && (
            <p className="text-sm text-gray-600 mb-4">{field.description}</p>
          )}
        </div>
      );
    }

    if (field.type === 'notice') {
      return (
        <Alert key={fieldKey} className="col-span-full bg-blue-50 border-blue-200">
          <Info className="h-4 w-4 text-blue-600" />
          <AlertDescription className="text-blue-800">
            <strong>{field.title}</strong>
            {field.text && <div className="mt-1">{field.text}</div>}
          </AlertDescription>
        </Alert>
      );
    }

    return (
      <div key={fieldKey} className="space-y-2">
        <Label htmlFor={fieldKey} className="text-sm font-medium text-gray-700">
          {field.label}
          {isFieldRequired(field) && <span className="text-red-500 ml-1">*</span>}
        </Label>
        
        {field.type === 'text' && (
          <Input
            id={fieldKey}
            value={formData[fieldKey] || ''}
            onChange={(e) => handleInputChange(fieldKey, e.target.value)}
            placeholder={field.placeholder}
            required={isFieldRequired(field)}
          />
        )}
        
        {field.type === 'date' && (
          <Input
            id={fieldKey}
            type="date"
            value={formData[fieldKey] || ''}
            onChange={(e) => handleInputChange(fieldKey, e.target.value)}
            required={isFieldRequired(field)}
          />
        )}
        
        {field.type === 'list' && (
          <Select onValueChange={(value) => handleInputChange(fieldKey, value)}>
            <SelectTrigger>
              <SelectValue placeholder={`Select ${field.label.toLowerCase()}`} />
            </SelectTrigger>
            <SelectContent>
              {field.listvalue?.map((option: string) => (
                <SelectItem key={option} value={option}>{option}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
        
        {field.type === 'amount' && renderAmountField(field, prefix)}
        
        {field.type === 'label' && (
          <div className="text-sm text-gray-900 p-2 bg-gray-50 rounded border">
            {formData[fieldKey] || formData[field.label] || 'Not provided'}
          </div>
        )}
      </div>
    );
  };

  const renderSection = (section: any, prefix = '') => {
    const sectionKey = section.title;
    const isExpanded = sectionExpanded[sectionKey];
    const fields = section.fields || section.input_fields || [];
    
    return (
      <Card key={sectionKey} className="mb-6">
        <CardHeader 
          className="cursor-pointer"
          onClick={() => toggleSection(sectionKey)}
        >
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-lg font-semibold text-gray-900">
                {section.title}
              </CardTitle>
              {section.description && (
                <CardDescription className="text-gray-600">
                  {section.description}
                </CardDescription>
              )}
            </div>
            {isExpanded ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
          </div>
        </CardHeader>
        
        {isExpanded && (
          <CardContent>
            <div className="space-y-4">
              {(() => {
                const groupedFields: any[] = [];
                let currentSubsection: string | null = null;
                let subsectionFields: any[] = [];
                let standaloneFields: any[] = [];

                fields.forEach((field: any) => {
                  if (field.type === 'subsection') {
                    // If we have accumulated standalone fields, add them first
                    if (standaloneFields.length > 0) {
                      groupedFields.push({
                        type: 'fieldGroup',
                        fields: standaloneFields
                      });
                      standaloneFields = [];
                    }
                    // If we have accumulated fields for previous subsection, add them
                    if (subsectionFields.length > 0) {
                      groupedFields.push({
                        type: 'fieldGroup',
                        fields: subsectionFields
                      });
                      subsectionFields = [];
                    }
                    // Add the subsection header
                    groupedFields.push({
                      type: 'subsectionHeader',
                      field: field
                    });
                    currentSubsection = field.label;
                  } else if (field.subsection === currentSubsection) {
                    // This field belongs to the current subsection
                    subsectionFields.push(field);
                  } else {
                    // This field doesn't belong to any subsection - collect as standalone
                    if (subsectionFields.length > 0) {
                      groupedFields.push({
                        type: 'fieldGroup',
                        fields: subsectionFields
                      });
                      subsectionFields = [];
                    }
                    standaloneFields.push(field);
                    currentSubsection = null;
                  }
                });

                // Add any remaining fields
                if (standaloneFields.length > 0) {
                  groupedFields.push({
                    type: 'fieldGroup',
                    fields: standaloneFields
                  });
                }
                if (subsectionFields.length > 0) {
                  groupedFields.push({
                    type: 'fieldGroup',
                    fields: subsectionFields
                  });
                }

                return groupedFields.map((group, index) => {
                  if (group.type === 'subsectionHeader') {
                    return (
                      <div key={`subsection-${index}`} className="w-full">
                        {renderField(group.field, prefix)}
                      </div>
                    );
                  } else if (group.type === 'fieldGroup') {
                    return (
                      <div key={`group-${index}`} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {group.fields.map((field: any) => (
                          <div key={`${prefix}${field.label}`} className="col-span-1">
                            {renderField(field, prefix)}
                          </div>
                        ))}
                      </div>
                    );
                  }
                });
              })()}
            </div>
            
            {/* Add compliance notice for Compliance Details section */}
            {section.title === 'Compliance Details' && (
              <Alert className="mt-6 bg-blue-50 border-blue-200">
                <Info className="h-4 w-4 text-blue-600" />
                <AlertDescription className="text-blue-800">
                  <strong>Compliance Notice:</strong> This information is required for AML/KYC compliance and regulatory requirements. All data is securely encrypted and processed according to international financial regulations.
                </AlertDescription>
              </Alert>
            )}
            

          </CardContent>
        )}
      </Card>
    );
  };

  const renderOutput = (tabIndex: number) => {
    if (!showOutput[tabIndex]) return null;

    const sampleData = tabIndex === 0 
      ? {
          "Exchange Rate": "1 USD = 20.15 MXN",
          "Transfer Fee": "$4.99",
          "Maximum Transfer Limit": "$10,000 USD per transaction"
        }
      : tabIndex === 1
      ? {
          "Exchange Rate": "1 USD = 20.15 MXN",
          "Transfer Fee": "$4.99"
        }
      : {
          "Order Number": "1234567890"
        };

    return (
      <Card className="mt-6 bg-green-50 border-green-200">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-green-800">
            {tabIndex === 2 ? 'Order Information' : 'Pricing Information'}
          </CardTitle>
          <CardDescription className="text-green-700">
            {tabIndex === 2 ? 'Order created successfully' : 'Fee and exchange rate'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {Object.entries(sampleData).map(([key, value]) => (
              <div key={key} className="flex justify-between">
                <span className="font-medium text-green-800">{key}:</span>
                <span className="text-green-900">{value}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  };

  const renderTabContent = () => {
    if (currentTab === 0) {
      // Pricing tab
      return (
        <div>
          {renderSection({
            title: "Check Pricing Details",
            description: "Provide payout country and amount information",
            fields: [
              {
                label: "Payout Country",
                type: "list",
                listvalue: ["Mexico", "India", "Canada"],
                required: "true"
              },
              {
                label: "Payout Method",
                type: "list",
                listvalue: ["Cash Pickup", "Bank Deposit", "Mobile Wallet"],
                required: "true"
              },
              {
                label: "Amount Information",
                type: "subsection",
                required: "false"
              },
              {
                label: "Send Amount",
                type: "amount",
                required: "true",
                subsection: "Amount Information",
                placeholder: "0.00"
              },
              {
                label: "Payout Amount",
                type: "amount",
                required: "false",
                subsection: "Amount Information",
                placeholder: "0.00"
              }
            ]
          })}
          {renderOutput(0)}
        </div>
      );
    } else if (currentTab === 1) {
      // Order Create tab
      return (
        <div>
          {renderSection({
            title: "Sender Details",
            description: "Your personal information",
            input_fields: [
              { label: "First Name", type: "text", required: "true", placeholder: "Enter first name" },
              { label: "Paternal Name", type: "text", required: "true", placeholder: "Enter paternal name" },
              { label: "Maternal Name", type: "text", required: "true", placeholder: "Enter maternal name" },
              { label: "Phone Country Code", type: "list", required: "true", listvalue: ["+1", "+44", "+52", "+86", "+91"] },
              { label: "Phone Number", type: "text", required: "true", placeholder: "Enter phone number" },
              { label: "Email", type: "text", required: "false", placeholder: "Enter email address" },
              { label: "Address Information", type: "subsection", required: "false" },
              { label: "Address Line 1", type: "text", placeholder: "Enter street address", subsection: "Address Information", required: "true" },
              { label: "Address Line 2", type: "text", placeholder: "Enter room number", subsection: "Address Information", required: "false" },
              { label: "City", type: "text", placeholder: "Enter city", subsection: "Address Information", required: "true" },
              { label: "Postal Code", type: "text", placeholder: "Enter postal code", subsection: "Address Information", required: "true" },
              { label: "Country", type: "list", subsection: "Address Information", listvalue: ["United States", "Canada", "Mexico", "India"], required: "true" }
            ]
          })}
          
          {renderSection({
            title: "Compliance Details",
            description: "Identity verification and compliance information",
            fields: [
              { label: "Personal Information", type: "subsection", required: "false" },
              { label: "Date of Birth", type: "date", required: "true", subsection: "Personal Information" },
              { label: "Nationality", type: "list", listvalue: ["American", "Canadian", "Mexican", "Indian"], required: "true", subsection: "Personal Information" },
              { label: "Identification", type: "subsection", required: "false" },
              { label: "ID Type", type: "list", listvalue: ["Driver's license", "Passport", "National ID"], required: "true", subsection: "Identification" },
              { label: "ID Number", type: "text", placeholder: "Enter ID number", required: "true", subsection: "Identification" },
              { label: "ID Expiration Date", type: "date", required: "true", subsection: "Identification" },
              { label: "Employment", type: "subsection", required: "false" },
              { label: "Occupation", type: "list", listvalue: ["Employed", "Self-employed", "Student", "Retired"], required: "true", subsection: "Employment" },
              { label: "Employer Name", type: "text", placeholder: "Enter employer name (if applicable)", required: "true", subsection: "Employment" },
              { label: "Other Information", type: "subsection", required: "false" },
              { label: "Source of Funds", type: "list", listvalue: ["Salary/Employment", "Business Income", "Savings", "Investment Returns"], required: "true", subsection: "Other Information" }
            ]
          })}
          
          {renderSection({
            title: "Receiver Details",
            description: "Recipient Information",
            fields: [
              { label: "First Name", type: "text", required: "true", placeholder: "Enter first name" },
              { label: "Paternal Name", type: "text", required: "true", placeholder: "Enter paternal name" },
              { label: "Maternal Name", type: "text", required: "true", placeholder: "Enter maternal name" },
              { label: "Relationship to Sender", type: "list", listvalue: ["Spouse", "Parent", "Child", "Sibling", "Friend"], required: "false" },
              { label: "Contact Information (Optional)", type: "subsection", description: "Providing contact information helps ensure smooth delivery", required: "false" },
              { label: "Phone Country Code", type: "list", required: "false", subsection: "Contact Information (Optional)", listvalue: ["+1", "+44", "+52", "+86", "+91"] },
              { label: "Phone Number", type: "text", required: "false", subsection: "Contact Information (Optional)", placeholder: "Enter phone number" }
            ]
          }, 'Receiver ')}
          
          {renderSection({
            title: "Transaction Details",
            description: "Financial information and delivery method",
            fields: [
              { label: "Payout Country", type: "list", listvalue: ["Mexico", "India", "Canada"], required: "true" },
              { label: "Payout Method", type: "list", listvalue: ["Cash Pickup", "Bank Deposit", "Mobile Wallet"], required: "true" },
              { label: "Amount Information", type: "subsection", required: "false" },
              { label: "Send Amount", type: "amount", required: "true", subsection: "Amount Information", placeholder: "0.00" },
              { label: "Payout Amount", type: "amount", required: "false", subsection: "Amount Information", placeholder: "0.00" },
              { label: "Bank Details (For Bank Deposit)", type: "subsection", required: "false" },
              { label: "Bank Name", type: "text", placeholder: "Enter bank name", required: "false", subsection: "Bank Details (For Bank Deposit)" },
              { label: "Account Number", type: "text", placeholder: "Enter account number", required: "false", subsection: "Bank Details (For Bank Deposit)" },
              { label: "Routing Number", type: "text", placeholder: "Enter routing number", required: "false", subsection: "Bank Details (For Bank Deposit)" },
              { label: "Account Type", type: "list", listvalue: ["Checking", "Savings"], required: "false", subsection: "Bank Details (For Bank Deposit)" }
            ]
          }, 'Transaction ')}
          {renderOutput(1)}
        </div>
      );
    } else {
      // Order Confirm tab - read-only version
      return (
        <div>
          {renderSection({
            title: "Sender Details",
            description: "Your personal information",
            input_fields: [
              { label: "First Name", type: "label", required: "true" },
              { label: "Paternal Name", type: "label", required: "true" },
              { label: "Maternal Name", type: "label", required: "true" },
              { label: "Phone Country Code", type: "label", required: "true" },
              { label: "Phone Number", type: "label", required: "true" },
              { label: "Email", type: "label", required: "false" },
              { label: "Address Information", type: "subsection", required: "false" },
              { label: "Address Line 1", type: "label", subsection: "Address Information", required: "true" },
              { label: "Address Line 2", type: "label", subsection: "Address Information", required: "false" },
              { label: "City", type: "label", subsection: "Address Information", required: "true" },
              { label: "Postal Code", type: "label", subsection: "Address Information", required: "true" },
              { label: "Country", type: "label", subsection: "Address Information", required: "true" }
            ]
          })}
          
          {renderSection({
            title: "Receiver Details",
            description: "Recipient Information",
            fields: [
              { label: "First Name", type: "label", required: "true" },
              { label: "Paternal Name", type: "label", required: "true" },
              { label: "Maternal Name", type: "label", required: "true" },
              { label: "Relationship to Sender", type: "label", required: "false" }
            ]
          }, 'Receiver ')}
          
          {renderSection({
            title: "Pricing Information",
            description: "Fee and exchange rate",
            fields: [
              { label: "Exchange Rate", type: "label", required: "false" },
              { label: "Transfer Fee", type: "label", required: "false" }
            ]
          })}
          {renderOutput(2)}
        </div>
      );
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto p-6">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Send Money Worldwide</h1>
          <p className="text-lg text-gray-600">Fast, secure, and reliable money transfers</p>
        </div>

        {/* Step Indicator */}
        {renderStepIndicator()}

        {/* Tab Navigation */}
        <div className="mb-6">
          <div className="border-b border-gray-200">
            <nav className="-mb-px flex space-x-8">
              {tabs.map((tab, index) => (
                <button
                  key={tab}
                  onClick={() => setCurrentTab(index)}
                  className={cn(
                    "py-2 px-1 border-b-2 font-medium text-sm",
                    index === currentTab
                      ? "border-yellow-400 text-yellow-600"
                      : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                  )}
                >
                  {tab}
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* Tab Content */}
        {renderTabContent()}

        {/* Action Buttons */}
        <div className="mt-8 flex justify-center">
          {!submittedTabs[currentTab] ? (
            <Button
              onClick={() => handleSubmit(currentTab)}
              className="bg-yellow-400 hover:bg-yellow-500 text-gray-900 px-8 py-3 text-lg font-medium"
            >
              Submit
            </Button>
          ) : (
            <Button
              onClick={() => handleContinue(currentTab)}
              className="bg-green-500 hover:bg-green-600 text-white px-8 py-3 text-lg font-medium"
            >
              Continue
            </Button>
          )}
        </div>


      </div>
    </div>
  );
}
