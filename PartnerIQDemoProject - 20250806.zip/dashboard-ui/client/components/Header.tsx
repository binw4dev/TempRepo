import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-white shadow-sm border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-3">
            {/* Western Union Logo - Using a modern placeholder */}
            <img
              src="https://cdn.builder.io/api/v1/image/assets%2F12ef3b91196646429dd4b8f74e3c93cd%2Fa5bed23b57a9444abc618fd0de901dbb?format=webp&width=800"
              alt="Western Union"
              className="h-8 w-auto"
            />
            <div className="flex flex-col">
              <h1 className="text-xl font-semibold text-gray-900">
                PartnerIQ Demo Application
              </h1>
              <span className="text-xs text-gray-500 hidden sm:block">
                Powered by Western Union
              </span>
            </div>
          </div>
          
          <nav className="hidden md:flex items-center space-x-6">
            <a href="#" className="text-gray-600 hover:text-gray-900 text-sm font-medium transition-colors">
              Dashboard
            </a>
            <a href="#" className="text-gray-600 hover:text-gray-900 text-sm font-medium transition-colors">
              Analytics
            </a>
            <a href="#" className="text-gray-600 hover:text-gray-900 text-sm font-medium transition-colors">
              Partners
            </a>
            <a href="#" className="text-gray-600 hover:text-gray-900 text-sm font-medium transition-colors">
              Settings
            </a>
          </nav>

          <div className="flex items-center space-x-3">
            <button className="bg-yellow-400 hover:bg-yellow-500 text-black px-4 py-2 rounded-lg text-sm font-medium transition-colors">
              Get Started
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
