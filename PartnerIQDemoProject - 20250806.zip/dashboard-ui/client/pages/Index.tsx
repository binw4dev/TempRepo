import React, { useState } from 'react';
import Header from '../components/Header';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import {
  FlaskConical,
  Settings,
  TestTube,
  Database,
  Link2,
  FileText,
  BarChart3,
  Play,
  CheckCircle,
  XCircle,
  Clock,
  Edit3,
  ChevronDown,
  Trash2
} from "lucide-react";

// Types for test cases
interface TestCase {
  id: string;
  name: string;
  description: string;
  status: "pass" | "fail" | "pending" | "running";
  selected: boolean;
  details?: {
    testToRun: string;
    expectedResults: string;
  };
}

interface TestCategory {
  id: string;
  name: string;
  testCases: TestCase[];
}

export default function Index() {
  const [consoleOutput, setConsoleOutput] = useState<string[]>([]);
  const [isRunning, setIsRunning] = useState<string | null>(null);
  const [selectedLanguage, setSelectedLanguage] = useState<string>('Java');
  const [selectedFrontendFramework, setSelectedFrontendFramework] = useState<string>('React');
  const [selectedWorkflowSteps, setSelectedWorkflowSteps] = useState<string>('Full Integration');
  const [selectedTestingOption, setSelectedTestingOption] = useState<string>('1. Generate Testing Cases');
  const [activeSection, setActiveSection] = useState<'architecture' | 'features'>('features');
  const [currentPath, setCurrentPath] = useState<string>('/');
  const [showTestingSuiteModal, setShowTestingSuiteModal] = useState<boolean>(false);

  // Environment state
  const [environment, setEnvironment] = useState({
    identifier: "",
    counterID: "",
    reference: ""
  });

  // Test cases state
  const [uiTestCategories, setUiTestCategories] = useState<TestCategory[]>([
    {
      id: "order-details",
      name: "Order Details",
      testCases: [
        { id: "od-1", name: "Validate order information display", description: "Test order data rendering", status: "pending", selected: false },
        { id: "od-2", name: "Order status updates", description: "Test real-time status changes", status: "pending", selected: false },
        { id: "od-3", name: "Order history navigation", description: "Test order history access", status: "pending", selected: false }
      ]
    },
    {
      id: "order-response",
      name: "Order Response",
      testCases: [
        { id: "or-1", name: "Success response handling", description: "Test positive order responses", status: "pending", selected: false },
        { id: "or-2", name: "Error response handling", description: "Test error scenarios", status: "pending", selected: false },
        { id: "or-3", name: "Timeout response handling", description: "Test timeout scenarios", status: "pending", selected: false }
      ]
    },
    {
      id: "create-order",
      name: "Create Order",
      testCases: [
        { id: "co-1", name: "Order form validation", description: "Test input validation", status: "pending", selected: false },
        { id: "co-2", name: "Order submission flow", description: "Test complete order creation", status: "pending", selected: false },
        { id: "co-3", name: "Order confirmation display", description: "Test confirmation UI", status: "pending", selected: false }
      ]
    },
    {
      id: "create-order-response",
      name: "Create Order Response",
      testCases: [
        { id: "cor-1", name: "Creation success response", description: "Test successful order creation", status: "pending", selected: false },
        { id: "cor-2", name: "Creation failure response", description: "Test failed order creation", status: "pending", selected: false },
        { id: "cor-3", name: "Partial order response", description: "Test partial completion", status: "pending", selected: false }
      ]
    }
  ]);

  const [backendTestCategories, setBackendTestCategories] = useState<TestCategory[]>([
    {
      id: "api-endpoints",
      name: "API Endpoints",
      testCases: [
        { id: "api-1", name: "GET orders endpoint", description: "Test orders retrieval", status: "pending", selected: false },
        { id: "api-2", name: "POST create order endpoint", description: "Test order creation API", status: "pending", selected: false },
        { id: "api-3", name: "PUT update order endpoint", description: "Test order updates", status: "pending", selected: false }
      ]
    },
    {
      id: "data-validation",
      name: "Data Validation",
      testCases: [
        { id: "dv-1", name: "Input sanitization", description: "Test data cleaning", status: "pending", selected: false },
        { id: "dv-2", name: "Schema validation", description: "Test data structure validation", status: "pending", selected: false },
        { id: "dv-3", name: "Business rule validation", description: "Test business logic", status: "pending", selected: false }
      ]
    },
    {
      id: "authentication",
      name: "Authentication",
      testCases: [
        { id: "auth-1", name: "Token validation", description: "Test JWT token validation", status: "pending", selected: false },
        { id: "auth-2", name: "Permission checks", description: "Test access control", status: "pending", selected: false },
        { id: "auth-3", name: "Session management", description: "Test session handling", status: "pending", selected: false }
      ]
    },
    {
      id: "performance",
      name: "Performance",
      testCases: [
        { id: "perf-1", name: "Response time validation", description: "Test API response times", status: "pending", selected: false },
        { id: "perf-2", name: "Load testing", description: "Test under high load", status: "pending", selected: false },
        { id: "perf-3", name: "Memory usage monitoring", description: "Test memory efficiency", status: "pending", selected: false }
      ]
    }
  ]);

  const [selectedTestCase, setSelectedTestCase] = useState<TestCase | null>(null);
  const [isEditingDetails, setIsEditingDetails] = useState(false);

  // Splunk queries state
  const [splunkQueries, setSplunkQueries] = useState([
    {
      id: "sq-1",
      name: "Order Processing Logs",
      partner: "Partner A",
      query: 'index=orders source="/var/log/orders.log" | search "order_id=' + (environment.identifier || '*') + '"',
      linkedTestCases: ["od-1", "co-2"],
      isActive: true
    },
    {
      id: "sq-2",
      name: "API Error Logs",
      partner: "Partner B",
      query: 'index=api_errors earliest=-1h | search level=ERROR',
      linkedTestCases: ["or-2", "api-1"],
      isActive: false
    }
  ]);

  const [editingSplunkQuery, setEditingSplunkQuery] = useState<any>(null);
  const [isAddingSplunkQuery, setIsAddingSplunkQuery] = useState(false);
  const [logOutput, setLogOutput] = useState<string[]>([
    "[2024-01-20 10:30:15] INFO: Test execution started",
    "[2024-01-20 10:30:16] DEBUG: Environment loaded - ID: " + (environment.identifier || 'not_set'),
    "[2024-01-20 10:30:17] INFO: PartnerOS connection established",
    "[2024-01-20 10:30:18] INFO: Running selected test cases...",
    "[2024-01-20 10:30:19] WARN: No test cases currently selected"
  ]);

  // PartnerOS connections state (now editable)
  const [partnerOSConnections, setPartnerOSConnections] = useState([
    {
      id: "pq-1",
      name: "PartnerOS Health Check",
      method: "GET",
      url: "https://api.partneros.com/health",
      linkedTestCases: ["od-1", "api-1"],
      headers: "Authorization: Bearer ${environment.identifier}",
      body: ""
    },
    {
      id: "pq-2",
      name: "Create Partner Order",
      method: "POST",
      url: "https://api.partneros.com/orders",
      linkedTestCases: ["co-2", "api-2"],
      headers: "Authorization: Bearer ${environment.identifier}\nContent-Type: application/json",
      body: '{\n  "counterID": "${environment.counterID}",\n  "reference": "${environment.reference}"\n}'
    },
    {
      id: "pq-3",
      name: "Get Order Status",
      method: "GET",
      url: "https://api.partneros.com/orders/{orderId}?ref=${environment.reference}",
      linkedTestCases: ["or-1", "dv-2"],
      headers: "Authorization: Bearer ${environment.identifier}",
      body: ""
    }
  ]);

  const [editingPartnerOSConnection, setEditingPartnerOSConnection] = useState<any>(null);
  const [isAddingPartnerOSConnection, setIsAddingPartnerOSConnection] = useState(false);
  const [modalNavigationSource, setModalNavigationSource] = useState<'main' | 'testcase'>('main');

  const toggleTestCase = (categories: TestCategory[], setCategories: React.Dispatch<React.SetStateAction<TestCategory[]>>, categoryId: string, testCaseId: string) => {
    setCategories(categories.map(category => 
      category.id === categoryId 
        ? {
            ...category,
            testCases: category.testCases.map(testCase =>
              testCase.id === testCaseId 
                ? { ...testCase, selected: !testCase.selected }
                : testCase
            )
          }
        : category
    ));
  };

  const openTestCaseDetails = (testCase: TestCase) => {
    setSelectedTestCase(testCase);
    setIsEditingDetails(true);
  };

  const saveTestCaseDetails = (details: { testToRun: string; expectedResults: string }) => {
    if (selectedTestCase) {
      const updateCategories = (categories: TestCategory[]) => 
        categories.map(category => ({
          ...category,
          testCases: category.testCases.map(testCase =>
            testCase.id === selectedTestCase.id 
              ? { ...testCase, details }
              : testCase
          )
        }));

      setUiTestCategories(updateCategories);
      setBackendTestCategories(updateCategories);
      setIsEditingDetails(false);
      setSelectedTestCase(null);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pass": return <CheckCircle className="h-4 w-4 text-green-500" />;
      case "fail": return <XCircle className="h-4 w-4 text-red-500" />;
      case "running": return <Clock className="h-4 w-4 text-blue-500 animate-spin" />;
      default: return <Clock className="h-4 w-4 text-gray-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pass": return "bg-green-100 text-green-800";
      case "fail": return "bg-red-100 text-red-800";
      case "running": return "bg-blue-100 text-blue-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getSelectedTestCaseIds = () => {
    const uiSelected = uiTestCategories.flatMap(cat =>
      cat.testCases.filter(tc => tc.selected).map(tc => tc.id)
    );
    const backendSelected = backendTestCategories.flatMap(cat =>
      cat.testCases.filter(tc => tc.selected).map(tc => tc.id)
    );
    return [...uiSelected, ...backendSelected];
  };

  const runSplunkQuery = (queryId: string) => {
    const query = splunkQueries.find(q => q.id === queryId);
    if (query) {
      // Replace environment variables in the query
      const processedQuery = query.query
        .replace(/\$\{environment\.identifier\}/g, environment.identifier || 'null')
        .replace(/\$\{environment\.counterID\}/g, environment.counterID || 'null')
        .replace(/\$\{environment\.reference\}/g, environment.reference || 'null');

      setLogOutput(prev => [
        ...prev,
        `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Running Splunk query: ${query.name}`,
        `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] DEBUG: Original Query: ${query.query}`,
        `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] DEBUG: Processed Query: ${processedQuery}`,
        `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Partner: ${query.partner}`,
        `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Environment: ID=${environment.identifier || 'not_set'}, Counter=${environment.counterID || 'not_set'}, Ref=${environment.reference || 'not_set'}`,
        `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Searching logs...`
      ]);

      // Simulate log results after a delay
      setTimeout(() => {
        setLogOutput(prev => [
          ...prev,
          `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] RESULT: Found 23 matching log entries`,
          `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Query execution completed`
        ]);
      }, 2000);
    }
  };

  const saveSplunkQuery = (queryData: any) => {
    if (editingSplunkQuery) {
      setSplunkQueries(prev => prev.map(q =>
        q.id === editingSplunkQuery.id ? { ...q, ...queryData } : q
      ));
    } else {
      const newQuery = {
        id: `sq-${Date.now()}`,
        isActive: false,
        ...queryData
      };
      setSplunkQueries(prev => [...prev, newQuery]);
    }
    setEditingSplunkQuery(null);
    setIsAddingSplunkQuery(false);
  };

  const deleteSplunkQuery = (queryId: string) => {
    setSplunkQueries(prev => prev.filter(q => q.id !== queryId));
  };

  // PartnerOS connection management functions
  const savePartnerOSConnection = (connectionData: any) => {
    if (editingPartnerOSConnection) {
      setPartnerOSConnections(prev => prev.map(conn =>
        conn.id === editingPartnerOSConnection.id ? { ...conn, ...connectionData } : conn
      ));
    } else {
      const newConnection = {
        id: `pq-${Date.now()}`,
        ...connectionData
      };
      setPartnerOSConnections(prev => [...prev, newConnection]);
    }
    setEditingPartnerOSConnection(null);
    setIsAddingPartnerOSConnection(false);
  };

  const deletePartnerOSConnection = (connectionId: string) => {
    setPartnerOSConnections(prev => prev.filter(conn => conn.id !== connectionId));
  };

  const runPartnerOSConnection = (connectionId: string) => {
    const connection = partnerOSConnections.find(conn => conn.id === connectionId);
    if (connection) {
      // Replace environment variables in the connection
      const processedUrl = connection.url
        .replace(/\$\{environment\.identifier\}/g, environment.identifier || 'null')
        .replace(/\$\{environment\.counterID\}/g, environment.counterID || 'null')
        .replace(/\$\{environment\.reference\}/g, environment.reference || 'null');

      const processedHeaders = connection.headers
        .replace(/\$\{environment\.identifier\}/g, environment.identifier || 'null')
        .replace(/\$\{environment\.counterID\}/g, environment.counterID || 'null')
        .replace(/\$\{environment\.reference\}/g, environment.reference || 'null');

      const processedBody = connection.body
        .replace(/\$\{environment\.identifier\}/g, environment.identifier || 'null')
        .replace(/\$\{environment\.counterID\}/g, environment.counterID || 'null')
        .replace(/\$\{environment\.reference\}/g, environment.reference || 'null');

      setLogOutput(prev => [
        ...prev,
        `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Running PartnerOS connection: ${connection.name}`,
        `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] DEBUG: ${connection.method} ${processedUrl}`,
        `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] DEBUG: Headers: ${processedHeaders}`,
        processedBody ? `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] DEBUG: Body: ${processedBody}` : '',
        `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Executing request...`
      ].filter(Boolean));

      // Simulate API response
      setTimeout(() => {
        setLogOutput(prev => [
          ...prev,
          `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] RESULT: HTTP 200 - Request successful`,
          `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: PartnerOS connection completed`
        ]);
      }, 1500);
    }
  };

  // Playwright test runner functions
  const [isRunningTests, setIsRunningTests] = useState(false);
  const [isRunningBackendTests, setIsRunningBackendTests] = useState(false);
  const [testResults, setTestResults] = useState<{[key: string]: any}>({});

  const runPlaywrightTests = async () => {
    const selectedTests = uiTestCategories.flatMap(category =>
      category.testCases.filter(tc => tc.selected)
    );

    if (selectedTests.length === 0) {
      setLogOutput(prev => [
        ...prev,
        `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] WARN: No UI test cases selected for execution`
      ]);
      return;
    }

    setIsRunningTests(true);

    // Update selected tests to running status
    setUiTestCategories(prev => prev.map(category => ({
      ...category,
      testCases: category.testCases.map(tc =>
        tc.selected ? { ...tc, status: "running" as const } : tc
      )
    })));

    setLogOutput(prev => [
      ...prev,
      `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Starting Playwright test execution`,
      `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Selected tests: ${selectedTests.map(t => t.id).join(', ')}`,
      `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Environment Variables:`,
      `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: - IDENTIFIER=${environment.identifier || 'not_set'}`,
      `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: - COUNTER_ID=${environment.counterID || 'not_set'}`,
      `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: - REFERENCE=${environment.reference || 'not_set'}`,
      `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Launching Python Playwright runner...`
    ]);

    // Simulate test execution
    for (let i = 0; i < selectedTests.length; i++) {
      const test = selectedTests[i];

      setTimeout(() => {
        setLogOutput(prev => [
          ...prev,
          `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Running test: ${test.name}`,
          `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] DEBUG: IDENTIFIER=${environment.identifier || 'not_set'} COUNTER_ID=${environment.counterID || 'not_set'} REFERENCE=${environment.reference || 'not_set'} pytest tests/ui/${test.id}.py --browser=chromium`
        ]);
      }, (i + 1) * 1000);

      setTimeout(() => {
        const success = Math.random() > 0.3; // 70% success rate for demo
        const status = success ? "pass" : "fail";

        setUiTestCategories(prev => prev.map(category => ({
          ...category,
          testCases: category.testCases.map(tc =>
            tc.id === test.id ? { ...tc, status } : tc
          )
        })));

        setLogOutput(prev => [
          ...prev,
          `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] ${success ? 'PASS' : 'FAIL'}: ${test.name} - ${success ? 'Test completed successfully' : 'Test failed with assertion error'}`
        ]);

        if (i === selectedTests.length - 1) {
          setTimeout(() => {
            setIsRunningTests(false);
            setLogOutput(prev => [
              ...prev,
              `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Playwright test execution completed`,
              `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Results summary available in Results tab`
            ]);
          }, 500);
        }
      }, (i + 2) * 1000);
    }
  };

  const runCategoryTests = (categoryId: string) => {
    const category = uiTestCategories.find(cat => cat.id === categoryId);
    if (!category) return;

    // Select all tests in this category
    setUiTestCategories(prev => prev.map(cat =>
      cat.id === categoryId
        ? {
            ...cat,
            testCases: cat.testCases.map(tc => ({ ...tc, selected: true }))
          }
        : cat
    ));

    // Run tests after a brief delay to allow UI update
    setTimeout(() => {
      runPlaywrightTests();
    }, 100);
  };

  // Backend test runner functions with Playwright automation
  const runBackendTests = async () => {
    const selectedTests = backendTestCategories.flatMap(category =>
      category.testCases.filter(tc => tc.selected)
    );

    if (selectedTests.length === 0) {
      setLogOutput(prev => [
        ...prev,
        `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] WARN: No backend test cases selected for execution`
      ]);
      return;
    }

    setIsRunningBackendTests(true);

    // Update selected tests to running status
    setBackendTestCategories(prev => prev.map(category => ({
      ...category,
      testCases: category.testCases.map(tc =>
        tc.selected ? { ...tc, status: "running" as const } : tc
      )
    })));

    setLogOutput(prev => [
      ...prev,
      `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: ======= BACKEND PLAYWRIGHT TEST EXECUTION STARTED =======`,
      `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Selected backend tests: ${selectedTests.map(t => t.id).join(', ')}`,
      `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Playwright Backend Automation Framework: Python + API Testing`,
      `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Environment Variables:`,
      `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: - IDENTIFIER=${environment.identifier || 'not_set'}`,
      `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: - COUNTER_ID=${environment.counterID || 'not_set'}`,
      `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: - REFERENCE=${environment.reference || 'not_set'}`,
      `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Launching headless Chromium for backend testing...`
    ]);

    // Execute tests sequentially
    for (let i = 0; i < selectedTests.length; i++) {
      const test = selectedTests[i];

      setTimeout(() => {
        setLogOutput(prev => [
          ...prev,
          `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: ===== EXECUTING PLAYWRIGHT BACKEND TEST: ${test.name} =====`,
          `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Test ID: ${test.id}`,
          `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Description: ${test.description}`,
          `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] DEBUG: IDENTIFIER=${environment.identifier || 'not_set'} COUNTER_ID=${environment.counterID || 'not_set'} REFERENCE=${environment.reference || 'not_set'} pytest tests/backend/${test.id}.py --browser=chromium --headless`,
          `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Initializing Playwright browser context for backend testing...`
        ]);

        // Find linked PartnerOS connections
        const linkedConnections = partnerOSConnections.filter(conn =>
          conn.linkedTestCases.includes(test.id)
        );

        // Find linked Splunk queries
        const linkedQueries = splunkQueries.filter(query =>
          query.linkedTestCases.includes(test.id)
        );

        setLogOutput(prev => [
          ...prev,
          `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Found ${linkedConnections.length} linked PartnerOS connections`,
          `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Found ${linkedQueries.length} linked Splunk queries`
        ]);

        // Execute linked PartnerOS connections
        linkedConnections.forEach((connection, connIndex) => {
          setTimeout(() => {
            const processedUrl = connection.url
              .replace(/\$\{environment\.identifier\}/g, environment.identifier || 'null')
              .replace(/\$\{environment\.counterID\}/g, environment.counterID || 'null')
              .replace(/\$\{environment\.reference\}/g, environment.reference || 'null');

            const processedHeaders = connection.headers
              .replace(/\$\{environment\.identifier\}/g, environment.identifier || 'null')
              .replace(/\$\{environment\.counterID\}/g, environment.counterID || 'null')
              .replace(/\$\{environment\.reference\}/g, environment.reference || 'null');

            setLogOutput(prev => [
              ...prev,
              `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: --- Playwright: Executing PartnerOS Connection: ${connection.name} ---`,
              `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] DEBUG: Creating new browser page for API testing`,
              `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] DEBUG: Playwright Request: ${connection.method} ${processedUrl}`,
              `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] DEBUG: Headers: ${processedHeaders}`,
              connection.body ? `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] DEBUG: Body: ${connection.body}` : '',
              `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Playwright: Making API request via browser context...`
            ].filter(Boolean));

            // Simulate Playwright API response
            setTimeout(() => {
              const success = Math.random() > 0.2; // 80% success rate
              setLogOutput(prev => [
                ...prev,
                `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Playwright: API request executed via browser context`,
                `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] ${success ? 'SUCCESS' : 'ERROR'}: PartnerOS ${connection.name} - ${success ? 'HTTP 200 OK' : 'HTTP 500 Internal Server Error'}`,
                success ?
                  `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] RESULT: Playwright validated response data structure` :
                  `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] ERROR: Playwright detected API failure - timeout or server error`,
                `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Playwright: Closing API request page context`
              ]);
            }, 500 + (connIndex * 300));
          }, 200 + (connIndex * 500));
        });

        // Execute linked Splunk queries
        linkedQueries.forEach((query, queryIndex) => {
          setTimeout(() => {
            const processedQuery = query.query
              .replace(/\$\{environment\.identifier\}/g, environment.identifier || 'null')
              .replace(/\$\{environment\.counterID\}/g, environment.counterID || 'null')
              .replace(/\$\{environment\.reference\}/g, environment.reference || 'null');

            setLogOutput(prev => [
              ...prev,
              `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: --- Playwright: Executing Splunk Query: ${query.name} ---`,
              `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] DEBUG: Playwright: Navigating to Splunk interface`,
              `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] DEBUG: Partner: ${query.partner}`,
              `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] DEBUG: Playwright: Injecting query: ${processedQuery}`,
              `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Playwright: Automated search execution for test case ${test.id}...`
            ]);

            // Simulate Playwright-automated Splunk query results
            setTimeout(() => {
              const logCount = Math.floor(Math.random() * 50) + 1;
              const hasErrors = Math.random() > 0.6;
              setLogOutput(prev => [
                ...prev,
                `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Playwright: Query execution completed`,
                `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] RESULT: Playwright extracted ${logCount} log entries for ${query.name}`,
                `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Playwright: Automated log analysis performed`,
                hasErrors ?
                  `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] WARN: Playwright detected ${Math.floor(Math.random() * 5) + 1} error entries in logs` :
                  `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Playwright: No errors found in automated log analysis`,
                `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Playwright: Closing Splunk browser session`
              ]);
            }, 800 + (queryIndex * 400));
          }, 1000 + (queryIndex * 600));
        });

        // Determine test result after all connections and queries
        setTimeout(() => {
          const success = Math.random() > 0.25; // 75% success rate
          const status = success ? "pass" : "fail";

          setBackendTestCategories(prev => prev.map(category => ({
            ...category,
            testCases: category.testCases.map(tc =>
              tc.id === test.id ? { ...tc, status } : tc
            )
          })));

          setLogOutput(prev => [
            ...prev,
            `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Playwright: Cleaning up browser contexts and resources`,
            `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] ${success ? 'PASS' : 'FAIL'}: Playwright Backend test ${test.name} - ${success ? 'All automated validations successful' : 'Playwright test failed validation checks'}`,
            `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Playwright: Browser session closed for test ${test.id}`,
            `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: ===== PLAYWRIGHT TEST ${test.id} COMPLETED =====`
          ]);

          // Complete the test execution when all tests are done
          if (i === selectedTests.length - 1) {
            setTimeout(() => {
              setIsRunningBackendTests(false);
              setLogOutput(prev => [
                ...prev,
                `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: ======= BACKEND PLAYWRIGHT TEST EXECUTION COMPLETED =======`,
                `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Total Playwright backend tests executed: ${selectedTests.length}`,
                `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Playwright automation framework: API testing + Log analysis`,
                `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: All browser contexts and resources cleaned up`,
                `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Results summary available in Results tab`
              ]);
            }, 500);
          }
        }, 2000 + (linkedConnections.length * 500) + (linkedQueries.length * 600));

      }, i * 4000); // Stagger each test by 4 seconds
    }
  };

  const runBackendCategoryTests = (categoryId: string) => {
    const category = backendTestCategories.find(cat => cat.id === categoryId);
    if (!category) return;

    // Select all tests in this category
    setBackendTestCategories(prev => prev.map(cat =>
      cat.id === categoryId
        ? {
            ...cat,
            testCases: cat.testCases.map(tc => ({ ...tc, selected: true }))
          }
        : cat
    ));

    // Run tests after a brief delay to allow UI update
    setTimeout(() => {
      runBackendTests();
    }, 100);
  };

  // Environment management functions
  const clearEnvironmentSettings = () => {
    setEnvironment({
      identifier: "",
      counterID: "",
      reference: ""
    });

    // Log the environment clear action
    setLogOutput(prev => [
      ...prev,
      `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: Environment settings cleared`,
      `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: All environment variables reset to empty values`,
      `[${new Date().toISOString().slice(0, 19).replace('T', ' ')}] INFO: This will affect all connections, queries, and test executions`
    ]);
  };

  // Mock file system structure
  const fileSystem: Record<string, any> = {
    '/': {
      'package.json': { type: 'file', size: '2.1 KB' },
      'README.md': { type: 'file', size: '1.5 KB' },
      'tsconfig.json': { type: 'file', size: '450 B' },
      'tailwind.config.ts': { type: 'file', size: '1.2 KB' },
      'vite.config.ts': { type: 'file', size: '800 B' },
      'client/': { type: 'directory' },
      'server/': { type: 'directory' },
      'shared/': { type: 'directory' },
      'public/': { type: 'directory' }
    },
    '/client/': {
      'App.tsx': { type: 'file', size: '1.1 KB' },
      'global.css': { type: 'file', size: '3.2 KB' },
      'vite-env.d.ts': { type: 'file', size: '200 B' },
      'pages/': { type: 'directory' },
      'components/': { type: 'directory' },
      'hooks/': { type: 'directory' },
      'lib/': { type: 'directory' }
    },
    '/client/pages/': {
      'Index.tsx': { type: 'file', size: '28.5 KB' },
      'NotFound.tsx': { type: 'file', size: '850 B' }
    },
    '/client/components/': {
      'Header.tsx': { type: 'file', size: '2.3 KB' },
      'ui/': { type: 'directory' }
    },
    '/client/components/ui/': {
      'button.tsx': { type: 'file', size: '1.5 KB' },
      'card.tsx': { type: 'file', size: '900 B' },
      'input.tsx': { type: 'file', size: '1.2 KB' },
      'select.tsx': { type: 'file', size: '1.8 KB' },
      'toast.tsx': { type: 'file', size: '2.1 KB' }
    },
    '/server/': {
      'index.ts': { type: 'file', size: '2.8 KB' },
      'node-build.ts': { type: 'file', size: '600 B' },
      'routes/': { type: 'directory' }
    },
    '/server/routes/': {
      'demo.ts': { type: 'file', size: '450 B' }
    },
    '/shared/': {
      'api.ts': { type: 'file', size: '320 B' }
    },
    '/public/': {
      'placeholder.svg': { type: 'file', size: '2.4 KB' },
      'robots.txt': { type: 'file', size: '150 B' }
    }
  };

  const openFeaturesSection = () => {
    setActiveSection('features');
    // Scroll to the Interactive Demo Features section after a brief delay to allow state update
    setTimeout(() => {
      const element = document.getElementById('interactive-demo-features');
      if (element) {
        element.scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });
      }
    }, 100);
  };

  const navigateToPath = (newPath: string) => {
    if (fileSystem[newPath]) {
      setCurrentPath(newPath);
    }
  };

  const navigateUp = () => {
    if (currentPath === '/') return;
    const pathParts = currentPath.split('/').filter(Boolean);
    pathParts.pop();
    const parentPath = pathParts.length > 0 ? '/' + pathParts.join('/') + '/' : '/';
    navigateToPath(parentPath);
  };

  const navigateDown = (folderName: string) => {
    const newPath = currentPath === '/' ? `/${folderName}` : `${currentPath}${folderName}`;
    navigateToPath(newPath);
  };

  const getCurrentDirectoryContents = () => {
    return fileSystem[currentPath] || {};
  };

  const runFeature = async (featureType: 'backend' | 'frontend' | 'partneros') => {
    setIsRunning(featureType);
    setConsoleOutput([]);

    const logs = getFeatureLogs(featureType);

    for (let i = 0; i < logs.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 500 + Math.random() * 1000));
      setConsoleOutput(prev => [...prev, logs[i]]);
    }

    setIsRunning(null);
  };

  const getFileExtension = (language: string) => {
    switch (language) {
      case 'Java': return '.java';
      case 'Python': return '.py';
      case 'C#': return '.cs';
      case 'Node.js': return '.js';
      case 'Go': return '.go';
      case 'PHP': return '.php';
      case 'Ruby': return '.rb';
      default: return '.java';
    }
  };

  const getFramework = (language: string) => {
    switch (language) {
      case 'Java': return 'Spring Boot';
      case 'Python': return 'FastAPI';
      case 'C#': return '.NET Core';
      case 'Node.js': return 'Express.js';
      case 'Go': return 'Gin';
      case 'PHP': return 'Laravel';
      case 'Ruby': return 'Ruby on Rails';
      default: return 'Spring Boot';
    }
  };

  const getFrontendFileExtension = (framework: string) => {
    switch (framework) {
      case 'React': return '.jsx';
      case 'Angular': return '.component.ts';
      case 'Vue': return '.vue';
      case 'Svelte': return '.svelte';
      case 'Next.js': return '.tsx';
      case 'Nuxt.js': return '.vue';
      case 'Vanilla JS': return '.js';
      default: return '.jsx';
    }
  };

  const getFrontendBuildTool = (framework: string) => {
    switch (framework) {
      case 'React': return 'Vite';
      case 'Angular': return 'Angular CLI';
      case 'Vue': return 'Vue CLI';
      case 'Svelte': return 'SvelteKit';
      case 'Next.js': return 'Next.js';
      case 'Nuxt.js': return 'Nuxt.js';
      case 'Vanilla JS': return 'Webpack';
      default: return 'Vite';
    }
  };

  const getWorkflowLogs = (workflowType: string) => {
    switch (workflowType) {
      case 'Full Integration':
        return [
          '[↗ - Generate End-to-End Workflow]',
          'Initializing full stack integration...',
          '-->Connecting PartnerOS with Backend App',
          'Setting up PartnerOS SDK integration...',
          '-->SDK version 2.4.1 downloaded successfully',
          '-->API keys and OAuth 2.0 setup complete',
          'Configuring Backend API endpoints...',
          `-->Integrating ${selectedLanguage} backend with PartnerOS`,
          '-->Partner CRUD operations configured',
          'Connecting Backend with Frontend...',
          `-->Setting up ${selectedFrontendFramework} API integration`,
          '-->State management and data flow configured',
          'Testing end-to-end workflow...',
          '-->Authentication flow: ✓ Passed',
          '-->Data synchronization: ✓ Passed',
          '-->Transaction processing: ✓ Passed',
          'End-to-end workflow generation completed successfully.'
        ];
      case 'PartnerOS + Backend':
        return [
          '[↗ - PartnerOS + Backend Integration]',
          'Focusing on PartnerOS and Backend integration...',
          'Downloading PartnerOS SDK...',
          '-->SDK version 2.4.1 downloaded successfully',
          `-->Installing ${selectedLanguage} SDK dependencies`,
          'Configuring authentication...',
          '-->API keys and OAuth 2.0 setup complete',
          `-->Setting up ${selectedLanguage} authentication middleware`,
          'Setting up partner management endpoints...',
          `-->Generating ${selectedLanguage} API controllers`,
          '-->Partner CRUD operations configured',
          'Establishing real-time data sync...',
          '-->WebSocket connections established',
          '-->Database synchronization configured',
          'Testing PartnerOS-Backend integration...',
          '-->All 12 integration tests passed',
          'PartnerOS + Backend integration completed successfully.'
        ];
      case 'Backend + Frontend':
        return [
          '[↗ - Backend + Frontend Integration]',
          'Focusing on Backend and Frontend integration...',
          `-->Connecting ${selectedLanguage} backend with ${selectedFrontendFramework} frontend`,
          'Setting up API communication layer...',
          `-->Generating ${selectedFrontendFramework} API service layer`,
          '-->HTTP client configuration completed',
          'Configuring data models and interfaces...',
          `-->TypeScript interfaces generated for ${selectedFrontendFramework}`,
          '-->Data validation schemas synchronized',
          'Setting up state management...',
          `-->${selectedFrontendFramework} state management configured`,
          '-->API response caching implemented',
          'Implementing error handling...',
          '-->Global error handling middleware setup',
          '-->User-friendly error messages configured',
          'Testing Backend-Frontend integration...',
          '-->API endpoints: ✓ All 8 tests passed',
          '-->Data flow: ✓ Passed',
          'Backend + Frontend integration completed successfully.'
        ];
      default:
        return [];
    }
  };

  const getTestingLogs = (testingType: string) => {
    switch (testingType) {
      case '1. Generate Testing Cases':
        return [
          '[↗ - Generate Testing Cases]',
          'Analyzing application structure...',
          `-->Scanning ${selectedLanguage} backend endpoints`,
          `-->Analyzing ${selectedFrontendFramework} frontend components`,
          'Generating comprehensive test suites...',
          '-->Unit test cases generated for backend APIs',
          '-->Component test cases generated for frontend',
          '-->Integration test cases generated for end-to-end flows',
          'Creating test data and mock scenarios...',
          '-->Test data templates created',
          '-->Mock user scenarios defined',
          '-->Edge case test scenarios generated',
          'Generating automated test scripts...',
          '-->Jest test files generated for backend',
          `-->${selectedFrontendFramework === 'Angular' ? 'Jasmine/Karma' : 'Jest/Testing Library'} tests for frontend`,
          '-->Cypress E2E test scripts generated',
          'Testing case generation completed successfully.'
        ];
      case '2. Build Testing Environment':
        return [
          '[↗ - Build Testing Environment]',
          'Setting up isolated testing environment...',
          '-->Creating Docker containers for testing',
          '-->Setting up test databases with sample data',
          'Configuring testing infrastructure...',
          `-->Configuring ${selectedLanguage} testing frameworks`,
          `-->${selectedFrontendFramework} testing environment setup`,
          '-->CI/CD pipeline configuration for automated testing',
          'Installing testing dependencies...',
          '-->Test runners and assertion libraries installed',
          '-->Mock servers and testing utilities configured',
          '-->Performance testing tools integrated',
          'Environment validation and health checks...',
          '-->Database connections verified',
          '-->API endpoints accessibility confirmed',
          '-->Frontend test environment ready',
          'Testing environment build completed successfully.'
        ];
      case '3. Run Application':
        return [
          '[↗ - Run Application]',
          'Starting comprehensive application testing...',
          '-->Launching backend services in test mode',
          `-->Starting ${selectedFrontendFramework} development server`,
          'Executing automated test suites...',
          '-->Running unit tests: ✓ 45/45 passed',
          '-->Running integration tests: ✓ 23/23 passed',
          '-->Running component tests: ✓ 31/31 passed',
          'Performing end-to-end testing...',
          '-->User authentication flow: ✓ Passed',
          '-->Data submission and validation: ✓ Passed',
          '-->Cross-browser compatibility: ✓ Passed',
          'Running performance and load tests...',
          '-->Response time analysis: ✓ Average 245ms',
          '-->Memory usage optimization: ✓ Within limits',
          '-->Concurrent user testing: ✓ 100 users supported',
          'Application testing completed successfully.'
        ];
      default:
        return [];
    }
  };

  const runTestingSuite = () => {
    setShowTestingSuiteModal(true);
  };

  const getFeatureLogs = (featureType: 'backend' | 'frontend' | 'partneros' | 'testing') => {
    switch (featureType) {
      case 'backend':
        const fileExtension = getFileExtension(selectedLanguage);
        const framework = getFramework(selectedLanguage);
        return [
          '[↗ - Create Backend]',
          `Creating ${selectedLanguage}-based backend application...`,
          `-->Setting up ${framework} project structure`,
          `-->${selectedLanguage}-based backend application created successfully:`,
          `D:\\dev\\workspace\\PartnerIQDemoProject\\dashboard\\backend\\generated-artifacts\\server${fileExtension}`,
          `Installing ${selectedLanguage} dependencies...`,
          `-->Dependencies installed successfully`,
          'Requesting PartnerOS api docs',
          '-->api doc saved to generated-artifacts/api-docs\\catalog_api-docs_spec.json',
          '-->api doc saved to generated-artifacts/api-docs\\workflow_api-docs_spec.json',
          '-->api doc saved to generated-artifacts/api-docs\\metadata_api-docs_spec.json',
          'Requesting Backend api docs',
          '-->api doc saved to generated-artifacts/api-docs\\backend_api-docs_spec.json',
          '-->api doc saved to generated-artifacts/api-docs\\backend_ui_generation_spec.json',
          `${selectedLanguage} backend generation completed successfully.`
        ];
      case 'frontend':
        const frontendFileExt = getFrontendFileExtension(selectedFrontendFramework);
        const buildTool = getFrontendBuildTool(selectedFrontendFramework);
        return [
          '[↗ - Generate Frontend UI]',
          `Initializing ${selectedFrontendFramework} frontend generation...`,
          `-->Setting up ${buildTool} project structure`,
          `-->Setting up component library and design system`,
          'Creating responsive layouts...',
          `-->Generated components: Header${frontendFileExt}, Navigation${frontendFileExt}, Dashboard${frontendFileExt}`,
          'D:\\dev\\workspace\\PartnerIQDemoProject\\frontend\\src\\components\\',
          `Applying ${selectedFrontendFramework === 'Angular' ? 'SCSS' : 'TailwindCSS'} styling...`,
          '-->Styled components with responsive breakpoints',
          `Setting up routing and state management...`,
          `-->${selectedFrontendFramework} Router and state management configured`,
          'Building interactive elements...',
          '-->Forms, buttons, and data tables generated',
          'Optimizing for mobile and desktop...',
          '-->Responsive design patterns applied',
          `${selectedFrontendFramework} frontend UI generation completed successfully.`
        ];
      case 'partneros':
        return getWorkflowLogs(selectedWorkflowSteps);
      case 'testing':
        return getTestingLogs(selectedTestingOption);
      default:
        return [];
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Partner<span className="text-yellow-400">IQ</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-300 mb-4">
              Demo Application
            </p>
            <p className="text-lg text-gray-400 max-w-3xl mx-auto mb-8">
              Experience the power of intelligent partner management and analytics.
              Built with cutting-edge technology to deliver insights that drive business growth.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={openFeaturesSection}
                className="bg-yellow-400 hover:bg-yellow-500 text-black px-8 py-3 rounded-lg font-semibold text-lg transition-all transform hover:scale-105"
              >
                Start Demo
              </button>
              <button className="border border-gray-600 hover:border-gray-500 text-white px-8 py-3 rounded-lg font-semibold text-lg transition-all hover:bg-gray-800">
                Learn More
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Powerful Features
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto mb-8">
              Discover how PartnerIQ revolutionizes partner management with intelligent insights and seamless integration.
            </p>

            {/* Step Indicator */}
            <div className="flex flex-col sm:flex-row justify-center items-center gap-6 max-w-5xl mx-auto">
              <div className="flex items-center">
                <div className="w-8 h-8 bg-yellow-400 text-black rounded-full flex items-center justify-center font-semibold text-sm">
                  1
                </div>
                <div className="ml-3 text-left">
                  <div className="text-sm font-semibold text-gray-900">Generate Backend App</div>
                  <div className="text-xs text-gray-600">Create robust APIs</div>
                </div>
              </div>

              <div className="hidden sm:block w-8 h-px bg-gray-300"></div>
              <div className="sm:hidden w-px h-8 bg-gray-300"></div>

              <div className="flex items-center">
                <div className="w-8 h-8 bg-yellow-400 text-black rounded-full flex items-center justify-center font-semibold text-sm">
                  2
                </div>
                <div className="ml-3 text-left">
                  <div className="text-sm font-semibold text-gray-900">Generate Frontend UI</div>
                  <div className="text-xs text-gray-600">Build responsive interfaces</div>
                </div>
              </div>

              <div className="hidden sm:block w-8 h-px bg-gray-300"></div>
              <div className="sm:hidden w-px h-8 bg-gray-300"></div>

              <div className="flex items-center">
                <div className="w-8 h-8 bg-yellow-400 text-black rounded-full flex items-center justify-center font-semibold text-sm">
                  3
                </div>
                <div className="ml-3 text-left">
                  <div className="text-sm font-semibold text-gray-900">Generate End-to-End Workflow</div>
                  <div className="text-xs text-gray-600">Connect all components</div>
                </div>
              </div>

              <div className="hidden sm:block w-8 h-px bg-gray-300"></div>
              <div className="sm:hidden w-px h-8 bg-gray-300"></div>

              <div className="flex items-center">
                <div className="w-8 h-8 bg-yellow-400 text-black rounded-full flex items-center justify-center font-semibold text-sm">
                  4
                </div>
                <div className="ml-3 text-left">
                  <div className="text-sm font-semibold text-gray-900">Test Application Online</div>
                  <div className="text-xs text-gray-600">Validate functionality</div>
                </div>
              </div>
            </div>
          </div>

          {/* Collapsible Sub-sections */}
          <div className="mb-20">
            {/* Sub-section 1: Architecture Overview */}
            <div className="bg-white rounded-xl shadow-lg mb-8 overflow-hidden">
              <button
                onClick={() => setActiveSection(activeSection === 'architecture' ? 'features' : 'architecture')}
                className="w-full px-8 py-6 text-left hover:bg-gray-50 transition-colors flex items-center justify-between"
              >
                <div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">
                    Solution Architecture Overview
                  </h3>
                  <p className="text-gray-600">
                    Explore how PartnerIQ integrates with PartnerOS APIs to auto-generate backend services and frontend UIs.
                  </p>
                </div>
                <div className="ml-4">
                  <svg 
                    className={`w-6 h-6 text-gray-500 transition-transform duration-200 ${activeSection === 'architecture' ? 'rotate-180' : ''}`}
                    fill="none" 
                    stroke="currentColor" 
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </div>
              </button>
              
              {activeSection === 'architecture' && (
                <div className="px-8 pb-8">
                  <div className="border-t border-gray-200 pt-8">
                    {/* Architecture diagrams would go here */}
                    <div className="bg-gray-50 rounded-xl p-8 mb-12">
                      <h4 className="text-xl font-semibold text-gray-900 mb-6 text-center">
                        Architecture Goal 1: System Auto-Generation via PartnerOS API
                      </h4>
                      <p className="text-center text-gray-600">Architecture diagram visualization would be displayed here</p>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Sub-section 2: Features */}
            <div id="interactive-demo-features" className="bg-white rounded-xl shadow-lg overflow-hidden">
              <button
                onClick={() => setActiveSection(activeSection === 'features' ? 'architecture' : 'features')}
                className="w-full px-8 py-6 text-left hover:bg-gray-50 transition-colors flex items-center justify-between"
              >
                <div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">
                    Interactive Demo Features
                  </h3>
                  <p className="text-gray-600">
                    Try out the powerful code generation and integration capabilities with live demos.
                  </p>
                </div>
                <div className="ml-4">
                  <svg 
                    className={`w-6 h-6 text-gray-500 transition-transform duration-200 ${activeSection === 'features' ? 'rotate-180' : ''}`}
                    fill="none" 
                    stroke="currentColor" 
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </div>
              </button>
              
              {activeSection === 'features' && (
                <div className="px-8 pb-8">
                  <div className="border-t border-gray-200 pt-8">
                    <div className="grid md:grid-cols-3 gap-8">
                      <div className="bg-gray-50 rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow">
                        <div className="flex items-center gap-4 mb-6">
                          <div className="w-12 h-12 bg-yellow-400 rounded-lg flex items-center justify-center">
                            <svg className="w-6 h-6 text-black" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 12h14M5 12a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2M5 12a2 2 0 00-2 2v4a2 2 0 002 2h14a2 2 0 002-2v-4a2 2 0 00-2-2m-2-4h.01M17 16h.01" />
                            </svg>
                          </div>
                          <h3 className="text-xl font-semibold text-gray-900">
                            Generate Backend App
                          </h3>
                        </div>
                        <p className="text-gray-600 mb-6">
                          Automatically generate robust backend applications with API endpoints, database models, and business logic tailored to your partner requirements.
                        </p>
                        <div className="mb-4">
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Programming Language
                          </label>
                          <select
                            value={selectedLanguage}
                            onChange={(e) => setSelectedLanguage(e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent"
                          >
                            <option value="Java">Java (Spring Boot)</option>
                            <option value="Python">Python (FastAPI)</option>
                            <option value="C#">C# (.NET Core)</option>
                            <option value="Node.js">Node.js (Express.js)</option>
                            <option value="Go">Go (Gin)</option>
                            <option value="PHP">PHP (Laravel)</option>
                            <option value="Ruby">Ruby (Ruby on Rails)</option>
                          </select>
                        </div>
                        <button
                          onClick={() => runFeature('backend')}
                          disabled={isRunning !== null}
                          className="bg-yellow-400 hover:bg-yellow-500 disabled:bg-gray-300 disabled:cursor-not-allowed text-black px-4 py-2 rounded-lg font-semibold text-sm transition-colors"
                        >
                          {isRunning === 'backend' ? 'Running...' : 'Run Demo'}
                        </button>
                      </div>

                      <div className="bg-gray-50 rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow">
                        <div className="flex items-center gap-4 mb-6">
                          <div className="w-12 h-12 bg-yellow-400 rounded-lg flex items-center justify-center">
                            <svg className="w-6 h-6 text-black" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                            </svg>
                          </div>
                          <h3 className="text-xl font-semibold text-gray-900">
                            Generate Frontend UI
                          </h3>
                        </div>
                        <p className="text-gray-600 mb-6">
                          Create responsive, modern user interfaces with pre-built components, design systems, and interactive elements for seamless user experiences.
                        </p>
                        <div className="mb-4">
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Frontend Framework
                          </label>
                          <select
                            value={selectedFrontendFramework}
                            onChange={(e) => setSelectedFrontendFramework(e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent"
                          >
                            <option value="React">React (Vite)</option>
                            <option value="Angular">Angular (Angular CLI)</option>
                            <option value="Vue">Vue (Vue CLI)</option>
                            <option value="Svelte">Svelte (SvelteKit)</option>
                            <option value="Next.js">Next.js (React)</option>
                            <option value="Nuxt.js">Nuxt.js (Vue)</option>
                            <option value="Vanilla JS">Vanilla JS (Webpack)</option>
                          </select>
                        </div>
                        <button
                          onClick={() => runFeature('frontend')}
                          disabled={isRunning !== null}
                          className="bg-yellow-400 hover:bg-yellow-500 disabled:bg-gray-300 disabled:cursor-not-allowed text-black px-4 py-2 rounded-lg font-semibold text-sm transition-colors"
                        >
                          {isRunning === 'frontend' ? 'Running...' : 'Run Demo'}
                        </button>
                      </div>

                      <div className="bg-gray-50 rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow">
                        <div className="flex items-center gap-4 mb-6">
                          <div className="w-12 h-12 bg-yellow-400 rounded-lg flex items-center justify-center">
                            <svg className="w-6 h-6 text-black" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M9 19l3 3m0 0l3-3m-3 3V10" />
                            </svg>
                          </div>
                          <h3 className="text-xl font-semibold text-gray-900">
                            Generate End-to-End Workflow
                          </h3>
                        </div>
                        <p className="text-gray-600 mb-6">
                          Seamlessly connect your Backend App, Frontend UI with PartnerOS as an end-to-end transaction journey, with advanced partner management, real-time data sync, and enhanced functionality.
                        </p>
                        <div className="mb-4">
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Integration Workflow
                          </label>
                          <select
                            value={selectedWorkflowSteps}
                            onChange={(e) => setSelectedWorkflowSteps(e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent"
                          >
                            <option value="Full Integration">Full Integration (PartnerOS + Backend + Frontend)</option>
                            <option value="PartnerOS + Backend">PartnerOS + Backend Integration</option>
                            <option value="Backend + Frontend">Backend + Frontend Integration</option>
                          </select>
                        </div>
                        <button
                          onClick={() => runFeature('partneros')}
                          disabled={isRunning !== null}
                          className="bg-yellow-400 hover:bg-yellow-500 disabled:bg-gray-300 disabled:cursor-not-allowed text-black px-4 py-2 rounded-lg font-semibold text-sm transition-colors"
                        >
                          {isRunning === 'partneros' ? 'Running...' : 'Run Demo'}
                        </button>
                      </div>
                    </div>

                    {/* Test Application Online Feature - New Row */}
                    <div className="mt-8">
                      <div className="bg-gray-50 rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow">
                        <div className="flex items-center gap-4 mb-6">
                          <div className="w-12 h-12 bg-yellow-400 rounded-lg flex items-center justify-center">
                            <svg className="w-6 h-6 text-black" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                          </div>
                          <h3 className="text-xl font-semibold text-gray-900">
                            Test Application Online
                          </h3>
                        </div>
                        <p className="text-gray-600 mb-6">
                          Comprehensive testing suite to validate your generated applications with automated test case generation, environment setup, and execution of all testing scenarios including unit, integration, and end-to-end tests.
                        </p>
                        <div className="mb-4">
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Testing Process
                          </label>
                          <select
                            value={selectedTestingOption}
                            onChange={(e) => setSelectedTestingOption(e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent"
                          >
                            <option value="1. Generate Testing Cases">1. Generate Testing Cases</option>
                            <option value="2. Build Testing Environment">2. Build Testing Environment</option>
                            <option value="3. Run Application">3. Run Application</option>
                          </select>
                        </div>
                        <button
                          onClick={runTestingSuite}
                          className="bg-yellow-400 hover:bg-yellow-500 text-black px-4 py-2 rounded-lg font-semibold text-sm transition-colors"
                        >
                          Launch Testing Suite
                        </button>
                      </div>
                    </div>

                    {/* Live Demo Console */}
                    <div className="mt-12">
                      <div className="text-center mb-8">
                        <h4 className="text-2xl font-bold text-gray-900 mb-4">
                          Live Demo Console
                        </h4>
                        <p className="text-lg text-gray-600">
                          Watch real-time output as features are executed
                        </p>
                      </div>

                      <div className="bg-black rounded-lg p-6 h-[500px] overflow-auto">
                        <div className="flex items-center justify-between mb-4">
                          <div className="flex items-center space-x-2">
                            <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                            <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                          </div>
                          <span className="text-gray-400 text-sm">PartnerIQ Demo Console</span>
                        </div>

                        <div className="font-mono text-sm">
                          {consoleOutput.length === 0 ? (
                            <div className="text-gray-500">
                              Console ready. Click "Run Demo" on any feature above to see output...
                            </div>
                          ) : (
                            consoleOutput.map((line, index) => (
                              <div key={index} className="text-green-400 mb-1">
                                {line}
                              </div>
                            ))
                          )}
                          {isRunning && (
                            <div className="text-yellow-400 animate-pulse">
                              ▋
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* File Browser */}
                    <div className="mt-12">
                      <div className="text-center mb-8">
                        <h4 className="text-2xl font-bold text-gray-900 mb-4">
                          Project File Browser
                        </h4>
                        <p className="text-lg text-gray-600">
                          Browse and explore the generated project structure
                        </p>
                      </div>

                      <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
                        {/* Path Navigation */}
                        <div className="bg-gray-50 px-4 py-3 border-b border-gray-200 flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <button
                              onClick={navigateUp}
                              disabled={currentPath === '/'}
                              className="p-2 hover:bg-gray-200 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed"
                              title="Go up one level"
                            >
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                              </svg>
                            </button>
                            <div className="flex items-center space-x-1 text-sm text-gray-600">
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-5l-2-2H5a2 2 0 00-2 2z" />
                              </svg>
                              <span className="font-mono bg-gray-100 px-2 py-1 rounded">
                                {currentPath}
                              </span>
                            </div>
                          </div>
                          <div className="text-sm text-gray-500">
                            {Object.keys(getCurrentDirectoryContents()).length} items
                          </div>
                        </div>

                        {/* File/Folder List */}
                        <div className="h-80 overflow-y-auto">
                          <div className="divide-y divide-gray-100">
                            {Object.entries(getCurrentDirectoryContents()).map(([name, item]) => (
                              <div
                                key={name}
                                className={`px-4 py-3 flex items-center justify-between hover:bg-gray-50 ${
                                  item.type === 'directory' ? 'cursor-pointer' : ''
                                }`}
                                onClick={() => item.type === 'directory' && navigateDown(name)}
                              >
                                <div className="flex items-center space-x-3">
                                  {item.type === 'directory' ? (
                                    <svg className="w-5 h-5 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-5l-2-2H5a2 2 0 00-2 2z" />
                                    </svg>
                                  ) : (
                                    <svg className="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                                    </svg>
                                  )}
                                  <span className={`${item.type === 'directory' ? 'font-medium text-blue-600' : 'text-gray-700'}`}>
                                    {name}
                                  </span>
                                  {item.type === 'directory' && (
                                    <span className="text-xs text-gray-400">folder</span>
                                  )}
                                </div>
                                {item.type === 'file' && (
                                  <div className="text-sm text-gray-500">
                                    {item.size}
                                  </div>
                                )}
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-gray-900 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-yellow-400 mb-2">1000+</div>
              <div className="text-gray-300">Active Partners</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-yellow-400 mb-2">$50M+</div>
              <div className="text-gray-300">Transaction Volume</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-yellow-400 mb-2">99.9%</div>
              <div className="text-gray-300">Uptime</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-yellow-400 mb-2">24/7</div>
              <div className="text-gray-300">Support</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-yellow-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-black mb-4">
            Ready to Experience PartnerIQ?
          </h2>
          <p className="text-lg text-gray-800 mb-8 max-w-2xl mx-auto">
            Join thousands of organizations already using PartnerIQ to optimize their partner relationships and drive growth.
          </p>
          <button
            onClick={openFeaturesSection}
            className="bg-black hover:bg-gray-800 text-white px-8 py-3 rounded-lg font-semibold text-lg transition-all transform hover:scale-105"
          >
            Start Your Demo Today
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-3 mb-4 md:mb-0">
              <img
                src="https://cdn.builder.io/api/v1/image/assets%2F12ef3b91196646429dd4b8f74e3c93cd%2Fa5bed23b57a9444abc618fd0de901dbb?format=webp&width=800"
                alt="Western Union"
                className="h-8 w-auto"
              />
              <div>
                <div className="font-semibold">PartnerIQ Demo</div>
                <div className="text-sm text-gray-400">Powered by Western Union</div>
              </div>
            </div>
            <div className="text-sm text-gray-400">
              © 2024 Western Union. All rights reserved.
            </div>
          </div>
        </div>
      </footer>

      {/* Comprehensive Testing Suite Modal */}
      {showTestingSuiteModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 w-full max-w-7xl rounded-lg overflow-hidden">
            {/* Header */}
            <header className="bg-white border-b border-slate-200 shadow-sm">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex items-center justify-between h-16">
                  <div className="flex items-center gap-3">
                    <div className="bg-yellow-500 p-2 rounded-lg">
                      <FlaskConical className="h-6 w-6 text-black" />
                    </div>
                    <div>
                      <h1 className="text-xl font-semibold text-slate-900">Western Union PartnerIQ Test Suite</h1>
                      <p className="text-sm text-slate-500">Comprehensive Testing Platform</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
                      Western Union Ready
                    </Badge>
                    <button
                      onClick={() => setShowTestingSuiteModal(false)}
                      className="text-gray-400 hover:text-gray-600 transition-colors"
                    >
                      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </button>
                  </div>
                </div>
              </div>
            </header>

            {/* Main Content */}
            <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 h-[calc(100vh-100px)] overflow-y-auto">
              <Tabs defaultValue="environment" className="space-y-6">
                <TabsList className="grid w-full grid-cols-6 lg:w-auto lg:grid-cols-6 h-auto p-1 bg-white border shadow-sm">
                  <TabsTrigger value="environment" className="flex items-center gap-2 py-3 px-4 data-[state=active]:bg-yellow-500 data-[state=active]:text-black data-[state=active]:font-semibold data-[state=inactive]:bg-white data-[state=inactive]:text-slate-600">
                    <Settings className="h-4 w-4" />
                    <span className="hidden sm:inline">Environment</span>
                  </TabsTrigger>
                  <TabsTrigger value="ui-tests" className="flex items-center gap-2 py-3 px-4 data-[state=active]:bg-yellow-500 data-[state=active]:text-black data-[state=active]:font-semibold data-[state=inactive]:bg-white data-[state=inactive]:text-slate-600">
                    <TestTube className="h-4 w-4" />
                    <span className="hidden sm:inline">UI Tests</span>
                  </TabsTrigger>
                  <TabsTrigger value="backend-tests" className="flex items-center gap-2 py-3 px-4 data-[state=active]:bg-yellow-500 data-[state=active]:text-black data-[state=active]:font-semibold data-[state=inactive]:bg-white data-[state=inactive]:text-slate-600">
                    <Database className="h-4 w-4" />
                    <span className="hidden sm:inline">Backend Tests</span>
                  </TabsTrigger>
                  <TabsTrigger value="partneros" className="flex items-center gap-2 py-3 px-4 data-[state=active]:bg-yellow-500 data-[state=active]:text-black data-[state=active]:font-semibold data-[state=inactive]:bg-white data-[state=inactive]:text-slate-600">
                    <Link2 className="h-4 w-4" />
                    <span className="hidden sm:inline">PartnerOS</span>
                  </TabsTrigger>
                  <TabsTrigger value="logs" className="flex items-center gap-2 py-3 px-4 data-[state=active]:bg-yellow-500 data-[state=active]:text-black data-[state=active]:font-semibold data-[state=inactive]:bg-white data-[state=inactive]:text-slate-600">
                    <FileText className="h-4 w-4" />
                    <span className="hidden sm:inline">Logs</span>
                  </TabsTrigger>
                  <TabsTrigger value="results" className="flex items-center gap-2 py-3 px-4 data-[state=active]:bg-yellow-500 data-[state=active]:text-black data-[state=active]:font-semibold data-[state=inactive]:bg-white data-[state=inactive]:text-slate-600">
                    <BarChart3 className="h-4 w-4" />
                    <span className="hidden sm:inline">Results</span>
                  </TabsTrigger>
                </TabsList>

                {/* Environment Details Tab */}
                <TabsContent value="environment">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Settings className="h-5 w-5" />
                        Environment Details
                      </CardTitle>
                      <CardDescription>
                        Configure your testing environment parameters
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div className="space-y-2">
                          <label className="text-sm font-medium text-slate-700">Identifier</label>
                          <Input
                            value={environment.identifier}
                            onChange={(e) => setEnvironment({ ...environment, identifier: e.target.value })}
                            placeholder="Enter environment identifier"
                            className="bg-white"
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-sm font-medium text-slate-700">Counter ID</label>
                          <Input
                            value={environment.counterID}
                            onChange={(e) => setEnvironment({ ...environment, counterID: e.target.value })}
                            placeholder="Enter counter ID"
                            className="bg-white"
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-sm font-medium text-slate-700">Reference</label>
                          <Input
                            value={environment.reference}
                            onChange={(e) => setEnvironment({ ...environment, reference: e.target.value })}
                            placeholder="Enter reference"
                            className="bg-white"
                          />
                        </div>
                      </div>
                      <div className="pt-4 border-t">
                        <div className="flex items-center justify-between">
                          <Button
                            variant="outline"
                            onClick={clearEnvironmentSettings}
                            className="text-red-600 border-red-300 hover:bg-red-50 font-semibold"
                          >
                            <Trash2 className="h-4 w-4 mr-2" />
                            Clear Environment Settings
                          </Button>
                          <Button className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold">
                            Save Environment Settings
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                {/* UI Test Cases Tab */}
                <TabsContent value="ui-tests">
                  <div className="space-y-6">
                    {/* Test Runner Controls */}
                    <Card>
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <div>
                            <CardTitle className="flex items-center gap-2">
                              <TestTube className="h-5 w-5" />
                              Playwright Test Runner
                            </CardTitle>
                            <CardDescription>
                              Execute UI tests using Python Playwright automation
                            </CardDescription>
                          </div>
                          <div className="flex items-center gap-3">
                            <Badge className="bg-blue-100 text-blue-800">
                              Python + Playwright
                            </Badge>
                            <Button
                              onClick={runPlaywrightTests}
                              disabled={isRunningTests || uiTestCategories.flatMap(cat => cat.testCases).filter(tc => tc.selected).length === 0}
                              className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold disabled:bg-gray-400"
                            >
                              {isRunningTests ? (
                                <>
                                  <Clock className="h-4 w-4 mr-2 animate-spin" />
                                  Running Tests...
                                </>
                              ) : (
                                <>
                                  <Play className="h-4 w-4 mr-2" />
                                  Run Selected Tests
                                </>
                              )}
                            </Button>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center gap-4 text-sm text-slate-600">
                          <div className="flex items-center gap-2">
                            <span>Selected Tests:</span>
                            <Badge variant="outline">
                              {uiTestCategories.flatMap(cat => cat.testCases).filter(tc => tc.selected).length}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-2">
                            <span>Environment:</span>
                            <Badge variant="outline">
                              {environment.identifier || 'Default'}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-2">
                            <span>Browser:</span>
                            <Badge variant="outline">Chromium</Badge>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Test Categories */}
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <TestTube className="h-5 w-5" />
                          UI Test Cases
                        </CardTitle>
                        <CardDescription>
                          Manage and execute user interface test cases by category
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                          {uiTestCategories.map((category) => (
                            <Card key={category.id} className="border-slate-200">
                              <CardHeader className="pb-3">
                                <div className="flex items-center justify-between">
                                  <CardTitle className="text-lg text-slate-800">{category.name}</CardTitle>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => runCategoryTests(category.id)}
                                    disabled={isRunningTests}
                                    className="text-yellow-600 border-yellow-300 hover:bg-yellow-50 font-semibold"
                                  >
                                    <Play className="h-3 w-3 mr-1" />
                                    Run Category
                                  </Button>
                                </div>
                                <div className="flex items-center gap-2 mt-2">
                                  <Badge
                                    variant="outline"
                                    className="text-xs"
                                  >
                                    {category.testCases.filter(tc => tc.selected).length}/{category.testCases.length} selected
                                  </Badge>
                                  <Badge
                                    className={`text-xs ${
                                      category.testCases.every(tc => tc.status === 'pass') ? 'bg-green-100 text-green-800' :
                                      category.testCases.some(tc => tc.status === 'fail') ? 'bg-red-100 text-red-800' :
                                      category.testCases.some(tc => tc.status === 'running') ? 'bg-blue-100 text-blue-800' :
                                      'bg-gray-100 text-gray-800'
                                    }`}
                                  >
                                    {category.testCases.every(tc => tc.status === 'pass') ? 'All Passed' :
                                     category.testCases.some(tc => tc.status === 'fail') ? 'Some Failed' :
                                     category.testCases.some(tc => tc.status === 'running') ? 'Running' :
                                     'Pending'}
                                  </Badge>
                                </div>
                              </CardHeader>
                              <CardContent className="space-y-3">
                                {category.testCases.map((testCase) => (
                                  <div key={testCase.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border">
                                    <div className="flex items-center gap-3">
                                      <Checkbox
                                        checked={testCase.selected}
                                        onCheckedChange={() => toggleTestCase(uiTestCategories, setUiTestCategories, category.id, testCase.id)}
                                        disabled={isRunningTests}
                                      />
                                      <div className="flex-1 min-w-0">
                                        <p className="text-sm font-medium text-slate-900 truncate">{testCase.name}</p>
                                        <p className="text-xs text-slate-500 truncate">{testCase.description}</p>
                                        <p className="text-xs text-slate-400 font-mono">
                                          tests/ui/{testCase.id}.py
                                        </p>
                                      </div>
                                    </div>
                                    <div className="flex items-center gap-2">
                                      {getStatusIcon(testCase.status)}
                                      <Button
                                        size="sm"
                                        variant="ghost"
                                        onClick={() => openTestCaseDetails(testCase)}
                                        disabled={isRunningTests}
                                      >
                                        <Edit3 className="h-3 w-3" />
                                      </Button>
                                    </div>
                                  </div>
                                ))}
                                <div className="pt-2 border-t">
                                  <div className="flex items-center justify-between text-xs text-slate-500">
                                    <span>Pytest command:</span>
                                    <code className="bg-slate-100 px-2 py-1 rounded">
                                      pytest tests/ui/{category.id}/ --browser=chromium
                                    </code>
                                  </div>
                                </div>
                              </CardContent>
                            </Card>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>

                {/* Backend Test Cases Tab */}
                <TabsContent value="backend-tests">
                  <div className="space-y-6">
                    {/* Backend Test Runner Controls */}
                    <Card>
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <div>
                            <CardTitle className="flex items-center gap-2">
                              <Database className="h-5 w-5" />
                              Playwright Backend Test Runner
                            </CardTitle>
                            <CardDescription>
                              Execute automated backend tests using Playwright with integrated PartnerOS API testing and Splunk log analysis
                            </CardDescription>
                          </div>
                          <div className="flex items-center gap-3">
                            <Badge className="bg-purple-100 text-purple-800">
                              Playwright + API + Logs
                            </Badge>
                            <Button
                              onClick={runBackendTests}
                              disabled={isRunningBackendTests || backendTestCategories.flatMap(cat => cat.testCases).filter(tc => tc.selected).length === 0}
                              className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold disabled:bg-gray-400"
                            >
                              {isRunningBackendTests ? (
                                <>
                                  <Clock className="h-4 w-4 mr-2 animate-spin" />
                                  Running Playwright Tests...
                                </>
                              ) : (
                                <>
                                  <Play className="h-4 w-4 mr-2" />
                                  Run Playwright Tests
                                </>
                              )}
                            </Button>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-sm text-slate-600">
                          <div className="flex items-center gap-2">
                            <span>Selected Tests:</span>
                            <Badge variant="outline">
                              {backendTestCategories.flatMap(cat => cat.testCases).filter(tc => tc.selected).length}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-2">
                            <span>PartnerOS Connections:</span>
                            <Badge variant="outline">
                              {partnerOSConnections.length} Available
                            </Badge>
                          </div>
                          <div className="flex items-center gap-2">
                            <span>Splunk Queries:</span>
                            <Badge variant="outline">
                              {splunkQueries.filter(q => q.isActive).length} Active
                            </Badge>
                          </div>
                          <div className="flex items-center gap-2">
                            <span>Environment:</span>
                            <Badge variant="outline">
                              {environment.identifier || 'Default'}
                            </Badge>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Backend Test Categories */}
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <Database className="h-5 w-5" />
                          Backend Test Cases
                        </CardTitle>
                        <CardDescription>
                          Manage and execute Playwright-automated backend test cases with linked API connections and log queries
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                          {backendTestCategories.map((category) => (
                            <Card key={category.id} className="border-slate-200">
                              <CardHeader className="pb-3">
                                <div className="flex items-center justify-between">
                                  <CardTitle className="text-lg text-slate-800">{category.name}</CardTitle>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => runBackendCategoryTests(category.id)}
                                    disabled={isRunningBackendTests}
                                    className="text-yellow-600 border-yellow-300 hover:bg-yellow-50 font-semibold"
                                  >
                                    <Play className="h-3 w-3 mr-1" />
                                    Run Category
                                  </Button>
                                </div>
                                <div className="flex items-center gap-2 mt-2">
                                  <Badge
                                    variant="outline"
                                    className="text-xs"
                                  >
                                    {category.testCases.filter(tc => tc.selected).length}/{category.testCases.length} selected
                                  </Badge>
                                  <Badge
                                    className={`text-xs ${
                                      category.testCases.every(tc => tc.status === 'pass') ? 'bg-green-100 text-green-800' :
                                      category.testCases.some(tc => tc.status === 'fail') ? 'bg-red-100 text-red-800' :
                                      category.testCases.some(tc => tc.status === 'running') ? 'bg-blue-100 text-blue-800' :
                                      'bg-gray-100 text-gray-800'
                                    }`}
                                  >
                                    {category.testCases.every(tc => tc.status === 'pass') ? 'All Passed' :
                                     category.testCases.some(tc => tc.status === 'fail') ? 'Some Failed' :
                                     category.testCases.some(tc => tc.status === 'running') ? 'Running' :
                                     'Pending'}
                                  </Badge>
                                </div>
                              </CardHeader>
                              <CardContent className="space-y-3">
                                {category.testCases.map((testCase) => {
                                  const linkedConnections = partnerOSConnections.filter(conn =>
                                    conn.linkedTestCases.includes(testCase.id)
                                  );
                                  const linkedQueries = splunkQueries.filter(query =>
                                    query.linkedTestCases.includes(testCase.id)
                                  );

                                  return (
                                    <div key={testCase.id} className="space-y-2">
                                      <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border">
                                        <div className="flex items-center gap-3">
                                          <Checkbox
                                            checked={testCase.selected}
                                            onCheckedChange={() => toggleTestCase(backendTestCategories, setBackendTestCategories, category.id, testCase.id)}
                                            disabled={isRunningBackendTests}
                                          />
                                          <div className="flex-1 min-w-0">
                                            <p className="text-sm font-medium text-slate-900 truncate">{testCase.name}</p>
                                            <p className="text-xs text-slate-500 truncate">{testCase.description}</p>
                                          </div>
                                        </div>
                                        <div className="flex items-center gap-2">
                                          {getStatusIcon(testCase.status)}
                                          <Button
                                            size="sm"
                                            variant="ghost"
                                            onClick={() => openTestCaseDetails(testCase)}
                                            disabled={isRunningBackendTests}
                                          >
                                            <Edit3 className="h-3 w-3" />
                                          </Button>
                                        </div>
                                      </div>

                                      {/* Show linked connections and queries */}
                                      <div className="ml-8 space-y-1">
                                        {linkedConnections.length > 0 && (
                                          <div className="flex items-center gap-2 text-xs text-slate-500">
                                            <Link2 className="h-3 w-3" />
                                            <span>PartnerOS Connections:</span>
                                            {linkedConnections.map(conn => (
                                              <Badge key={conn.id} variant="outline" className="text-xs">
                                                {conn.method} {conn.name}
                                              </Badge>
                                            ))}
                                          </div>
                                        )}
                                        {linkedQueries.length > 0 && (
                                          <div className="flex items-center gap-2 text-xs text-slate-500">
                                            <FileText className="h-3 w-3" />
                                            <span>Splunk Queries:</span>
                                            {linkedQueries.map(query => (
                                              <Badge key={query.id} variant="outline" className="text-xs">
                                                {query.name} ({query.partner})
                                              </Badge>
                                            ))}
                                          </div>
                                        )}
                                        {linkedConnections.length === 0 && linkedQueries.length === 0 && (
                                          <div className="text-xs text-amber-600">
                                            ⚠️ No linked connections or queries found
                                          </div>
                                        )}
                                      </div>
                                    </div>
                                  );
                                })}
                                <div className="pt-2 border-t">
                                  <div className="flex items-center justify-between text-xs text-slate-500">
                                    <span>Framework:</span>
                                    <code className="bg-slate-100 px-2 py-1 rounded">
                                      Playwright + API + Logs
                                    </code>
                                  </div>
                                  <div className="flex items-center justify-between text-xs text-slate-500 mt-1">
                                    <span>Test Path:</span>
                                    <code className="bg-slate-100 px-2 py-1 rounded">
                                      tests/backend/{category.id}/*.py
                                    </code>
                                  </div>
                                </div>
                              </CardContent>
                            </Card>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>

                {/* PartnerOS Connection Tab */}
                <TabsContent value="partneros">
                  <Card>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div>
                          <CardTitle className="flex items-center gap-2">
                            <Link2 className="h-5 w-5" />
                            PartnerOS Connections
                          </CardTitle>
                          <CardDescription>
                            Manage and execute API connections to PartnerOS endpoints
                          </CardDescription>
                        </div>
                        <Button
                          onClick={() => setIsAddingPartnerOSConnection(true)}
                          className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold"
                        >
                          + Add Connection
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      {partnerOSConnections.map((connection) => (
                        <Card key={connection.id} className="border-slate-200">
                          <CardContent className="p-4">
                            <div className="flex items-start justify-between">
                              <div className="space-y-3 flex-1">
                                <div className="flex items-center gap-3">
                                  <Badge className={`${connection.method === 'GET' ? 'bg-green-100 text-green-800' : connection.method === 'POST' ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800'}`}>
                                    {connection.method}
                                  </Badge>
                                  <h3 className="font-semibold text-slate-900">{connection.name}</h3>
                                </div>
                                <div className="space-y-2">
                                  <div>
                                    <label className="text-xs font-medium text-slate-500">URL:</label>
                                    <p className="text-sm text-slate-600 font-mono bg-slate-50 p-2 rounded border">
                                      {connection.url}
                                    </p>
                                  </div>
                                  {connection.headers && (
                                    <div>
                                      <label className="text-xs font-medium text-slate-500">Headers:</label>
                                      <p className="text-sm text-slate-600 font-mono bg-slate-50 p-2 rounded border whitespace-pre-line">
                                        {connection.headers}
                                      </p>
                                    </div>
                                  )}
                                  {connection.body && (
                                    <div>
                                      <label className="text-xs font-medium text-slate-500">Body:</label>
                                      <p className="text-sm text-slate-600 font-mono bg-slate-50 p-2 rounded border whitespace-pre-line">
                                        {connection.body}
                                      </p>
                                    </div>
                                  )}
                                </div>
                                <div className="flex items-center gap-2">
                                  <span className="text-xs text-slate-500">Linked Test Cases:</span>
                                  {connection.linkedTestCases.map((testCaseId) => (
                                    <Badge key={testCaseId} variant="outline" className="text-xs">
                                      {testCaseId}
                                    </Badge>
                                  ))}
                                </div>
                              </div>
                              <div className="flex items-center gap-2 ml-4">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => setEditingPartnerOSConnection(connection)}
                                >
                                  <Edit3 className="h-3 w-3" />
                                </Button>
                                <Button
                                  size="sm"
                                  onClick={() => runPartnerOSConnection(connection.id)}
                                  className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold"
                                >
                                  <Play className="h-3 w-3 mr-1" />
                                  Run
                                </Button>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </CardContent>
                  </Card>
                </TabsContent>

                {/* Backend Logs Tab */}
                <TabsContent value="logs">
                  <div className="space-y-6">
                    {/* Splunk Queries Management */}
                    <Card>
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <div>
                            <CardTitle className="flex items-center gap-2">
                              <FileText className="h-5 w-5" />
                              Splunk Query Management
                            </CardTitle>
                            <CardDescription>
                              Create and manage partner-specific Splunk queries linked to test cases
                            </CardDescription>
                          </div>
                          <Button
                            onClick={() => setIsAddingSplunkQuery(true)}
                            className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold"
                          >
                            + Add Query
                          </Button>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          {splunkQueries.map((query) => (
                            <Card key={query.id} className="border-slate-200">
                              <CardContent className="p-4">
                                <div className="flex items-start justify-between">
                                  <div className="space-y-3 flex-1">
                                    <div className="flex items-center gap-3">
                                      <h3 className="font-semibold text-slate-900">{query.name}</h3>
                                      <Badge className="bg-purple-100 text-purple-800">
                                        {query.partner}
                                      </Badge>
                                      <Badge
                                        className={query.isActive ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}
                                      >
                                        {query.isActive ? "Active" : "Inactive"}
                                      </Badge>
                                    </div>
                                    <div className="bg-slate-50 p-3 rounded border font-mono text-sm">
                                      {query.query}
                                    </div>
                                    <div className="flex items-center gap-2">
                                      <span className="text-xs text-slate-500">Linked Test Cases:</span>
                                      {query.linkedTestCases.map((testCaseId) => (
                                        <Badge key={testCaseId} variant="outline" className="text-xs">
                                          {testCaseId}
                                        </Badge>
                                      ))}
                                    </div>
                                  </div>
                                  <div className="flex items-center gap-2 ml-4">
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      onClick={() => setEditingSplunkQuery(query)}
                                    >
                                      <Edit3 className="h-3 w-3" />
                                    </Button>
                                    <Button
                                      size="sm"
                                      onClick={() => runSplunkQuery(query.id)}
                                      className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold"
                                    >
                                      <Play className="h-3 w-3 mr-1" />
                                      Run
                                    </Button>
                                  </div>
                                </div>
                              </CardContent>
                            </Card>
                          ))}
                        </div>
                      </CardContent>
                    </Card>

                    {/* Live Log Output */}
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <FileText className="h-5 w-5" />
                          Live Log Output
                        </CardTitle>
                        <CardDescription>
                          Real-time Splunk query results and system logs
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="bg-slate-900 text-green-400 p-4 rounded-lg font-mono text-sm min-h-[300px] max-h-[400px] overflow-y-auto">
                          <div className="space-y-1">
                            {logOutput.map((line, index) => (
                              <div
                                key={index}
                                className={`
                                  ${line.includes('ERROR') ? 'text-red-400' : ''}
                                  ${line.includes('WARN') ? 'text-yellow-400' : ''}
                                  ${line.includes('RESULT') ? 'text-blue-400' : ''}
                                `}
                              >
                                {line}
                              </div>
                            ))}
                            <div className="text-gray-500 animate-pulse">█</div>
                          </div>
                        </div>
                        <div className="flex justify-between items-center mt-4">
                          <div className="text-sm text-slate-500">
                            Selected Test Cases: {getSelectedTestCaseIds().join(', ') || 'None'}
                          </div>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setLogOutput(prev => prev.slice(0, 5))}
                          >
                            Clear Logs
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>

                {/* Results Tab */}
                <TabsContent value="results">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <BarChart3 className="h-5 w-5" />
                        Test Results
                      </CardTitle>
                      <CardDescription>
                        Analysis and reporting of test execution results
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-6">
                        {/* Test Summary Stats */}
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                          <Card className="bg-green-50 border-green-200">
                            <CardContent className="p-4 text-center">
                              <div className="text-2xl font-bold text-green-700">12</div>
                              <div className="text-sm text-green-600">Passed</div>
                            </CardContent>
                          </Card>
                          <Card className="bg-red-50 border-red-200">
                            <CardContent className="p-4 text-center">
                              <div className="text-2xl font-bold text-red-700">3</div>
                              <div className="text-sm text-red-600">Failed</div>
                            </CardContent>
                          </Card>
                          <Card className="bg-blue-50 border-blue-200">
                            <CardContent className="p-4 text-center">
                              <div className="text-2xl font-bold text-blue-700">2</div>
                              <div className="text-sm text-blue-600">Running</div>
                            </CardContent>
                          </Card>
                          <Card className="bg-gray-50 border-gray-200">
                            <CardContent className="p-4 text-center">
                              <div className="text-2xl font-bold text-gray-700">8</div>
                              <div className="text-sm text-gray-600">Pending</div>
                            </CardContent>
                          </Card>
                        </div>

                        {/* Results Table Placeholder */}
                        <Card>
                          <CardHeader>
                            <CardTitle className="text-lg">Detailed Test Results</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-3">
                              <div className="text-sm text-slate-500 text-center py-8">
                                Results will appear here after test execution...
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>

              {/* PartnerOS Connection Editor Modal */}
              {(isAddingPartnerOSConnection || editingPartnerOSConnection) && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
                  <Card className="w-full max-w-2xl max-h-[90vh] flex flex-col">
                    <CardHeader className="flex-shrink-0">
                      <CardTitle>
                        {editingPartnerOSConnection ? 'Edit PartnerOS Connection' : 'Add New PartnerOS Connection'}
                      </CardTitle>
                      <CardDescription>
                        Configure API connections to PartnerOS endpoints with environment variable support
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6 flex-1 overflow-y-auto">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Connection Name</label>
                          <Input
                            placeholder="Enter connection name..."
                            defaultValue={editingPartnerOSConnection?.name || ""}
                            id="connection-name"
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-sm font-medium">HTTP Method</label>
                          <select
                            className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                            defaultValue={editingPartnerOSConnection?.method || "GET"}
                            id="connection-method"
                          >
                            <option value="GET">GET</option>
                            <option value="POST">POST</option>
                            <option value="PUT">PUT</option>
                            <option value="DELETE">DELETE</option>
                            <option value="PATCH">PATCH</option>
                          </select>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">URL</label>
                        <Input
                          placeholder="https://api.partneros.com/... (use ${environment.identifier} for variables)"
                          defaultValue={editingPartnerOSConnection?.url || ""}
                          id="connection-url"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Headers (one per line)</label>
                        <textarea
                          className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                          placeholder="Authorization: Bearer ${environment.identifier}&#10;Content-Type: application/json"
                          defaultValue={editingPartnerOSConnection?.headers || ""}
                          id="connection-headers"
                          rows={3}
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Request Body (JSON)</label>
                        <textarea
                          className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                          placeholder='{"counterID": "${environment.counterID}", "reference": "${environment.reference}"}'
                          defaultValue={editingPartnerOSConnection?.body || ""}
                          id="connection-body"
                          rows={4}
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Linked Test Cases</label>
                        <div className="max-h-64 overflow-y-auto border rounded p-2 space-y-2">
                          {[...uiTestCategories, ...backendTestCategories].map(category => (
                            <Collapsible key={category.id} defaultOpen={true}>
                              <CollapsibleTrigger className="flex items-center justify-between w-full p-2 bg-slate-100 rounded hover:bg-slate-200 transition-colors">
                                <span className="text-sm font-medium text-slate-700">{category.name}</span>
                                <ChevronDown className="h-4 w-4 text-slate-500 transition-transform data-[state=open]:rotate-180" />
                              </CollapsibleTrigger>
                              <CollapsibleContent className="pt-2">
                                <div className="space-y-2 pl-4">
                                  {category.testCases.map(tc => (
                                    <div key={tc.id} className="flex items-center space-x-2">
                                      <Checkbox
                                        id={`conn-link-${tc.id}`}
                                        defaultChecked={editingPartnerOSConnection?.linkedTestCases?.includes(tc.id)}
                                      />
                                      <label
                                        htmlFor={`conn-link-${tc.id}`}
                                        className="text-xs text-slate-600 cursor-pointer flex-1"
                                      >
                                        {tc.name}
                                      </label>
                                    </div>
                                  ))}
                                </div>
                              </CollapsibleContent>
                            </Collapsible>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                    <div className="flex-shrink-0 p-6 pt-0 border-t bg-white">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="outline"
                          onClick={() => {
                            setIsAddingPartnerOSConnection(false);
                            setEditingPartnerOSConnection(null);
                            if (modalNavigationSource === 'testcase' && selectedTestCase) {
                              setIsEditingDetails(true);
                            }
                            setModalNavigationSource('main');
                          }}
                        >
                          Cancel
                        </Button>
                        {editingPartnerOSConnection && (
                          <Button
                            variant="destructive"
                            onClick={() => {
                              deletePartnerOSConnection(editingPartnerOSConnection.id);
                              setEditingPartnerOSConnection(null);
                            }}
                          >
                            Delete
                          </Button>
                        )}
                        <Button
                          onClick={() => {
                            const connectionName = (document.getElementById('connection-name') as HTMLInputElement)?.value;
                            const connectionMethod = (document.getElementById('connection-method') as HTMLSelectElement)?.value;
                            const connectionUrl = (document.getElementById('connection-url') as HTMLInputElement)?.value;
                            const connectionHeaders = (document.getElementById('connection-headers') as HTMLTextAreaElement)?.value;
                            const connectionBody = (document.getElementById('connection-body') as HTMLTextAreaElement)?.value;

                            const linkedTestCases = [...uiTestCategories, ...backendTestCategories]
                              .flatMap(cat => cat.testCases)
                              .filter(tc => (document.getElementById(`conn-link-${tc.id}`) as HTMLInputElement)?.checked)
                              .map(tc => tc.id);

                            savePartnerOSConnection({
                              name: connectionName,
                              method: connectionMethod,
                              url: connectionUrl,
                              headers: connectionHeaders,
                              body: connectionBody,
                              linkedTestCases
                            });

                            if (modalNavigationSource === 'testcase' && selectedTestCase) {
                              setTimeout(() => {
                                setIsEditingDetails(true);
                              }, 100);
                            }
                            setModalNavigationSource('main');
                          }}
                          className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold"
                        >
                          Save Connection
                        </Button>
                      </div>
                    </div>
                  </Card>
                </div>
              )}

              {/* Splunk Query Editor Modal */}
              {(isAddingSplunkQuery || editingSplunkQuery) && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
                  <Card className="w-full max-w-2xl">
                    <CardHeader>
                      <CardTitle>
                        {editingSplunkQuery ? 'Edit Splunk Query' : 'Add New Splunk Query'}
                      </CardTitle>
                      <CardDescription>
                        Configure partner-specific Splunk queries for log analysis
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Query Name</label>
                          <Input
                            placeholder="Enter query name..."
                            defaultValue={editingSplunkQuery?.name || ""}
                            id="query-name"
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Partner</label>
                          <Input
                            placeholder="Enter partner name..."
                            defaultValue={editingSplunkQuery?.partner || ""}
                            id="partner-name"
                          />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Splunk Query</label>
                        <textarea
                          className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                          placeholder="Enter Splunk search query..."
                          defaultValue={editingSplunkQuery?.query || ""}
                          id="splunk-query"
                          rows={4}
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Linked Test Cases</label>
                        <div className="max-h-64 overflow-y-auto border rounded p-2 space-y-2">
                          {[...uiTestCategories, ...backendTestCategories].map(category => (
                            <Collapsible key={category.id} defaultOpen={true}>
                              <CollapsibleTrigger className="flex items-center justify-between w-full p-2 bg-slate-100 rounded hover:bg-slate-200 transition-colors">
                                <span className="text-sm font-medium text-slate-700">{category.name}</span>
                                <ChevronDown className="h-4 w-4 text-slate-500 transition-transform data-[state=open]:rotate-180" />
                              </CollapsibleTrigger>
                              <CollapsibleContent className="pt-2">
                                <div className="space-y-2 pl-4">
                                  {category.testCases.map(tc => (
                                    <div key={tc.id} className="flex items-center space-x-2">
                                      <Checkbox
                                        id={`link-${tc.id}`}
                                        defaultChecked={editingSplunkQuery?.linkedTestCases?.includes(tc.id)}
                                      />
                                      <label
                                        htmlFor={`link-${tc.id}`}
                                        className="text-xs text-slate-600 cursor-pointer flex-1"
                                      >
                                        {tc.name}
                                      </label>
                                    </div>
                                  ))}
                                </div>
                              </CollapsibleContent>
                            </Collapsible>
                          ))}
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="is-active"
                          defaultChecked={editingSplunkQuery?.isActive || false}
                        />
                        <label htmlFor="is-active" className="text-sm font-medium">
                          Make this query active
                        </label>
                      </div>
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="outline"
                          onClick={() => {
                            setIsAddingSplunkQuery(false);
                            setEditingSplunkQuery(null);
                            if (modalNavigationSource === 'testcase' && selectedTestCase) {
                              setIsEditingDetails(true);
                            }
                            setModalNavigationSource('main');
                          }}
                        >
                          Cancel
                        </Button>
                        {editingSplunkQuery && (
                          <Button
                            variant="destructive"
                            onClick={() => {
                              deleteSplunkQuery(editingSplunkQuery.id);
                              setEditingSplunkQuery(null);
                            }}
                          >
                            Delete
                          </Button>
                        )}
                        <Button
                          onClick={() => {
                            const queryName = (document.getElementById('query-name') as HTMLInputElement)?.value;
                            const partnerName = (document.getElementById('partner-name') as HTMLInputElement)?.value;
                            const splunkQuery = (document.getElementById('splunk-query') as HTMLTextAreaElement)?.value;
                            const isActive = (document.getElementById('is-active') as HTMLInputElement)?.checked;

                            const linkedTestCases = [...uiTestCategories, ...backendTestCategories]
                              .flatMap(cat => cat.testCases)
                              .filter(tc => (document.getElementById(`link-${tc.id}`) as HTMLInputElement)?.checked)
                              .map(tc => tc.id);

                            saveSplunkQuery({
                              name: queryName,
                              partner: partnerName,
                              query: splunkQuery,
                              linkedTestCases,
                              isActive
                            });

                            if (modalNavigationSource === 'testcase' && selectedTestCase) {
                              setTimeout(() => {
                                setIsEditingDetails(true);
                              }, 100);
                            }
                            setModalNavigationSource('main');
                          }}
                          className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold"
                        >
                          Save Query
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}

              {/* Enhanced Test Case Details Modal */}
              {isEditingDetails && selectedTestCase && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
                  <Card className="w-full max-w-4xl max-h-[90vh] overflow-y-auto">
                    <CardHeader>
                      <CardTitle>Edit Test Case Details</CardTitle>
                      <CardDescription>{selectedTestCase.name} - {selectedTestCase.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {/* Test Case Details */}
                        <div className="space-y-4">
                          <h3 className="text-lg font-semibold text-slate-900">Test Case Configuration</h3>
                          <div className="space-y-2">
                            <label className="text-sm font-medium">Test Case to Run</label>
                            <textarea
                              className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                              placeholder="Enter detailed test case instructions..."
                              defaultValue={selectedTestCase.details?.testToRun || ""}
                              id="test-case-to-run"
                              rows={3}
                            />
                          </div>
                          <div className="space-y-2">
                            <label className="text-sm font-medium">Expected Results</label>
                            <textarea
                              className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                              placeholder="Enter expected test results..."
                              defaultValue={selectedTestCase.details?.expectedResults || ""}
                              id="test-case-expected-results"
                              rows={3}
                            />
                          </div>
                        </div>

                        {/* Environment Variables Reference */}
                        <div className="space-y-4">
                          <h3 className="text-lg font-semibold text-slate-900">Environment Variables</h3>
                          <div className="bg-slate-50 p-3 rounded border space-y-2">
                            <p className="text-xs text-slate-600">Available for use in connections and queries:</p>
                            <div className="grid grid-cols-1 gap-1 font-mono text-xs">
                              <div><span className="text-blue-600">${`{environment.identifier}`}</span> = {environment.identifier || 'not_set'}</div>
                              <div><span className="text-blue-600">${`{environment.counterID}`}</span> = {environment.counterID || 'not_set'}</div>
                              <div><span className="text-blue-600">${`{environment.reference}`}</span> = {environment.reference || 'not_set'}</div>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* PartnerOS Connections */}
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <h3 className="text-lg font-semibold text-slate-900">PartnerOS Connections</h3>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              setModalNavigationSource('testcase');
                              setIsAddingPartnerOSConnection(true);
                              setIsEditingDetails(false);
                            }}
                            className="text-yellow-600 border-yellow-300 hover:bg-yellow-50"
                          >
                            + Add New Connection
                          </Button>
                        </div>
                        <div className="grid grid-cols-1 gap-3 max-h-48 overflow-y-auto">
                          {partnerOSConnections.map(connection => {
                            const isLinked = connection.linkedTestCases.includes(selectedTestCase.id);
                            return (
                              <div key={connection.id} className={`p-3 rounded border ${isLinked ? 'bg-yellow-50 border-yellow-200' : 'bg-slate-50'}`}>
                                <div className="flex items-start justify-between">
                                  <div className="flex items-start gap-3">
                                    <Checkbox
                                      checked={isLinked}
                                      onCheckedChange={(checked) => {
                                        if (checked) {
                                          // Add test case to connection's linked test cases
                                          setPartnerOSConnections(prev => prev.map(conn =>
                                            conn.id === connection.id
                                              ? { ...conn, linkedTestCases: [...conn.linkedTestCases, selectedTestCase.id] }
                                              : conn
                                          ));
                                        } else {
                                          // Remove test case from connection's linked test cases
                                          setPartnerOSConnections(prev => prev.map(conn =>
                                            conn.id === connection.id
                                              ? { ...conn, linkedTestCases: conn.linkedTestCases.filter(id => id !== selectedTestCase.id) }
                                              : conn
                                          ));
                                        }
                                      }}
                                      id={`conn-${connection.id}`}
                                    />
                                    <div className="space-y-1">
                                      <div className="flex items-center gap-2">
                                        <Badge className={`${connection.method === 'GET' ? 'bg-green-100 text-green-800' : connection.method === 'POST' ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800'}`}>
                                          {connection.method}
                                        </Badge>
                                        <span className="font-medium text-sm">{connection.name}</span>
                                      </div>
                                      <p className="text-xs text-slate-500 font-mono">{connection.url}</p>
                                    </div>
                                  </div>
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    onClick={() => {
                                      setModalNavigationSource('testcase');
                                      setEditingPartnerOSConnection(connection);
                                      setIsEditingDetails(false);
                                    }}
                                  >
                                    <Edit3 className="h-3 w-3" />
                                  </Button>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      {/* Splunk Queries */}
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <h3 className="text-lg font-semibold text-slate-900">Splunk Log Queries</h3>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              setModalNavigationSource('testcase');
                              setIsAddingSplunkQuery(true);
                              setIsEditingDetails(false);
                            }}
                            className="text-purple-600 border-purple-300 hover:bg-purple-50"
                          >
                            + Add New Query
                          </Button>
                        </div>
                        <div className="grid grid-cols-1 gap-3 max-h-48 overflow-y-auto">
                          {splunkQueries.map(query => {
                            const isLinked = query.linkedTestCases.includes(selectedTestCase.id);
                            return (
                              <div key={query.id} className={`p-3 rounded border ${isLinked ? 'bg-purple-50 border-purple-200' : 'bg-slate-50'}`}>
                                <div className="flex items-start justify-between">
                                  <div className="flex items-start gap-3">
                                    <Checkbox
                                      checked={isLinked}
                                      onCheckedChange={(checked) => {
                                        if (checked) {
                                          // Add test case to query's linked test cases
                                          setSplunkQueries(prev => prev.map(q =>
                                            q.id === query.id
                                              ? { ...q, linkedTestCases: [...q.linkedTestCases, selectedTestCase.id] }
                                              : q
                                          ));
                                        } else {
                                          // Remove test case from query's linked test cases
                                          setSplunkQueries(prev => prev.map(q =>
                                            q.id === query.id
                                              ? { ...q, linkedTestCases: q.linkedTestCases.filter(id => id !== selectedTestCase.id) }
                                              : q
                                          ));
                                        }
                                      }}
                                      id={`query-${query.id}`}
                                    />
                                    <div className="space-y-1">
                                      <div className="flex items-center gap-2">
                                        <Badge className="bg-purple-100 text-purple-800">
                                          {query.partner}
                                        </Badge>
                                        <span className="font-medium text-sm">{query.name}</span>
                                        <Badge className={query.isActive ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"} >
                                          {query.isActive ? "Active" : "Inactive"}
                                        </Badge>
                                      </div>
                                      <p className="text-xs text-slate-500 font-mono truncate">{query.query}</p>
                                    </div>
                                  </div>
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    onClick={() => {
                                      setModalNavigationSource('testcase');
                                      setEditingSplunkQuery(query);
                                      setIsEditingDetails(false);
                                    }}
                                  >
                                    <Edit3 className="h-3 w-3" />
                                  </Button>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      {/* Action Buttons */}
                      <div className="flex justify-end gap-2 pt-4 border-t">
                        <Button variant="outline" onClick={() => setIsEditingDetails(false)}>
                          Cancel
                        </Button>
                        <Button
                          onClick={() => {
                            const testToRun = (document.getElementById('test-case-to-run') as HTMLTextAreaElement)?.value;
                            const expectedResults = (document.getElementById('test-case-expected-results') as HTMLTextAreaElement)?.value;

                            saveTestCaseDetails({
                              testToRun: testToRun || "",
                              expectedResults: expectedResults || ""
                            });
                          }}
                          className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold"
                        >
                          Save Test Case
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}
            </main>
          </div>
        </div>
      )}
    </div>
  );
}
