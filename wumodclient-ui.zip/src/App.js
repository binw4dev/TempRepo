import './App.css';
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import { useState, useEffect } from 'react';
import Header from "./components/Header";
import Footer from "./components/Footer";
import Token from "./components/Token";
import DynamicTemplate from "./components/DynamicTemplate";
import { Col, Container, Navbar, Row, Stack } from "react-bootstrap";
import React from "react";
import TemplateService from "./services/TemplateService";

function App() {
  const [ccList, setCcList] = useState(new Array());
  
  useEffect(() => {
    TemplateService.getCountryCurrencyList().then(resp => {
      setCcList(resp.data.obj);
      //console.log("setCcList ", ccList);
    });
  }, []);

  return (
    <div className="App">
      <Header />
      <Row>
        <Col sm="2">
          <Stack>
            <Navbar className="m-2">
              <Container style={{ background: "round black" }}>
                <Navbar.Brand href="/token" style={{ fontSize: "medium", color: "yellow" }} >
                  Token Generator
                </Navbar.Brand>
              </Container>
            </Navbar>
            <Navbar className="m-2">
              <Container style={{ background: "round black" }}>
                <Navbar.Brand href="/template" style={{ fontSize: "medium", color: "yellow" }} >
                  Dynamic UI Template
                </Navbar.Brand>
              </Container>
            </Navbar>
            <Navbar className="m-2">
              <Container style={{ background: "gray" }}>
                <Navbar.Brand href="/" style={{ fontSize: "medium", color: "yellow" }} >
                  Predefined List Query
                </Navbar.Brand>
              </Container>
            </Navbar>
            <Navbar className="m-2">
              <Container style={{ background: "gray" }}>
                <Navbar.Brand href="/" style={{ fontSize: "medium", color: "yellow" }} >
                  Fee Inquiry
                </Navbar.Brand>
              </Container>
            </Navbar>
            <Navbar className="m-2">
              <Container style={{ background: "gray" }}>
                <Navbar.Brand href="/" style={{ fontSize: "medium", color: "yellow" }} >
                  Send Money
                </Navbar.Brand>
              </Container>
            </Navbar>
            <Navbar className="m-2">
              <Container style={{ background: "gray" }}>
                <Navbar.Brand href="/" style={{ fontSize: "medium", color: "yellow" }} >
                  Receive Money
                </Navbar.Brand>
              </Container>
            </Navbar>
            <Navbar className="m-2">
              <Container style={{ background: "gray" }}>
                <Navbar.Brand href="/" style={{ fontSize: "medium", color: "yellow" }} >
                  Pay Status Inquiry
                </Navbar.Brand>
              </Container>
            </Navbar>
          </Stack>
        </Col>
        <Col sm="10">
          <Router>
            <div className="container">
              <Routes>
                <Route path="/token" element={<Token />} />
                <Route path="/template" element={<DynamicTemplate ccList={ccList} />} />
              </Routes>
            </div>
          </Router>
        </Col>
      </Row>
    </div>
  );
}

export default App;
