import React, { Component } from 'react';
import { useState, useEffect } from 'react';
import { withRouter } from "../utils/withRouter";
import TemplateService from "../services/TemplateService";
import TemplateFields from './TemplateFields';
import { Button, Card, CardBody, Col, Container, FloatingLabel, Form, Row } from "react-bootstrap";
import Dropdown from 'react-bootstrap/Dropdown';

let dictionary = {};
let defaultValue = '';

const DynamicTemplate = (props) => {
    const [countryCode, setCountryCode] = useState('');
    const [jsonText, setJsonText] = useState('');
    const [templateFields, setTemplateFields] = useState(new Array());
    
    function RenderDropdown(props) {
        const dropdown = props.dropdown;
        let content = [];
        let n = dropdown.length;
        for (let i = 0; i < n; i++) {
            const option = dropdown[i];
            if(option.defaultOption === true) {
                content.push(
                    <option value={option.value} selected>{option.text}</option>
                );
            } else {
                content.push(
                    <option value={option.value}>{option.text}</option>
                );
            }
        }
        return content;
    }

    function RenderTemplateFields() {
        let content = [];
        let n = templateFields.length;
        for (let i = 0; i < n; i++) {
            const field = templateFields[i];
            console.log("my field.fieldName : ", field.fieldName);
            defaultValue = dictionary[field.fieldName];
            if(!defaultValue || defaultValue === '') {
                defaultValue = "enter " + field.fieldText;
            }
            //console.log("my defaultValue : ", defaultValue);
            //dictionary[field.fieldName] = "";
            if(field.fieldType === 'DROPDOWN') {
                if(field.fieldName === 'gender' || field.fieldName === 'id_type' ) {
                    const dropdownOptions = field.dropdown;
                    const m = dropdownOptions.length;
                    content.push(
                        <Form.Group className="mb-2" controlId={field.fieldName} key={field.fieldName}>
                            <FloatingLabel
                                controlId={field.fieldName}
                                label={'[' + field.fieldText + ']'}
                                className="mb-3"
                            >
                                <select class="form-select form-select-sm" aria-label=".form-select-sm example">
                                    <RenderDropdown dropdown={dropdownOptions} />
                                </select>
                            </FloatingLabel>
                        </Form.Group>
                    );
                } else {
                    content.push(
                        <Form.Group className="mb-2" controlId={field.fieldName} key={field.fieldName}>
                            <FloatingLabel
                                controlId={field.fieldName}
                                label={'[' + field.fieldText + ']'}
                                className="mb-3"
                            >
                                <select class="form-select form-select-sm" aria-label=".form-select-sm example">
                                    <option value="1">One</option>
                                    <option value="2">Two</option>
                                    <option value="3">Three</option>
                                </select>
                            </FloatingLabel>
                        </Form.Group>
                    );
                }
            } else {
                content.push(
                    <Form.Group className="mb-2" controlId={field.fieldName} key={field.fieldName}>
                        <FloatingLabel
                            controlId={field.fieldName}
                            label={'[' + field.fieldText + ']'}
                            className="mb-3"
                        >
                            <Form.Control type="input" placeholder={field.fieldText} onChange={changeFieldValue}
                                    defaultValue={defaultValue}
                                />
                        </FloatingLabel>
                    </Form.Group>
                );
            }
        }
        return content;
    }

    const changeFieldValue = (event) => {
        //console.log("event.target id ", event.target.id);
        const fieldId = event.target.id;
        const value = event.target.value;
        dictionary[fieldId] = value;
    }

    const changeCountryCode = (event) => {
        const countryCode = event.target.value;
        if (countryCode === 'PH') {
            let templateRequest = {
                templateId: 'UNI_01',
                version: 'PH_1.1',
                countryCode: 'PH',
                currencyCode: 'PHP'
            };
            dictionary["template_id"] = 'UNI_01';
            dictionary["version"] = 'PH_1.1';            
            requestTemplate(templateRequest);

        } else if (countryCode === 'CN') {
            let templateRequest = {
                templateId: 'CHN_01',
                version: 'CHN_01',
                countryCode: 'CN',
                currencyCode: 'USD'
            };
            dictionary['template_id'] = 'CHN_01';
            dictionary['version'] = 'CHN_01';
            requestTemplate(templateRequest);
        }
    };

    const requestTemplate = async (templateRequest) => {
        await fetch('http://localhost:8080/template', {
            method: 'POST',
            body: JSON.stringify(templateRequest),
            headers: {
                'Content-type': 'application/json; charset=UTF-8',
            },
        })
            .then((response) => response.json())
            .then((data) => {
                console.log("data.obj.templateFields", data.obj.templateFields);
                setTemplateFields(data.obj.templateFields);
                setCountryCode(data.obj.countryCode);
                setJsonText(JSON.stringify(data.obj, null, 2));
            })
            .catch((err) => {
                console.log(err.message);
            });
    };

    return (
        <Container>
            <Row>
                <Col sm={5}>
                    <Form style={{ marginTop: '10px' }}>
                        <Form.Group className="mb-2" controlId="countryCode">
                            <Form.Select aria-label="Select a country" value={countryCode} onChange={changeCountryCode}>
                                <option>Select a country</option>
                                <option value="PH">Philippines</option>
                                <option value="CN">China</option>
                            </Form.Select>
                        </Form.Group>
                    </Form>
                </Col>
            </Row>
            <Row>
                
                <Col sm={5}>
                    <Card style={{ width: '100%', marginTop: '10px' }}>
                        <Card.Body>
                            <Card.Title>JSON message</Card.Title>
                            <Form>
                                <Form.Group className="mb-2" controlId="json_text">
                                    <FloatingLabel
                                        controlId="floatingInput"
                                        label="JSON"
                                        className="mb-3"
                                    >
                                        <Form.Control as="textarea" rows={20} style={{height:'unset'}} value={jsonText}
                                            readOnly={true} />
                                    </FloatingLabel>
                                </Form.Group>
                            </Form>
                        </Card.Body>
                    </Card>
                </Col>
                <Col sm={5}>
                    <Card style={{ width: '100%', marginTop: '10px' }}>
                        <Card.Body>
                            <Card.Title>Compliance template</Card.Title>
                            <Form>
                                <RenderTemplateFields />
                            </Form>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </Container>
    );

}

export default withRouter(DynamicTemplate);