import React, { Component } from 'react';
import { withRouter } from "../utils/withRouter";
import TemplateService from "../services/TemplateService";
import TemplateFields from './TemplateFields';
import { Button, Card, CardBody, Col, Container, FloatingLabel, Form, Row } from "react-bootstrap";

class DynamicTemplate extends Component {

    constructor(props) {
        super(props);

        this.state = {
            countryCode: '',
            jsonText: '',
            templateFields: new Array(),
            fieldValue: '',
            fieldMap: new Map()
        }

        this.changeCountryCode = this.changeCountryCode.bind(this);
    }

    changeCountryCode(event) {
        //this.setState({ countryCode: event.target.value });
        const countryCode = event.target.value;
        if(countryCode === 'PH') {
            let templateRequest = {
                templateId: 'UNI_01',
                version: 'PH_1.1',
                countryCode: 'PH',
                currencyCode: 'PHP'
            };

            this.requestTemplate(templateRequest);
            /*TemplateService.requestTemplate(templateRequest).then(resp => {
                template = resp.data.obj;
                console.log("template.templateFields ", template.templateFields);
                this.setState({ countryCode: event.target.value });
                this.setState({ templateFields: template.templateFields, countryCode: event.target.value });
            });*/
            
        } else if(this.state.countryCode === 'CN') {
            
        }
    }

    async requestTemplate(templateRequest) {
        await fetch('http://localhost:8080/template', {
          method: 'POST',
          body: JSON.stringify(templateRequest),
          headers: {
            'Content-type': 'application/json; charset=UTF-8',
          },
        })
          .then((response) => response.json())
          .then((data) => {
            console.log("data.obj.templateFields", data.obj.templateFields);
            this.setState({ templateFields: data.obj.templateFields, countryCode: data.obj.countryCode });
          })
          .catch((err) => {
            console.log(err.message);
          });
      }

    changeFieldValue(event) {
        console("event.target ", event.target);
    }

    render() {
        return (
            <Container>
                {
                                    
                                    this.state.templateFields.map((field, i) => {
                                        <h>aaaa</h>
                                    })}
                <Row>
                    <Col sm={5}>
                        <Form style={{ marginTop: '10px' }}>
                            <Form.Group className="mb-2" controlId="countryCode">
                                <Form.Select aria-label="Select a country" value={this.state.countryCode} onChange={this.changeCountryCode}>
                                    <option>Select a country</option>
                                    <option value="PH">Philippines</option>
                                    <option value="CN">China</option>
                                </Form.Select>
                            </Form.Group>
                        </Form>
                    </Col>
                </Row>
                <Row>
                    <Col sm={5}>
                        <Card style={{ width: '100%', marginTop: '10px' }}>
                            <Card.Body>
                                <Card.Title>UI template of Transaction</Card.Title>
                                <Form>
                                    <TemplateFields templateFields={this.state.templateFields} />
                                </Form>
                            </Card.Body>
                        </Card>
                    </Col>
                    <Col sm={5}>
                        <Card style={{ width: '100%', marginTop: '10px' }}>
                            <Card.Body>
                                <Card.Title>JSON template</Card.Title>
                                <Form>
                                    <Form.Group className="mb-2" controlId="json_text">
                                        <FloatingLabel
                                            controlId="floatingInput"
                                            label="JSON"
                                            className="mb-3"
                                        >
                                            <Form.Control as="textarea" rows={20} value={this.state.jsonText}
                                                readOnly={true} />
                                        </FloatingLabel>
                                    </Form.Group>
                                </Form>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
            </Container>

        );
    }
}

export default withRouter(DynamicTemplate);