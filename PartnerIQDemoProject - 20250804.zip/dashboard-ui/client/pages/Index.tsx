import React, { useEffect, useState } from 'react';
import Header from '../components/Header';
import axios from "axios";
import { io } from "socket.io-client";

export default function Index() {

  const rootPath = 'generated-artifacts'

  const [consoleOutput, setConsoleOutput] = useState<string[]>([]);
  const [isRunning, setIsRunning] = useState<string | null>(null);
  const [selectedLanguage, setSelectedLanguage] = useState<string>('Java');
  const [selectedFrontendFramework, setSelectedFrontendFramework] = useState<string>('React');
  const [selectedWorkflowSteps, setSelectedWorkflowSteps] = useState<string>('Full Integration');
  const [selectedTestingOption, setSelectedTestingOption] = useState<string>('1. Generate Testing Cases');
  const [activeSection, setActiveSection] = useState<'architecture' | 'features'>('architecture');
  const [currentPath, setCurrentPath] = useState<string>(rootPath);
  const [items, setItems] = useState([]);

  const logSubject = "log_consoleoutput"
  const socket = io("http://localhost:5000");

  useEffect(() => {
    fetchFolder(currentPath);
    const intervalId = setInterval(() => {
      fetchFolder(currentPath);
    }, 10000);

    const handler = (data: any) => {
      setConsoleOutput(prev => [...prev, data.log]);
    };

    socket.on(logSubject, handler);

    return () => {
      clearInterval(intervalId);
      socket.off(logSubject, handler);
    };
  }, [currentPath]);

  /*useEffect(() => {
      fetchFolder(currentPath);
      const intervalId = setInterval(() => {
        fetchFolder(currentPath);
      }, 10000);

      socket.on(logSubject, (data) => {
        setConsoleOutput(prev => [...prev, data.log]);
      });
      return () => {
        socket.off(logSubject);
      };
    }, [currentPath]
  );*/

  /*useEffect(() => {
      socket.on(logSubject, (data) => {
        setConsoleOutput(prev => [...prev, data.log]);
      });
      return () => {
        socket.off(logSubject);
      };
    }, []
  );*/

  const fetchFolder = async (path: string) => {
    const res = await fetch(`http://localhost:5000/list-dir?path=${path}`);
    const data = await res.json();
    setItems(data.items);
    //setCurrentPath(data.currentPath);
  };

  const openFeaturesSection = () => {
    setActiveSection('features');
    // Scroll to the Interactive Demo Features section after a brief delay to allow state update
    setTimeout(() => {
      const element = document.getElementById('interactive-demo-features');
      if (element) {
        element.scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });
      }
    }, 100);
  };

  const navigateUp = () => {
    if (currentPath === '/') return;
    const pathParts = currentPath.split('/').filter(Boolean);
    pathParts.pop();
    //const parentPath = pathParts.length > 0 ? '/' + pathParts.join('/') + '/' : '/';
    const parentPath = pathParts.join('/');
    setCurrentPath(parentPath);
  };

  const handleFolderClick = (folderName: string) => {
    const newPath = currentPath.endsWith("/")
      ? currentPath + folderName
      : currentPath + "/" + folderName;
    setCurrentPath(newPath);
    //fetchFolder(newPath);
  };

  const runFeature = async (featureType: 'backend' | 'frontend' | 'integration' | 'testing', taskUrl: string, title: string) => {

    switch (featureType) {
      case 'backend':
      case 'frontend':
      case 'integration':
        setIsRunning(featureType);
        setConsoleOutput([]);
        axios.post(taskUrl);
        setConsoleOutput(prev => [...prev, "---------------------"]);
        setConsoleOutput(prev => [...prev, "[" + title + "]"]);
        setIsRunning(null);
        return;
      case 'testing':
        setIsRunning(featureType);
        setConsoleOutput([]);
        const logs = getFeatureLogs(featureType);
        for (let i = 0; i < logs.length; i++) {
          await new Promise(resolve => setTimeout(resolve, 500 + Math.random() * 1000));
          setConsoleOutput(prev => [...prev, logs[i]]);
        }
        setIsRunning(null);
        return;
      default:
        return;
    }
  };

  const getFileExtension = (language: string) => {
    switch (language) {
      case 'Java': return '.java';
      case 'Python': return '.py';
      case 'C#': return '.cs';
      case 'Node.js': return '.js';
      case 'Go': return '.go';
      case 'PHP': return '.php';
      case 'Ruby': return '.rb';
      default: return '.java';
    }
  };

  const getFramework = (language: string) => {
    switch (language) {
      case 'Java': return 'Spring Boot';
      case 'Python': return 'FastAPI';
      case 'C#': return '.NET Core';
      case 'Node.js': return 'Express.js';
      case 'Go': return 'Gin';
      case 'PHP': return 'Laravel';
      case 'Ruby': return 'Ruby on Rails';
      default: return 'Spring Boot';
    }
  };

  const getFrontendFileExtension = (framework: string) => {
    switch (framework) {
      case 'React': return '.jsx';
      case 'Angular': return '.component.ts';
      case 'Vue': return '.vue';
      case 'Svelte': return '.svelte';
      case 'Next.js': return '.tsx';
      case 'Nuxt.js': return '.vue';
      case 'Vanilla JS': return '.js';
      default: return '.jsx';
    }
  };

  const getFrontendBuildTool = (framework: string) => {
    switch (framework) {
      case 'React': return 'Vite';
      case 'Angular': return 'Angular CLI';
      case 'Vue': return 'Vue CLI';
      case 'Svelte': return 'SvelteKit';
      case 'Next.js': return 'Next.js';
      case 'Nuxt.js': return 'Nuxt.js';
      case 'Vanilla JS': return 'Webpack';
      default: return 'Vite';
    }
  };

  const getWorkflowLogs = (workflowType: string) => {
    switch (workflowType) {
      case 'Full Integration':
        return [
          '[↗ - Generate End-to-End Workflow]',
          'Initializing full stack integration...',
          '-->Connecting PartnerOS with Backend App',
          'Setting up PartnerOS SDK integration...',
          '-->SDK version 2.4.1 downloaded successfully',
          '-->API keys and OAuth 2.0 setup complete',
          'Configuring Backend API endpoints...',
          `-->Integrating ${selectedLanguage} backend with PartnerOS`,
          '-->Partner CRUD operations configured',
          'Connecting Backend with Frontend...',
          `-->Setting up ${selectedFrontendFramework} API integration`,
          '-->State management and data flow configured',
          'Testing end-to-end workflow...',
          '-->Authentication flow: ✓ Passed',
          '-->Data synchronization: ✓ Passed',
          '-->Transaction processing: ✓ Passed',
          'End-to-end workflow generation completed successfully.'
        ];
      case 'PartnerOS + Backend':
        return [
          '[↗ - PartnerOS + Backend Integration]',
          'Focusing on PartnerOS and Backend integration...',
          'Downloading PartnerOS SDK...',
          '-->SDK version 2.4.1 downloaded successfully',
          `-->Installing ${selectedLanguage} SDK dependencies`,
          'Configuring authentication...',
          '-->API keys and OAuth 2.0 setup complete',
          `-->Setting up ${selectedLanguage} authentication middleware`,
          'Setting up partner management endpoints...',
          `-->Generating ${selectedLanguage} API controllers`,
          '-->Partner CRUD operations configured',
          'Establishing real-time data sync...',
          '-->WebSocket connections established',
          '-->Database synchronization configured',
          'Testing PartnerOS-Backend integration...',
          '-->All 12 integration tests passed',
          'PartnerOS + Backend integration completed successfully.'
        ];
      case 'Backend + Frontend':
        return [
          '[↗ - Backend + Frontend Integration]',
          'Focusing on Backend and Frontend integration...',
          `-->Connecting ${selectedLanguage} backend with ${selectedFrontendFramework} frontend`,
          'Setting up API communication layer...',
          `-->Generating ${selectedFrontendFramework} API service layer`,
          '-->HTTP client configuration completed',
          'Configuring data models and interfaces...',
          `-->TypeScript interfaces generated for ${selectedFrontendFramework}`,
          '-->Data validation schemas synchronized',
          'Setting up state management...',
          `-->${selectedFrontendFramework} state management configured`,
          '-->API response caching implemented',
          'Implementing error handling...',
          '-->Global error handling middleware setup',
          '-->User-friendly error messages configured',
          'Testing Backend-Frontend integration...',
          '-->API endpoints: ✓ All 8 tests passed',
          '-->Data flow: ✓ Passed',
          'Backend + Frontend integration completed successfully.'
        ];
      default:
        return [];
    }
  };

  const getTestingLogs = (testingType: string) => {
    switch (testingType) {
      case '1. Generate Testing Cases':
        return [
          '[↗ - Generate Testing Cases]',
          'Analyzing application structure...',
          `-->Scanning ${selectedLanguage} backend endpoints`,
          `-->Analyzing ${selectedFrontendFramework} frontend components`,
          'Generating comprehensive test suites...',
          '-->Unit test cases generated for backend APIs',
          '-->Component test cases generated for frontend',
          '-->Integration test cases generated for end-to-end flows',
          'Creating test data and mock scenarios...',
          '-->Test data templates created',
          '-->Mock user scenarios defined',
          '-->Edge case test scenarios generated',
          'Generating automated test scripts...',
          '-->Jest test files generated for backend',
          `-->${selectedFrontendFramework === 'Angular' ? 'Jasmine/Karma' : 'Jest/Testing Library'} tests for frontend`,
          '-->Cypress E2E test scripts generated',
          'Testing case generation completed successfully.'
        ];
      case '2. Build Testing Environment':
        return [
          '[↗ - Build Testing Environment]',
          'Setting up isolated testing environment...',
          '-->Creating Docker containers for testing',
          '-->Setting up test databases with sample data',
          'Configuring testing infrastructure...',
          `-->Configuring ${selectedLanguage} testing frameworks`,
          `-->${selectedFrontendFramework} testing environment setup`,
          '-->CI/CD pipeline configuration for automated testing',
          'Installing testing dependencies...',
          '-->Test runners and assertion libraries installed',
          '-->Mock servers and testing utilities configured',
          '-->Performance testing tools integrated',
          'Environment validation and health checks...',
          '-->Database connections verified',
          '-->API endpoints accessibility confirmed',
          '-->Frontend test environment ready',
          'Testing environment build completed successfully.'
        ];
      case '3. Run Application':
        return [
          '[↗ - Run Application]',
          'Starting comprehensive application testing...',
          '-->Launching backend services in test mode',
          `-->Starting ${selectedFrontendFramework} development server`,
          'Executing automated test suites...',
          '-->Running unit tests: ✓ 45/45 passed',
          '-->Running integration tests: ✓ 23/23 passed',
          '-->Running component tests: ✓ 31/31 passed',
          'Performing end-to-end testing...',
          '-->User authentication flow: ✓ Passed',
          '-->Data submission and validation: ✓ Passed',
          '-->Cross-browser compatibility: ✓ Passed',
          'Running performance and load tests...',
          '-->Response time analysis: ✓ Average 245ms',
          '-->Memory usage optimization: ✓ Within limits',
          '-->Concurrent user testing: ✓ 100 users supported',
          'Application testing completed successfully.'
        ];
      default:
        return [];
    }
  };

  const getFeatureLogs = (featureType: 'backend' | 'frontend' | 'integration' | 'testing') => {
    switch (featureType) {
      case 'backend':
        const fileExtension = getFileExtension(selectedLanguage);
        const framework = getFramework(selectedLanguage);
        return [
          '[↗ - Create Backend]',
          `Creating ${selectedLanguage}-based backend application...`,
          `-->Setting up ${framework} project structure`,
          `-->${selectedLanguage}-based backend application created successfully:`,
          `D:\\dev\\workspace\\PartnerIQDemoProject\\dashboard\\backend\\generated-artifacts\\server${fileExtension}`,
          `Installing ${selectedLanguage} dependencies...`,
          `-->Dependencies installed successfully`,
          'Requesting PartnerOS api docs',
          '-->api doc saved to generated-artifacts/api-docs\\catalog_api-docs_spec.json',
          '-->api doc saved to generated-artifacts/api-docs\\workflow_api-docs_spec.json',
          '-->api doc saved to generated-artifacts/api-docs\\metadata_api-docs_spec.json',
          'Requesting Backend api docs',
          '-->api doc saved to generated-artifacts/api-docs\\backend_api-docs_spec.json',
          '-->api doc saved to generated-artifacts/api-docs\\backend_ui_generation_spec.json',
          `${selectedLanguage} backend generation completed successfully.`
        ];
      case 'frontend':
        const frontendFileExt = getFrontendFileExtension(selectedFrontendFramework);
        const buildTool = getFrontendBuildTool(selectedFrontendFramework);
        return [
          '[↗ - Generate Frontend UI]',
          `Initializing ${selectedFrontendFramework} frontend generation...`,
          `-->Setting up ${buildTool} project structure`,
          `-->Setting up component library and design system`,
          'Creating responsive layouts...',
          `-->Generated components: Header${frontendFileExt}, Navigation${frontendFileExt}, Dashboard${frontendFileExt}`,
          'D:\\dev\\workspace\\PartnerIQDemoProject\\frontend\\src\\components\\',
          `Applying ${selectedFrontendFramework === 'Angular' ? 'SCSS' : 'TailwindCSS'} styling...`,
          '-->Styled components with responsive breakpoints',
          `Setting up routing and state management...`,
          `-->${selectedFrontendFramework} Router and state management configured`,
          'Building interactive elements...',
          '-->Forms, buttons, and data tables generated',
          'Optimizing for mobile and desktop...',
          '-->Responsive design patterns applied',
          `${selectedFrontendFramework} frontend UI generation completed successfully.`
        ];
      case 'integration':
        return getWorkflowLogs(selectedWorkflowSteps);
      case 'testing':
        return getTestingLogs(selectedTestingOption);
      default:
        return [];
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Partner<span className="text-yellow-400">IQ</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-300 mb-4">
              Demo Application
            </p>
            <p className="text-lg text-gray-400 max-w-3xl mx-auto mb-8">
              Experience the power of intelligent partner management and analytics.
              Built with cutting-edge technology to deliver insights that drive business growth.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={openFeaturesSection}
                className="bg-yellow-400 hover:bg-yellow-500 text-black px-8 py-3 rounded-lg font-semibold text-lg transition-all transform hover:scale-105"
              >
                Start Demo
              </button>
              <button className="border border-gray-600 hover:border-gray-500 text-white px-8 py-3 rounded-lg font-semibold text-lg transition-all hover:bg-gray-800">
                Learn More
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Powerful Features
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto mb-8">
              Discover how PartnerIQ revolutionizes partner management with intelligent insights and seamless integration.
            </p>

            {/* Step Indicator */}
            <div className="flex flex-col sm:flex-row justify-center items-center gap-6 max-w-5xl mx-auto">
              <div className="flex items-center">
                <div className="w-8 h-8 bg-yellow-400 text-black rounded-full flex items-center justify-center font-semibold text-sm">
                  1
                </div>
                <div className="ml-3 text-left">
                  <div className="text-sm font-semibold text-gray-900">Generate Backend App</div>
                  <div className="text-xs text-gray-600">Create robust APIs</div>
                </div>
              </div>

              <div className="hidden sm:block w-8 h-px bg-gray-300"></div>
              <div className="sm:hidden w-px h-8 bg-gray-300"></div>

              <div className="flex items-center">
                <div className="w-8 h-8 bg-yellow-400 text-black rounded-full flex items-center justify-center font-semibold text-sm">
                  2
                </div>
                <div className="ml-3 text-left">
                  <div className="text-sm font-semibold text-gray-900">Generate Frontend UI</div>
                  <div className="text-xs text-gray-600">Build responsive interfaces</div>
                </div>
              </div>

              <div className="hidden sm:block w-8 h-px bg-gray-300"></div>
              <div className="sm:hidden w-px h-8 bg-gray-300"></div>

              <div className="flex items-center">
                <div className="w-8 h-8 bg-yellow-400 text-black rounded-full flex items-center justify-center font-semibold text-sm">
                  3
                </div>
                <div className="ml-3 text-left">
                  <div className="text-sm font-semibold text-gray-900">Generate End-to-End Workflow</div>
                  <div className="text-xs text-gray-600">Connect all components</div>
                </div>
              </div>

              <div className="hidden sm:block w-8 h-px bg-gray-300"></div>
              <div className="sm:hidden w-px h-8 bg-gray-300"></div>

              <div className="flex items-center">
                <div className="w-8 h-8 bg-yellow-400 text-black rounded-full flex items-center justify-center font-semibold text-sm">
                  4
                </div>
                <div className="ml-3 text-left">
                  <div className="text-sm font-semibold text-gray-900">Test Application Online</div>
                  <div className="text-xs text-gray-600">Validate functionality</div>
                </div>
              </div>
            </div>
          </div>

          {/* Collapsible Sub-sections */}
          <div className="mb-20">
            {/* Sub-section 1: Architecture Overview */}
            <div className="bg-white rounded-xl shadow-lg mb-8 overflow-hidden">
              <button
                onClick={() => setActiveSection(activeSection === 'architecture' ? 'features' : 'architecture')}
                className="w-full px-8 py-6 text-left hover:bg-gray-50 transition-colors flex items-center justify-between"
              >
                <div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">
                    Solution Architecture Overview
                  </h3>
                  <p className="text-gray-600">
                    Explore how PartnerIQ integrates with PartnerOS APIs to auto-generate backend services and frontend UIs.
                  </p>
                </div>
                <div className="ml-4">
                  <svg
                    className={`w-6 h-6 text-gray-500 transition-transform duration-200 ${activeSection === 'architecture' ? 'rotate-180' : ''}`}
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </div>
              </button>

              {activeSection === 'architecture' && (
                <div className="px-8 pb-8">
                  <div className="border-t border-gray-200 pt-8">
                    {/* Architecture Diagram 1: Auto-Generation */}
                    <div className="bg-gray-50 rounded-xl p-8 mb-12">
                      <h4 className="text-xl font-semibold text-gray-900 mb-6 text-center">
                        Architecture Goal 1: System Auto-Generation via PartnerOS API
                      </h4>
                      <div className="flex justify-center">
                        <svg width="1000" height="400" viewBox="0 0 1000 400" className="max-w-full h-auto">
                          {/* PartnerOS APIs */}
                          <g>
                            <rect x="50" y="50" width="120" height="280" rx="8" fill="#FFC107" stroke="#F57C00" strokeWidth="2" />
                            <text x="110" y="35" textAnchor="middle" className="fill-gray-900 text-sm font-semibold">PartnerOS APIs</text>

                            <rect x="60" y="70" width="100" height="60" rx="6" fill="#FFF3E0" />
                            <text x="110" y="90" textAnchor="middle" className="fill-gray-800 text-xs font-medium">Catalog API</text>
                            <text x="110" y="105" textAnchor="middle" className="fill-gray-600 text-xs">Categories</text>
                            <text x="110" y="118" textAnchor="middle" className="fill-gray-600 text-xs">Products</text>

                            <rect x="60" y="145" width="100" height="60" rx="6" fill="#FFF3E0" />
                            <text x="110" y="165" textAnchor="middle" className="fill-gray-800 text-xs font-medium">Workflow API</text>
                            <text x="110" y="180" textAnchor="middle" className="fill-gray-600 text-xs">Journey Steps</text>
                            <text x="110" y="193" textAnchor="middle" className="fill-gray-600 text-xs">Sequences</text>

                            <rect x="60" y="220" width="100" height="60" rx="6" fill="#FFF3E0" />
                            <text x="110" y="240" textAnchor="middle" className="fill-gray-800 text-xs font-medium">Metadata API</text>
                            <text x="110" y="255" textAnchor="middle" className="fill-gray-600 text-xs">Schemas</text>
                            <text x="110" y="268" textAnchor="middle" className="fill-gray-600 text-xs">Field Rules</text>
                          </g>

                          {/* Sequential Arrows */}
                          <defs>
                            <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="10" refY="3.5" orient="auto">
                              <polygon points="0 0, 10 3.5, 0 7" fill="#4CAF50" />
                            </marker>
                          </defs>

                          <path d="M 180 100 Q 220 100 250 130" stroke="#4CAF50" strokeWidth="3" fill="none" markerEnd="url(#arrowhead)" />
                          <text x="215" y="110" textAnchor="middle" className="fill-green-600 text-xs font-medium">1. Fetch</text>

                          <path d="M 180 175 Q 220 175 250 175" stroke="#4CAF50" strokeWidth="3" fill="none" markerEnd="url(#arrowhead)" />
                          <text x="215" y="170" textAnchor="middle" className="fill-green-600 text-xs font-medium">2. Fetch</text>

                          <path d="M 180 250 Q 220 250 250 220" stroke="#4CAF50" strokeWidth="3" fill="none" markerEnd="url(#arrowhead)" />
                          <text x="215" y="240" textAnchor="middle" className="fill-green-600 text-xs font-medium">3. Fetch</text>

                          {/* Generation Engine */}
                          <rect x="250" y="130" width="140" height="90" rx="8" fill="#2196F3" stroke="#1976D2" strokeWidth="2" />
                          <text x="320" y="115" textAnchor="middle" className="fill-gray-900 text-sm font-semibold">Generation Engine</text>
                          <text x="320" y="155" textAnchor="middle" className="fill-white text-xs font-medium">Auto-Generate</text>
                          <text x="320" y="170" textAnchor="middle" className="fill-white text-xs">Backend Code</text>
                          <text x="320" y="185" textAnchor="middle" className="fill-white text-xs">Frontend Config</text>
                          <text x="320" y="200" textAnchor="middle" className="fill-white text-xs">UI Schemas</text>

                          {/* Backend Generation */}
                          <path d="M 400 150 Q 450 150 480 120" stroke="#FF9800" strokeWidth="3" fill="none" markerEnd="url(#arrowhead)" />
                          <text x="440" y="140" textAnchor="middle" className="fill-orange-600 text-xs font-medium">Generate</text>

                          <rect x="480" y="60" width="140" height="120" rx="8" fill="#FF9800" stroke="#F57C00" strokeWidth="2" />
                          <text x="550" y="45" textAnchor="middle" className="fill-gray-900 text-sm font-semibold">Backend Services</text>
                          <text x="550" y="85" textAnchor="middle" className="fill-white text-xs font-medium">Swagger Generator</text>
                          <text x="550" y="105" textAnchor="middle" className="fill-white text-xs">Java/Python/Node.js</text>
                          <text x="550" y="125" textAnchor="middle" className="fill-white text-xs">API Endpoints</text>
                          <text x="550" y="145" textAnchor="middle" className="fill-white text-xs">Service Interfaces</text>
                          <text x="550" y="165" textAnchor="middle" className="fill-white text-xs">Data Models</text>

                          {/* Frontend Generation */}
                          <path d="M 400 200 Q 450 200 480 230" stroke="#9C27B0" strokeWidth="3" fill="none" markerEnd="url(#arrowhead)" />
                          <text x="440" y="220" textAnchor="middle" className="fill-purple-600 text-xs font-medium">Generate</text>

                          <rect x="480" y="200" width="140" height="120" rx="8" fill="#9C27B0" stroke="#7B1FA2" strokeWidth="2" />
                          <text x="550" y="195" textAnchor="middle" className="fill-gray-900 text-sm font-semibold">Frontend UI</text>
                          <text x="550" y="225" textAnchor="middle" className="fill-white text-xs font-medium">Builder.io Config</text>
                          <text x="550" y="245" textAnchor="middle" className="fill-white text-xs">React/Angular</text>
                          <text x="550" y="265" textAnchor="middle" className="fill-white text-xs">Dynamic Forms</text>
                          <text x="550" y="285" textAnchor="middle" className="fill-white text-xs">UI Components</text>
                          <text x="550" y="305" textAnchor="middle" className="fill-white text-xs">Responsive Layouts</text>

                          {/* Integration Lines */}
                          <path d="M 650 120 Q 700 120 700 175 Q 700 230 650 230" stroke="#4CAF50" strokeWidth="3" fill="none" markerEnd="url(#arrowhead)" />
                          <text x="720" y="175" className="fill-green-600 text-xs font-medium">Integrated</text>
                          <text x="720" y="188" className="fill-green-600 text-xs font-medium">System</text>

                          {/* Generated System */}
                          <rect x="750" y="120" width="180" height="140" rx="8" fill="#4CAF50" stroke="#388E3C" strokeWidth="2" />
                          <text x="840" y="105" textAnchor="middle" className="fill-gray-900 text-sm font-semibold">Generated Full-Stack System</text>
                          <text x="840" y="150" textAnchor="middle" className="fill-white text-xs font-medium">PartnerOS ↔ Backend Integration</text>
                          <text x="840" y="170" textAnchor="middle" className="fill-white text-xs font-medium">Backend ↔ Frontend Integration</text>
                          <text x="840" y="195" textAnchor="middle" className="fill-white text-xs font-medium">✓ Auto-generated APIs</text>
                          <text x="840" y="215" textAnchor="middle" className="fill-white text-xs font-medium">✓ Dynamic UI Components</text>
                          <text x="840" y="235" textAnchor="middle" className="fill-white text-xs font-medium">✓ Ready for Production</text>
                        </svg>
                      </div>
                    </div>

                    {/* Architecture Diagram 2: Runtime Flow */}
                    <div className="bg-gray-50 rounded-xl p-8">
                      <h4 className="text-xl font-semibold text-gray-900 mb-6 text-center">
                        Architecture Goal 2: Runtime Integration of Money Transfer Journey
                      </h4>
                      <div className="flex justify-center">
                        <svg width="1000" height="350" viewBox="0 0 1000 350" className="max-w-full h-auto">
                          {/* Frontend UI */}
                          <rect x="50" y="80" width="160" height="200" rx="8" fill="#9C27B0" stroke="#7B1FA2" strokeWidth="2" />
                          <text x="130" y="65" textAnchor="middle" className="fill-gray-900 text-sm font-semibold">Frontend UI</text>
                          <text x="130" y="110" textAnchor="middle" className="fill-white text-xs font-medium">Transaction Steps</text>

                          <rect x="65" y="125" width="130" height="35" rx="4" fill="#FFF3E0" />
                          <text x="130" y="135" textAnchor="middle" className="fill-gray-800 text-xs">1. Quote Request</text>
                          <text x="130" y="150" textAnchor="middle" className="fill-gray-600 text-xs">User Input Form</text>

                          <rect x="65" y="170" width="130" height="35" rx="4" fill="#FFF3E0" />
                          <text x="130" y="180" textAnchor="middle" className="fill-gray-800 text-xs">2. Create Order</text>
                          <text x="130" y="195" textAnchor="middle" className="fill-gray-600 text-xs">Payment Details</text>

                          <rect x="65" y="215" width="130" height="35" rx="4" fill="#FFF3E0" />
                          <text x="130" y="225" textAnchor="middle" className="fill-gray-800 text-xs">3. Confirm Order</text>
                          <text x="130" y="240" textAnchor="middle" className="fill-gray-600 text-xs">Final Verification</text>

                          {/* API Calls to Backend */}
                          <path d="M 220 142 L 300 142" stroke="#FF5722" strokeWidth="3" fill="none" markerEnd="url(#arrowhead)" />
                          <text x="260" y="135" textAnchor="middle" className="fill-red-600 text-xs font-medium">API Call</text>

                          <path d="M 220 187 L 300 187" stroke="#FF5722" strokeWidth="3" fill="none" markerEnd="url(#arrowhead)" />
                          <text x="260" y="180" textAnchor="middle" className="fill-red-600 text-xs font-medium">API Call</text>

                          <path d="M 220 232 L 300 232" stroke="#FF5722" strokeWidth="3" fill="none" markerEnd="url(#arrowhead)" />
                          <text x="260" y="225" textAnchor="middle" className="fill-red-600 text-xs font-medium">API Call</text>

                          {/* Backend System */}
                          <rect x="300" y="80" width="180" height="200" rx="8" fill="#FF9800" stroke="#F57C00" strokeWidth="2" />
                          <text x="390" y="65" textAnchor="middle" className="fill-gray-900 text-sm font-semibold">Backend Orchestration</text>
                          <text x="390" y="110" textAnchor="middle" className="fill-white text-xs font-medium">Transaction Workflow Engine</text>

                          <rect x="315" y="125" width="150" height="35" rx="4" fill="#FFF3E0" />
                          <text x="390" y="135" textAnchor="middle" className="fill-gray-800 text-xs">Quote Processing</text>
                          <text x="390" y="150" textAnchor="middle" className="fill-gray-600 text-xs">Validate & Route</text>

                          <rect x="315" y="170" width="150" height="35" rx="4" fill="#FFF3E0" />
                          <text x="390" y="180" textAnchor="middle" className="fill-gray-800 text-xs">Order Management</text>
                          <text x="390" y="195" textAnchor="middle" className="fill-gray-600 text-xs">Payment Processing</text>

                          <rect x="315" y="215" width="150" height="35" rx="4" fill="#FFF3E0" />
                          <text x="390" y="225" textAnchor="middle" className="fill-gray-800 text-xs">Transaction Execution</text>
                          <text x="390" y="240" textAnchor="middle" className="fill-gray-600 text-xs">Status Management</text>

                          {/* Backend to PartnerOS */}
                          <path d="M 490 142 L 570 142" stroke="#4CAF50" strokeWidth="3" fill="none" markerEnd="url(#arrowhead)" />
                          <text x="530" y="135" textAnchor="middle" className="fill-green-600 text-xs font-medium">Relay</text>

                          <path d="M 490 187 L 570 187" stroke="#4CAF50" strokeWidth="3" fill="none" markerEnd="url(#arrowhead)" />
                          <text x="530" y="180" textAnchor="middle" className="fill-green-600 text-xs font-medium">Relay</text>

                          <path d="M 490 232 L 570 232" stroke="#4CAF50" strokeWidth="3" fill="none" markerEnd="url(#arrowhead)" />
                          <text x="530" y="225" textAnchor="middle" className="fill-green-600 text-xs font-medium">Relay</text>

                          {/* PartnerOS */}
                          <rect x="570" y="80" width="160" height="200" rx="8" fill="#FFC107" stroke="#F57C00" strokeWidth="2" />
                          <text x="650" y="65" textAnchor="middle" className="fill-gray-900 text-sm font-semibold">PartnerOS</text>
                          <text x="650" y="110" textAnchor="middle" className="fill-white text-xs font-medium">Money Transfer Engine</text>

                          <rect x="585" y="125" width="130" height="35" rx="4" fill="#FFF3E0" />
                          <text x="650" y="135" textAnchor="middle" className="fill-gray-800 text-xs">Quote Calculation</text>
                          <text x="650" y="150" textAnchor="middle" className="fill-gray-600 text-xs">Rates & Fees</text>

                          <rect x="585" y="170" width="130" height="35" rx="4" fill="#FFF3E0" />
                          <text x="650" y="180" textAnchor="middle" className="fill-gray-800 text-xs">Order Creation</text>
                          <text x="650" y="195" textAnchor="middle" className="fill-gray-600 text-xs">Compliance Check</text>

                          <rect x="585" y="215" width="130" height="35" rx="4" fill="#FFF3E0" />
                          <text x="650" y="225" textAnchor="middle" className="fill-gray-800 text-xs">Transaction Processing</text>
                          <text x="650" y="240" textAnchor="middle" className="fill-gray-600 text-xs">Settlement</text>

                          {/* Response Flow */}
                          <path d="M 570 160 L 490 160" stroke="#2196F3" strokeWidth="2" fill="none" markerEnd="url(#arrowhead)" />
                          <path d="M 300 160 L 220 160" stroke="#2196F3" strokeWidth="2" fill="none" markerEnd="url(#arrowhead)" />
                          <text x="395" y="175" textAnchor="middle" className="fill-blue-600 text-xs">Response Flow</text>

                          {/* Transaction Status */}
                          <rect x="780" y="120" width="180" height="100" rx="8" fill="#4CAF50" stroke="#388E3C" strokeWidth="2" />
                          <text x="870" y="105" textAnchor="middle" className="fill-gray-900 text-sm font-semibold">Transaction Journey</text>
                          <text x="870" y="145" textAnchor="middle" className="fill-white text-xs font-medium">✓ Real-time Status Updates</text>
                          <text x="870" y="165" textAnchor="middle" className="fill-white text-xs font-medium">✓ End-to-End Tracking</text>
                          <text x="870" y="185" textAnchor="middle" className="fill-white text-xs font-medium">✓ Seamless User Experience</text>
                          <text x="870" y="205" textAnchor="middle" className="fill-white text-xs font-medium">✓ Automated Compliance</text>

                          <path d="M 740 180 L 770 170" stroke="#4CAF50" strokeWidth="3" fill="none" markerEnd="url(#arrowhead)" />
                        </svg>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Sub-section 2: Features */}
            <div id="interactive-demo-features" className="bg-white rounded-xl shadow-lg overflow-hidden">
              <button
                onClick={() => setActiveSection(activeSection === 'features' ? 'architecture' : 'features')}
                className="w-full px-8 py-6 text-left hover:bg-gray-50 transition-colors flex items-center justify-between"
              >
                <div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">
                    Interactive Demo Features
                  </h3>
                  <p className="text-gray-600">
                    Try out the powerful code generation and integration capabilities with live demos.
                  </p>
                </div>
                <div className="ml-4">
                  <svg
                    className={`w-6 h-6 text-gray-500 transition-transform duration-200 ${activeSection === 'features' ? 'rotate-180' : ''}`}
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </div>
              </button>

              {activeSection === 'features' && (
                <div className="px-8 pb-8">
                  <div className="border-t border-gray-200 pt-8">
                    <div className="grid md:grid-cols-3 gap-8">
                      <div className="bg-gray-50 rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow">
                        <div className="flex items-center gap-4 mb-6">
                          <div className="w-12 h-12 bg-yellow-400 rounded-lg flex items-center justify-center">
                            <svg className="w-6 h-6 text-black" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 12h14M5 12a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2M5 12a2 2 0 00-2 2v4a2 2 0 002 2h14a2 2 0 002-2v-4a2 2 0 00-2-2m-2-4h.01M17 16h.01" />
                            </svg>
                          </div>
                          <h3 className="text-xl font-semibold text-gray-900">
                            Generate Backend App
                          </h3>
                        </div>
                        <p className="text-gray-600 mb-6">
                          Automatically generate robust backend applications with API endpoints, database models, and business logic tailored to your partner requirements.
                        </p>
                        <div className="mb-4">
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Programming Language
                          </label>
                          <select
                            value={selectedLanguage}
                            onChange={(e) => setSelectedLanguage(e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent"
                          >
                            <option value="Java">Java (Spring Boot)</option>
                            <option value="Python">Python (FastAPI)</option>
                            <option value="C#">C# (.NET Core)</option>
                            <option value="Node.js">Node.js (Express.js)</option>
                            <option value="Go">Go (Gin)</option>
                            <option value="PHP">PHP (Laravel)</option>
                            <option value="Ruby">Ruby (Ruby on Rails)</option>
                          </select>
                        </div>
                        <button
                          onClick={() => runFeature('backend', 'http://localhost:5000/create-backend', '1 - Create Backend')}
                          disabled={isRunning !== null}
                          className="bg-yellow-400 hover:bg-yellow-500 disabled:bg-gray-300 disabled:cursor-not-allowed text-black px-4 py-2 rounded-lg font-semibold text-sm transition-colors"
                        >
                          {isRunning === 'backend' ? 'Running...' : 'Run Demo'}
                        </button>
                      </div>

                      <div className="bg-gray-50 rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow">
                        <div className="flex items-center gap-4 mb-6">
                          <div className="w-12 h-12 bg-yellow-400 rounded-lg flex items-center justify-center">
                            <svg className="w-6 h-6 text-black" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                            </svg>
                          </div>
                          <h3 className="text-xl font-semibold text-gray-900">
                            Generate Frontend UI
                          </h3>
                        </div>
                        <p className="text-gray-600 mb-6">
                          Create responsive, modern user interfaces with pre-built components, design systems, and interactive elements for seamless user experiences.
                        </p>
                        <div className="mb-4">
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Frontend Framework
                          </label>
                          <select
                            value={selectedFrontendFramework}
                            onChange={(e) => setSelectedFrontendFramework(e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent"
                          >
                            <option value="React">React (Vite)</option>
                            <option value="Angular">Angular (Angular CLI)</option>
                            <option value="Vue">Vue (Vue CLI)</option>
                            <option value="Svelte">Svelte (SvelteKit)</option>
                            <option value="Next.js">Next.js (React)</option>
                            <option value="Nuxt.js">Nuxt.js (Vue)</option>
                            <option value="Vanilla JS">Vanilla JS (Webpack)</option>
                          </select>
                        </div>
                        <button
                          onClick={() => runFeature('frontend', 'http://localhost:5000/create-frontend', '2 - Create Frontend UI')}
                          disabled={isRunning !== null}
                          className="bg-yellow-400 hover:bg-yellow-500 disabled:bg-gray-300 disabled:cursor-not-allowed text-black px-4 py-2 rounded-lg font-semibold text-sm transition-colors"
                        >
                          {isRunning === 'frontend' ? 'Running...' : 'Run Demo'}
                        </button>
                      </div>

                      <div className="bg-gray-50 rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow">
                        <div className="flex items-center gap-4 mb-6">
                          <div className="w-12 h-12 bg-yellow-400 rounded-lg flex items-center justify-center">
                            <svg className="w-6 h-6 text-black" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M9 19l3 3m0 0l3-3m-3 3V10" />
                            </svg>
                          </div>
                          <h3 className="text-xl font-semibold text-gray-900">
                            Generate End-to-End Workflow
                          </h3>
                        </div>
                        <p className="text-gray-600 mb-6">
                          Seamlessly connect your Backend App, Frontend UI with PartnerOS as an end-to-end transaction journey, with advanced partner management, real-time data sync, and enhanced functionality.
                        </p>
                        <div className="mb-4">
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Integration Workflow
                          </label>
                          <select
                            value={selectedWorkflowSteps}
                            onChange={(e) => setSelectedWorkflowSteps(e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent"
                          >
                            <option value="Full Integration">Full Integration (PartnerOS + Backend + Frontend)</option>
                            <option value="PartnerOS + Backend">PartnerOS + Backend Integration</option>
                            <option value="Backend + Frontend">Backend + Frontend Integration</option>
                          </select>
                        </div>
                        <button
                          onClick={() => runFeature('integration', 'http://localhost:5000/generate-workflow', '3 - Generate End-to-End workflow')}
                          disabled={isRunning !== null}
                          className="bg-yellow-400 hover:bg-yellow-500 disabled:bg-gray-300 disabled:cursor-not-allowed text-black px-4 py-2 rounded-lg font-semibold text-sm transition-colors"
                        >
                          {isRunning === 'integration' ? 'Running...' : 'Run Demo'}
                        </button>
                      </div>
                    </div>

                    {/* Test Application Online Feature - New Row */}
                    <div className="mt-8">
                      <div className="bg-gray-50 rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow">
                        <div className="flex items-center gap-4 mb-6">
                          <div className="w-12 h-12 bg-yellow-400 rounded-lg flex items-center justify-center">
                            <svg className="w-6 h-6 text-black" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                          </div>
                          <h3 className="text-xl font-semibold text-gray-900">
                            Test Application Online
                          </h3>
                        </div>
                        <p className="text-gray-600 mb-6">
                          Comprehensive testing suite to validate your generated applications with automated test case generation, environment setup, and execution of all testing scenarios including unit, integration, and end-to-end tests.
                        </p>
                        <div className="mb-4">
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Testing Process
                          </label>
                          <select
                            value={selectedTestingOption}
                            onChange={(e) => setSelectedTestingOption(e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent"
                          >
                            <option value="1. Generate Testing Cases">1. Generate Testing Cases</option>
                            <option value="2. Build Testing Environment">2. Build Testing Environment</option>
                            <option value="3. Run Application">3. Run Application</option>
                          </select>
                        </div>
                        <button
                          onClick={() => runFeature('testing')}
                          disabled={isRunning !== null}
                          className="bg-yellow-400 hover:bg-yellow-500 disabled:bg-gray-300 disabled:cursor-not-allowed text-black px-4 py-2 rounded-lg font-semibold text-sm transition-colors"
                        >
                          {isRunning === 'testing' ? 'Running...' : 'Run Demo'}
                        </button>
                      </div>
                    </div>

                    {/* Live Demo Console */}
                    <div className="mt-12">
                      <div className="text-center mb-8">
                        <h4 className="text-2xl font-bold text-gray-900 mb-4">
                          Live Demo Console
                        </h4>
                        <p className="text-lg text-gray-600">
                          Watch real-time output as features are executed
                        </p>
                      </div>

                      <div className="bg-black rounded-lg p-6 h-[500px] overflow-auto">
                        <div className="flex items-center justify-between mb-4">
                          <div className="flex items-center space-x-2">
                            <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                            <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                          </div>
                          <span className="text-gray-400 text-sm">PartnerIQ Demo Console</span>
                        </div>

                        <div className="font-mono text-sm">
                          {consoleOutput.length === 0 ? (
                            <div className="text-gray-500">
                              Console ready. Click "Run Demo" on any feature above to see output...
                            </div>
                          ) : (
                            consoleOutput.map((line, index) => (
                              <div key={index} className="text-green-400 mb-1">
                                {line}
                              </div>
                            ))
                          )}
                          {isRunning && (
                            <div className="text-yellow-400 animate-pulse">
                              ▋
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* File Browser */}
                    <div className="mt-12">
                      <div className="text-center mb-8">
                        <h4 className="text-2xl font-bold text-gray-900 mb-4">
                          Project File Browser
                        </h4>
                        <p className="text-lg text-gray-600">
                          Browse and explore the generated project structure
                        </p>
                      </div>

                      <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
                        {/* Path Navigation */}
                        <div className="bg-gray-50 px-4 py-3 border-b border-gray-200 flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <button
                              onClick={navigateUp}
                              disabled={currentPath === rootPath}
                              className="p-2 hover:bg-gray-200 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed"
                              title="Go up one level"
                            >
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                              </svg>
                            </button>
                            <div className="flex items-center space-x-1 text-sm text-gray-600">
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-5l-2-2H5a2 2 0 00-2 2z" />
                              </svg>
                              <span className="font-mono bg-gray-100 px-2 py-1 rounded">
                                {currentPath}
                              </span>
                            </div>
                          </div>
                          <div className="text-sm text-gray-500">
                            {items.length} items
                          </div>
                        </div>

                        {/* File/Folder List */}
                        <div className="h-80 overflow-y-auto">
                          <div className="divide-y divide-gray-100">
                            {items.map((item) => (
                              <div
                                key={item.name}
                                className={`px-4 py-3 flex items-center justify-between hover:bg-gray-50 ${item.isDirectory ? 'cursor-pointer' : ''
                                  }`}
                                onClick={() => item.isDirectory && handleFolderClick(item.name)}
                              >
                                <div className="flex items-center space-x-3">
                                  {item.isDirectory ? (
                                    <svg className="w-5 h-5 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-5l-2-2H5a2 2 0 00-2 2z" />
                                    </svg>
                                  ) : (
                                    <svg className="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                                    </svg>
                                  )}
                                  <span className={`${item.isDirectory ? 'font-medium text-blue-600' : 'text-gray-700'}`}>
                                    {item.name}
                                  </span>
                                  {item.isDirectory && (
                                    <span className="text-xs text-gray-400">folder</span>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-gray-900 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-yellow-400 mb-2">1000+</div>
              <div className="text-gray-300">Active Partners</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-yellow-400 mb-2">$50M+</div>
              <div className="text-gray-300">Transaction Volume</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-yellow-400 mb-2">99.9%</div>
              <div className="text-gray-300">Uptime</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-yellow-400 mb-2">24/7</div>
              <div className="text-gray-300">Support</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-yellow-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-black mb-4">
            Ready to Experience PartnerIQ?
          </h2>
          <p className="text-lg text-gray-800 mb-8 max-w-2xl mx-auto">
            Join thousands of organizations already using PartnerIQ to optimize their partner relationships and drive growth.
          </p>
          <button
            onClick={openFeaturesSection}
            className="bg-black hover:bg-gray-800 text-white px-8 py-3 rounded-lg font-semibold text-lg transition-all transform hover:scale-105"
          >
            Start Your Demo Today
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-3 mb-4 md:mb-0">
              <img
                src="https://cdn.builder.io/api/v1/image/assets%2F12ef3b91196646429dd4b8f74e3c93cd%2Fa5bed23b57a9444abc618fd0de901dbb?format=webp&width=800"
                alt="Western Union"
                className="h-8 w-auto"
              />
              <div>
                <div className="font-semibold">PartnerIQ Demo</div>
                <div className="text-sm text-gray-400">Powered by Western Union</div>
              </div>
            </div>
            <div className="text-sm text-gray-400">
              © 2024 Western Union. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
