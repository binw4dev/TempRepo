// Import JSON files as ES modules
import countriesData from './countries.json';
import exchangeRatesData from './exchange-rates.json';

// TypeScript interfaces for better type safety
export interface Country {
  code: string;
  name: string;
  countryCode: string;
  currency: string;
  flag: string;
}

export interface PayoutCountry {
  code: string;
  name: string;
  currency: string;
  rate: number;
  fee: number;
}

export interface ExchangeRates {
  baseCurrency: string;
  lastUpdated: string;
  rates: Record<string, number>;
  countries: PayoutCountry[];
}

// Export the data with proper typing
export const countries: Country[] = countriesData.countries;
export const exchangeRates: ExchangeRates = exchangeRatesData;
export const payoutCountries: PayoutCountry[] = exchangeRatesData.countries;

// Utility functions
export const getCountryByCode = (code: string): Country | undefined => {
  return countries.find(country => country.countryCode === code);
};

export const getPayoutCountryByCode = (code: string): PayoutCountry | undefined => {
  return payoutCountries.find(country => country.code === code);
};

export const getExchangeRate = (currencyCode: string): number => {
  return exchangeRates.rates[currencyCode] || 1;
};
