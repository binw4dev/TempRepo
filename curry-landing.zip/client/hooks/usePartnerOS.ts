import { useState, useEffect } from 'react';
import { 
  partnerOSService, 
  type MetaField, 
  type MetaListValue, 
  type WorkflowResponse,
  type ProductCatalogResponse,
  type ModuleCatalogResponse,
  type CatalogField
} from '../services/partnerOSService';

// Generic hook for async data fetching
function useAsyncData<T>(
  fetchFunction: () => Promise<T>,
  defaultValue: T,
  dependencies: any[] = []
) {
  const [data, setData] = useState<T>(defaultValue);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        setError(null);
        const result = await fetchFunction();
        setData(result);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'An error occurred');
        setData(defaultValue);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, dependencies);

  const refetch = () => {
    setLoading(true);
    setError(null);
  };

  return { data, loading, error, refetch };
}

// === Metadata API Hooks ===

// Hook for getting quote fields metadata
export function useQuoteFields() {
  return useAsyncData(
    () => partnerOSService.getQuoteFields(),
    [] as MetaField[]
  );
}

// Hook for getting create order fields metadata
export function useCreateOrderFields() {
  return useAsyncData(
    () => partnerOSService.getCreateOrderFields(),
    [] as MetaField[]
  );
}

// Hook for getting countries from WU metadata
export function useWUCountries() {
  return useAsyncData(
    () => partnerOSService.getCountries(),
    [] as MetaListValue[]
  );
}

// Hook for getting currencies from WU metadata
export function useWUCurrencies() {
  return useAsyncData(
    () => partnerOSService.getCurrencies(),
    [] as MetaListValue[]
  );
}

// Hook for getting payout methods from WU metadata
export function usePayoutMethods() {
  return useAsyncData(
    () => partnerOSService.getPayoutMethods(),
    [] as MetaListValue[]
  );
}

// Hook for getting list values for a specific field
export function useFieldListValues(fieldName: string) {
  return useAsyncData(
    () => partnerOSService.getFieldListValues(fieldName),
    [] as MetaListValue[],
    [fieldName]
  );
}

// === Workflow API Hooks ===

// Hook for getting SendMoney workflow
export function useSendMoneyWorkflow() {
  return useAsyncData(
    () => partnerOSService.getSendMoneyWorkflow(),
    { name: "SendMoney_Workflow", modules: [] } as WorkflowResponse
  );
}

// Hook for getting white label workflow
export function useWhiteLabelWorkflow() {
  return useAsyncData(
    () => partnerOSService.getWhiteLabelWorkflow(),
    { name: "SendMoney_partner_Workflow", modules: [] } as WorkflowResponse
  );
}

// Hook for getting a specific workflow module
export function useWorkflowModule(workflowType: 'cash' | 'whitelabel', moduleName: string) {
  return useAsyncData(
    () => partnerOSService.getWorkflowModule(workflowType, moduleName),
    null,
    [workflowType, moduleName]
  );
}

// === Catalog API Hooks ===

// Hook for getting product catalog
export function useProductCatalog() {
  return useAsyncData(
    () => partnerOSService.getProductCatalog(),
    { products: [] } as ProductCatalogResponse
  );
}

// Hook for getting order module catalog
export function useOrderModuleCatalog() {
  return useAsyncData(
    () => partnerOSService.getOrderModuleCatalog(),
    { module: { name: "Order", paths: [] } } as ModuleCatalogResponse
  );
}

// Hook for getting pricing module catalog
export function usePricingModuleCatalog() {
  return useAsyncData(
    () => partnerOSService.getPricingModuleCatalog(),
    { module: { name: "Pricing", paths: [] } } as ModuleCatalogResponse
  );
}

// Hook for getting field schema
export function useFieldSchema(fieldName: string) {
  return useAsyncData(
    () => partnerOSService.getFieldSchema(fieldName),
    null as CatalogField | null,
    [fieldName]
  );
}

// === Combined/Utility Hooks ===

// Hook for form validation - gets field requirements and validations
export function useFieldValidation(fieldName: string, context: 'quote' | 'order' = 'order') {
  const [validation, setValidation] = useState<{
    required: boolean;
    regex: string | null;
    maxLength?: number;
    description?: string;
  }>({
    required: false,
    regex: null
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchValidation = async () => {
      try {
        setLoading(true);
        setError(null);

        const [isRequired, regexPattern, schema] = await Promise.all([
          partnerOSService.isFieldRequired(fieldName, context),
          partnerOSService.getFieldValidation(fieldName),
          partnerOSService.getFieldSchema(fieldName)
        ]);

        setValidation({
          required: isRequired,
          regex: regexPattern,
          maxLength: schema?.max ? parseInt(schema.max) : undefined,
          description: schema?.description
        });
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to fetch validation');
      } finally {
        setLoading(false);
      }
    };

    fetchValidation();
  }, [fieldName, context]);

  return { validation, loading, error };
}

// Hook for dynamic form fields - combines metadata and catalog info
export function useDynamicFormFields(context: 'quote' | 'order' = 'order') {
  const { data: metaFields, loading: metaLoading, error: metaError } = context === 'quote' 
    ? useQuoteFields() 
    : useCreateOrderFields();

  const { data: catalog, loading: catalogLoading, error: catalogError } = useOrderModuleCatalog();

  const [enrichedFields, setEnrichedFields] = useState<(MetaField & { 
    schema?: CatalogField;
    validation?: {
      required: boolean;
      regex: string | null;
      maxLength?: number;
      description?: string;
    };
  })[]>([]);

  useEffect(() => {
    if (!metaFields.length || !catalog.schemas) return;

    const enrichFields = async () => {
      const enriched = await Promise.all(
        metaFields.map(async (field) => {
          const schema = catalog.schemas?.find(s => s.name === field.name);
          const regex = await partnerOSService.getFieldValidation(field.name);
          
          return {
            ...field,
            schema,
            validation: {
              required: field.required === 'M',
              regex,
              maxLength: schema?.max ? parseInt(schema.max) : undefined,
              description: schema?.description
            }
          };
        })
      );
      setEnrichedFields(enriched);
    };

    enrichFields();
  }, [metaFields, catalog.schemas]);

  return {
    fields: enrichedFields,
    loading: metaLoading || catalogLoading,
    error: metaError || catalogError
  };
}

// Hook for workflow step validation
export function useWorkflowStepValidation(workflowType: 'cash' | 'whitelabel' = 'cash') {
  const { data: workflow, loading, error } = workflowType === 'cash' 
    ? useSendMoneyWorkflow() 
    : useWhiteLabelWorkflow();

  const validateStep = (currentStep: string, data: any): { 
    isValid: boolean; 
    nextStep: string | null; 
    errors: string[] 
  } => {
    const module = workflow.modules.find(m => m.name === currentStep);
    if (!module) {
      return { isValid: false, nextStep: null, errors: ['Invalid step'] };
    }

    // Basic validation logic - you can enhance this based on your needs
    const errors: string[] = [];
    let nextStep: string | null = null;

    // Check success criteria
    if (module.successCriterias && module.successCriterias.length > 0) {
      const successCriteria = module.successCriterias[0]; // Use first criteria for simplicity
      nextStep = successCriteria.next || null;
    }

    return {
      isValid: errors.length === 0,
      nextStep,
      errors
    };
  };

  return {
    workflow,
    validateStep,
    loading,
    error
  };
}

// === Cache Management Hook ===
export function useCacheManager() {
  const clearCache = () => {
    partnerOSService.clearCache();
  };

  const getCacheInfo = () => {
    return partnerOSService.getCacheInfo();
  };

  return { clearCache, getCacheInfo };
}
