import { useState, useEffect } from 'react';
import { dataService, type Country, type PayoutCountry, type Relationship, type PaymentMethod } from '../services/dataService';

// Hook for fetching countries
export function useCountries() {
  const [countries, setCountries] = useState<Country[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchCountries = async () => {
      try {
        setLoading(true);
        const data = await dataService.getCountries();
        setCountries(data);
        setError(null);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to fetch countries');
        setCountries([]);
      } finally {
        setLoading(false);
      }
    };

    fetchCountries();
  }, []);

  return { countries, loading, error, refetch: () => setLoading(true) };
}

// Hook for fetching payout countries
export function usePayoutCountries() {
  const [countries, setCountries] = useState<PayoutCountry[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchPayoutCountries = async () => {
      try {
        setLoading(true);
        const data = await dataService.getPayoutCountries();
        setCountries(data);
        setError(null);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to fetch payout countries');
        setCountries([]);
      } finally {
        setLoading(false);
      }
    };

    fetchPayoutCountries();
  }, []);

  return { countries, loading, error, refetch: () => setLoading(true) };
}

// Hook for fetching relationships
export function useRelationships() {
  const [relationships, setRelationships] = useState<Relationship[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchRelationships = async () => {
      try {
        setLoading(true);
        const data = await dataService.getRelationships();
        setRelationships(data);
        setError(null);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to fetch relationships');
        setRelationships([]);
      } finally {
        setLoading(false);
      }
    };

    fetchRelationships();
  }, []);

  return { relationships, loading, error, refetch: () => setLoading(true) };
}

// Hook for fetching payment methods
export function usePaymentMethods() {
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchPaymentMethods = async () => {
      try {
        setLoading(true);
        const data = await dataService.getPaymentMethods();
        setPaymentMethods(data);
        setError(null);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to fetch payment methods');
        setPaymentMethods([]);
      } finally {
        setLoading(false);
      }
    };

    fetchPaymentMethods();
  }, []);

  return { paymentMethods, loading, error, refetch: () => setLoading(true) };
}

// Hook for exchange rate calculations
export function useExchangeRate(countryCode: string, amount: number) {
  const [exchangeRate, setExchangeRate] = useState<number>(1);
  const [receiveAmount, setReceiveAmount] = useState<number>(0);
  const [fees, setFees] = useState<{fixed: number, percentage: number, total: number}>({
    fixed: 0,
    percentage: 0,
    total: 0
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!countryCode || amount <= 0) {
      setReceiveAmount(0);
      return;
    }

    const calculateExchange = async () => {
      try {
        setLoading(true);
        setError(null);

        // Fetch exchange rate and fees in parallel
        const [rate, feeData] = await Promise.all([
          dataService.getExchangeRate(countryCode),
          dataService.calculateFees(countryCode, amount)
        ]);

        setExchangeRate(rate);
        setReceiveAmount(amount * rate);
        setFees(feeData);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to calculate exchange rate');
        setExchangeRate(1);
        setReceiveAmount(0);
        setFees({ fixed: 4.99, percentage: 0, total: 4.99 });
      } finally {
        setLoading(false);
      }
    };

    calculateExchange();
  }, [countryCode, amount]);

  return {
    exchangeRate,
    receiveAmount,
    fees,
    totalCost: amount + fees.total,
    loading,
    error
  };
}
