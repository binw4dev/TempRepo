// Western Union PartnerOS Data Service
// Handles metadata, workflow, and catalog APIs

// === TypeScript Interfaces from OpenAPI Specs ===

// Metadata API Types
export interface MetaField {
  name: string;
  label: string;
  length?: number;
  uiFieldType: string;
  uriIdentifier?: string;
  required: "M" | "C" | "O"; // Mandatory, Conditional, Optional
  conditions?: MetaCondition[];
  listValue?: MetaListValue[];
  validations?: MetaValidation[];
}

export interface MetaListValue {
  displayValue: string;
  id: string;
}

export interface MetaValidation {
  type: string;
  expression: string;
}

export interface MetaCondition {
  operation: string;
  valueList?: { value: string }[];
  dependentFieldList?: {
    fieldName: string;
    dependency: string;
    listValue?: MetaListValue[];
  }[];
}

export interface MetaResponse {
  fieldsDetails: {
    fields: MetaField[];
  };
}

// Workflow API Types
export interface WorkflowModule {
  name: string;
  pathName: string;
  pathUri: string;
  isMandatory?: boolean;
  caching?: {
    isEnabled: boolean;
    ttl: number;
  };
  metaRequired?: boolean;
  metaApi?: {
    uri: string;
    headers?: any[];
    body?: any;
  };
  successCriterias?: WorkflowCriteria[];
  failureCriterias?: WorkflowCriteria[];
}

export interface WorkflowCriteria {
  context: string;
  condition: string;
  type: string;
  next?: string;
  retryAfter?: number;
  retryLimit?: number;
}

export interface WorkflowResponse {
  name: string;
  version?: string;
  description?: string;
  modules: WorkflowModule[];
}

// Catalog API Types
export interface CatalogProduct {
  productName: "SENDMONEY" | "RECEIVEMONEY";
  modules: string[];
}

export interface CatalogModule {
  name: string;
  paths: CatalogPath[];
}

export interface CatalogPath {
  name: string;
  uri: string;
  type: string;
  header?: CatalogHeader[];
  parameters?: CatalogParameter[];
  requestFields?: CatalogFieldReference[];
  responseFields?: CatalogFieldReference[];
}

export interface CatalogHeader {
  name: string;
  description?: string;
  required?: boolean;
}

export interface CatalogParameter {
  name: string;
  scope: "Query" | "Path";
  description?: string;
  required?: boolean;
  type?: string;
}

export interface CatalogFieldReference {
  name: string;
  type: "single" | "array";
}

export interface CatalogField {
  name: string;
  label?: string;
  length?: number;
  uiFieldType?: string;
  uriIdentifier?: string;
  format?: string;
  description?: string;
  min?: string;
  max?: string;
  validations?: MetaValidation[];
}

export interface ProductCatalogResponse {
  name?: string;
  version?: string;
  description?: string;
  products: CatalogProduct[];
}

export interface ModuleCatalogResponse {
  name?: string;
  version?: string;
  description?: string;
  module: CatalogModule;
  schemas?: CatalogField[];
}

// === Data Service Class ===
class PartnerOSService {
  private cache = new Map<string, any>();
  private readonly baseUrl = '/data';

  private async fetchJSON<T>(filename: string): Promise<T> {
    // Check cache first
    if (this.cache.has(filename)) {
      return this.cache.get(filename);
    }

    try {
      const response = await fetch(`${this.baseUrl}/${filename}`);
      if (!response.ok) {
        throw new Error(`Failed to fetch ${filename}: ${response.statusText}`);
      }
      
      const data = await response.json();
      
      // Cache the result
      this.cache.set(filename, data);
      
      return data;
    } catch (error) {
      console.error(`Error fetching ${filename}:`, error);
      throw error;
    }
  }

  // === Metadata API Methods ===

  // Get metadata specification
  async getMetadataSpec(): Promise<any> {
    return this.fetchJSON('metadata.json');
  }

  // Extract fields from metadata examples for quote API
  async getQuoteFields(): Promise<MetaField[]> {
    const spec = await this.getMetadataSpec();
    const quoteExample = spec.components?.examples?.QuoteResponse?.value;
    return quoteExample?.fieldsDetails?.fields || [];
  }

  // Extract fields from metadata examples for create order API
  async getCreateOrderFields(): Promise<MetaField[]> {
    const spec = await this.getMetadataSpec();
    const orderExample = spec.components?.examples?.createOrderResponse?.value;
    return orderExample?.fieldsDetails?.fields || [];
  }

  // Get list values for a specific field
  async getFieldListValues(fieldName: string): Promise<MetaListValue[]> {
    const quoteFields = await this.getQuoteFields();
    const createOrderFields = await this.getCreateOrderFields();
    const allFields = [...quoteFields, ...createOrderFields];
    
    const field = allFields.find(f => f.name === fieldName);
    return field?.listValue || [];
  }

  // === Workflow API Methods ===

  // Get workflow specification
  async getWorkflowSpec(): Promise<any> {
    return this.fetchJSON('workflow.json');
  }

  // Get SendMoney workflow for cash payment
  async getSendMoneyWorkflow(): Promise<WorkflowResponse> {
    const spec = await this.getWorkflowSpec();
    const workflow = spec.components?.examples?.SendMoneyCashPayWorkflowResponse?.value;
    return workflow || { name: "SendMoney_Workflow", modules: [] };
  }

  // Get workflow for white label partners
  async getWhiteLabelWorkflow(): Promise<WorkflowResponse> {
    const spec = await this.getWorkflowSpec();
    const workflow = spec.components?.examples?.SendMoneyWorkflowResponse?.value;
    return workflow || { name: "SendMoney_partner_Workflow", modules: [] };
  }

  // Get specific workflow module by name
  async getWorkflowModule(workflowType: 'cash' | 'whitelabel', moduleName: string): Promise<WorkflowModule | null> {
    const workflow = workflowType === 'cash' 
      ? await this.getSendMoneyWorkflow()
      : await this.getWhiteLabelWorkflow();
    
    return workflow.modules.find(module => module.name === moduleName) || null;
  }

  // === Catalog API Methods ===

  // Get catalog specification
  async getCatalogSpec(): Promise<any> {
    return this.fetchJSON('catalog.json');
  }

  // Get product catalog
  async getProductCatalog(): Promise<ProductCatalogResponse> {
    const spec = await this.getCatalogSpec();
    const catalog = spec.components?.examples?.ProductCatalogResponse?.value;
    return catalog || { products: [] };
  }

  // Get order module catalog
  async getOrderModuleCatalog(): Promise<ModuleCatalogResponse> {
    const spec = await this.getCatalogSpec();
    const catalog = spec.components?.examples?.OrderCatalogResponse?.value;
    return catalog || { module: { name: "Order", paths: [] } };
  }

  // Get pricing module catalog
  async getPricingModuleCatalog(): Promise<ModuleCatalogResponse> {
    const spec = await this.getCatalogSpec();
    const catalog = spec.components?.examples?.PricingCatalogResponse?.value;
    return catalog || { module: { name: "Pricing", paths: [] } };
  }

  // Get field schema by name
  async getFieldSchema(fieldName: string): Promise<CatalogField | null> {
    const orderCatalog = await this.getOrderModuleCatalog();
    const schemas = orderCatalog.schemas || [];
    return schemas.find(schema => schema.name === fieldName) || null;
  }

  // === Utility Methods ===

  // Get countries from metadata
  async getCountries(): Promise<MetaListValue[]> {
    return this.getFieldListValues('sender.country');
  }

  // Get currencies from metadata
  async getCurrencies(): Promise<MetaListValue[]> {
    return this.getFieldListValues('sender.currency');
  }

  // Get payout methods from metadata
  async getPayoutMethods(): Promise<MetaListValue[]> {
    return this.getFieldListValues('payoutMethod');
  }

  // Get validation regex for a field
  async getFieldValidation(fieldName: string): Promise<string | null> {
    const schema = await this.getFieldSchema(fieldName);
    if (schema?.validations && schema.validations.length > 0) {
      const regexValidation = schema.validations.find(v => v.type === 'regex');
      return regexValidation?.expression || null;
    }
    return null;
  }

  // Check if field is required
  async isFieldRequired(fieldName: string, context: 'quote' | 'order' = 'order'): Promise<boolean> {
    const fields = context === 'quote' 
      ? await this.getQuoteFields()
      : await this.getCreateOrderFields();
    
    const field = fields.find(f => f.name === fieldName);
    return field?.required === 'M'; // M = Mandatory
  }

  // Clear cache (useful for refreshing data)
  clearCache(): void {
    this.cache.clear();
  }

  // Get cache information
  getCacheInfo(): { size: number; keys: string[] } {
    return {
      size: this.cache.size,
      keys: Array.from(this.cache.keys())
    };
  }
}

// Export singleton instance
export const partnerOSService = new PartnerOSService();

// Types are already exported with their interface declarations above
