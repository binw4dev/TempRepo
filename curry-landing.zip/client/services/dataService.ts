// Data service for fetching JSON files from public folder

export interface Country {
  code: string;
  name: string;
  countryCode: string;
  currency: string;
  flag: string;
  active: boolean;
}

export interface PayoutCountry {
  code: string;
  name: string;
  currency: string;
  exchangeRate: number;
  fees: {
    fixed: number;
    percentage: number;
    minimum: number;
    maximum: number;
  };
  deliveryMethods: string[];
  processingTime: string;
  flag: string;
  active: boolean;
  limits: {
    min: number;
    max: number;
  };
}

export interface Relationship {
  id: string;
  name: string;
  category: string;
  description: string;
  requiresAdditionalInfo: boolean;
}

export interface PaymentMethod {
  id: string;
  name: string;
  type: string;
  description: string;
  icon: string;
  processingTime: string;
  fees: {
    fixed: number;
    percentage: number;
  };
  features: string[];
  requirements: string[];
  active: boolean;
  limits: {
    min: number;
    max: number;
  };
}

class DataService {
  private cache = new Map<string, any>();
  private readonly baseUrl = '/data';

  private async fetchJSON<T>(filename: string): Promise<T> {
    // Check cache first
    if (this.cache.has(filename)) {
      return this.cache.get(filename);
    }

    try {
      const response = await fetch(`${this.baseUrl}/${filename}`);
      if (!response.ok) {
        throw new Error(`Failed to fetch ${filename}: ${response.statusText}`);
      }
      
      const data = await response.json();
      
      // Cache the result
      this.cache.set(filename, data);
      
      return data;
    } catch (error) {
      console.error(`Error fetching ${filename}:`, error);
      throw error;
    }
  }

  // Fetch phone/address countries
  async getCountries(): Promise<Country[]> {
    const data = await this.fetchJSON<{phoneCountries: Country[]}>('countries.json');
    return data.phoneCountries.filter(country => country.active);
  }

  // Fetch address countries
  async getAddressCountries(): Promise<Country[]> {
    const data = await this.fetchJSON<{addressCountries: Country[]}>('countries.json');
    return data.addressCountries;
  }

  // Fetch payout countries with exchange rates
  async getPayoutCountries(): Promise<PayoutCountry[]> {
    const data = await this.fetchJSON<{countries: PayoutCountry[]}>('payout-countries.json');
    return data.countries.filter(country => country.active);
  }

  // Get specific payout country by code
  async getPayoutCountry(code: string): Promise<PayoutCountry | null> {
    const countries = await this.getPayoutCountries();
    return countries.find(country => country.code === code) || null;
  }

  // Fetch relationships
  async getRelationships(): Promise<Relationship[]> {
    const data = await this.fetchJSON<{relationships: Relationship[]}>('relationships.json');
    return data.relationships;
  }

  // Fetch payment methods
  async getPaymentMethods(): Promise<PaymentMethod[]> {
    const data = await this.fetchJSON<{paymentMethods: PaymentMethod[]}>('payment-methods.json');
    return data.paymentMethods.filter(method => method.active);
  }

  // Get exchange rate for a specific currency
  async getExchangeRate(countryCode: string): Promise<number> {
    const country = await this.getPayoutCountry(countryCode);
    return country?.exchangeRate || 1;
  }

  // Calculate fees for a transfer
  async calculateFees(countryCode: string, amount: number): Promise<{fixed: number, percentage: number, total: number}> {
    const country = await this.getPayoutCountry(countryCode);
    if (!country) {
      return { fixed: 4.99, percentage: 0, total: 4.99 };
    }

    const fixed = country.fees.fixed;
    const percentageFee = (amount * country.fees.percentage) / 100;
    const total = Math.min(
      Math.max(fixed + percentageFee, country.fees.minimum),
      country.fees.maximum
    );

    return {
      fixed,
      percentage: percentageFee,
      total
    };
  }

  // Clear cache (useful for refreshing data)
  clearCache(): void {
    this.cache.clear();
  }

  // Get cache status
  getCacheInfo(): {size: number, keys: string[]} {
    return {
      size: this.cache.size,
      keys: Array.from(this.cache.keys())
    };
  }
}

// Export singleton instance
export const dataService = new DataService();

// Export types with different names to avoid conflicts
export type {
  Country as DataServiceCountry,
  PayoutCountry as DataServicePayoutCountry,
  Relationship as DataServiceRelationship,
  PaymentMethod as DataServicePaymentMethod
};
