import React, { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";

export interface ComplianceDetails {
  dateOfBirth: string;
  nationality: string;
  idType: string;
  idNumber: string;
  idExpireDate: string;
  occupation: string;
  employerName: string;
  sourceOfFunds: string;
}

interface ComplianceDetailsFormProps {
  initialData?: ComplianceDetails | null;
  onSubmit: (data: ComplianceDetails) => void;
}

const idTypes = [
  "Passport",
  "Driver's License",
  "National ID",
  "State ID",
  "Social Security Card",
  "Birth Certificate",
  "Other Government ID"
];

const occupations = [
  "Professional",
  "Management",
  "Service",
  "Sales",
  "Office/Administrative",
  "Construction",
  "Production",
  "Transportation",
  "Healthcare",
  "Education",
  "Government",
  "Military",
  "Retired",
  "Student",
  "Unemployed",
  "Self-employed",
  "Other"
];

const sourceOfFundsOptions = [
  "Employment/Salary",
  "Business Income",
  "Investment Income",
  "Savings",
  "Family Support",
  "Gift",
  "Pension/Retirement",
  "Government Benefits",
  "Loan",
  "Sale of Property",
  "Other"
];

const nationalities = [
  "United States",
  "Canada", 
  "Mexico",
  "India",
  "United Kingdom",
  "France",
  "Germany",
  "Spain",
  "Italy",
  "Other"
];

export function ComplianceDetailsForm({
  initialData,
  onSubmit,
}: ComplianceDetailsFormProps) {
  const [formData, setFormData] = useState<ComplianceDetails>({
    dateOfBirth: initialData?.dateOfBirth || "",
    nationality: initialData?.nationality || "",
    idType: initialData?.idType || "",
    idNumber: initialData?.idNumber || "",
    idExpireDate: initialData?.idExpireDate || "",
    occupation: initialData?.occupation || "",
    employerName: initialData?.employerName || "",
    sourceOfFunds: initialData?.sourceOfFunds || "",
  });

  const [errors, setErrors] = useState<{ [K in keyof ComplianceDetails]?: string }>({});

  const validateForm = (): boolean => {
    const newErrors: { [K in keyof ComplianceDetails]?: string } = {};

    if (!formData.dateOfBirth.trim()) {
      newErrors.dateOfBirth = "Date of birth is required";
    }
    if (!formData.nationality.trim()) {
      newErrors.nationality = "Nationality is required";
    }
    if (!formData.idType.trim()) {
      newErrors.idType = "ID type is required";
    }
    if (!formData.idNumber.trim()) {
      newErrors.idNumber = "ID number is required";
    }
    if (!formData.idExpireDate.trim()) {
      newErrors.idExpireDate = "ID expiration date is required";
    }
    if (!formData.occupation.trim()) {
      newErrors.occupation = "Occupation is required";
    }
    if (!formData.sourceOfFunds.trim()) {
      newErrors.sourceOfFunds = "Source of funds is required";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      onSubmit(formData);
    }
  };

  const updateField = (field: keyof ComplianceDetails, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: undefined }));
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-4">
        <h4 className="font-semibold text-gray-900">Personal Information</h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="dateOfBirth">Date of Birth *</Label>
            <Input
              id="dateOfBirth"
              type="date"
              value={formData.dateOfBirth}
              onChange={(e) => updateField("dateOfBirth", e.target.value)}
              className={errors.dateOfBirth ? "border-red-500" : ""}
            />
            {errors.dateOfBirth && (
              <p className="text-sm text-red-500 mt-1">{errors.dateOfBirth}</p>
            )}
          </div>

          <div>
            <Label htmlFor="nationality">Nationality *</Label>
            <Select
              value={formData.nationality}
              onValueChange={(value) => updateField("nationality", value)}
            >
              <SelectTrigger className={errors.nationality ? "border-red-500" : ""}>
                <SelectValue placeholder="Select nationality" />
              </SelectTrigger>
              <SelectContent>
                {nationalities.map((nationality) => (
                  <SelectItem key={nationality} value={nationality}>
                    {nationality}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.nationality && (
              <p className="text-sm text-red-500 mt-1">{errors.nationality}</p>
            )}
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <h4 className="font-semibold text-gray-900">Identification</h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="idType">ID Type *</Label>
            <Select
              value={formData.idType}
              onValueChange={(value) => updateField("idType", value)}
            >
              <SelectTrigger className={errors.idType ? "border-red-500" : ""}>
                <SelectValue placeholder="Select ID type" />
              </SelectTrigger>
              <SelectContent>
                {idTypes.map((idType) => (
                  <SelectItem key={idType} value={idType}>
                    {idType}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.idType && (
              <p className="text-sm text-red-500 mt-1">{errors.idType}</p>
            )}
          </div>

          <div>
            <Label htmlFor="idNumber">ID Number *</Label>
            <Input
              id="idNumber"
              value={formData.idNumber}
              onChange={(e) => updateField("idNumber", e.target.value)}
              className={errors.idNumber ? "border-red-500" : ""}
              placeholder="Enter ID number"
            />
            {errors.idNumber && (
              <p className="text-sm text-red-500 mt-1">{errors.idNumber}</p>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="idExpireDate">ID Expiration Date *</Label>
            <Input
              id="idExpireDate"
              type="date"
              value={formData.idExpireDate}
              onChange={(e) => updateField("idExpireDate", e.target.value)}
              className={errors.idExpireDate ? "border-red-500" : ""}
            />
            {errors.idExpireDate && (
              <p className="text-sm text-red-500 mt-1">{errors.idExpireDate}</p>
            )}
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <h4 className="font-semibold text-gray-900">Employment & Financial Information</h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="occupation">Occupation *</Label>
            <Select
              value={formData.occupation}
              onValueChange={(value) => updateField("occupation", value)}
            >
              <SelectTrigger className={errors.occupation ? "border-red-500" : ""}>
                <SelectValue placeholder="Select occupation" />
              </SelectTrigger>
              <SelectContent>
                {occupations.map((occupation) => (
                  <SelectItem key={occupation} value={occupation}>
                    {occupation}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.occupation && (
              <p className="text-sm text-red-500 mt-1">{errors.occupation}</p>
            )}
          </div>

          <div>
            <Label htmlFor="employerName">Employer Name</Label>
            <Input
              id="employerName"
              value={formData.employerName}
              onChange={(e) => updateField("employerName", e.target.value)}
              placeholder="Enter employer name (if applicable)"
            />
          </div>
        </div>

        <div>
          <Label htmlFor="sourceOfFunds">Source of Funds *</Label>
          <Select
            value={formData.sourceOfFunds}
            onValueChange={(value) => updateField("sourceOfFunds", value)}
          >
            <SelectTrigger className={errors.sourceOfFunds ? "border-red-500" : ""}>
              <SelectValue placeholder="Select source of funds" />
            </SelectTrigger>
            <SelectContent>
              {sourceOfFundsOptions.map((source) => (
                <SelectItem key={source} value={source}>
                  {source}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {errors.sourceOfFunds && (
            <p className="text-sm text-red-500 mt-1">{errors.sourceOfFunds}</p>
          )}
        </div>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <h5 className="font-semibold text-blue-900 mb-2">Compliance Notice:</h5>
        <p className="text-sm text-blue-800">
          This information is required for compliance with anti-money laundering (AML) 
          and know your customer (KYC) regulations. All information provided will be 
          kept confidential and secure.
        </p>
      </div>

      <div className="flex justify-end pt-4">
        <Button
          type="submit"
          className="bg-brand-yellow hover:bg-brand-yellow-dark text-black px-8"
        >
          Save Compliance Details
        </Button>
      </div>
    </form>
  );
}
