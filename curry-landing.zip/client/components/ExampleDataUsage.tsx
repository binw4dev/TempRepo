import React, { useState, useEffect } from 'react';

// Method 1: Direct import (compile-time)
import { countries, payoutCountries, getExchangeRate } from '../data';

// Method 2: Runtime fetch function
const fetchCountriesFromPublic = async () => {
  try {
    const response = await fetch('/api/countries.json');
    const data = await response.json();
    return data.data.countries;
  } catch (error) {
    console.error('Error fetching countries:', error);
    return [];
  }
};

export function ExampleDataUsage() {
  const [runtimeCountries, setRuntimeCountries] = useState([]);

  // Example: Load data at runtime
  useEffect(() => {
    fetchCountriesFromPublic().then(setRuntimeCountries);
  }, []);

  return (
    <div className="p-4">
      <h3 className="text-lg font-bold mb-4">Data Usage Examples</h3>
      
      {/* Method 1: Direct import usage */}
      <div className="mb-6">
        <h4 className="font-semibold">Countries from JSON import:</h4>
        <ul className="list-disc list-inside">
          {countries.map((country) => (
            <li key={country.countryCode}>
              {country.flag} {country.name} ({country.code})
            </li>
          ))}
        </ul>
      </div>

      {/* Payout countries */}
      <div className="mb-6">
        <h4 className="font-semibold">Payout Countries with Rates:</h4>
        <ul className="list-disc list-inside">
          {payoutCountries.map((country) => (
            <li key={country.code}>
              {country.name}: 1 USD = {country.rate} {country.currency}
            </li>
          ))}
        </ul>
      </div>

      {/* Method 2: Runtime fetch usage */}
      <div className="mb-6">
        <h4 className="font-semibold">Countries from runtime fetch:</h4>
        <ul className="list-disc list-inside">
          {runtimeCountries.map((country: any) => (
            <li key={country.countryCode}>
              {country.name} ({country.code})
            </li>
          ))}
        </ul>
      </div>

      {/* Example: Using utility functions */}
      <div>
        <h4 className="font-semibold">Exchange Rate Example:</h4>
        <p>1 USD = {getExchangeRate('MXN')} MXN</p>
      </div>
    </div>
  );
}
