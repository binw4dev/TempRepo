import React from "react";
import { ArrowLeft, CreditCard, Banknote, Clock, Shield } from "lucide-react";
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";

interface PaymentMethodSelectionProps {
  onSelect: (method: "cash" | "card") => void;
  onBack: () => void;
}

export function PaymentMethodSelection({
  onSelect,
  onBack,
}: PaymentMethodSelectionProps) {
  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        <div className="flex items-center space-x-4 mb-8">
          <Button
            variant="ghost"
            onClick={onBack}
            className="p-2 hover:bg-gray-100"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              Choose Payment Method
            </h1>
            <p className="text-gray-600 mt-2">
              Select how you'd like to pay for your transfer
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Cash Payment Option */}
          <Card
            className="cursor-pointer hover:shadow-lg transition-shadow border-2 hover:border-brand-blue"
            onClick={() => onSelect("cash")}
          >
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Banknote className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">
                Pay with Cash
              </h3>
              <p className="text-gray-600 mb-6">
                Visit one of our partner locations to pay with cash and complete
                your transfer
              </p>

              <div className="space-y-3 text-left">
                <div className="flex items-center space-x-3">
                  <Clock className="w-5 h-5 text-green-600" />
                  <span className="text-sm text-gray-700">
                    No processing time - instant confirmation
                  </span>
                </div>
                <div className="flex items-center space-x-3">
                  <Shield className="w-5 h-5 text-green-600" />
                  <span className="text-sm text-gray-700">
                    Secure and reliable
                  </span>
                </div>
                <div className="flex items-center space-x-3">
                  <Banknote className="w-5 h-5 text-green-600" />
                  <span className="text-sm text-gray-700">
                    No bank account required
                  </span>
                </div>
              </div>

              <Button className="w-full mt-6 bg-green-600 hover:bg-green-700">
                Pay with Cash
              </Button>
            </CardContent>
          </Card>

          {/* Card Payment Option */}
          <Card
            className="cursor-pointer hover:shadow-lg transition-shadow border-2 hover:border-brand-blue"
            onClick={() => onSelect("card")}
          >
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <CreditCard className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">
                Pay with Card
              </h3>
              <p className="text-gray-600 mb-6">
                Use your debit or credit card for instant and convenient payment
              </p>

              <div className="space-y-3 text-left">
                <div className="flex items-center space-x-3">
                  <Clock className="w-5 h-5 text-blue-600" />
                  <span className="text-sm text-gray-700">
                    Instant payment processing
                  </span>
                </div>
                <div className="flex items-center space-x-3">
                  <Shield className="w-5 h-5 text-blue-600" />
                  <span className="text-sm text-gray-700">
                    Bank-level security
                  </span>
                </div>
                <div className="flex items-center space-x-3">
                  <CreditCard className="w-5 h-5 text-blue-600" />
                  <span className="text-sm text-gray-700">
                    Supports Visa, Mastercard, and more
                  </span>
                </div>
              </div>

              <Button className="w-full mt-6 bg-brand-yellow hover:bg-brand-yellow-dark text-black">
                Pay with Card
              </Button>
            </CardContent>
          </Card>
        </div>

        <div className="mt-8 p-6 bg-white rounded-lg border border-gray-200">
          <h4 className="font-semibold text-gray-900 mb-4">
            Why Choose Our Service?
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center">
              <div className="w-12 h-12 bg-brand-yellow rounded-full flex items-center justify-center mx-auto mb-3">
                <Shield className="w-6 h-6 text-gray-800" />
              </div>
              <h5 className="font-semibold text-gray-900 mb-1">100% Secure</h5>
              <p className="text-sm text-gray-600">
                Your money and data are protected with bank-level security
              </p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-brand-yellow rounded-full flex items-center justify-center mx-auto mb-3">
                <Clock className="w-6 h-6 text-gray-800" />
              </div>
              <h5 className="font-semibold text-gray-900 mb-1">
                Fast Transfer
              </h5>
              <p className="text-sm text-gray-600">
                Money arrives in 1-3 business days, sometimes faster
              </p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-brand-yellow rounded-full flex items-center justify-center mx-auto mb-3">
                <Banknote className="w-6 h-6 text-gray-800" />
              </div>
              <h5 className="font-semibold text-gray-900 mb-1">Best Rates</h5>
              <p className="text-sm text-gray-600">
                Competitive exchange rates with transparent fees
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
