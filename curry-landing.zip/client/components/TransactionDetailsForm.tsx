import React, { useState, useEffect } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import { Card, CardContent } from "./ui/card";
import { useFieldListValues } from "../hooks/usePartnerOS";
import { TransferInfo } from "./TransferInfo";

export interface TransactionDetails {
  payoutCountry: string;
  payoutMethod: string;
  sendAmount: number;
  receiveAmount: number;
  totalAmount: number;
  exchangeRate: number;
  fees: number;
}

interface TransactionDetailsFormProps {
  initialData?: TransactionDetails | null;
  onSubmit: (data: TransactionDetails) => void;
}

// Exchange rates mapping - in real app this would come from WU pricing API
const exchangeRates: Record<string, { currency: string; rate: number }> = {
  "MX": { currency: "MXN", rate: 17.5 },
  "IN": { currency: "INR", rate: 83.2 },
  "CA": { currency: "CAD", rate: 1.35 },
  "US": { currency: "USD", rate: 1.0 },
};

export function TransactionDetailsForm({
  initialData,
  onSubmit,
}: TransactionDetailsFormProps) {
  // Load WU API data for receiver countries
  const { data: receiverCountries, loading: countriesLoading } = useFieldListValues('receiver.country');
  const [formData, setFormData] = useState<TransactionDetails>({
    payoutCountry: initialData?.payoutCountry || "",
    payoutMethod: initialData?.payoutMethod || "",
    sendAmount: initialData?.sendAmount || 0,
    receiveAmount: initialData?.receiveAmount || 0,
    totalAmount: initialData?.totalAmount || 0,
    exchangeRate: initialData?.exchangeRate || 0,
    fees: initialData?.fees || 4.99,
  });

    const [errors, setErrors] = useState<{ [K in keyof TransactionDetails]?: string }>({});

  const selectedCountry = receiverCountries.find(
    (country) => country.id === formData.payoutCountry,
  );

  const exchangeData = selectedCountry ? exchangeRates[selectedCountry.id] : null;

  useEffect(() => {
    if (exchangeData && formData.sendAmount > 0) {
      const fees = 4.99;
      const exchangeRate = exchangeData.rate;
      const receiveAmount = Number(formData.sendAmount) * exchangeRate;
      const totalAmount = Number(formData.sendAmount) + fees;

      setFormData((prev) => ({
        ...prev,
        receiveAmount,
        totalAmount,
        exchangeRate,
        fees,
      }));
    }
  }, [formData.sendAmount, formData.payoutCountry, exchangeData]);

    const validateForm = (): boolean => {
    const newErrors: { [K in keyof TransactionDetails]?: string } = {};

    if (!formData.payoutCountry) {
      newErrors.payoutCountry = "Payout country is required";
    }
    if (!formData.payoutMethod) {
      newErrors.payoutMethod = "Payout method is required";
    }
    if (!formData.sendAmount || Number(formData.sendAmount) <= 0) {
      newErrors.sendAmount = "Send amount must be greater than 0";
    }
    if (Number(formData.sendAmount) > 5000) {
      newErrors.sendAmount = "Send amount cannot exceed $5,000";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      onSubmit(formData);
    }
  };

  const updateSendAmount = (value: string) => {
    const amount = parseFloat(value) || 0;
    setFormData((prev) => ({ ...prev, sendAmount: amount }));
    if (errors.sendAmount) {
      setErrors((prev) => ({ ...prev, sendAmount: undefined }));
    }
  };

  const updatePayoutCountry = (value: string) => {
    setFormData((prev) => ({ ...prev, payoutCountry: value }));
    if (errors.payoutCountry) {
      setErrors((prev) => ({ ...prev, payoutCountry: undefined }));
    }
  };

  const updatePayoutMethod = (value: string) => {
    setFormData((prev) => ({ ...prev, payoutMethod: value }));
    if (errors.payoutMethod) {
      setErrors((prev) => ({ ...prev, payoutMethod: undefined }));
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <Label htmlFor="payoutCountry">Payout Country *</Label>
          <Select
            value={formData.payoutCountry}
            onValueChange={updatePayoutCountry}
            disabled={countriesLoading}
          >
            <SelectTrigger
              className={errors.payoutCountry ? "border-red-500" : ""}
            >
              <SelectValue placeholder={countriesLoading ? "Loading countries..." : "Select destination country"} />
            </SelectTrigger>
            <SelectContent>
              {receiverCountries.map((country) => (
                <SelectItem key={country.id} value={country.id}>
                  <div className="flex items-center space-x-2">
                    <span>{country.displayValue}</span>
                    {exchangeRates[country.id] && (
                      <span className="text-gray-500">({exchangeRates[country.id].currency})</span>
                    )}
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {errors.payoutCountry && (
            <p className="text-sm text-red-500 mt-1">{errors.payoutCountry}</p>
          )}
        </div>

        <div>
          <Label htmlFor="payoutMethod">Payout Method *</Label>
          <Select
            value={formData.payoutMethod}
            onValueChange={updatePayoutMethod}
          >
            <SelectTrigger
              className={errors.payoutMethod ? "border-red-500" : ""}
            >
              <SelectValue placeholder="Select payout method" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="MIM">
                <div className="flex items-center space-x-2">
                  <span>Money In Minutes</span>
                  <span className="text-gray-500">(Cash Pickup)</span>
                </div>
              </SelectItem>
              <SelectItem value="D2B">
                <div className="flex items-center space-x-2">
                  <span>Direct To Bank</span>
                  <span className="text-gray-500">(Bank Deposit)</span>
                </div>
              </SelectItem>
              <SelectItem value="CA">
                <div className="flex items-center space-x-2">
                  <span>Cash</span>
                  <span className="text-gray-500">(Agent Location)</span>
                </div>
              </SelectItem>
              <SelectItem value="D2C">
                <div className="flex items-center space-x-2">
                  <span>Direct to Card</span>
                  <span className="text-gray-500">(Mobile Wallet)</span>
                </div>
              </SelectItem>
            </SelectContent>
          </Select>
          {errors.payoutMethod && (
            <p className="text-sm text-red-500 mt-1">{errors.payoutMethod}</p>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div></div>

        <div>
          <Label htmlFor="sendAmount">Send Amount (USD) *</Label>
          <Input
            id="sendAmount"
            type="number"
            min="1"
            max="5000"
            step="0.01"
            value={formData.sendAmount || ""}
            onChange={(e) => updateSendAmount(e.target.value)}
            className={errors.sendAmount ? "border-red-500" : ""}
            placeholder="0.00"
          />
          {errors.sendAmount && (
            <p className="text-sm text-red-500 mt-1">{errors.sendAmount}</p>
          )}
          <p className="text-sm text-gray-500 mt-1">Maximum transfer: $5,000</p>
        </div>
      </div>

      {exchangeData && selectedCountry && formData.sendAmount > 0 && (
        <Card className="border-brand-yellow border-2 bg-yellow-50">
          <CardContent className="p-6">
            <h4 className="font-semibold text-gray-900 mb-4">
              Transaction Summary
            </h4>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-600">Send Amount</span>
                <span className="font-semibold">
                  ${formData.sendAmount.toFixed(2)} USD
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Exchange Rate</span>
                <span className="font-semibold">
                  1 USD = {formData.exchangeRate.toLocaleString()}{" "}
                  {exchangeData.currency}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Transfer Fee</span>
                <span className="font-semibold">
                  ${formData.fees.toFixed(2)}
                </span>
              </div>
              <hr className="border-gray-300" />
              <div className="flex justify-between text-lg">
                <span className="font-semibold text-gray-900">
                  Recipient Gets
                </span>
                <span className="font-bold text-green-600">
                  {formData.receiveAmount.toLocaleString()}{" "}
                  {exchangeData.currency}
                </span>
              </div>
              <div className="flex justify-between text-lg">
                <span className="font-semibold text-gray-900">Total Cost</span>
                <span className="font-bold">
                  ${formData.totalAmount.toFixed(2)} USD
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <TransferInfo
        selectedCountry={formData.payoutCountry}
        sendAmount={formData.sendAmount}
        exchangeRate={formData.exchangeRate}
        currency={exchangeData?.currency}
      />

      <div className="flex justify-end pt-4">
        <Button
          type="submit"
          className="bg-brand-yellow hover:bg-brand-yellow-dark text-black px-8"
          disabled={!exchangeData || !formData.payoutMethod || formData.sendAmount <= 0 || countriesLoading}
        >
          Save Transaction Details
        </Button>
      </div>
    </form>
  );
}
