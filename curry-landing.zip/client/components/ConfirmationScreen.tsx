import React from "react";
import { ArrowLeft, CheckCircle, Edit, Clock, Shield } from "lucide-react";
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import type { FormData } from "../pages/Index";

interface ConfirmationScreenProps {
  formData: FormData;
  onEdit: (section: "sender" | "receiver" | "transaction") => void;
  onBack: () => void;
}

export function ConfirmationScreen({
  formData,
  onEdit,
  onBack,
}: ConfirmationScreenProps) {
  // Exchange rates mapping - matches TransactionDetailsForm
  const exchangeRates: Record<string, { currency: string; rate: number }> = {
    "MX": { currency: "MXN", rate: 17.5 },
    "IN": { currency: "INR", rate: 83.2 },
    "CA": { currency: "CAD", rate: 1.35 },
    "US": { currency: "USD", rate: 1.0 },
  };

  const exchangeData = formData.transaction?.payoutCountry
    ? exchangeRates[formData.transaction.payoutCountry]
    : null;

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        <div className="flex items-center space-x-4 mb-8">
          <Button
            variant="ghost"
            onClick={onBack}
            className="p-2 hover:bg-gray-100"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              Confirm Your Transfer
            </h1>
            <p className="text-gray-600 mt-2">
              Review your details before completing the transfer
            </p>
          </div>
        </div>

        <div className="space-y-6">
          {/* Transfer Summary */}
          <Card className="border-2 border-brand-yellow bg-yellow-50">
            <CardContent className="p-6">
              <div className="flex items-center space-x-3 mb-4">
                <CheckCircle className="w-6 h-6 text-green-600" />
                <h3 className="text-xl font-semibold text-gray-900">
                  Transfer Summary
                </h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <p className="text-sm text-gray-600">You're sending</p>
                  <p className="text-2xl font-bold text-gray-900">
                    ${formData.transaction?.sendAmount.toFixed(2)} USD
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">
                    {formData.receiver?.firstName} will receive
                  </p>
                  <p className="text-2xl font-bold text-green-600">
                    {formData.transaction?.receiveAmount.toLocaleString()}{" "}
                    {exchangeData?.currency || "USD"}
                  </p>
                </div>
              </div>
              <div className="mt-4 pt-4 border-t border-yellow-200">
                <div className="flex justify-between text-sm">
                  <span>Exchange Rate:</span>
                  <span>
                    1 USD ={" "}
                    {formData.transaction?.exchangeRate.toLocaleString()}{" "}
                    {exchangeData?.currency || "USD"}
                  </span>
                </div>
                <div className="flex justify-between text-sm mt-1">
                  <span>Transfer Fee:</span>
                  <span>${formData.transaction?.fees.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-lg font-semibold mt-2 pt-2 border-t border-yellow-200">
                  <span>Total Cost:</span>
                  <span>
                    ${formData.transaction?.totalAmount.toFixed(2)} USD
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Sender Details */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900">
                  Sender Details
                </h3>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onEdit("sender")}
                  className="flex items-center space-x-2"
                >
                  <Edit className="w-4 h-4" />
                  <span>Edit</span>
                </Button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-gray-600">Full Name</p>
                  <p className="font-semibold">
                    {formData.sender?.firstName} {formData.sender?.paternalName}{" "}
                    {formData.sender?.maternalName}
                  </p>
                </div>
                <div>
                  <p className="text-gray-600">Phone</p>
                  <p className="font-semibold">
                    {formData.sender?.phoneCountryCode}{" "}
                    {formData.sender?.phoneNumber}
                  </p>
                </div>
                <div>
                  <p className="text-gray-600">Email</p>
                  <p className="font-semibold">
                    {formData.sender?.email || "Not provided"}
                  </p>
                </div>
                <div>
                  <p className="text-gray-600">Address</p>
                  <p className="font-semibold">
                    {formData.sender?.addressLine1},{" "}
                    {formData.sender?.addressCity},{" "}
                    {formData.sender?.addressPostalCode}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Receiver Details */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900">
                  Receiver Details
                </h3>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onEdit("receiver")}
                  className="flex items-center space-x-2"
                >
                  <Edit className="w-4 h-4" />
                  <span>Edit</span>
                </Button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-gray-600">Full Name</p>
                  <p className="font-semibold">
                    {formData.receiver?.firstName}{" "}
                    {formData.receiver?.paternalName}{" "}
                    {formData.receiver?.maternalName}
                  </p>
                </div>
                <div>
                  <p className="text-gray-600">Relationship</p>
                  <p className="font-semibold">
                    {formData.receiver?.relationshipToReceiver}
                  </p>
                </div>
                <div>
                  <p className="text-gray-600">Phone</p>
                  <p className="font-semibold">
                    {formData.receiver?.phoneNumber
                      ? `${formData.receiver?.phoneCountryCode} ${formData.receiver?.phoneNumber}`
                      : "Not provided"}
                  </p>
                </div>
                <div>
                  <p className="text-gray-600">Destination</p>
                  <p className="font-semibold">
                    {formData.transaction?.payoutCountry ?
                      `Country: ${formData.transaction.payoutCountry}` :
                      "Not specified"}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Payment Method */}
          <Card>
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                Payment Method
              </h3>
              <div className="flex items-center space-x-3">
                <Badge
                  variant="secondary"
                  className="bg-green-50 text-green-700 border-green-200"
                >
                  {formData.paymentMethod === "cash"
                    ? "Cash Payment"
                    : "Card Payment"}
                </Badge>
                <p className="text-sm text-gray-600">
                  {formData.paymentMethod === "cash"
                    ? "You'll pay at a partner location"
                    : "Paid with debit/credit card"}
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Important Information */}
          <Card className="border-blue-200 bg-blue-50">
            <CardContent className="p-6">
              <div className="flex items-center space-x-3 mb-4">
                <Shield className="w-6 h-6 text-blue-600" />
                <h3 className="text-lg font-semibold text-blue-900">
                  Important Information
                </h3>
              </div>
              <div className="space-y-2 text-sm text-blue-800">
                <div className="flex items-center space-x-2">
                  <Clock className="w-4 h-4" />
                  <span>
                    Transfer typically completes within 1-3 business days
                  </span>
                </div>
                <p>
                  • You will receive a confirmation email with tracking
                  information
                </p>
                <p>
                  • The recipient will be notified when funds are available for
                  pickup
                </p>
                <p>
                  • Keep your reference number safe - it's needed for tracking
                  and customer service
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
            <Button variant="outline" className="flex-1" onClick={onBack}>
              Back to Payment
            </Button>
            <Button
              className="flex-1 bg-brand-yellow hover:bg-brand-yellow-dark text-black"
              onClick={() => alert("Transfer submitted! (Demo)")}
            >
              Confirm Transfer
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
