import React from "react";
import { ChevronDown, ChevronUp, Check } from "lucide-react";
import { Badge } from "./ui/badge";

interface SectionHeaderProps {
  title: string;
  subtitle?: string;
  stepNumber: number;
  isExpanded: boolean;
  isCompleted: boolean;
  onToggle: () => void;
}

export function SectionHeader({
  title,
  subtitle,
  stepNumber,
  isExpanded,
  isCompleted,
  onToggle,
}: SectionHeaderProps) {
  return (
    <button
      onClick={onToggle}
      className="w-full flex items-center justify-between p-4 text-left bg-white border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors"
    >
      <div className="flex items-center space-x-4">
        <div
          className={`
          flex items-center justify-center w-8 h-8 rounded-full font-semibold text-sm
          ${
            isCompleted
              ? "bg-green-500 text-white"
              : isExpanded
                ? "bg-brand-yellow text-black"
                : "bg-gray-200 text-gray-600"
          }
        `}
        >
          {isCompleted ? <Check className="w-4 h-4" /> : stepNumber}
        </div>
        <div>
          <h3 className="font-semibold text-gray-900 text-lg">{title}</h3>
          {subtitle && <p className="text-sm text-gray-500 mt-1">{subtitle}</p>}
        </div>
      </div>
      <div className="flex items-center space-x-2">
        {isCompleted && (
          <Badge
            variant="secondary"
            className="bg-green-50 text-green-700 border-green-200"
          >
            Complete
          </Badge>
        )}
        {isExpanded ? (
          <ChevronUp className="w-5 h-5 text-gray-400" />
        ) : (
          <ChevronDown className="w-5 h-5 text-gray-400" />
        )}
      </div>
    </button>
  );
}
