import React, { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import { useWUCountries, useFieldValidation } from "../hooks/usePartnerOS";

export interface SenderDetails {
  firstName: string;
  paternalName: string;
  maternalName: string;
  phoneCountryCode: string;
  phoneNumber: string;
  email?: string;
  addressLine1: string;
  addressCity: string;
  addressPostalCode: string;
  addressCountry: string;
}

interface SenderDetailsFormProps {
  initialData?: SenderDetails | null;
  onSubmit: (data: SenderDetails) => void;
}

// Countries will be loaded from WU API

export function SenderDetailsForm({
  initialData,
  onSubmit,
}: SenderDetailsFormProps) {
  // Load WU API data
  const { data: wuCountries, loading: countriesLoading } = useWUCountries();
  const { validation: firstNameValidation } = useFieldValidation('sender.name.firstName');
  const { validation: lastNameValidation } = useFieldValidation('sender.name.lastName');
  const [formData, setFormData] = useState<SenderDetails>({
    firstName: initialData?.firstName || "",
    paternalName: initialData?.paternalName || "",
    maternalName: initialData?.maternalName || "",
    phoneCountryCode: initialData?.phoneCountryCode || "+1",
    phoneNumber: initialData?.phoneNumber || "",
    email: initialData?.email || "",
    addressLine1: initialData?.addressLine1 || "",
    addressCity: initialData?.addressCity || "",
    addressPostalCode: initialData?.addressPostalCode || "",
    addressCountry: initialData?.addressCountry || "US",
  });

    const [errors, setErrors] = useState<{ [K in keyof SenderDetails]?: string }>({});

    const validateForm = (): boolean => {
    const newErrors: { [K in keyof SenderDetails]?: string } = {};

    if (!formData.firstName.trim()) {
      newErrors.firstName = "First name is required";
    }
    if (!formData.paternalName.trim()) {
      newErrors.paternalName = "Paternal name is required";
    }
    if (!formData.maternalName.trim()) {
      newErrors.maternalName = "Maternal name is required";
    }
    if (!formData.phoneNumber.trim()) {
      newErrors.phoneNumber = "Phone number is required";
    }
    if (!formData.addressLine1.trim()) {
      newErrors.addressLine1 = "Address is required";
    }
    if (!formData.addressCity.trim()) {
      newErrors.addressCity = "City is required";
    }
    if (!formData.addressPostalCode.trim()) {
      newErrors.addressPostalCode = "Postal code is required";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      onSubmit(formData);
    }
  };

  const updateField = (field: keyof SenderDetails, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: undefined }));
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <div>
          <Label htmlFor="firstName">First Name *</Label>
          <Input
            id="firstName"
            value={formData.firstName}
            onChange={(e) => updateField("firstName", e.target.value)}
            className={errors.firstName ? "border-red-500" : ""}
            placeholder="Enter first name"
          />
          {errors.firstName && (
            <p className="text-sm text-red-500 mt-1">{errors.firstName}</p>
          )}
        </div>

        <div>
          <Label htmlFor="paternalName">Paternal Name *</Label>
          <Input
            id="paternalName"
            value={formData.paternalName}
            onChange={(e) => updateField("paternalName", e.target.value)}
            className={errors.paternalName ? "border-red-500" : ""}
            placeholder="Enter paternal name"
          />
          {errors.paternalName && (
            <p className="text-sm text-red-500 mt-1">{errors.paternalName}</p>
          )}
        </div>

        <div>
          <Label htmlFor="maternalName">Maternal Name *</Label>
          <Input
            id="maternalName"
            value={formData.maternalName}
            onChange={(e) => updateField("maternalName", e.target.value)}
            className={errors.maternalName ? "border-red-500" : ""}
            placeholder="Enter maternal name"
          />
          {errors.maternalName && (
            <p className="text-sm text-red-500 mt-1">{errors.maternalName}</p>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="flex space-x-2">
          <div className="w-32">
            <Label htmlFor="phoneCountryCode">Country Code</Label>
            <Select
              value={formData.phoneCountryCode}
              onValueChange={(value) => updateField("phoneCountryCode", value)}
              disabled={countriesLoading}
            >
              <SelectTrigger>
                <SelectValue placeholder={countriesLoading ? "Loading..." : "Select country code"} />
              </SelectTrigger>
              <SelectContent>
                {wuCountries.map((country) => (
                  <SelectItem
                    key={`phone-${country.id}`}
                    value={country.id}
                  >
                    {country.displayValue}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="flex-1">
            <Label htmlFor="phoneNumber">Phone Number *</Label>
            <Input
              id="phoneNumber"
              value={formData.phoneNumber}
              onChange={(e) => updateField("phoneNumber", e.target.value)}
              className={errors.phoneNumber ? "border-red-500" : ""}
              placeholder="Enter phone number"
            />
            {errors.phoneNumber && (
              <p className="text-sm text-red-500 mt-1">{errors.phoneNumber}</p>
            )}
          </div>
        </div>

        <div>
          <Label htmlFor="email">Email (Optional)</Label>
          <Input
            id="email"
            type="email"
            value={formData.email}
            onChange={(e) => updateField("email", e.target.value)}
            placeholder="Enter email address"
          />
        </div>
      </div>

      <div className="space-y-4">
        <h4 className="font-semibold text-gray-900">Address Information</h4>

        <div>
          <Label htmlFor="addressLine1">Address Line 1 *</Label>
          <Input
            id="addressLine1"
            value={formData.addressLine1}
            onChange={(e) => updateField("addressLine1", e.target.value)}
            className={errors.addressLine1 ? "border-red-500" : ""}
            placeholder="Enter street address"
          />
          {errors.addressLine1 && (
            <p className="text-sm text-red-500 mt-1">{errors.addressLine1}</p>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <Label htmlFor="addressCity">City *</Label>
            <Input
              id="addressCity"
              value={formData.addressCity}
              onChange={(e) => updateField("addressCity", e.target.value)}
              className={errors.addressCity ? "border-red-500" : ""}
              placeholder="Enter city"
            />
            {errors.addressCity && (
              <p className="text-sm text-red-500 mt-1">{errors.addressCity}</p>
            )}
          </div>

          <div>
            <Label htmlFor="addressPostalCode">Postal Code *</Label>
            <Input
              id="addressPostalCode"
              value={formData.addressPostalCode}
              onChange={(e) => updateField("addressPostalCode", e.target.value)}
              className={errors.addressPostalCode ? "border-red-500" : ""}
              placeholder="Enter postal code"
            />
            {errors.addressPostalCode && (
              <p className="text-sm text-red-500 mt-1">
                {errors.addressPostalCode}
              </p>
            )}
          </div>

          <div>
            <Label htmlFor="addressCountry">Country</Label>
            <Select
              value={formData.addressCountry}
              onValueChange={(value) => updateField("addressCountry", value)}
              disabled={countriesLoading}
            >
              <SelectTrigger>
                <SelectValue placeholder={countriesLoading ? "Loading..." : "Select country"} />
              </SelectTrigger>
              <SelectContent>
                {wuCountries.map((country) => (
                  <SelectItem
                    key={`address-${country.id}`}
                    value={country.id}
                  >
                    {country.displayValue}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      <div className="flex justify-end pt-4">
        <Button
          type="submit"
          className="bg-brand-yellow hover:bg-brand-yellow-dark text-black px-8"
        >
          Save Sender Details
        </Button>
      </div>
    </form>
  );
}
