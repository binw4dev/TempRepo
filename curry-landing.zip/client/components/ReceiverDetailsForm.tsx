import React, { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import { useWUCountries, useFieldListValues } from "../hooks/usePartnerOS";

export interface ReceiverDetails {
  firstName: string;
  paternalName: string;
  maternalName: string;
  phoneCountryCode?: string;
  phoneNumber?: string;
  relationshipToReceiver: string;
}

interface ReceiverDetailsFormProps {
  initialData?: ReceiverDetails | null;
  onSubmit: (data: ReceiverDetails) => void;
}

// Static relationships list (can be moved to WU API if needed)
const relationships = [
  "Parent",
  "Child",
  "Sibling",
  "Spouse",
  "Grandparent",
  "Grandchild",
  "Friend",
  "Business Partner",
  "Other Family Member",
  "Other",
];

// Countries will be loaded from WU API

export function ReceiverDetailsForm({
  initialData,
  onSubmit,
}: ReceiverDetailsFormProps) {
  // Load WU API data
  const { data: wuCountries, loading: countriesLoading } = useWUCountries();
  const [formData, setFormData] = useState<ReceiverDetails>({
    firstName: initialData?.firstName || "",
    paternalName: initialData?.paternalName || "",
    maternalName: initialData?.maternalName || "",
    phoneCountryCode: initialData?.phoneCountryCode || "+1",
    phoneNumber: initialData?.phoneNumber || "",
    relationshipToReceiver: initialData?.relationshipToReceiver || "",
  });

    const [errors, setErrors] = useState<{ [K in keyof ReceiverDetails]?: string }>({});

    const validateForm = (): boolean => {
    const newErrors: { [K in keyof ReceiverDetails]?: string } = {};

    if (!formData.firstName.trim()) {
      newErrors.firstName = "First name is required";
    }
    if (!formData.paternalName.trim()) {
      newErrors.paternalName = "Paternal name is required";
    }
    if (!formData.maternalName.trim()) {
      newErrors.maternalName = "Maternal name is required";
    }
    if (!formData.relationshipToReceiver.trim()) {
      newErrors.relationshipToReceiver = "Relationship is required";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      onSubmit(formData);
    }
  };

  const updateField = (field: keyof ReceiverDetails, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: undefined }));
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <Label htmlFor="receiverFirstName">First Name *</Label>
          <Input
            id="receiverFirstName"
            value={formData.firstName}
            onChange={(e) => updateField("firstName", e.target.value)}
            className={errors.firstName ? "border-red-500" : ""}
            placeholder="Enter first name"
          />
          {errors.firstName && (
            <p className="text-sm text-red-500 mt-1">{errors.firstName}</p>
          )}
        </div>

        <div>
          <Label htmlFor="receiverPaternalName">Paternal Name *</Label>
          <Input
            id="receiverPaternalName"
            value={formData.paternalName}
            onChange={(e) => updateField("paternalName", e.target.value)}
            className={errors.paternalName ? "border-red-500" : ""}
            placeholder="Enter paternal name"
          />
          {errors.paternalName && (
            <p className="text-sm text-red-500 mt-1">{errors.paternalName}</p>
          )}
        </div>

        <div>
          <Label htmlFor="receiverMaternalName">Maternal Name *</Label>
          <Input
            id="receiverMaternalName"
            value={formData.maternalName}
            onChange={(e) => updateField("maternalName", e.target.value)}
            className={errors.maternalName ? "border-red-500" : ""}
            placeholder="Enter maternal name"
          />
          {errors.maternalName && (
            <p className="text-sm text-red-500 mt-1">{errors.maternalName}</p>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="relationshipToReceiver">
            Relationship to Receiver *
          </Label>
          <Select
            value={formData.relationshipToReceiver}
            onValueChange={(value) =>
              updateField("relationshipToReceiver", value)
            }
          >
            <SelectTrigger
              className={errors.relationshipToReceiver ? "border-red-500" : ""}
            >
              <SelectValue placeholder="Select relationship" />
            </SelectTrigger>
            <SelectContent>
              {relationships.map((relationship) => (
                <SelectItem key={relationship} value={relationship}>
                  {relationship}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {errors.relationshipToReceiver && (
            <p className="text-sm text-red-500 mt-1">
              {errors.relationshipToReceiver}
            </p>
          )}
        </div>
      </div>

      <div className="space-y-4">
        <h4 className="font-semibold text-gray-900">
          Contact Information (Optional)
        </h4>
        <p className="text-sm text-gray-600">
          Providing contact information helps ensure smooth delivery
        </p>

        <div className="flex space-x-2">
          <div className="w-32">
            <Label htmlFor="receiverPhoneCountryCode">Country Code</Label>
            <Select
              value={formData.phoneCountryCode || (wuCountries[0]?.id || "+1")}
              onValueChange={(value) => updateField("phoneCountryCode", value)}
              disabled={countriesLoading}
            >
              <SelectTrigger>
                <SelectValue placeholder={countriesLoading ? "Loading..." : "Select country code"} />
              </SelectTrigger>
              <SelectContent>
                {wuCountries.map((country) => (
                  <SelectItem
                    key={`receiver-phone-${country.id}`}
                    value={country.id}
                  >
                    {country.displayValue}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="flex-1">
            <Label htmlFor="receiverPhoneNumber">Phone Number</Label>
            <Input
              id="receiverPhoneNumber"
              value={formData.phoneNumber || ""}
              onChange={(e) => updateField("phoneNumber", e.target.value)}
              placeholder="Enter phone number"
            />
          </div>
        </div>
      </div>

      <div className="flex justify-end pt-4">
        <Button
          type="submit"
          className="bg-brand-yellow hover:bg-brand-yellow-dark text-black px-8"
        >
          Save Receiver Details
        </Button>
      </div>
    </form>
  );
}
