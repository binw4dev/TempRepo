import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { SenderDetailsForm } from "../components/SenderDetailsForm";
import { ReceiverDetailsForm } from "../components/ReceiverDetailsForm";
import { TransactionDetailsForm } from "../components/TransactionDetailsForm";
import { ComplianceDetailsForm } from "../components/ComplianceDetailsForm";
import { PaymentMethodSelection } from "../components/PaymentMethodSelection";
import { ConfirmationScreen } from "../components/ConfirmationScreen";
import { SectionHeader } from "../components/SectionHeader";
import { Card, CardContent } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Button } from "../components/ui/button";
import type { SenderDetails } from "../components/SenderDetailsForm";
import type { ReceiverDetails } from "../components/ReceiverDetailsForm";
import type { TransactionDetails } from "../components/TransactionDetailsForm";
import type { ComplianceDetails } from "../components/ComplianceDetailsForm";

export interface FormData {
  sender: SenderDetails | null;
  receiver: ReceiverDetails | null;
  transaction: TransactionDetails | null;
  compliance: ComplianceDetails | null;
  paymentMethod: "cash" | "card" | null;
}

type Step = "forms" | "payment" | "confirmation";
type FormSection = "sender" | "receiver" | "transaction" | "compliance";

export default function Index() {
  const [currentStep, setCurrentStep] = useState<Step>("forms");
  const [expandedSections, setExpandedSections] = useState<Set<FormSection>>(
    new Set(["sender"]),
  );
  const [formData, setFormData] = useState<FormData>({
    sender: null,
    receiver: null,
    transaction: null,
    compliance: null,
    paymentMethod: null,
  });

  const updateFormData = (section: keyof FormData, data: any) => {
    setFormData((prev) => ({
      ...prev,
      [section]: data,
    }));
  };

  const handleSectionComplete = (section: FormSection, data: any) => {
    updateFormData(section, data);

    // Auto-expand next section
    const sections: FormSection[] = ["sender", "compliance", "receiver", "transaction"];
    const currentIndex = sections.indexOf(section);
    if (currentIndex < sections.length - 1) {
      const nextSection = sections[currentIndex + 1];
      setExpandedSections((prev) => {
        const newSet = new Set(prev);
        newSet.delete(section);
        newSet.add(nextSection);
        return newSet;
      });
    } else {
      setExpandedSections((prev) => {
        const newSet = new Set(prev);
        newSet.delete(section);
        return newSet;
      });
    }
  };

  const handlePaymentMethodSelect = (method: "cash" | "card") => {
    updateFormData("paymentMethod", method);
    setCurrentStep("confirmation");
  };

  const handleEditSection = (section: FormSection) => {
    setCurrentStep("forms");
    toggleSection(section);
  };

  const toggleSection = (section: FormSection) => {
    setExpandedSections((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(section)) {
        newSet.delete(section);
      } else {
        newSet.add(section);
      }
      return newSet;
    });
  };

  const canProceedToPayment =
    formData.sender && formData.receiver && formData.transaction && formData.compliance;

  if (currentStep === "payment") {
    return (
      <PaymentMethodSelection
        onSelect={handlePaymentMethodSelect}
        onBack={() => setCurrentStep("forms")}
      />
    );
  }

  if (currentStep === "confirmation") {
    return (
      <ConfirmationScreen
        formData={formData}
        onEdit={handleEditSection}
        onBack={() => setCurrentStep("payment")}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Send Money Worldwide
          </h1>
          <p className="text-xl text-gray-600">
            Fast, secure, and reliable money transfers
          </p>
        </div>

        {/* Progress Indicator */}
        <div className="flex items-center justify-center space-x-4 mb-12">
          <div className="flex items-center space-x-2">
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center font-semibold text-sm ${
                formData.sender
                  ? "bg-green-500 text-white"
                  : "bg-brand-yellow text-black"
              }`}
            >
              1
            </div>
            <span className="text-sm font-medium text-gray-700">
              Sender Details
            </span>
          </div>
          <div className="w-8 h-px bg-gray-300"></div>
          <div className="flex items-center space-x-2">
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center font-semibold text-sm ${
                formData.compliance
                  ? "bg-green-500 text-white"
                  : formData.sender
                    ? "bg-brand-yellow text-black"
                    : "bg-gray-300 text-gray-600"
              }`}
            >
              2
            </div>
            <span className="text-sm font-medium text-gray-700">
              Compliance Details
            </span>
          </div>
          <div className="w-8 h-px bg-gray-300"></div>
          <div className="flex items-center space-x-2">
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center font-semibold text-sm ${
                formData.receiver
                  ? "bg-green-500 text-white"
                  : formData.compliance
                    ? "bg-brand-yellow text-black"
                    : "bg-gray-300 text-gray-600"
              }`}
            >
              3
            </div>
            <span className="text-sm font-medium text-gray-700">
              Receiver Details
            </span>
          </div>
          <div className="w-8 h-px bg-gray-300"></div>
          <div className="flex items-center space-x-2">
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center font-semibold text-sm ${
                formData.transaction
                  ? "bg-green-500 text-white"
                  : formData.receiver
                    ? "bg-brand-yellow text-black"
                    : "bg-gray-300 text-gray-600"
              }`}
            >
              4
            </div>
            <span className="text-sm font-medium text-gray-700">
              Transaction Details
            </span>
          </div>
        </div>

        <div className="space-y-6">
          {/* Sender Details Section */}
          <div>
            <SectionHeader
              title="Sender Details"
              subtitle="Your personal information"
              stepNumber={1}
              isExpanded={expandedSections.has("sender")}
              isCompleted={!!formData.sender}
              onToggle={() => toggleSection("sender")}
            />
            <AnimatePresence>
              {expandedSections.has("sender") && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="overflow-hidden"
                >
                  <Card className="mt-4">
                    <CardContent className="p-6">
                      <SenderDetailsForm
                        initialData={formData.sender}
                        onSubmit={(data) =>
                          handleSectionComplete("sender", data)
                        }
                      />
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Compliance Details Section */}
          <div>
            <SectionHeader
              title="Compliance Details"
              subtitle="Identity verification and compliance information"
              stepNumber={2}
              isExpanded={expandedSections.has("compliance")}
              isCompleted={!!formData.compliance}
              onToggle={() => toggleSection("compliance")}
            />
            <AnimatePresence>
              {expandedSections.has("compliance") && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="overflow-hidden"
                >
                  <Card className="mt-4">
                    <CardContent className="p-6">
                      <ComplianceDetailsForm
                        initialData={formData.compliance}
                        onSubmit={(data) =>
                          handleSectionComplete("compliance", data)
                        }
                      />
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Receiver Details Section */}
          <div>
            <SectionHeader
              title="Receiver Details"
              subtitle="Who will receive the money"
              stepNumber={3}
              isExpanded={expandedSections.has("receiver")}
              isCompleted={!!formData.receiver}
              onToggle={() => toggleSection("receiver")}
            />
            <AnimatePresence>
              {expandedSections.has("receiver") && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="overflow-hidden"
                >
                  <Card className="mt-4">
                    <CardContent className="p-6">
                      <ReceiverDetailsForm
                        initialData={formData.receiver}
                        onSubmit={(data) =>
                          handleSectionComplete("receiver", data)
                        }
                      />
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Transaction Details Section */}
          <div>
            <SectionHeader
              title="Transaction Details"
              subtitle="Amount and destination"
              stepNumber={4}
              isExpanded={expandedSections.has("transaction")}
              isCompleted={!!formData.transaction}
              onToggle={() => toggleSection("transaction")}
            />
            <AnimatePresence>
              {expandedSections.has("transaction") && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="overflow-hidden"
                >
                  <Card className="mt-4">
                    <CardContent className="p-6">
                      <TransactionDetailsForm
                        initialData={formData.transaction}
                        onSubmit={(data) =>
                          handleSectionComplete("transaction", data)
                        }
                      />
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Continue Button */}
          <div className="pt-8">
            {canProceedToPayment ? (
              <Button
                onClick={() => setCurrentStep("payment")}
                className="w-full sm:w-auto px-8 py-3 bg-brand-yellow hover:bg-brand-yellow-dark text-black text-lg font-semibold"
                size="lg"
              >
                Continue to Payment
              </Button>
            ) : (
              <div className="text-center">
                <Button
                  disabled
                  className="w-full sm:w-auto px-8 py-3 bg-brand-yellow hover:bg-brand-yellow-dark text-black text-lg font-semibold opacity-50"
                  size="lg"
                >
                  Continue to Payment
                </Button>
                <p className="text-sm text-gray-500 mt-2">
                  Please complete all sections above to continue
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
