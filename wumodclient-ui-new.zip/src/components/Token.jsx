import React, {Component} from 'react';
import {withRouter} from "../utils/withRouter";
import TokenService from "../services/TokenService";
import {Button, Card, CardBody, Col, Container, FloatingLabel, Form, Row} from "react-bootstrap";

class Token extends Component {

    constructor(props) {
        super(props);

        this.state = {
            tokenUrl: '',
            grant_type: '',
            scope: '',
            userName: '',
            password: '',
            access_token: '',
            token_type: '',
            expire_in: ''
        }

        this.changeTokenUrl = this.changeTokenUrl.bind(this);
        this.changeGrantType = this.changeGrantType.bind(this);
        this.changeScope = this.changeScope.bind(this);
        this.changeUserName = this.changeUserName.bind(this);
        this.changePassword = this.changePassword.bind(this);
    }

    componentDidMount() {
        this.getDefaultRequest();
    }

    changeTokenUrl = (event) => {
        this.setState({tokenUrl: event.target.value});
    }

    changeGrantType = (event) => {
        this.setState({grant_type: event.target.value});
    }

    changeScope = (event) => {
        this.setState({scope: event.target.value});
    }

    changeUserName = (event) => {
        this.setState({userName: event.target.value});
    }

    changePassword = (event) => {
        this.setState({password: event.target.value});
    }

    requestTokenFromWU = (event) => {
        event.preventDefault();
        let tokenRequest = {
            tokenUrl: this.tokenUrl,
            grant_type: this.state.grant_type,
            scope: this.state.scope,
            userName: this.state.userName,
            password: this.state.password
        };
        TokenService.requestTokenFromWU(tokenRequest).then(resp => {
            const token = resp.data.obj;
            this.setState({access_token: token.access_token});
            this.setState({token_type: token.token_type});
            this.setState({expire_in: token.expire_in});
        });
    }

    resetForm = (event) => {
        event.preventDefault();
        this.getDefaultRequest();
    }

    getDefaultRequest = () => {
        TokenService.getDefaultTokenRequest().then(resp => {
            const request = resp.data.obj;
            this.setState({tokenUrl: request.tokenUrl});
            this.setState({grant_type: request.grant_type});
            this.setState({scope: request.scope});
            this.setState({userName: request.userName});
            this.setState({password: request.password});
        });
    }

    render() {
        return (
            <Container>
                <Row>
                    <Col sm={5}>
                        <Card style={{ width: '100%', marginTop: '10px' }}>
                            <Card.Body>
                                <Card.Title>Request New Token</Card.Title>
                                <Form>
                                    <Form.Group className="mb-2" controlId="tokenUrl">
                                        <FloatingLabel
                                            controlId="floatingInput"
                                            label="Token Generator URL"
                                            className="mb-3"
                                        >
                                        <Form.Control type="input" placeholder="Token Generator URL" value={this.state.tokenUrl}
                                                      onChange={this.changeTokenUrl} />
                                        </FloatingLabel>
                                    </Form.Group>
                                    <Form.Group className="mb-2" controlId="grant_type">
                                        <FloatingLabel
                                            controlId="floatingInput"
                                            label="Grant Type"
                                            className="mb-3"
                                        >
                                        <Form.Control type="input" placeholder="Grant Type" value={this.state.grant_type}
                                                      onChange={this.changeGrantType} />
                                        </FloatingLabel>
                                    </Form.Group>
                                    <Form.Group className="mb-2" controlId="scope">
                                        <FloatingLabel
                                            controlId="floatingInput"
                                            label="Scope"
                                            className="mb-3"
                                        >
                                        <Form.Control type="input" placeholder="Scope" value={this.state.scope}
                                                      onChange={this.changeScope} />
                                        </FloatingLabel>
                                    </Form.Group>
                                    <Form.Group className="mb-2" controlId="userName">
                                        <FloatingLabel
                                            controlId="floatingInput"
                                            label="Username"
                                            className="mb-3"
                                        >
                                        <Form.Control type="input" placeholder="Username" value={this.state.userName}
                                                      onChange={this.changeUserName} />
                                        </FloatingLabel>
                                    </Form.Group>
                                    <Form.Group className="mb-2" controlId="password">
                                        <FloatingLabel
                                            controlId="floatingInput"
                                            label="Password"
                                            className="mb-3"
                                        >
                                        <Form.Control type="input" placeholder="Password" value={this.state.password}
                                                      onChange={this.changePassword} />
                                        </FloatingLabel>
                                    </Form.Group>
                                    <Button className="btn btn-success" onClick={this.requestTokenFromWU}>Generate</Button>
                                    <Button className="btn btn-danger" onClick={this.resetForm} style={{marginLeft: "10px"}}>Reset</Button>
                                </Form>
                            </Card.Body>
                        </Card>
                    </Col>
                    <Col sm={5}>
                        <Card style={{ width: '100%', marginTop: '10px' }}>
                            <Card.Body>
                                <Card.Title>Access Token</Card.Title>
                                <Form>
                                    <Form.Group className="mb-2" controlId="access_token">
                                        <FloatingLabel
                                            controlId="floatingInput"
                                            label="Access Token"
                                            className="mb-3"
                                        >
                                        <Form.Control as="textarea" rows={5} value={this.state.access_token}
                                                      readOnly={true} />
                                        </FloatingLabel>
                                    </Form.Group>
                                    <Form.Group className="mb-2" controlId="token_type">
                                        <FloatingLabel
                                            controlId="floatingInput"
                                            label="Token Type"
                                            className="mb-3"
                                        >
                                        <Form.Control type="input" value={this.state.token_type}
                                                      readOnly={true} />
                                        </FloatingLabel>
                                    </Form.Group>
                                    <Form.Group className="mb-2" controlId="expire_in">
                                        <FloatingLabel
                                            controlId="floatingInput"
                                            label="Expire In"
                                            className="mb-3"
                                        >
                                        <Form.Control type="input" value={this.state.expire_in}
                                                      readOnly={true} />
                                        </FloatingLabel>
                                    </Form.Group>
                                </Form>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
            </Container>

        );
    }
}

export default withRouter(Token);