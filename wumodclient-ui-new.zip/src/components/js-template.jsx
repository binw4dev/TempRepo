import React, {Component} from 'react';

class MyTemplate extends Component {

    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div>

            </div>
        );
    }
}

export default MyTemplate;