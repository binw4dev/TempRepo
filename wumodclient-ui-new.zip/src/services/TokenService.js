import axios from "axios";

const TOKEN_SERVICE_BASE_URL = "http://localhost:8080/token";

class TokenService {
    requestTokenFromWU(tokenRequest) {
        return axios.post(TOKEN_SERVICE_BASE_URL, tokenRequest);
    }

    getDefaultTokenRequest() {
        return axios.get(TOKEN_SERVICE_BASE_URL);
    }
}

export default new TokenService();