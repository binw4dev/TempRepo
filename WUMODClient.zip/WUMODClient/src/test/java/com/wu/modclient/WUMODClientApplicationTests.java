package com.wu.modclient;

import com.wu.modclient.entity.TokenRequestBody;
import com.wu.modclient.entity.TokenResponseBody;
import org.apache.tomcat.util.codec.binary.Base64;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.ResponseErrorHandler;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.Arrays;
import java.util.Map;

@SpringBootTest
class WUMODClientApplicationTests {

	private static final Logger logger = LoggerFactory.getLogger(WUMODClientApplicationTests.class);
	private static final String MOD_TOKEN_GENERATOR_URL = "https://signin-us-uat.westernunion.com/as/token.oauth2";
	private static final String MOD_USERNAME = "0oa11sepqusn1twj3h7v";
	private static final String MOD_PASSWORD = "FlKJKbK6addztsFDJ8cKCFz8itOhrViRDDoZxIKjy5NUsS3VmvKagPfyBVjPfI0Y";
	private static final String TOKEN_SCOPE = "pgw.config.currency-info  pgw.config.entitled-destinations pgw.config.origination-currencies pgw.config.payout-options pgw.config.state-list pgw.config.templates pgw.config.cascade-list pgw.customer.receiver pgw.disclaimers  pgw.orders pgw.orders.fees pgw.orders.quotes pgw.orders.confirm pgw.orders.release pgw.orders.inquiry pgw.notifications";
	private static final String TOKEN_GRANT_TYPE = "client_credentiadcls";

	@Autowired
	RestTemplate restTemplate;

	@Test
	void contextLoads() {
		String token = generateToken();
		System.out.println("token generated = " + token);
	}

	private String generateToken() {
		HttpHeaders httpHeaders = getHeaders();

		/*TokenRequestBody requestBody = new TokenRequestBody();
		requestBody.setScope(TOKEN_SCOPE);
		requestBody.setGrant_type(TOKEN_GRANT_TYPE);*/

		MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
		map.add("grant_type", TOKEN_GRANT_TYPE);
		map.add("scope", TOKEN_SCOPE);

		HttpEntity<Map > request = new HttpEntity<>(map, httpHeaders);
		try {
			ResponseEntity<TokenResponseBody> response =
					restTemplate.postForEntity(
							MOD_TOKEN_GENERATOR_URL, request, TokenResponseBody.class);
			TokenResponseBody body = response.getBody();
			if(body != null) {
				return body.getAccess_token();
			}
		} catch (RuntimeException e) {
			System.out.println("e = " + e.getMessage());
		}
		return null;
	}

	private HttpHeaders getHeaders () {
		String credentials = MOD_USERNAME + ":" + MOD_PASSWORD;
		String encodedCredentials =
				new String(Base64.encodeBase64(credentials.getBytes(), false));

		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("Authorization", "Basic " + encodedCredentials);
		httpHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		return httpHeaders;
	}
}
