package my.test;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class JavaHandsOn {
    public static void main(String[] args) {
        int[] arr = {2, 3, 5, 2, 3, 6};
        LinkedHashSet<Integer> newSet = Arrays.stream(arr).boxed().collect(
                () -> new LinkedHashSet<Integer>(),
                (LinkedHashSet<Integer> set, Integer item) -> set.add(item),
                (LinkedHashSet<Integer> set1, LinkedHashSet<Integer> set2) -> set1.addAll(set2)
        );
        System.out.println("newSet = " + newSet);

        Integer num = 5;
        Integer[] arrInt = {1, 3, 5, 4, 3};
        Set<Integer> set12 = Arrays.stream(arrInt).collect(Collectors.toSet());
        HashSet<Integer> newSet2 = new HashSet<>();
        IntStream.rangeClosed(1, num).forEach(i -> {
            if(!set12.contains(i)) {
                newSet2.add(i);
            }
        });
        System.out.println("newSet2 = " + newSet2);


        Integer[] arrStockPrice = {6, 9, 3, 7, 5};
        Integer prevPrice = arrStockPrice[0];
        Integer maxProfit = 0;
        for(int i = 1, n = arrStockPrice.length; i < n; i++) {
            Integer price = arrStockPrice[i];
            if((price - prevPrice) > maxProfit) {
                maxProfit = price - prevPrice;
            }
            prevPrice = price;
        }
        System.out.println("maxProfit : " + maxProfit);
        /*Optional<Integer> min = Arrays.stream(arrStockPrice).min(Integer::compareTo);
        Optional<Integer> max = Arrays.stream(arrStockPrice).max(Integer::compareTo);
        if(min.isPresent()) {
            System.out.println("Buy stock with price = " + min.get());
        }
        if(max.isPresent()) {
            System.out.println("Sell stock with price = " + max.get());
        }*/
    }
}
