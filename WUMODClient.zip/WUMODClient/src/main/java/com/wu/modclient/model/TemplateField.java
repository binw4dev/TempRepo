package com.wu.modclient.model;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.TreeMap;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class TemplateField {
    public enum TemplateFieldType {
        ALPHANUMERIC,
        NUMERIC,
        DATE,
        DROPDOWN,
    }

    private Integer id;
    private String fieldName;
    private TemplateFieldType fieldType;
    private String fieldText;
    private String fieldDesp;
    private String defaultValue;
    private boolean required;
    private Integer dropDownId;
    private List<Dropdown> dropdown;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFieldName() {
        return fieldName;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    public TemplateFieldType getFieldType() {
        return fieldType;
    }

    public void setFieldType(TemplateFieldType fieldType) {
        this.fieldType = fieldType;
    }

    public String getDefaultValue() {
        return defaultValue;
    }

    public void setDefaultValue(String defaultValue) {
        this.defaultValue = defaultValue;
    }

    public boolean isRequired() {
        return required;
    }

    public void setRequired(boolean required) {
        this.required = required;
    }

    public List<Dropdown> getDropdown() {
        return dropdown;
    }

    public void setDropdown(List<Dropdown> dropdown) {
        this.dropdown = dropdown;
    }

    public String getFieldText() {
        return fieldText;
    }

    public void setFieldText(String fieldText) {
        this.fieldText = fieldText;
    }

    public String getFieldDesp() {
        return fieldDesp;
    }

    public void setFieldDesp(String fieldDesp) {
        this.fieldDesp = fieldDesp;
    }

    public Integer getDropDownId() {
        return dropDownId;
    }

    public void setDropDownId(Integer dropDownId) {
        this.dropDownId = dropDownId;
    }

    @Override
    public String toString() {
        return "TemplateField{" +
                "id=" + id +
                ", fieldName='" + fieldName + '\'' +
                ", fieldType=" + fieldType +
                ", fieldText='" + fieldText + '\'' +
                ", fieldDesp='" + fieldDesp + '\'' +
                ", defaultValue='" + defaultValue + '\'' +
                ", required=" + required +
                ", dropdown=" + dropdown +
                '}';
    }
}
