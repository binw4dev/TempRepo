package com.wu.modclient.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ComplianceTemplate {
    private String templateId;
    private String version;
    private ComplianceTemplate.IDDetails idDetails;
    private String idIssueDate;
    private String idExpireDate;
    private String dateOfBirth;
    private String occupation;
    private String purpose;
    private String countryOfBirth;
    private String nationality;
    private String gender;
    private String sourceOfFund;
    private String relationship;
    private String ackFlag;

    public String getTemplateId() {
        return templateId;
    }

    public void setTemplateId(String templateId) {
        this.templateId = templateId;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public ComplianceTemplate.IDDetails getIdDetails() {
        return idDetails;
    }

    public void setIdDetails(ComplianceTemplate.IDDetails idDetails) {
        this.idDetails = idDetails;
    }

    public String getIdIssueDate() {
        return idIssueDate;
    }

    public void setIdIssueDate(String idIssueDate) {
        this.idIssueDate = idIssueDate;
    }

    public String getIdExpireDate() {
        return idExpireDate;
    }

    public void setIdExpireDate(String idExpireDate) {
        this.idExpireDate = idExpireDate;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getOccupation() {
        return occupation;
    }

    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    public String getCountryOfBirth() {
        return countryOfBirth;
    }

    public void setCountryOfBirth(String countryOfBirth) {
        this.countryOfBirth = countryOfBirth;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getSourceOfFund() {
        return sourceOfFund;
    }

    public void setSourceOfFund(String sourceOfFund) {
        this.sourceOfFund = sourceOfFund;
    }

    public String getRelationship() {
        return relationship;
    }

    public void setRelationship(String relationship) {
        this.relationship = relationship;
    }

    public String getAckFlag() {
        return ackFlag;
    }

    public void setAckFlag(String ackFlag) {
        this.ackFlag = ackFlag;
    }

    @Override
    public String toString() {
        return "ComplianceTemplateResponse{" +
                "templateId='" + templateId + '\'' +
                ", version='" + version + '\'' +
                ", idDetails=" + idDetails +
                ", idIssueDate='" + idIssueDate + '\'' +
                ", idExpireDate='" + idExpireDate + '\'' +
                ", dateOfBirth='" + dateOfBirth + '\'' +
                ", occupation='" + occupation + '\'' +
                ", purpose='" + purpose + '\'' +
                ", countryOfBirth='" + countryOfBirth + '\'' +
                ", nationality='" + nationality + '\'' +
                ", gender='" + gender + '\'' +
                ", sourceOfFund='" + sourceOfFund + '\'' +
                ", relationship='" + relationship + '\'' +
                ", ackFlag='" + ackFlag + '\'' +
                '}';
    }

    public class IDDetails {
        private String id;
        private String type;
        private String issuer;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getIssuer() {
            return issuer;
        }

        public void setIssuer(String issuer) {
            this.issuer = issuer;
        }

        @Override
        public String toString() {
            return "IDDetails{" +
                    "id='" + id + '\'' +
                    ", type='" + type + '\'' +
                    ", issuer='" + issuer + '\'' +
                    '}';
        }
    }
}
