package com.wu.modclient.service;

import com.wu.modclient.dto.RespBean;
import com.wu.modclient.dto.TokenRequest;
import com.wu.modclient.dto.TokenResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@Service
public class TokenService {
    @Autowired
    RestTemplate restTemplate;

    public RespBean requestTokenFromWU(TokenRequest tokenRequest) {
        HttpHeaders headers = tokenRequest.getHeaders();
        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
        map.add("grant_type", tokenRequest.getGrant_type());
        map.add("scope", tokenRequest.getScope());
        try {
            HttpEntity<Map> httpEntity = new HttpEntity<>(map, headers);
            ResponseEntity<TokenResponse> response =
                    restTemplate.postForEntity(
                            tokenRequest.getTokenUrl(), httpEntity, TokenResponse.class);
            TokenResponse token = response.getBody();
            if(token != null) {
                return RespBean.ok("Token generated.", token);
            }
            return RespBean.error(500, "Failed generate the token");
        } catch (RuntimeException e) {
            return RespBean.error(400, e.getMessage());
        }
    }

    public RespBean getDefaultTokenRequest() {
        return RespBean.ok("Default Token Request.", TokenRequest.getDefaultTokenRequest());
    }
}
