package com.wu.modclient.model;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class Template {
    private Integer id;
    private String templateId;
    private String version;
    private String countryCode;
    private String currencyCode;
    private List<TemplateField> templateFields = new ArrayList<>();

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTemplateId() {
        return templateId;
    }

    public void setTemplateId(String templateId) {
        this.templateId = templateId;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public List<TemplateField> getTemplateFields() {
        return templateFields;
    }

    public void setTemplateFields(List<TemplateField> templateFields) {
        this.templateFields = templateFields;
    }

    @Override
    public String toString() {
        return "Template{" +
                "id=" + id +
                ", templateId='" + templateId + '\'' +
                ", version='" + version + '\'' +
                ", country_code='" + countryCode + '\'' +
                ", currency_code='" + currencyCode + '\'' +
                ", templateFields=" + templateFields +
                '}';
    }
}
