package com.wu.modclient.controller;

import com.wu.modclient.dto.TemplateRequest;
import com.wu.modclient.dto.RespBean;
import com.wu.modclient.service.CountryCurrencyService;
import com.wu.modclient.service.TemplateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/template")
public class TemplateController {
    @Autowired
    TemplateService templateService;
    @Autowired
    CountryCurrencyService ccService;
    //@GetMapping
    @PostMapping
    public RespBean getTemplate(@RequestBody TemplateRequest templateRequest) {
        return templateService.getTemplate(templateRequest);
    }

    @GetMapping("/cclist")
    public RespBean getCountryCurrencyList() {
        return ccService.getCountryCurrencyList();
    }
    /*public RespBean getTemplate(
            @RequestParam(name = "templateId") String templateId,
            @RequestParam(name = "version") String version,
            @RequestParam(name = "countryCode") String countryCode,
            @RequestParam(name = "currencyCode") String currencyCode) {
        TemplateRequest templateRequest = new TemplateRequest();
        templateRequest.setTemplateId(templateId);
        templateRequest.setCountryCode(countryCode);
        templateRequest.setVersion(version);
        templateRequest.setCurrencyCode(currencyCode);
        return templateService.getTemplate(templateRequest);
    }*/
}
