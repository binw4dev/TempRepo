package com.wu.modclient.model;

public class Dropdown {
    private String text;
    private Object value;
    private boolean defaultOption;

    public Dropdown(String text, Object value) {
        this.text = text;
        this.value = value;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public Object getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public boolean isDefaultOption() {
        return defaultOption;
    }

    public void setDefaultOption(boolean defaultOption) {
        this.defaultOption = defaultOption;
    }

    @Override
    public String toString() {
        return "Dropdown{" +
                "text='" + text + '\'' +
                ", value='" + value + '\'' +
                '}';
    }
}
