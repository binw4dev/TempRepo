package com.wu.modclient.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import java.util.Arrays;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
//@JsonIgnoreProperties(value = {"userName", "password"})
public class TokenRequest {
    private static final String MOD_TOKEN_GENERATOR_URL = "https://signin-us-uat.westernunion.com/as/token.oauth2";
    private static final String MOD_USERNAME = "0oa11sepqusn1twj3h7v";
    private static final String MOD_PASSWORD = "FlKJKbK6addztsFDJ8cKCFz8itOhrViRDDoZxIKjy5NUsS3VmvKagPfyBVjPfI0Y";
    private static final String TOKEN_SCOPE = "pgw.config.currency-info  pgw.config.entitled-destinations pgw.config.origination-currencies pgw.config.payout-options pgw.config.state-list pgw.config.templates pgw.config.cascade-list pgw.customer.receiver pgw.disclaimers  pgw.orders pgw.orders.fees pgw.orders.quotes pgw.orders.confirm pgw.orders.release pgw.orders.inquiry pgw.notifications";
    private static final String TOKEN_GRANT_TYPE = "client_credentials";

    private String tokenUrl = MOD_TOKEN_GENERATOR_URL;
    private String grant_type = TOKEN_GRANT_TYPE;
    private String scope = TOKEN_SCOPE;
    private String userName = MOD_USERNAME;
    private String password = MOD_PASSWORD;

    private TokenRequest() {
        this.tokenUrl = MOD_TOKEN_GENERATOR_URL;
        this.grant_type = TOKEN_GRANT_TYPE;
        this.scope = TOKEN_SCOPE;
        this.userName = MOD_USERNAME;
        this.password = MOD_PASSWORD;
    }

    private static TokenRequest defaultRequest = new TokenRequest();

    public static TokenRequest getDefaultTokenRequest() {
        return defaultRequest;
    }

    public HttpHeaders getHeaders () {
        String credentials = MOD_USERNAME + ":" + MOD_PASSWORD;
        String encodedCredentials =
                new String(Base64.encodeBase64(credentials.getBytes(), false));

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("Authorization", "Basic " + encodedCredentials);
        httpHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        return httpHeaders;
    }

    public String getGrant_type() {
        return grant_type;
    }

    public void setGrant_type(String grant_type) {
        this.grant_type = grant_type;
    }

    public String getScope() {
        return scope;
    }

    public void setScope(String scope) {
        this.scope = scope;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getTokenUrl() {
        return tokenUrl;
    }

    public void setTokenUrl(String tokenUrl) {
        this.tokenUrl = tokenUrl;
    }
}
