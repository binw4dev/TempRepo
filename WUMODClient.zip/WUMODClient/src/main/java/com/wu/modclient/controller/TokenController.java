package com.wu.modclient.controller;

import com.wu.modclient.dto.RespBean;
import com.wu.modclient.dto.TokenRequest;
import com.wu.modclient.service.TokenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("token")
public class TokenController {
    @Autowired
    TokenService tokenService;

    @PostMapping
    public RespBean requestTokenFromWU(@RequestBody TokenRequest request) {
        return tokenService.requestTokenFromWU(request);
    }

    @GetMapping
    public RespBean getDefaultTokenRequest() {
        return tokenService.getDefaultTokenRequest();
    }
}
