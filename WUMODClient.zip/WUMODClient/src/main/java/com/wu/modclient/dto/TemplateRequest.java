package com.wu.modclient.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class TemplateRequest {
    private String templateId;
    private String version;
    private String countryCode;
    private String currencyCode;

    public String getTemplateId() {
        return templateId;
    }

    public void setTemplateId(String templateId) {
        this.templateId = templateId;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    @Override
    public String toString() {
        return "TemplateRequest{" +
                "templateId='" + templateId + '\'' +
                ", version='" + version + '\'' +
                ", country_code='" + countryCode + '\'' +
                ", currency_code='" + currencyCode + '\'' +
                '}';
    }
}
