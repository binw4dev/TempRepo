package com.wu.modclient.service;

import com.wu.modclient.dto.RespBean;
import com.wu.modclient.mapper.CountryCurrencyMapper;
import com.wu.modclient.model.CountryCurrency;
import com.wu.modclient.model.Dropdown;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CountryCurrencyService {
    @Autowired
    CountryCurrencyMapper ccMapper;

    public RespBean getCountryCurrencyList() {
        List<CountryCurrency> ccList = ccMapper.getCountryCurrencyList();
        List<Dropdown> ddlist = ccList
                .stream()
                .map(cc -> new Dropdown(cc.getCountryName() + " - " + cc.getCurrencyCode(), cc.getCurrencyCode())).toList();
        if(ccList != null) {
            return RespBean.ok("Country Currency List Retrieved", ddlist);
        }
        return RespBean.error(401, "No Country Currency List found");
    }
}
