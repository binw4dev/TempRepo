package com.wu.modclient.mapper;

import com.wu.modclient.model.CountryCurrency;

import java.util.List;

public interface CountryCurrencyMapper {
    List<CountryCurrency> getCountryCurrencyList();
}
