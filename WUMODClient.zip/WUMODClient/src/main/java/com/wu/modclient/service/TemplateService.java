package com.wu.modclient.service;

import com.wu.modclient.dto.TemplateRequest;
import com.wu.modclient.dto.RespBean;
import com.wu.modclient.mapper.TemplateFieldsMapper;
import com.wu.modclient.mapper.TemplateMapper;
import com.wu.modclient.model.Dropdown;
import com.wu.modclient.model.Template;
import com.wu.modclient.model.TemplateField;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TemplateService {
    @Autowired
    TemplateMapper templateMapper;
    @Autowired
    TemplateFieldsMapper templateFieldsMapper;

    public RespBean getTemplate(TemplateRequest templateRequest) {
        Template template = templateMapper.getTemplate(templateRequest);
        List<TemplateField> templateFields = template.getTemplateFields();
        for(TemplateField field : templateFields) {
            TemplateField.TemplateFieldType fieldType = field.getFieldType();
            if(fieldType.equals(TemplateField.TemplateFieldType.DROPDOWN)) {
                Integer dropDownId = field.getDropDownId();
                List<Dropdown> dropdown = templateFieldsMapper.getDropDown(dropDownId);
                field.setDropdown(dropdown);
            }
        }

        if(template != null) {
            return RespBean.ok("Template Retrieved", template);
        }
        return RespBean.error(401, "No template found");
    }
}
