package com.wu.modclient.mapper;

import com.wu.modclient.model.Dropdown;

import java.util.List;

public interface TemplateFieldsMapper {
    public List<Dropdown> getDropDown(Integer dropDownId);
}
