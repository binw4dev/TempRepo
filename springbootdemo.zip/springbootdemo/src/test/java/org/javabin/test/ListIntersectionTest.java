package org.javabin.test;

import java.util.*;
import java.util.stream.Collectors;

public class ListIntersectionTest {
    public static void main(String[] args) {
        LinkedList<Integer> list1 = new LinkedList<>();
        LinkedList<Integer> list2 = new LinkedList<>();
        for(int i = 0; i < 10; i++) {
            Random random = new Random();
            list1.add(random.nextInt(12));
            list2.add(random.nextInt(12));
        }
        List<Integer> list = findIntersection(list1, list2);
        list1.forEach(item -> {
            System.out.print(item + " ");
        });
        System.out.println();
        list2.forEach(item -> {
            System.out.print(item + " ");
        });
        System.out.println();
        if(list.size() == 0) {
            System.out.println("No intersection observed between the two lists.");
        } else {
            list.forEach(item -> {
                System.out.print(item + " ");
            });
        }
    }

    private static List<Integer> findIntersection(List<Integer> list1, List<Integer> list2) {
        HashSet<Integer> set = new HashSet<>();
        for(Integer item : list1) {
            if(list2.contains(item)) {
                set.add(item);
            }
        }

        List<Integer> list = set.stream().collect(Collectors.toList());

        return list;
    }
}
