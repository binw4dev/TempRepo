package org.javabin.test;

import java.util.ArrayList;
import java.util.HashMap;

public class EmployeeFilterTest {

    public static void main(String[] args) {
        ArrayList<Employee> employees = new ArrayList();
        employees.add(new Employee(1, "Javabin"));
        employees.add(new Employee(2, "Kunta"));
        employees.add(new Employee(3, "David"));
        employees.add(new Employee(4, "Samuel"));
        employees.add(new Employee(5, "Tumi"));
        employees.add(new Employee(6, "Kinte"));

        HashMap<Integer, Employee> employeeMap = new HashMap();
        employees.forEach(employee -> {
            if((employee.getId() % 2) == 0) {
                employeeMap.put(employee.getId(), employee);
            }
        });

        employeeMap.entrySet().forEach(entry -> {
            System.out.println("employee with even id number = " + entry.getValue());
        });
    }
}
