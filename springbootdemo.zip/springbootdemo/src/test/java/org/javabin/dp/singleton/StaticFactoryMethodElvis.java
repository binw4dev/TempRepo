package org.javabin.dp.singleton;

public class StaticFactoryMethodElvis {
    private static final StaticFactoryMethodElvis INSTANCE = new StaticFactoryMethodElvis();
    private StaticFactoryMethodElvis() { }
    public static StaticFactoryMethodElvis getInstance() { return INSTANCE; }

    public void leaveTheBuilding() {
        System.out.println("Whoa baby, I'm outta here!");
    }

    // This code would normally appear outside the class!
    public static void main(String[] args) {
        StaticFactoryMethodElvis elvis = StaticFactoryMethodElvis.getInstance();
        elvis.leaveTheBuilding();
    }
}
