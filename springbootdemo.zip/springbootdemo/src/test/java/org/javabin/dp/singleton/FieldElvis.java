package org.javabin.dp.singleton;

public class FieldElvis {
    public static final FieldElvis INSTANCE = new FieldElvis();

    private FieldElvis() { }

    public void leaveTheBuilding() {
        System.out.println("Whoa baby, I'm outta here!");
    }

    // This code would normally appear outside the class!
    public static void main(String[] args) {
        FieldElvis elvis = FieldElvis.INSTANCE;
        elvis.leaveTheBuilding();
    }
}
