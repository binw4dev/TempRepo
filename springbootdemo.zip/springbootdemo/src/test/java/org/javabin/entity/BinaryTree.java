package org.javabin.entity;

import java.util.Random;

public class BinaryTree {
    private TreeNode root;

    public static BinaryTree generateTree() {
        Random random = new Random();
        BinaryTree tree = new BinaryTree();
        TreeNode<Integer> root = new TreeNode<>(1);
        // level 1
        tree.setRoot(root);
        // level 2
        TreeNode leftSubLvl1 = new TreeNode(randomInt());
        root.setLeftSub(leftSubLvl1);
        TreeNode rightSubLvl1 = new TreeNode(randomInt());
        root.setRightSub(rightSubLvl1);
        // level 3
        TreeNode leftSubLvl2 = new TreeNode(randomInt());
        leftSubLvl1.setLeftSub(leftSubLvl2);
        TreeNode rightSubLvl2 = new TreeNode(randomInt());
        rightSubLvl1.setLeftSub(rightSubLvl2);
        // level 4
        TreeNode leftSubLvl3 = new TreeNode(randomInt());
        leftSubLvl2.setLeftSub(leftSubLvl3);
        TreeNode rightSubLvl3 = new TreeNode(randomInt());
        rightSubLvl2.setLeftSub(rightSubLvl3);
        return tree;
    }

    private static int randomInt() {
        return new Random().nextInt(1, 32);
    }

    public TreeNode getRoot() {
        return root;
    }

    public void setRoot(TreeNode root) {
        this.root = root;
    }
}
