package org.javabin.entity;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Stream;

public class FileStream {
    public static Stream<String> readFileByLine(String filePath) throws IOException {
        Path path = Paths.get(filePath);
        if(!Files.exists(path)) {
            throw new FileNotFoundException("File not found in the given path : " + filePath);
        }

        Stream<String> fileLines = Files.lines(path);
        return fileLines;
    }

    public static Stream<Path> readDirectory(String dirPath) throws IOException {
        Path path = Paths.get(dirPath);
        if(!Files.isDirectory(path)) {
            throw new FileNotFoundException("Directory not found in the given path : " + dirPath);
        }

        Stream<Path> filePaths = Files.walk(path);
        return filePaths;
    }
}
