package org.javabin.entity;

public class PrintUtil {
    public static void printOneLine(Object obj, String separator) {
        System.out.print(obj + separator);
    }


}
