package org.javabin.entity;

public class TreeNode<T> {
    private T data;
    private TreeNode leftSub;
    private TreeNode rightSub;

    public TreeNode(T data) {
        this.data = data;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public TreeNode getLeftSub() {
        return leftSub;
    }

    public void setLeftSub(TreeNode leftSub) {
        this.leftSub = leftSub;
    }

    public TreeNode getRightSub() {
        return rightSub;
    }

    public void setRightSub(TreeNode rightSub) {
        this.rightSub = rightSub;
    }
}
