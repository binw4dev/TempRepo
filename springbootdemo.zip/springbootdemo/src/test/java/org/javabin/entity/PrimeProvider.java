package org.javabin.entity;

public class PrimeProvider {
    private long lastPrime = 0L;

    public long next() {
        lastPrime = next(lastPrime);
        return lastPrime;
    }

    public static long next(long after) {
        long counter = after;
        while(!isPrime(++counter));
        return counter;
    }

    public static boolean isPrime(long num) {
        if(num <= 1) {
            return false;
        }
        if(num == 2) {
            return true;
        }
        if(num % 2 == 0) {
            return false;
        }

        long maxDivisor = (long)Math.sqrt(num);
        for(int counter = 3; counter <= maxDivisor; counter+=2) {
            if(num % counter == 0) {
                return false;
            }
        }
        return true;
    }

}
