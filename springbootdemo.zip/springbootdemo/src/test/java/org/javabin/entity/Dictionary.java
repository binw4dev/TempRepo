package org.javabin.entity;

public class Dictionary extends Book {

    public Dictionary(String id, String name, float price, String author) {
        super(id, name, price, author);
    }

    /**
     * Demonstrate whether we could change the scope of the overridden method in the subclass
     */
    @Override
    protected void print() {
        System.out.println("print the dictionary.");
    }
}
