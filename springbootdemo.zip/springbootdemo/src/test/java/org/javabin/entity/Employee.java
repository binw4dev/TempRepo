package org.javabin.entity;

import java.time.LocalDate;
import java.time.Month;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Objects;

public class Employee implements Comparable<Employee> {

    public static enum Gender {MALE, FEMALE};

    public static List<Employee> employees() {
        Employee ken = new Employee(1l, "emp-1", "Ken", "ken@mail.com", "employee address 1",
                LocalDate.of(1993, Month.APRIL, 13), Gender.MALE, 2800.21);
        Employee jane = new Employee(2l, "emp-2", "Jane", "jane@mail.com", "employee address 2",
                LocalDate.of(1993, Month.FEBRUARY, 13), Gender.FEMALE, 3205.21);
        Employee kunta = new Employee(3l, "emp-3", "Kunta", "kunta@mail.com", "employee address 3",
                LocalDate.of(1993, Month.APRIL, 13), Gender.MALE, 5200.41);
        Employee kinte = new Employee(4l, "emp-4", "Kinte", "kinte@mail.com", "employee address 4",
                LocalDate.of(1993, Month.FEBRUARY, 13), Gender.MALE, 3394.46);
        Employee samuel = new Employee(5l, "emp-5", "Samuel", "samuel@mail.com", "employee address 5",
                LocalDate.of(1993, Month.MARCH, 13), Gender.MALE, 5420.09);
        Employee chris = new Employee(6l, "emp-6", "Chris", "chris@mail.com", "employee address 6",
                LocalDate.of(1993, Month.APRIL, 13), Gender.MALE, 2800.12);
        Employee jenny = new Employee(7l, "emp-7", "Jenny", "jenny@mail.com", "employee address 7",
                LocalDate.of(1993, Month.DECEMBER, 13), Gender.FEMALE, 2800.74);
        Employee denis = new Employee(8l, "emp-8", "Denis", "denis@mail.com", "employee address 8",
                LocalDate.of(1993, Month.DECEMBER, 13), Gender.MALE, 0.29);

        List<Employee> employees = Arrays.asList(ken, jane, kunta, kinte, samuel, chris, jenny, denis);
        return employees;
    }

    private Long id;
    private String employeeId;
    private String name;
    private String email;
    private String address;
    private LocalDate dateOfBirth;
    private Gender gender;
    private Double salary;

    public Employee(Long id, String employeeId, String name, String email, String address, LocalDate dateOfBirth, Gender gender, Double salary) {
        this.id = id;
        this.employeeId = employeeId;
        this.name = name;
        this.email = email;
        this.address = address;
        this.dateOfBirth = dateOfBirth;
        this.gender = gender;
        this.salary = salary;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public Double getSalary() {
        return salary;
    }

    public void setSalary(Double salary) {
        this.salary = salary;
    }

    public Gender getGender() {
        return gender;
    }

    public boolean isMale() {
        return this.gender == Gender.MALE;
    }

    public boolean isFemale() {
        return this.gender == Gender.FEMALE;
    }

    public void setGender(Gender gender) {
        this.gender = gender;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", employeeId='" + employeeId + '\'' +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", address='" + address + '\'' +
                ", dateOfBirth=" + dateOfBirth +
                ", gender=" + gender +
                ", salary=" + salary +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Employee employee = (Employee) o;
        return Objects.equals(employeeId, employee.employeeId) && Objects.equals(name, employee.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(employeeId, name);
    }

    @Override
    public int compareTo(Employee employee) {
        return this.employeeId.compareTo(employee.getEmployeeId());
    }
}
