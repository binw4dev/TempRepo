package org.javabin.entity;

public class CarWithBuilder {
    private String name;
    private String type;
    private String vendor;
    private String brand;

    private CarWithBuilder(Builder builder) {
        this.name = builder.name;
        this.brand = builder.brand;
        this.vendor = builder.vendor;
        this.type = builder.type;
    }

    public static Builder builder() {
        return new Builder();
    }

    private static class Builder {
        private String name;
        private String type;
        private String vendor;
        private String brand;

        public Builder() {
        }

        public Builder name(String name) {
            this.name = name;
            return this;
        }

        public Builder type(String type) {
            this.type = type;
            return this;
        }

        public Builder vendor(String vendor) {
            this.vendor = vendor;
            return this;
        }

        public Builder brand(String brand) {
            this.brand = brand;
            return this;
        }

        public CarWithBuilder build() {
            return new CarWithBuilder(this);
        }
    }

    public static void main(String[] args) {
        CarWithBuilder aa = CarWithBuilder.builder().name("aa").build();
    }
}
