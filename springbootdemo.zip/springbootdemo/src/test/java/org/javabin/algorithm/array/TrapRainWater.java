package org.javabin.algorithm.array;

/**
 * Trapping Rainwater Problem states that given an array of n non-negative integers arr[] representing an elevation map where the width of each bar is 1,
 * compute how much water it can trap after rain.
 *
 * The basic intuition of the problem is as follows:
 *
 * An element of the array can store water if there are higher bars on the left and the right.
 * The amount of water to be stored in every position can be found by finding the heights of the higher bars on the left and right sides.
 * The total amount of water stored is the summation of the water stored in each index.
 * No water can be filled if there is no boundary on both sides.
 *
 * E.g.
 * Input: arr[] = {3, 0, 1, 0, 4, 0, 2}
 * Output: 10
 * Explanation: The expected rainwater to be trapped is shown in the above image.
 *
 *
 * Input: arr[]   = {3, 0, 2, 0, 4}
 * Output: 7
 * Explanation: We trap 0 + 3 + 1 + 3 + 0 = 7 units.
 *
 *
 * Input: arr[] = {1, 2, 3, 4}
 * Output: 0
 * Explanation : We cannot trap water as there is no height bound on both sides
 *
 *
 * Input: arr[] = {10, 9, 0, 5}
 * Output: 5
 * Explanation : We trap 0 + 0 + 5 + 0 = 5
 */
public class TrapRainWater {

    /**
     * [Expected Approach] Computing prefix and suffix max for every index – O(n) Time and O(n) Space
     *
     * For every element we first calculate and store the highest bar on the left and on the right (say stored in arrays left[] and right[]).
     * Then iterate the array and use the calculated values to find the amount of water stored in this index, which is the same as ( min(left[i], right[i]) – arr[i] )
     *
     * Consider arr[] = {3, 0, 2, 0, 4}
     * Therefore, left[] = {3, 3, 3, 3, 4} and right[] = {4, 4, 4, 4, 4}
     * Now consider iterating using i from 0 to end and compute water stored at every index as min(left[i], right[i]) – arr[i]) and if it is greater than 0, then add it to the result.
     *
     * Initialize : res = 0
     * For i = 0:  res = 0  + 0 = 0
     * For i = 1:  res = 0 + 3 = 3
     * For i = 2:  res = 3 + 1 = 4
     * For i = 3:  res = 4 + 3 = 7
     * For i = 4:  res = 7 + 0 = 7
     *
     * So total rain water trapped = 7
     */
    static int findWaterBetter(int[] arr) {
        int n = arr.length;

        // Left[i] contains height of tallest bar to the
        // left of i'th bar including itself
        int[] left = new int[n];

        // Right[i] contains height of tallest bar to
        // the right of i'th bar including itself
        int[] right = new int[n];

        // Initialize result
        int res = 0;

        // Fill left array
        left[0] = arr[0];
        for (int i = 1; i < n; i++)
            left[i] = Math.max(left[i - 1], arr[i]);

        // Fill right array
        right[n - 1] = arr[n - 1];
        for (int i = n - 2; i >= 0; i--)
            right[i] = Math.max(right[i + 1], arr[i]);

        // Calculate the accumulated water element by element
        for (int i = 1; i < n - 1; i++) {
            int minOf2 = Math.min(left[i - 1], right[i + 1]);
            if (minOf2 > arr[i]) {
                res += minOf2 - arr[i];
            }
        }

        return res;
    }

    /**
     * Best Approach – Using Two Pointers – O(n) Time and O(1) Space
     *
     * The approach is mainly based on the following facts:
     *
     * If we consider a subarray arr[left…right], we can decide the amount of water either for arr[left] or arr[right] if we know the left max (max element in arr[0…left-1]) and right max (max element in arr[right+1…n-1].
     * If left max is less than the right max, then we can decide for arr[left]. Else we can decide for arr[right]
     * If we decide for arr[left], then the amount of water would be left max – arr[left]
     *
     * How does this work? Let us consider the case when left max is less than the right max. For arr[left],
     * we know left max for it and we also know that the right max for it would not be less than left max because we already have a greater value in arr[right..n-1].
     * Any other value from left+1 to right – 1 would anyways be more than left max.
     *
     * Consider arr[] = {3, 0, 5, 0, 4}
     * Initial values:
     *
     * left = 1, right = 3, lMax = arr[0] = 3, rMax = arr[4] = 4
     * res = 0 (stores total water trapped)
     * left = 1, right = 3::  Since lMax < rMax, we fill water in arr[left] as 3- 0 = 3,
     * left = 2, right = 3:   lMax < rMax, but arr[left] > lMax, we we do not fill water, we update lMax  = 5
     * left = 3, right = 3:   Since lMax >= rMax, we fill water in arr[right] as 4-0
     *
     * Total water trapped = 3 + 0 + 4 = 7
     */
    static int maxWaterBest(int[] arr) {
        int left = 1;
        int right = arr.length - 2;

        // lMax : Maximum in subarray arr[0..left-1]
        // rMax : Maximum in subarray arr[right+1..n-1]
        int lMax = arr[left - 1];
        int rMax = arr[right + 1];

        int res = 0;
        while (left <= right) {

            // If rMax is smaller, then we can decide the amount of water for arr[right]
            if (rMax <= lMax) {

                // Add the water for arr[right]
                res += Math.max(0, rMax - arr[right]);

                // Update right max
                rMax = Math.max(rMax, arr[right]);

                // Update right pointer as we have decided the amount of water for this
                right -= 1;
            } else {

                // Add the water for arr[left]
                res += Math.max(0, lMax - arr[left]);

                // Update left max
                lMax = Math.max(lMax, arr[left]);

                // Update left pointer as we have decided water for this
                left += 1;
            }
        }
        return res;
    }

    /**
     * Brute Force – O(n2) Time and O(1) Space:
     * Traverse every array element and find the highest bars on the left and right sides.
     * Take the smaller of two heights.
     * The difference between the smaller height and the height of the current element is the amount of water that can be stored in this array element.
     */
    static int maxWater(int[] arr) {
        int res = 0;
        for (int i = 1; i < arr.length - 1; i++) {
            // Find the maximum element on its left
            int left = arr[i];
            for (int j = 0; j < i; j++)
                left = Math.max(left, arr[j]);

            // Find the maximum element on its right
            int right = arr[i];
            for (int j = i + 1; j < arr.length; j++)
                right = Math.max(right, arr[j]);

            // Update the maximum water
            res += Math.min(left, right) - arr[i];
        }

        return res;
    }

    public static void main(String[] args) {
        int[] arr = { 0, 1, 0, 2, 1, 0, 1, 3, 2, 1, 2, 1 };
        //int[] arr = { 3, 0, 1, 1, 1 };
        //int[] arr = { 4, 3, 1, 1 };
        System.out.println(maxWater(arr));
    }
}
