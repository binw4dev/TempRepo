package org.javabin.algorithm.array;

/**
 * Given an array arr[] of size N-1 with integers in the range of [1, N], the task is to find the missing number from the first N integers.
 * Note: There are no duplicates in the list.
 * <p>
 * E.g.
 * Input: arr[] = {1, 2, 4, 6, 3, 7, 8} , N = 8
 * Output: 5
 * Explanation: Here the size of the array is 8, so the range will be [1, 8]. The missing number between 1 to 8 is 5
 * <p>
 * Input: arr[] = {1, 2, 3, 5}, N = 5
 * Output: 4
 * Explanation: Here the size of the array is 4, so the range will be [1, 5]. The missing number between 1 to 5 is 4
 */
public class FindMissingNumber {
    /**
     * [Naive Approach] Using Hashing – O(n) time and O(n) auxiliary space
     *
     * The very basic idea is to use an array to store the frequency of each element in the given array. The number with a frequency of 0 is the missing number.
     */
    public static int missingNumber(int n, int[] arr) {
        // Create hash array of size n+1
        int[] hash = new int[n + 1];

        // Store frequencies of elements
        for (int i = 0; i < n - 1; i++) {
            hash[arr[i]]++;
        }

        // Find the missing number
        for (int i = 1; i <= n; i++) {
            if (hash[i] == 0) {
                return i;
            }
        }

        // Edge case handling (though problem guarantees a
        // solution)
        return -1;
    }

    /**
     * [Expected Approach-1] Using Sum of N terms Formula – O(n) time and O(1) auxiliary space
     *
     * An efficient approach is to use summation formula. As we know that the sum of the first N natural numbers is given by the formula N * (N + 1) / 2.
     * Compute this sum and subtract the sum of all elements in the array from it to get the missing number.
     */
    public static int missingNumberByGauss(int n, int[] arr) {
        int sum = 0;

        // Calculate the sum of array elements
        for (int i = 0; i < n - 1; i++) {
            sum += arr[i];
        }

        // Calculate the expected sum
        int expectedSum = (n * (n + 1)) / 2;

        // Return the missing number
        return expectedSum - sum;
    }

    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 5};
        int n = 5;
        System.out.println(missingNumberByGauss(n, arr));
    }
}
