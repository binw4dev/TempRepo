package org.javabin.algorithm.array;

/**
 * Given an integer array, the task is to find the maximum product of any subarray.
 *
 * Examples:
 *
 * Input: arr[] = {-2, 6, -3, -10, 0, 2}
 * Output: 180
 * Explanation: The subarray with maximum product is {6, -3, -10} with product = 6 * (-3) * (-10) = 180
 *
 *
 * Input: arr[] = {-1, -3, -10, 0, 60}
 * Output: 60
 * Explanation: The subarray with maximum product is {60}.
 */
public class MaxProductOfSubarray {
    /**
     * [Naive Approach]
     *
     * Time Complexity: O(n^2), where n is the size of array.
     * Auxiliary Space: O(1)
     *
     * The idea is to traverse over every contiguous subarray by using two nested loops,
     * find the product of each of these subarrays and return the maximum product among all the subarrays.
     */
    static long maxProductNaive(int arr[]) {
        int n = arr.length;

        // Initializing result
        long result = arr[0];

        for (int i = 0; i < n; i++) {
            long mul = 1;

            // traversing in current subarray
            for (int j = i; j < n; j++) {
                mul *= arr[j];

                // updating result every time
                // to keep track of the maximum product
                result = Math.max(result, mul);
            }
        }
        return result;
    }

    /**
     * [Expected Approach]
     *
     * Time Complexity: O(n), where n is the size of input array.
     * Auxiliary Space: O(1)
     *
     * Assume that the input array has only positive elements.
     * Then, we can simply iterate from left to right keeping track of the maximum running product ending at any index.
     * The maximum product would be the product ending at the last index.
     * The problem arises when we encounter zero or a negative element.
     *
     * If we encounter zero, then all the subarrays containing this zero will have product = 0,
     * so zero simply resets the product of the subarray.
     *
     * If we encounter a negative number, we need to keep track of the minimum product as well as the maximum product ending at the previous index.
     * This is because when we multiply the minimum product with a negative number,
     * it can give us the maximum product. So, keeping track of minimum product ending at any index is important as it can lead to the maximum product on encountering a negative number.
     *
     * Step-by-step algorithm:
     * 1. Create 3 variables, currMin, currMax and maxProd initialized to the first element of the array.
     * 2. Iterate the indices 0 to N-1 and update the variables:
     * 3. currMax = maximum(arr[i], currMax * arr[i], currMin * arr[i])
     * 4. currMin= minimum(arr[i], currMax * arr[i], currMin * arr[i])
     * 5. update the maxProd with the maximum value for each index.
     * 6. Return maxProd as the result.
     */
    static long maxProductExpected(int[] arr) {
        int n = arr.length;

        // max product ending at the current index
        long currMax = arr[0];

        // min product ending at the current index
        long currMin = arr[0];

        // Initialize overall max product
        long maxProd = arr[0];

        // Iterate through the array
        for (int i = 1; i < n; i++) {

            // Temporary variable to store the maximum product ending
            // at the current index
            long temp = max(arr[i] * 1L, arr[i] * currMax, arr[i] * currMin);

            // Update the minimum product ending at the current index
            currMin = min(arr[i] * 1L, arr[i] * currMax, arr[i] * currMin);

            // Update the maximum product ending at the current index
            currMax = temp;

            // Update the overall maximum product
            maxProd = Math.max(maxProd, currMax);
        }

        return maxProd;
    }

    private static long max(long a, long b, long c) {
        return Math.max(a, Math.max(b, c));
    }

    private static long min(long a, long b, long c) {
        return Math.min(a, Math.min(b, c));
    }

    public static void main(String[] args) {
        int arr[] = { -2, 6, -3, -10, 0, 2 };
        System.out.println(maxProductExpected(arr));
    }
}
