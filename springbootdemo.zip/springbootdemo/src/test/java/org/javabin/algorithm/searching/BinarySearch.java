package org.javabin.algorithm.searching;

/**
 * find the position of a given key from a 2D array (matrix) where all elements in any individual row or column are sorted.
 */
public class BinarySearch {

}
