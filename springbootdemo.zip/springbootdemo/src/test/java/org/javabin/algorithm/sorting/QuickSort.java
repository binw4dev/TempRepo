package org.javabin.algorithm.sorting;

import java.util.Arrays;

/**
 * Find the 'K'th smallest number in an unsorted array of numbers
 *
 * Time Complexity: average O(N) or worst case O(N^2)
 */
public class QuickSort {

    public static void main(String[] args) {
        int result = QuickSort.findKthSmallestNumber(new int[] { 1, 5, 4, 3, 1, 12, 2, 11, 5 }, 3);
        System.out.println("The 3rd smallest number is: " + result + "\n\n");

        result = QuickSort.findKthSmallestNumber(new int[] { 1, 5, 4, 3, 1, 12, 2, 11, 5 }, 5);
        System.out.println("The 5th smallest number is: " + result);
    }

    public static int findKthSmallestNumber(int[] nums, int k) {
        return findKthSmallestNumberRec(nums, k, 0, nums.length - 1);
    }

    public static int findKthSmallestNumberRec(int[] nums, int k, int start, int end) {
        int p = partition(nums, start, end);

        // Found the result
        if (p == k - 1)
            return nums[p];

        if (p > k - 1) // search lower part
            return findKthSmallestNumberRec(nums, k, start, p - 1);

        // search higher part
        return findKthSmallestNumberRec(nums, k, p + 1, end);
    }

    private static int partition(int[] nums, int low, int high) {

/*        System.out.print("\npartition start : from nums[" + low + "] to nums[" + high + "] : ");
        for (int i = low; i <= high; i++) {
            System.out.print(nums[i] + "\t");
        }
        System.out.println();*/

        if (low == high)
            return low;

        int pivot = nums[high];
        for (int i = low; i < high; i++) {
            // all elements smaller than 'pivot' will be swapped ahead of the index 'low'; 'low' will be moved to the next position after swap
            if (nums[i] < pivot) {
                //System.out.println("swap happened in loop : ");
                swap(nums, low++, i);
            }
        }
        // put the pivot in its correct place: the current 'low' has the last larger number than 'high', so swap the numbers on 'low' and 'high'
        //System.out.println("swap happened after loop : ");
        swap(nums, low, high);
        return low;
    }

    private static void swap(int[] nums, int i, int j) {
/*        System.out.print("\tnums array before swap\t:\t");
        for (int num : nums) {
            System.out.print(num + "\t");
        }
        System.out.println();
        System.out.println("\tnums[" + i + "] '" + nums[i] + "' <-> nums[" + j + "] '" + nums[j] + "'");*/

        int temp = nums[i];
        nums[i] = nums[j];
        nums[j] = temp;

/*        System.out.print("\tnums array after swap\t:\t");
        for (int num : nums) {
            System.out.print(num + "\t");
        }
        System.out.println();*/
    }
}

/*

partition start : from nums[0] to nums[8] : 1	5	4	3	1	12	2	11	5
swap happened in loop :
	nums array before swap	:	1	5	4	3	1	12	2	11	5
	nums[0] '1' <-> nums[0] '1'
	nums array after swap	:	1	5	4	3	1	12	2	11	5
swap happened in loop :
	nums array before swap	:	1	5	4	3	1	12	2	11	5
	nums[1] '5' <-> nums[2] '4'
	nums array after swap	:	1	4	5	3	1	12	2	11	5
swap happened in loop :
	nums array before swap	:	1	4	5	3	1	12	2	11	5
	nums[2] '5' <-> nums[3] '3'
	nums array after swap	:	1	4	3	5	1	12	2	11	5
swap happened in loop :
	nums array before swap	:	1	4	3	5	1	12	2	11	5
	nums[3] '5' <-> nums[4] '1'
	nums array after swap	:	1	4	3	1	5	12	2	11	5
swap happened in loop :
	nums array before swap	:	1	4	3	1	5	12	2	11	5
	nums[4] '5' <-> nums[6] '2'
	nums array after swap	:	1	4	3	1	2	12	5	11	5
swap happened after loop :
	nums array before swap	:	1	4	3	1	2	12	5	11	5
	nums[5] '12' <-> nums[8] '5'
	nums array after swap	:	1	4	3	1	2	5	5	11	12

partition start : from nums[0] to nums[4] : 1	4	3	1	2
swap happened in loop :
	nums array before swap	:	1	4	3	1	2	5	5	11	12
	nums[0] '1' <-> nums[0] '1'
	nums array after swap	:	1	4	3	1	2	5	5	11	12
swap happened in loop :
	nums array before swap	:	1	4	3	1	2	5	5	11	12
	nums[1] '4' <-> nums[3] '1'
	nums array after swap	:	1	1	3	4	2	5	5	11	12
swap happened after loop :
	nums array before swap	:	1	1	3	4	2	5	5	11	12
	nums[2] '3' <-> nums[4] '2'
	nums array after swap	:	1	1	2	4	3	5	5	11	12
The 3rd smallest number is: 2



partition start : from nums[0] to nums[8] : 1	5	4	3	1	12	2	11	5
swap happened in loop :
	nums array before swap	:	1	5	4	3	1	12	2	11	5
	nums[0] '1' <-> nums[0] '1'
	nums array after swap	:	1	5	4	3	1	12	2	11	5
swap happened in loop :
	nums array before swap	:	1	5	4	3	1	12	2	11	5
	nums[1] '5' <-> nums[2] '4'
	nums array after swap	:	1	4	5	3	1	12	2	11	5
swap happened in loop :
	nums array before swap	:	1	4	5	3	1	12	2	11	5
	nums[2] '5' <-> nums[3] '3'
	nums array after swap	:	1	4	3	5	1	12	2	11	5
swap happened in loop :
	nums array before swap	:	1	4	3	5	1	12	2	11	5
	nums[3] '5' <-> nums[4] '1'
	nums array after swap	:	1	4	3	1	5	12	2	11	5
swap happened in loop :
	nums array before swap	:	1	4	3	1	5	12	2	11	5
	nums[4] '5' <-> nums[6] '2'
	nums array after swap	:	1	4	3	1	2	12	5	11	5
swap happened after loop :
	nums array before swap	:	1	4	3	1	2	12	5	11	5
	nums[5] '12' <-> nums[8] '5'
	nums array after swap	:	1	4	3	1	2	5	5	11	12

partition start : from nums[0] to nums[4] : 1	4	3	1	2
swap happened in loop :
	nums array before swap	:	1	4	3	1	2	5	5	11	12
	nums[0] '1' <-> nums[0] '1'
	nums array after swap	:	1	4	3	1	2	5	5	11	12
swap happened in loop :
	nums array before swap	:	1	4	3	1	2	5	5	11	12
	nums[1] '4' <-> nums[3] '1'
	nums array after swap	:	1	1	3	4	2	5	5	11	12
swap happened after loop :
	nums array before swap	:	1	1	3	4	2	5	5	11	12
	nums[2] '3' <-> nums[4] '2'
	nums array after swap	:	1	1	2	4	3	5	5	11	12

partition start : from nums[3] to nums[4] : 4	3
swap happened after loop :
	nums array before swap	:	1	1	2	4	3	5	5	11	12
	nums[3] '4' <-> nums[4] '3'
	nums array after swap	:	1	1	2	3	4	5	5	11	12

partition start : from nums[4] to nums[4] : 4
Kth smallest number is: 4


 */