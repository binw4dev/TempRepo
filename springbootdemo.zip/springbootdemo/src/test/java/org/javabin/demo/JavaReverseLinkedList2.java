package org.javabin.demo;

import java.util.Arrays;
import java.util.List;

public class JavaReverseLinkedList2 {
    static class Node<T> {
        private T value;
        public Node next;

        public Node(T value) {
            this.value = value;
        }

        public T getValue() {
            return value;
        }

        public void setValue(T value) {
            this.value = value;
        }

        @Override
        public String toString() {
            return "Node{" +
                    "value=" + value +
                    ", next=" + next +
                    '}';
        }
    }

    private static Node reverseLinkedList(Node head) {
        Node currNode = head;
        Node prevNode = null;
        Node nextNode = null;
        while(currNode != null) {
            nextNode = currNode.next;
            currNode.next = prevNode;
            prevNode = currNode;
            currNode = nextNode;
        }
        return prevNode;
    }

    private static void printLinkedList(Node head) {
        Node currNode = head;
        System.out.println("---------Print Linkedlist start--------");
        System.out.println("currNode = " + currNode);
        System.out.println("---------Print Linkedlist end--------");
    }

    public static void main(String[] args) {
        int[] arr = {1, 3, 5, 3, 2, 6, 17, 19};
        List<Integer> list = Arrays.stream(arr).boxed().toList();
        Node prevNode = null;
        Node head = null;
        for(Integer i : list) {
            Node node = new Node(i);
            if(head == null) {
                head = node;
                prevNode = node;
            } else {
                prevNode.next = node;
                prevNode = node;
            }
        }
        System.out.println("Before reversing");
        printLinkedList(head);
        Node reversedHead = reverseLinkedList(head);
        System.out.println("After reversing");
        printLinkedList(reversedHead);
    }
}
