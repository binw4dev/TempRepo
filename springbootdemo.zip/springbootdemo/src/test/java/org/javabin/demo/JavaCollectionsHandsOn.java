package org.javabin.demo;

import java.util.*;
import java.util.stream.Collectors;

public class JavaCollectionsHandsOn {

    public static void main(String[] args) {
        //operationsOfSet();

        HashMap<String, Integer> map = new HashMap<>();
        map.put("Jayant", 80);
        map.put("Abhishek", 90);
        map.put("Anushka", 80);
        map.put("Amit", 75);
        map.put("Danish", 40);
        System.out.println("map = " + map);
        Map<String, Integer> sortedMap = sortingMapByKey(map);
        System.out.println("sortedMap = " + sortedMap);


    }

    /**
     * Set Operations : Union, Intersection, Difference
     * 
     * Set Union = [65, 2, 3, 99, 4, 6, 102, 87, 56, 12]
     * Set Intersection = [3, 4, 6, 87, 12]
     * Set Difference = [65, 2, 99, 102, 56]
     * Set contains null = [null, 2, 3, 99, 4, 6, 87, 56, 12]
     */
    private static void operationsOfSet() {
        int[] arr1 = {2, 4, 3, 6, 12, 56, 87, 99};
        int[] arr2 = {6, 3, 4, 65, 12, 87, 102};
        Set<Integer> set1 = Arrays.stream(arr1).boxed().collect(Collectors.toSet());
        Set<Integer> set2 = Arrays.stream(arr2).boxed().collect(Collectors.toSet());

        HashSet<Integer> union = new HashSet<>(set1);
        HashSet<Integer> intersection = new HashSet<>(set1);

        union.addAll(set2);
        intersection.retainAll(set2);

        HashSet<Integer> difference = new HashSet<>(union);
        difference.removeAll(intersection);

        System.out.println("Set Union = " + union);
        System.out.println("Set Intersection = " + intersection);
        System.out.println("Set Difference = " + difference);

        set1.add(null);
        System.out.println("Set contains null = " + set1);
    }

    /**
     * Sorting a Map by keys, using LinkedHashMap and Java Stream
     */
    public static Map<String, Integer> sortingMapByKey(Map<String, Integer> map) {
        LinkedHashMap<String, Integer> sortedMap = map.entrySet()
                .stream()
                .sorted((e1, e2) -> e1.getKey().compareTo(e2.getKey()))
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        Map.Entry::getValue,
                        (e1, e2) -> e1,
                        LinkedHashMap::new));
        return sortedMap;
    }
}
