package org.javabin.demo;

import com.sun.jdi.VoidValue;

import java.lang.management.ManagementFactory;
import java.lang.management.ThreadInfo;
import java.lang.management.ThreadMXBean;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class JavaMultithreadHandsOn {

    public static void main(String[] args) {
        //getAllThreadsInJVM();

        //demoDeadlock();

        //demoNonDeadlock();

        //demoCreateNewThread();

        //demoProducerConsumer();

        //demoThreadState();

        //DaemonThread.testDaemonThread();

        //BlockedInterrupted.testThreadInterrupt();

        //StopSuspendResume.testStopSuspendResume();

        //UncaughtExceptionInThread.testUncaughtExceptionInThread();

        //testDiningPhilosophers();
        //testDiningPhilosophersSynchronized();

        //ReadMostlyData.testReadMostlyData();

        //SemaphoreRestaurant.testSemaphoreRestaurant();

        //MeetAtBarrier.testMeetAtBarrier();

        //StartTogetherByPhaser.testStartTogetherByPhaser();

        //MultiplePhasesSynchronization.testMultiplePhases();

        //ExchangerProducerConsumerTest.testExchangerProducerConsumer();

        ExecutorCallableTest.testExecutorCallableTask();
    }

    /**
     * Demonstrate how to create new thread : By inheriting from the Thread class
     */
    static class MyThread extends Thread {
        @Override
        public void run() {
            System.out.println(Thread.currentThread() + " Hello, MyThread");
        }
    }
    /**
     * Demonstrate how to create new thread : By using the method reference to a method that takes no parameters and returns void
     */
    public static void myMethodRef() {
        System.out.println(Thread.currentThread() + " Hello, Thread with Method Reference");
    }
    public static void demoCreateNewThread() {
        Runnable myRun = () -> System.out.println(Thread.currentThread() + "Hello, Thread with myRun");
        Thread thread1 = new Thread(myRun);
        thread1.start();
        Thread thread2 = new Thread(() -> System.out.println(Thread.currentThread() + " Hello, Thread with myRun 2"));
        thread2.start();
        MyThread myThread = new MyThread();
        myThread.start();
        Thread thread3 = new Thread(JavaMultithreadHandsOn::myMethodRef);
        thread3.start();
    }
    /**
     * Demonstrate how to create new thread : By implementing the Runnable interface in your class
     */
    public static class myRun implements Runnable {
        @Override
        public void run() {
            System.out.println(Thread.currentThread() + " Hello, myRun");
        }
    }

    /**
     * 获取JVM全部线程
     *
     * [5] Attach Listener //添加事件
     * [4] Signal Dispatcher // 分发处理给 JVM 信号的线程
     * [3] Finalizer //调用对象 finalize 方法的线程
     * [2] Reference Handler //清除 reference 线程
     * [1] main //main 线程,程序入口
     */
    public static void getAllThreadsInJVM() {
        // 获取 Java 线程管理 MXBean
        ThreadMXBean threadMXBean = ManagementFactory.getThreadMXBean();
        // 不需要获取同步的 monitor 和 synchronizer 信息，仅获取线程和线程堆栈信息
        ThreadInfo[] threadInfos = threadMXBean.dumpAllThreads(false, false);
        // 遍历线程信息，仅打印线程 ID 和线程名称信息
        for (ThreadInfo threadInfo : threadInfos) {
            System.out.println("[" + threadInfo.getThreadId() + "] " + threadInfo.getThreadName());
        }
    }

    /**
     * Demonstrate the scenario of threads deadlock
     */
    private static Object resource1 = new Object();
    private static Object resource2 = new Object();
    public static void demoDeadlock() {
        new Thread(() -> {
            synchronized (resource1) {
                System.out.println(Thread.currentThread() + " get resource1");
                try {
                    Thread.sleep(10000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println(Thread.currentThread() + " waiting get resource2");
                synchronized (resource2) {
                    System.out.println(Thread.currentThread() + " get resource2");
                }
            }
        }, "Thread-1").start();
        new Thread(() -> {
            synchronized (resource2) {
                System.out.println(Thread.currentThread() + "get resource2");
                try {
                    Thread.sleep(10000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println(Thread.currentThread() + " waiting get resource1");
                synchronized(resource1) {
                    System.out.println(Thread.currentThread() + " get resource1");
                }
            }
        }, "Thread-2").start();
    }
    public static void demoNonDeadlock() {
        new Thread(() -> {
            synchronized (resource1) {
                System.out.println(Thread.currentThread() + " get resource1");
                try {
                    Thread.sleep(10000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println(Thread.currentThread() + " waiting get resource2");
                synchronized (resource2) {
                    System.out.println(Thread.currentThread() + " get resource2");
                }
            }
        }, "Thread-1").start();
        new Thread(() -> {
            synchronized (resource1) {
                System.out.println(Thread.currentThread() + "get resource2");
                try {
                    Thread.sleep(10000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println(Thread.currentThread() + " waiting get resource1");
                synchronized(resource2) {
                    System.out.println(Thread.currentThread() + " get resource1");
                }
            }
        }, "Thread-2").start();
    }



    /**
     * Demonstrate Producer and Consumer Synchronization problem : mutual exclusion synchronization
     */
    static class DataBuffer {
        private int data;
        private boolean empty;

        public synchronized void produce(int data) {
            while(!this.empty) {
                try {
                    this.wait();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
            this.data = data;
            this.empty = false;
            this.notify();
            System.out.println("Produced new data : " + data);
        }

        public synchronized void consume() {
            while(this.empty) {
                try {
                    this.wait();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
            System.out.println("Consumed the data : " + this.data);
            this.empty = true;
            this.notify();
        }
    }

    /**
     * Demonstrate Producer and Consumer Synchronization problem : conditional synchronization
     */
    static class DataQueue extends DataBuffer {
        private Queue<Integer> queue = new LinkedList<Integer>();
        private int capacity;
        public DataQueue(int capacity) {
            this.capacity = capacity;
        }
        @Override
        public synchronized void produce(int data) {
            while(queue.size() >= capacity) {
                try {
                    this.wait();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
            queue.add(data);
            this.notify();
            System.out.println("Produced new data : " + data);
        }

        public synchronized void consume() {
            while(queue.size() == 0) {
                try {
                    this.wait();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
            Integer data = queue.remove();
            System.out.println("Consumed the data : " + data);
            this.notify();
        }
    }

    static class Producer extends Thread {
        private DataBuffer buffer;
        public Producer(DataBuffer buffer) {
            this.buffer = buffer;
        }

        @Override
        public void run() {
            Random random = new Random();
            while(true) {
                int data = random.nextInt();
                buffer.produce(data);
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
    static class Consumer extends Thread {
        private DataBuffer buffer;

        public Consumer(DataBuffer buffer) {
            this.buffer = buffer;
        }

        @Override
        public void run() {
            while(true) {
                buffer.consume();
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
    public static void demoProducerConsumer() {
        //DataBuffer dataBuffer = new DataBuffer();
        DataQueue dataQueue = new DataQueue(5);
        new Producer(dataQueue).start();
        new Consumer(dataQueue).start();
    }

    /**
     * Demonstrate the Thread in different states
     *
     * Result :
     * Before start()-ts.isAlive():false
     * #1:NEW
     * After start()-ts.isAlive():true
     * #2:RUNNABLE
     * #3:WAITING
     * #4:RUNNABLE
     * #5:TERMINATED
     * At the end. ts.isAlive():false
     */
    public static void demoThreadState() {
        Object syncObject = new Object();
        ThreadState ts = new ThreadState(syncObject);
        System.out.println("Before start()-ts.isAlive():" + ts.isAlive());
        System.out.println("#1:" + ts.getState());

        // Start the thread
        ts.start();
        System.out.println("After start()-ts.isAlive():" + ts.isAlive());
        System.out.println("#2:" + ts.getState());
        ts.setWait(true);

        // Make the current thread sleep before testing the WAITING state
        sleepNow(100);

        /**
         * obtain the monitor of syncObject after the ts thread called the wait() method
         */
        synchronized (syncObject) {
            System.out.println("#3:" + ts.getState());
            ts.setWait(false);

            // Wake up the waiting thread
            syncObject.notifyAll();
        }

        // Make the current thread sleep before testing the RUNNABLE state
        sleepNow(2000);
        System.out.println("#4:" + ts.getState());
        ts.setKeepRunning(false);

        // Make the current thread sleep before testing the TERMINATED state
        sleepNow(2000);
        System.out.println("#5:" + ts.getState());
        System.out.println("At the end. ts.isAlive():" + ts.isAlive());
    }

    /**
     * Demonstrate the Thread in different states
     */
    static class ThreadState extends Thread {
        private boolean keepRunning = true;
        private boolean wait = false;
        private Object syncObject = null;

        public ThreadState(Object syncObject) {
            this.syncObject = syncObject;
        }

        public void run() {
            while (keepRunning) {
                synchronized (syncObject) {
                    if (wait) {
                        try {
                            syncObject.wait();
                        }
                        catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }

        public void setKeepRunning(boolean keepRunning) {
            this.keepRunning = keepRunning;
        }

        public void setWait(boolean wait) {
            this.wait = wait;
        }
    }

    public static void sleepNow(long millis) {
        try {
            Thread.currentThread().sleep(millis);
        }
        catch (InterruptedException e) {
        }
    }

    public static void sleepNowWithRandom(int bound) {
        int sleepTime = new Random().nextInt(bound) + 1;
        sleepNow(sleepTime * 1000);
    }

    /**
     * Demonstrate the feature of Daemon Thread : When JVM detects that all threads in an application are only daemon threads, it exits the application
     * Usage : DaemonThread.testDaemonThread();
     *
     * Result :
     * Exiting main method
     * Counter:1
     */
    static class DaemonThread {
        public static void testDaemonThread() {
            Thread t = new Thread(DaemonThread::print);
            t.setDaemon(true);
            t.start();
            System.out.println("Exiting main method");
        }

        public static void testNonDaemonThread() {
            Thread t = new Thread(DaemonThread::print);
            t.setDaemon(false);
            t.start();
            System.out.println("Exiting main method");
        }

        public static void print() {
            int counter = 1 ;
            while(true) {
                try {
                    System.out.println("Counter:" + counter++);
                    Thread.sleep(2000); // sleep for 2 seconds
                }
                catch(InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * Demonstrate Thread Interrupt
     * Usage : BlockedInterrupted.testThreadInterrupt()
     *
     * Result :
     * Thread.currentThread().isInterrupted() = false
     * Thread.interrupted() = false
     * Counter:1
     * Counter:2
     * Counter:3
     * Counter:4
     * I got interrupted!
     * Thread.currentThread().isInterrupted() = false
     * Thread.interrupted() = false
     */
    static class BlockedInterrupted {
        public static void testThreadInterrupt() {
            Thread t = new Thread(BlockedInterrupted::run);
            t.start();
            // main thread sleeps for 5 seconds
            sleepNow(5000);

            /**
             * Interrupt the sleeping thread : this will not change the interrupt status
             */
            t.interrupt();
        }

        public static void run() {
            /**
             * The interrupted status will NOT be cleared after called isInterrupted() instance method
             */
            System.out.println("Thread.currentThread().isInterrupted() = " + Thread.currentThread().isInterrupted());
            /**
             * The interrupted status will be cleared after called Thread.interrupted() static method
             */
            System.out.println("Thread.interrupted() = " + Thread.interrupted());

            int counter = 1;
            while (true) {
                try {
                    Thread.sleep(1000);
                    System.out.println("Counter:" + counter++);
                }
                catch (InterruptedException e) {
                    System.out.println("I got interrupted!");
                    System.out.println("Thread.currentThread().isInterrupted() = " + Thread.currentThread().isInterrupted());
                    System.out.println("Thread.interrupted() = " + Thread.interrupted());
                    // Terminate the thread by returning
                    return;
                }
            }
        }
    }

    /**
     * Demonstrate the volatile variable in Thread
     *
     * A thread does not cache the value of a volatile variable in its working memory.
     * At the start and at the end of a synchronized method/block, the values of the volatile variable in thread’s working memory and the main memory are synchronized
     */
    static class VolatileVariable extends Thread {
        private volatile boolean keepRunning = true;

        public void run() {
            System.out.println("Thread started...");
            // keepRunning is volatile. So, for every read, the thread reads its
            // latest value from the main memory, instead of the working memory
            while (keepRunning) {
                System.out.println("Going to sleep ...");
                sleepNow(3000);
            }
            System.out.println("Thread stopped...");
        }

        public void stopThread() {
            this.keepRunning = false;
        }

        public static void testVolatileVariable() {
            // Create the thread
            VolatileVariable vv = new VolatileVariable();
            // Start the thread
            vv.start();
            // Let the main thread sleep for 3 seconds
            sleepNow(3000);
            // Stop the thread
            System.out.println("Going to set the stop flag to true...");
            vv.stopThread();
        }
    }

    /**
     * Demonstrate how to stop, suspend and resume a Thread without calling the error-prone methods stop(), suspend(), resume()
     * Simulate the stop, suspend and resume actions by using wait, sleep, notify/notifyAll methods + flag variables
     *
     * Usage :
     * StopSuspendResume.testStopSuspendResume()
     *
     * Result :
     * Thread started...
     * Going to sleep...
     * Going to sleep...
     * Going to sleep...
     * Suspended...
     * Resumed...
     * Going to sleep...
     * Going to sleep...
     * Thread stopped...
     */
    static class StopSuspendResume extends Thread {
        private volatile boolean keepRunning = true;
        private boolean suspended = false;

        public synchronized void stopThread() {
            this.keepRunning = false;
            // Notify the thread in case it is suspended when this method
            // is called, so  it will wake up and stop.
            this.notify();

            /**
             * Force stop Thread by calling interrupt method, to avoid the case that Thread is blocked on other monitor
             */
            this.interrupt();
        }

        public synchronized void suspendThread() {
            this.suspended = true;
        }

        public synchronized void resumeThread() {
            this.suspended = false;
            this.notify();
        }

        public void run() {
            System.out.println("Thread started...");
            while (keepRunning) {
                try {
                    System.out.println("Going to sleep...");
                    Thread.sleep(1000);

                    // Check for a suspended condition must be made inside a
                    // synchronized block to call the wait() method
                    synchronized (this) {
                        while (suspended) {
                            System.out.println("Suspended...");
                            this.wait();
                            System.out.println("Resumed...");
                        }
                    }
                }
                catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            System.out.println("Thread stopped...");
        }

        public static void testStopSuspendResume() {
            StopSuspendResume t = new StopSuspendResume();
            // Start the thread
            t.start();
            // Sleep for 2 seconds
            sleepNow(2000);
            // Suspend the thread
            t.suspendThread();
            // Sleep for 2 seconds
            sleepNow(2000);
            // Resume the thread
            t.resumeThread();
            // Sleep for 2 seconds
            sleepNow(2000);
            // Stop the thread
            t.stopThread();
        }
    }

    /**
     * Demonstrate how to set Uncaught Exception Handler for a Thread
     *
     * Usage :
     * UncaughtExceptionInThread.testUncaughtExceptionInThread();
     */
    static class UncaughtExceptionInThread {
        public static void testUncaughtExceptionInThread() {
            // Set an uncaught exception handler for main thread
            Thread.currentThread().setUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
                public void uncaughtException(Thread t, Throwable e) {
                    System.out.println("Caught Exception from Thread:" + t.getName());
                }
            });
            // Throw an exception
            throw new RuntimeException();
        }
    }
    static class CatchAllThreadExceptionHandler implements Thread.UncaughtExceptionHandler {
        public void uncaughtException(Thread t, Throwable e) {
            System.out.println("Caught Exception from Thread:" + t.getName());
        }
    }

    /**
     * Demonstrate the dining-philosophers problem using the explicit lock constructs : Lock(interface) and ReentrantLock(implementation class)
     */
    public static void testDiningPhilosophers() {
        /**
         * Lock nonFairLock1 = new ReentrantLock(); // A non-fair lock (Default is non-fair)
         * Lock nonFairLock2 = new ReentrantLock(false); // A non-fair lock
         * Lock fairLock2 = new ReentrantLock(true); // A fair lock
         */
        Lock fork1 = new ReentrantLock();
        Lock fork2 = new ReentrantLock();
        Lock fork3 = new ReentrantLock();
        Lock fork4 = new ReentrantLock();
        Lock fork5 = new ReentrantLock();

        Philosopher p1 = new Philosopher(fork1, fork2, "Philosopher 1");
        Philosopher p2 = new Philosopher(fork2, fork3, "Philosopher 2");
        Philosopher p3 = new Philosopher(fork3, fork4, "Philosopher 3");
        Philosopher p4 = new Philosopher(fork4, fork5, "Philosopher 4");
        Philosopher p5 = new Philosopher(fork5, fork1, "Philosopher 5");

        Thread t1 = new Thread(p1);
        Thread t2 = new Thread(p2);
        Thread t3 = new Thread(p3);
        Thread t4 = new Thread(p4);
        Thread t5 = new Thread(p5);
        t1.start();
        t2.start();
        t3.start();
        t4.start();
        t5.start();
    }
    static class Philosopher extends Thread {
        private Lock leftFork;
        private Lock rightFork;
        private String name; // Philosopher's name
        public Philosopher(Lock leftFork, Lock rightFork, String name) {
            this.leftFork  = leftFork;
            this.rightFork = rightFork;
            this.name = name;
        }

        @Override
        public void run() {
            while (true) {
                this.think();
                this.eat();
            }
        }

        public void think() {
            System.out.println(name + " is thinking...");
            sleepNow(2000);
        }

        public void eat() {
            // Try to get the left fork
            if (leftFork.tryLock()) {
                try {
                    // try to get the right fork
                    if (rightFork.tryLock()) {
                        try {
                            // Got both forks. Eat now
                            System.out.println(name + " is eating...");
                            sleepNow(2000);
                        }
                        finally {
                            // release the right fork
                            rightFork.unlock();
                        }
                    }
                }
                finally {
                    // release the left fork
                    leftFork.unlock();
                }
            }
        }
    }

    /**
     * Demonstrate the dining-philosophers problem using synchronized keyword
     */
    public static void testDiningPhilosophersSynchronized() {
        Object fork1 = new Object();
        Object fork2 = new Object();
        Object fork3 = new Object();
        Object fork4 = new Object();
        Object fork5 = new Object();

        PhilosopherSynchronized p1 = new PhilosopherSynchronized(fork1, fork2, "Philosopher 1", 1);
        PhilosopherSynchronized p2 = new PhilosopherSynchronized(fork2, fork3, "Philosopher 2", 2);
        PhilosopherSynchronized p3 = new PhilosopherSynchronized(fork3, fork4, "Philosopher 3", 3);
        PhilosopherSynchronized p4 = new PhilosopherSynchronized(fork4, fork5, "Philosopher 4", 4);
        PhilosopherSynchronized p5 = new PhilosopherSynchronized(fork5, fork1, "Philosopher 5", 5);

        Thread t1 = new Thread(p1);
        Thread t2 = new Thread(p2);
        Thread t3 = new Thread(p3);
        Thread t4 = new Thread(p4);
        Thread t5 = new Thread(p5);
        t1.start();
        t2.start();
        t3.start();
        t4.start();
        t5.start();
    }
    static class PhilosopherSynchronized extends Thread {
        private Object leftFork;
        private Object rightFork;
        private String name;
        private int id;
        public PhilosopherSynchronized(Object leftFork, Object rightFork, String name, int id) {
            this.leftFork = leftFork;
            this.rightFork = rightFork;
            this.name = name;
            this.id = id;
        }

        @Override
        public void run() {
            while (true) {
                this.think();
                this.eat();
            }
        }

        public void think() {
            System.out.println(name + " is thinking...");
            sleepNow(2000);
        }

        /**
         * To avoid deadlock problem, philosopher whose id is even number should pick up left fork first, whereas philosopher whose id is odd number should pick up right fork first
         */
        public void eat() {
            if(id % 2 == 0) {
                synchronized (leftFork) {
                    synchronized (rightFork) {
                        System.out.println(name + " is eating...");
                        sleepNow(2000);
                    }
                }
            } else {
                synchronized (rightFork) {
                    synchronized (leftFork) {
                        System.out.println(name + " is eating...");
                        sleepNow(2000);
                    }
                }
            }
        }
    }

    /**
     * Demonstrate a Read-Mostly Data Structure using ReentrantReadWriteLock
     */
    static class ReadMostlyData {
        private int value;
        private ReentrantReadWriteLock rwLock = new ReentrantReadWriteLock();
        private Lock rLock = rwLock.readLock();
        private Lock wLock = rwLock.writeLock();

        public ReadMostlyData(int value) {
            this.value = value;
        }

        public int getValue() {
            // Use the read lock, so multiple threads may read concurrently
            rLock.lock();
            try {
                return this.value;
            } finally {
                rLock.unlock();
            }
        }

        public void setValue(int value) {
            // Use the write lock, so only one thread can write at a time
            wLock.lock();
            try {
                this.value = value;
            } finally {
                wLock.unlock();
            }
        }

        public static void testReadMostlyData() {
            ReadMostlyData data = new ReadMostlyData(10);
            new DataReader(data).start();
            new DataReader(data).start();
            new DataWriter(data).start();
            new DataReader(data).start();
            new DataReader(data).start();
            new DataWriter(data).start();
            new DataReader(data).start();
        }

        static class DataReader extends Thread {
            private ReadMostlyData data;
            public DataReader(ReadMostlyData data) {
                this.data = data;
            }
            @Override
            public void run() {
                while (true) {
                    LocalTime now = LocalTime.now();
                    int dataValue = data.getValue();
                    System.out.println(now + " - Thread " +  Thread.currentThread() + " read data : " + dataValue);
                    sleepNow(2000);
                }
            }
        }

        static class DataWriter extends Thread {
            private ReadMostlyData data;
            public DataWriter(ReadMostlyData data) {
                this.data = data;
            }
            @Override
            public void run() {
                while (true) {
                    int dataValue = new Random().nextInt(30);
                    LocalTime now = LocalTime.now();
                    data.setValue(dataValue);
                    System.out.println(now + " - Thread " +  Thread.currentThread() + " write data : " + dataValue);
                    sleepNow(2000);
                }
            }
        }
    }

    /**
     * Demonstrate how to use Semaphore (Synchronizer) and allow N threads to access resources
     */
    static class SemaphoreRestaurant {
        private Semaphore tables;

        public SemaphoreRestaurant(int tablesCount) {
            // Create a semaphore using number of tables we have
            this.tables = new Semaphore(tablesCount);
        }

        public void getTable(int customerID) {
            try {
                System.out.println("Customer #" + customerID + " is trying to get a table.");
                // Acquire a permit for a table
                tables.acquire();
                System.out.println("Customer #" + customerID + " got a table.");
            }
            catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        public void returnTable(int customerID) {
            System.out.println("Customer #" + customerID + " returned a table.");
            tables.release();
        }

        public static void testSemaphoreRestaurant() {
            // Create a restaurant with two dining tables
            SemaphoreRestaurant restaurant = new SemaphoreRestaurant(2);

            // Create five customers
            for (int i = 1; i <= 5; i++) {
                RestaurantCustomer c = new RestaurantCustomer(restaurant, i);
                c.start();
            }
        }

        static class RestaurantCustomer extends Thread {
            private SemaphoreRestaurant r;
            private int customerID;
            private static final Random random = new Random();

            public RestaurantCustomer(SemaphoreRestaurant r, int customerID) {
                this.r = r;
                this.customerID = customerID;
            }

            public void run() {
                r.getTable(this.customerID); // Get a table
                try {
                    // Eat for some time. Use number between 1 and 30 seconds
                    int eatingTime = random.nextInt(30) + 1 ;
                    System.out.println("Customer #" + this.customerID +
                            " will eat for " + eatingTime +
                            " seconds.");
                    Thread.sleep(eatingTime * 1000);
                    System.out.println("Customer #" + this.customerID +
                            " is done eating.");
                } catch(InterruptedException e) {
                    e.printStackTrace();
                } finally {
                    r.returnTable(this.customerID);
                }
            }
        }
    }

    /**
     * Demonstrate how to use Barrier, BarrierAction, CyclicBarrier (Synchronizer) and make a group of threads meeting at a barrier point and execute a barrier action.
     *
     * class CyclicBarrier is reusable.
     */
    static class MeetAtBarrier extends Thread {
        private CyclicBarrier barrier;
        private int ID;
        private static Random random = new Random();

        public MeetAtBarrier(int ID, CyclicBarrier barrier) {
            this.ID = ID;
            this.barrier = barrier;
        }

        public void run() {
            try {
                // Generate a random number between 1 and 30 to wait
                int workTime = random.nextInt(30) + 1;
                System.out.println("Thread #" + ID + " is going to work for " + workTime + " seconds");
                sleepNow(workTime * 1000);
                System.out.println("Thread #" + ID + " is waiting at the barrier...");
                /**
                 * Wait at barrier for other threads in group to arrive.
                 * If a thread times out, or it is interrupted while waiting at the barrier point, the barrier is considered broken.
                 * The thread that times out is released with a TimeoutException, whereas all waiting threads at the barrier are released with a BrokenBarrierException.
                 *
                 * Tip: the await() method of the CyclicBarrier class returns the arrival index of the thread calling it. the last thread
                 *      to arrive at the barrier has an index of zero and the first has an index of the number of threads in the group minus one.
                 *      You can use this index to do any special processing in your program. For example, the last thread to arrive at the barrier
                 *      may log the time when a particular round of computation is finished by all participating threads.
                 */
                int awaitId = this.barrier.await(30, TimeUnit.SECONDS);
                System.out.println("Thread #" + ID + " with await id [" + awaitId + "] passed the barrier...");
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (BrokenBarrierException e) {
                System.out.println(Thread.currentThread() + " got exception - Barrier is broken...");
            } catch (TimeoutException e) {
                System.out.println(Thread.currentThread() + " is timeout...");
            }
        }

        public static void testMeetAtBarrier() {
            // Create a barrier for a group of three threads with a barrier action
            Runnable barrierAction = () -> System.out.println("We are all together. It's party time...");
            CyclicBarrier barrier = new CyclicBarrier(3, barrierAction);
            for (int i = 1; i <= 3; i++) {
                MeetAtBarrier t = new MeetAtBarrier(i, barrier);
                t.start();
            }
        }
    }

    /**
     * Demonstrate how to start multiple tasks together using Phaser (Synchronizer)
     */
    static class StartTogetherByPhaser {
        public static void testStartTogetherByPhaser() {
            // Start with 1 registered party
            Phaser phaser = new Phaser(1);
            // Let us start three tasks
            final int TASK_COUNT = 3;
            for(int i = 1; i <= TASK_COUNT; i++) {
                // Register a new party with the phaser for each task
                phaser.register();

                // Now create the task and start it
                String taskName = "Task #" + i;
                StartTogetherTask task = new StartTogetherTask(taskName, phaser);
                task.start();
            }
            // Now, deregister the self, so all tasks can advance
            phaser.arriveAndDeregister();
        }

        /**
         * not use controller party
         */
        public static void testStartTogetherByPhaser2() {
            // Start with 0 registered party
            Phaser phaser = new Phaser();
            // Let’s start three tasks
            final int TASK_COUNT = 3;
            // Initialize all tasksa in one go
            phaser.bulkRegister(TASK_COUNT);
            for(int i = 1; i <= TASK_COUNT; i++) {
                // Now create the task and start it
                String taskName = "Task #" + i;
                StartTogetherTask task = new StartTogetherTask(taskName, phaser);
                task.start();
            }
        }

        static class StartTogetherTask extends Thread {
            private Phaser phaser;
            private String taskName;
            private static Random rand = new Random();

            public StartTogetherTask(String taskName, Phaser phaser) {
                this.taskName = taskName;
                this.phaser = phaser;
            }

            @Override
            public void run() {
                System.out.println(taskName + ":Initializing...");
                // Sleep for some time between 1 and 5 seconds
                int sleepTime = rand.nextInt(5) + 1;
                try {
                    Thread.sleep(sleepTime * 1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println(taskName + ":Initialized...");
                // Wait for all parties to arrive to start the task
                phaser.arriveAndAwaitAdvance();
                System.out.println(taskName + ":Started...");
            }
        }
    }

    /**
     * Demonstrate how the Phaser works in multiple phases by synchronizing multiple parties in each phase.
     * Multiple tasks generate random integers in each phase and add them to a List, and after the Phaser is terminated, the program computes the sum of all the randomly generated integers.
     */
    static class MultiplePhasesSynchronization {
        public static void testMultiplePhases() {
            final int PHASE_COUNT = 2;
            Phaser phaser
                    = new Phaser() {
                public boolean onAdvance(int phase, int parties) {
                    // Print the phaser details
                    System.out.println("Phase:" + phase
                            + ", Parties:" + parties
                            + ", Arrived:" + this.getArrivedParties());
                    boolean terminatePhaser = false;

                    // Terminate the phaser when we reach the PHASE_COUNT
                    // or there is no registered party
                    if (phase >= PHASE_COUNT - 1 || parties == 0) {
                        terminatePhaser = true;
                    }

                    return terminatePhaser;
                }
            };

            // Use a synchronized List
            List<Integer> list = Collections.synchronizedList(new ArrayList<Integer>());

            // Let us start three tasks
            final int ADDER_COUNT = 3;

            // Register parties one more than the number of adder tasks.
            // The extra party will synchronize to compute the result of
            // all generated integers by all adder tasks
            phaser.bulkRegister(ADDER_COUNT + 1);
            for (int i = 1; i <= ADDER_COUNT; i++) {
                // Create the task and start it
                String taskName = "Task #" + i;
                AdderTask task = new AdderTask(taskName, phaser, list);
                task.start();
            }

            // Wait for the phaser to terminate, so we can compute the sum
            // of all generated integers by the adder tasks
            while (!phaser.isTerminated()) {
                // The extra party waits all other parties arrive and then advance all to the next phase
                phaser.arriveAndAwaitAdvance();
            }

            // Phaser is terminated now. Compute the sum
            int sum = 0;
            for (Integer num : list) {
                sum = sum + num;
            }

            System.out.println("Sum = " + sum);
        }

        static class AdderTask extends Thread {
            private Phaser phaser;
            private String taskName;
            private List<Integer> list;
            private static Random rand = new Random();

            public AdderTask(String taskName, Phaser phaser, List<Integer> list) {
                this.taskName = taskName;
                this.phaser = phaser;
                this.list = list;
            }

            @Override
            public void run() {
                do {
                    // Generate a random integer between 1 and 10
                    int num = rand.nextInt(10) + 1;
                    System.out.println(taskName + " added " + num);
                    // Add the integer to the list
                    list.add(num);
                    // Wait for all parties to arrive at the phaser
                    phaser.arriveAndAwaitAdvance();
                } while (!phaser.isTerminated());
            }
        }
    }

    /**
     * Demonstrate how to implement one-time barrier using Latch (Synchronizer)
     */
    static class LatchTest {
        public static void testLatch() {
            // Create a countdown latch with 2 as its counter
            CountDownLatch latch = new CountDownLatch(2);
            // Create and start the main service
            LatchMainService ms = new LatchMainService(latch);
            ms.start();
            // Create and start two helper services
            for (int i = 1; i <= 2; i++) {
                LatchHelperService lhs = new LatchHelperService(i, latch);
                lhs.start();
            }
        }

        static class LatchMainService extends Thread {
            private CountDownLatch latch;

            public LatchMainService(CountDownLatch latch) {
                this.latch = latch;
            }

            public void run() {
                try {
                    System.out.println("Main service is waiting for helper services to start...");
                    latch.await();
                    System.out.println("Main service has started...");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }

        static class LatchHelperService extends Thread {
            private int ID;
            private CountDownLatch latch;
            private Random random = new Random();

            public LatchHelperService(int ID, CountDownLatch latch) {
                this.ID = ID;
                this.latch = latch;
            }

            public void run() {
                try {
                    int startupTime = random.nextInt(30) + 1;

                    System.out.println("Service #" + ID + " starting in "
                            + startupTime + " seconds...");
                    Thread.sleep(startupTime * 1000);
                    System.out.println("Service #" + ID + " has started...");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } finally {
                    // Count down on the latch to indicate that it has started
                    this.latch.countDown();
                }
            }
        }
    }

    /**
     * Demonstrate how the Exchanger lets two threads wait for each other at a synchronization point and exchange an object then continue their activities.
     */
    static class ExchangerProducerConsumerTest {
        public static void testExchangerProducerConsumer() {
            Exchanger<ArrayList<Integer>> exchanger = new Exchanger<>();
            // The producer will produce 5 integers at a time
            ExchangerProducer producer = new ExchangerProducer(exchanger, 5);
            ExchangerConsumer consumer = new ExchangerConsumer(exchanger);
            producer.start();
            consumer.start();
        }

        static class ExchangerProducer extends Thread {
            private Exchanger<ArrayList<Integer>> exchanger;
            private ArrayList<Integer> buffer = new ArrayList<Integer>();
            private int bufferLimit;
            private Random random = new Random();
            private int currentValue = 0; // to produce values

            public ExchangerProducer(Exchanger<ArrayList<Integer>> exchanger,
                                     int bufferLimit) {
                this.exchanger = exchanger;
                this.bufferLimit = bufferLimit;
            }

            public void run() {
                // keep producing integers
                while (true) {
                    try {
                        System.out.println("Producer is filling the buffer with data...");
                        // Wait for some time by sleeping
                        sleepNowWithRandom(20);
                        // Fill the buffer
                        this.fillBuffer();
                        System.out.println("Producer has produced:" + buffer);
                        // Let us wait for the consumer to exchange data
                        System.out.println("Producer is waiting to exchange the data...");
                        buffer = exchanger.exchange(buffer);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }

            public void fillBuffer() {
                for (int i = 1; i <= bufferLimit; i++) {
                    buffer.add(++currentValue);
                }
            }
        }

        static class ExchangerConsumer extends Thread {
            private Exchanger<ArrayList<Integer>> exchanger;
            private ArrayList<Integer> buffer = new ArrayList<Integer>();
            private Random random = new Random();

            public ExchangerConsumer(Exchanger<ArrayList<Integer>> exchanger) {
                this.exchanger = exchanger;
            }

            public void run() {
                // keep consuming the integers
                while (true) {
                    try {
                        // Let us wait for the consumer to exchange data
                        System.out.println("Consumer is waiting to exchange the data...");
                        buffer = exchanger.exchange(buffer);
                        System.out.println("Consumer has received:" + buffer);
                        System.out.println("Consumer is emptying data from the buffer...");
                        // Wait for some time by sleeping
                        sleepNowWithRandom(20);
                        // Empty the buffer
                        this.emptyBuffer();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }

            public void emptyBuffer() {
                buffer.clear();
            }
        }
    }

    /**
     * Demonstrate how to use Executor Framework with Runnable task
     */
    static class ExecutorRunnableTest {
        public static void testRunnableTask() {
            final int THREAD_COUNT = 3;
            final int LOOP_COUNT = 3;
            final int TASK_COUNT = 5;
            // Get an executor with three threads in its thread pool
            ExecutorService exec = Executors.newFixedThreadPool(THREAD_COUNT);
            // Create five tasks and submit them to the executor
            for(int i = 1; i <= TASK_COUNT; i++) {
                RunnableTask task = new RunnableTask(i, LOOP_COUNT);
                exec.submit(task);
            }
            // Let us shutdown the executor
            exec.shutdown();
        }

        /**
         * Implement task using Runnable interface
         */
        static class RunnableTask implements Runnable {
            private int taskId;
            private int loopCounter;
            private Random random = new Random();

            public RunnableTask(int taskId, int loopCounter) {
                this.taskId = taskId;
                this.loopCounter = loopCounter;
            }

            public void run() {
                for(int i = 1; i <= loopCounter; i++) {
                    try {
                        int sleepTime = random.nextInt(10) + 1;
                        System.out.println("Task #" + this.taskId + " - Iteration #" + i + " is going to sleep for " + sleepTime + " seconds.");
                        Thread.sleep(sleepTime * 1000);
                    } catch(Exception e) {
                        System.out.println("Task #" + this.taskId + " has been interrupted.");
                        break;
                    }
                }
            }
        }
    }

    /**
     * Demonstrate how to use Executor Framework with Callable task
     */
    static class ExecutorCallableTest {
        public static void testExecutorCallableTask() {
            // Get an executor with three threads in its thread pool
            ExecutorService exec = Executors.newFixedThreadPool(3);
            // Create the callable task with loop counter as 3
            CallableTask task = new CallableTask(1, 3);
            // Submit the callable task to executor
            Future<Integer> submittedTask = exec.submit(task);
            try {
                Integer result = submittedTask.get();
                System.out.println("Task's total sleep time: " + result + " seconds");
            } catch (ExecutionException e) {
                System.out.println("Error in executing the task.");
            }  catch (InterruptedException e) {
                System.out.println("Task execution has been interrupted.");
            }
            // Let us shutdown the executor
            exec.shutdown();
        }

        /**
         * Implement task using Callable interface which has the method call() that can return result
         */
        static class CallableTask implements Callable<Integer> {
            private int taskId  ;
            private int loopCounter  ;
            private Random random = new Random();

            public CallableTask(int taskId, int loopCounter) {
                this.taskId = taskId;
                this.loopCounter = loopCounter;
            }

            public Integer call() throws InterruptedException {
                int totalSleepTime = 0 ;
                for (int i = 1; i <= loopCounter; i++) {
                    try {
                        int sleepTime = random.nextInt(10) + 1;
                        System.out.println("Task #" + this.taskId + " - Iteration #" + i + " is going to sleep for " + sleepTime + " seconds.");
                        Thread.sleep(sleepTime * 1000);
                        totalSleepTime = totalSleepTime + sleepTime;
                    } catch(InterruptedException e) {
                        System.out.println("Task #" + this.taskId + " has been interupted.");
                        throw e;
                    }
                }
                return totalSleepTime;
            }
        }
    }

    /**
     * Demonstrate how to schedule a task that will run in the future, using the ScheduledExecutorService interface
     */
    static class ScheduledTaskTest {
        public static void testScheduledTask() {
            // Get an executor with 3 threads
            ScheduledExecutorService sexec = Executors.newScheduledThreadPool(3);
            // Task #1 and Task #2
            ScheduledTask task1 = new ScheduledTask(1);
            ScheduledTask task2 = new ScheduledTask(2);
            // Task #1 will run after 2 seconds
            sexec.schedule(task1, 2, TimeUnit.SECONDS);

            // Task #2 runs after 5 seconds delay and keep running every 10 seconds
            sexec.scheduleAtFixedRate(task2, 5, 10, TimeUnit.SECONDS);

            // Let the current thread sleep for 60 seconds and shut down the executor that will cancel the task #2 because it is scheduled to run after every 10 seconds
            try {
                TimeUnit.SECONDS.sleep(60);
            } catch(InterruptedException e) {
                e.printStackTrace();
            }
            // Shut down the executor
            sexec.shutdown();
        }

        static class ScheduledTask implements Runnable {
            private int taskId;

            public ScheduledTask(int taskId) {
                this.taskId = taskId;
            }

            public void run() {
                LocalDateTime currentDateTime = LocalDateTime.now();
                System.out.println("Task #" + this.taskId + " ran at " + currentDateTime);
            }
        }
    }
}
