package org.javabin.demo;

import java.util.Arrays;

public class JavaReverseLinkedList {
    static class Node <T> {
        private T value;
        public Node next;

        public Node(T value) {
            this.value = value;
            this.next = null;
        }

        public T getValue() {
            return value;
        }

        public void setValue(T value) {
            this.value = value;
        }

        @Override
        public String toString() {
            return "Node{" +
                    "value=" + value +
                    '}';
        }
    }

    private static void printLinkedList(Node head) {
        Node currNode = head;
        while(currNode != null) {
            System.out.print(currNode + "\t");
            currNode = currNode.next;
        }
        System.out.println();
    }

    private static Node reverseLinkedList(Node head) {
        Node prevNode = null;
        Node currNode = head;
        Node nextNode = null;
        while(currNode != null) {
            nextNode = currNode.next;
            currNode.next = prevNode;
            prevNode = currNode;
            currNode = nextNode;
        }
        return prevNode;
    }

    public static void main(String[] args) {
        int[] num = {4, 3, 6, 1, 8, 7, 5, 12, 90};
        Integer[] intArray = Arrays.stream(num).boxed().toArray(Integer[]::new);
        Node prev = null;
        Node head = null;
        for (Integer intNum : intArray) {
            Node node = new Node(intNum);
            if(head == null) {
                head = node;
            } else {
                prev.next = node;
            }
            prev = node;
        }

        printLinkedList(head);
        Node reversedHead = reverseLinkedList(head);
        printLinkedList(reversedHead);
    }
}
