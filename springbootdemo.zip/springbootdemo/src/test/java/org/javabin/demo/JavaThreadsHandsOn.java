package org.javabin.demo;

public class JavaThreadsHandsOn {
    public void ThreadHandsOn() {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                System.out.println("This is a new thread : " + Thread.currentThread().toString());
            }
        });
        thread.start();

        Thread thread2 = new Thread(new RunThread());
        thread2.start();

        Thread thread3 = new Thread(RunThread::execute);
        thread3.start();
    }

    class RunThread implements Runnable {
        @Override
        public void run() {
            System.out.println("This is the 2nd new thread : " + Thread.currentThread().toString());
        }

        public static void execute() {
            System.out.println("This is the 3rd new thread with execute running : " + Thread.currentThread().toString());
        }
    }

    public static void main(String[] args) {
        JavaThreadsHandsOn app = new JavaThreadsHandsOn();
        app.ThreadHandsOn();
    }
}
