package org.javabin.demo;

import java.util.Arrays;
import java.util.stream.Collectors;

public class JavaAlgorithmHandsOn {
    public static void main(String[] args) {
        int[] arr = {1, 20, -6, 18, 9, 12, -20, 28, 15, 17};
        /*binarySearch(10, 0, arr.length - 1, arr);*/

        /*int[] sortedArr = mergeSorting(0, arr.length - 1, arr);
        Arrays.stream(sortedArr).forEach(i -> System.out.print(i + "\t"));*/

        /*int kthSmallestNumber = findKthSmallestNumber(arr, 4);
        System.out.println("kthSmallestNumber = " + kthSmallestNumber);*/

        /*quickSort(arr, 0, arr.length - 1);
        printIntArray(arr);*/
        printIntArray(arr);
        insertionSort(arr);
        printIntArray(arr);
    }

    private static void printIntArray(int[] arr) {
        String arrStr = Arrays.stream(arr).mapToObj(String::valueOf).collect(Collectors.joining(", "));
        System.out.println("arr = " + arrStr);
    }

    /**
     * Quick Sort
     *
     * int[] arr = {1, 20, -6, 18, 9, 12, -20, 28, 15, 17};
     * pivot : 17,	arr = 1, -6, 9, 12, -20, 15, 17, 28, 18, 20
     * pivot : 15,	arr = 1, -6, 9, 12, -20, 15, 17, 28, 18, 20
     * pivot : -20,	arr = -20, -6, 9, 12, 1, 15, 17, 28, 18, 20
     * pivot : 1,	arr = -20, -6, 1, 12, 9, 15, 17, 28, 18, 20
     * pivot : 9,	arr = -20, -6, 1, 9, 12, 15, 17, 28, 18, 20
     * pivot : 20,	arr = -20, -6, 1, 9, 12, 15, 17, 18, 20, 28
     * arr = -20, -6, 1, 9, 12, 15, 17, 18, 20, 28
     *
     * Best Case:
     * Occurs when the pivot divides the array into two nearly equal parts.
     * Each recursive call processes half the elements.
     * Time complexity: O(n log n).
     *
     * Average Case:
     * On average, the pivot will not perfectly split the array but still results in logarithmic recursive levels.
     * Time complexity: O(n log n).
     *
     * Worst Case:
     * Occurs when the pivot is the smallest or largest element, resulting in one partition with all elements except one.
     * This causes the recursion depth to become n, making the sorting linear in one dimension.
     * Time complexity: O(n²).
     */
    private static void quickSort(int[] arr, int low, int high) {
        if (low < high) {
            // Find the partition index
            int pi = quickSortPartition(arr, low, high);
            // Recursively sort elements before and after partition
            quickSort(arr, low, pi - 1);
            quickSort(arr, pi + 1, high);
        }
    }

    private static int quickSortPartition(int[] arr, int low, int high) {
        int pivot = arr[high]; // Pivot element
        int i = low; // Index of smaller element
        for (int j = low; j < high; j++) {
            // If the current element is smaller than or equal to the pivot
            if (arr[j] <= pivot) {
                // Swap arr[i] and arr[j]
                swapIntArray(arr, i++, j);
            }
        }
        // Swap arr[i+1] and arr[high] (or pivot)
        swapIntArray(arr, i, high);
        System.out.print("pivot : " + pivot + ", ");
        printIntArray(arr);
        return i;
    }

    private static void swapIntArray(int[] nums, int i, int j) {
        int temp = nums[i];
        nums[i] = nums[j];
        nums[j] = temp;
    }

    /**
     * Quick Sort
     *
     * Problem Statement:
     * Given an unsorted array of numbers, find the Kth smallest number in it.
     */
    private static int findKthSmallestNumber(int[] nums, int k) {
        return findKthSmallestNumberRec(nums, k, 0, nums.length - 1);
    }

    public static int findKthSmallestNumberRec(int[] nums, int k, int start, int end) {
        int p = partition(nums, start, end);
        if (p == k - 1) {
            return nums[p];
        }
        if (p > k - 1) {
            // search lower part
            return findKthSmallestNumberRec(nums, k, start, p - 1);
        }
        // search higher part
        return findKthSmallestNumberRec(nums, k, p + 1, end);
    }

    private static int partition(int[] nums, int low, int high) {
        if (low == high) {
            return low;
        }

        int pivot = nums[high];
        for (int i = low; i < high; i++) {
            // all elements less than 'pivot' will be before the index 'low'
            if (nums[i] < pivot) {
                swapIntArray(nums, low++, i);
            }
        }
        // put the pivot in its correct place
        swapIntArray(nums, low, high);
        return low;
    }

    /**
     * Insertion Sort
     */
    public static void insertionSort(int[] arr) {
        for (int i = 1, n = arr.length; i < n; i++) {
            int key = arr[i];
            int j = i - 1;

            // Move elements of arr[0..i-1], that are greater than key,
            // to one position ahead of their current position
            while (j >= 0 && arr[j] > key) {
                arr[j + 1] = arr[j];
                j = j - 1;
            }
            arr[j + 1] = key;
            System.out.print("key = " + key + ", ");
            printIntArray(arr);
        }
    }

    /**
     * Implement a binary search.
     * The array elements must be sorted before performing the binary search.
     *
     * The binary search algorithm is based on the following conditions:
     * If the key is less than the middle element, then you now need to search only in the first half of the array.
     * If the key is greater than the middle element, then you need to search only in the second half of the array.
     * If the key is equal to the middle element in the array, then the search ends.
     * Finally, if the key is not found in the whole array, it indicates that the element is not present.
     */
    private static void binarySearch(int elem, int start, int end, int[] arr) {
        if(start > end) {
            System.out.println(String.format("Failed to find the elem %d",elem));
            return;
        }

        //int mid = (end - start) / 2 + start;
        int mid = (end + start) / 2;
        if(elem == arr[mid]) {
            System.out.println(String.format("Found the elem %d in the index %d",elem, mid));
            return;
        } else if(elem < arr[mid]) {
            binarySearch(elem, start, mid - 1, arr);
        } else if(elem > arr[mid]) {
            binarySearch(elem, mid + 1, end, arr);
        }
    }

    private static void binarySearch2(int elem, int start, int end, int[] arr) {
        int mid = (start + end) / 2;
        while (start <= end) {
            if (arr[mid] < elem) {
                start = mid + 1;
            } else if (arr[mid] == elem) {
                System.out.println(String.format("Found the elem %d in the index %d",elem, mid));
                return;
            } else {
                end = mid - 1;
            }
            mid = (start + end) / 2;
        }

        System.out.println(String.format("Failed to find the elem %d",elem));
        return;
    }

    /**
     * Implement merge sorting.
     *
     * Merge sort is one of the most efficient sorting algorithms.
     * It works on the principle of “divide and conquer”.
     * It is based on the idea of breaking down a list into several sub-lists until each sub-list consists of a single element,
     * and then merging those sub-lists in a manner that results in a sorted list.
     */
    private static int[] mergeSorting(int start, int end, int[] arr) {
        if(start == end) {
            int[] sortedArr = new int[1];
            sortedArr[0] = arr[start];
            return sortedArr;
        }
        int mid = (start + end) / 2;
        int[] sortedArr1 = mergeSorting(start, mid, arr);
        int[] sortedArr2 = mergeSorting(mid + 1, end, arr);
        return mergeTwoSortedArray(sortedArr1, sortedArr2);
    }

    private static int[] mergeTwoSortedArray(int[] arr1, int[] arr2) {
        int len1 = arr1.length;
        int len2 = arr2.length;
        int[] mergedArr = new int[len1 + len2];
        int iArr1 = 0;
        int iArr2 = 0;
        int iMergedArr = 0;

        while(iArr1 < len1 && iArr2 < len2) {
            if(arr1[iArr1] <= arr2[iArr2]) {
                mergedArr[iMergedArr++] = arr1[iArr1++];
            } else {
                mergedArr[iMergedArr++] = arr2[iArr2++];
            }
        }

        if(iArr1 == len1) {
            for (int i = iArr2; i < len2; i++) {
                mergedArr[iMergedArr++] = arr2[i];
            }
        }

        if(iArr2 == len2) {
            for (int i = iArr1; i < len1; i++) {
                mergedArr[iMergedArr++] = arr1[i];
            }
        }

        return mergedArr;
    }
}
