package org.javabin.demo;

import org.javabin.entity.Employee;
import org.javabin.entity.FileStream;
import org.javabin.entity.PrimeProvider;

import java.io.IOException;
import java.time.Month;
import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.regex.Pattern;
import java.util.stream.*;

public class JavaStreamHandsOn {

    public static void main(String[] args) {
        List<Integer> intList = Arrays.asList(2, 3, 5, 1, 7, 9, 5, 8, 10);
        int sumOfSquaredOdd = intList.stream()
                .filter(n -> n % 2 == 1)
                .map(n -> n * n)
                .reduce(0, Integer::sum);
        sumOfSquaredOdd = intList.stream()
                .filter(n -> n % 2 == 1)
                .map(n -> n * n)
                .reduce(0, (n1, n2) -> n1 + n2);
        System.out.println("Sum of Squared Odd Number = " + sumOfSquaredOdd);

        Double sumOfSalary2 = Employee.employees().parallelStream()
                .filter(Employee::isFemale)
                // the last parameter "Double::sum" is used only with the parallel stream.
                .reduce(0.0, (partialSum, employee) -> partialSum + employee.getSalary(), Double::sum);
        System.out.println("sumOfSalary2 = " + sumOfSalary2);

        double sumOfSalary3 = Employee.employees().stream()
                .filter(Employee::isFemale)
                .mapToDouble(Employee::getSalary)
                .sum();
        System.out.println("sumOfSalary3 = " + sumOfSalary3);

        //createStreams();
        //optionalValue();
        //collectDataOnStreams();
        //operationsOnStreams();
        //collectDataInMaps();
        //collectSummaryStatistics();
        //joinStringUsingCollectors();
        //groupingData();
        //partitioningData();
        //adaptCollectorResult();
        //findAndMatch();
        //parallelStreams();
    }

    /**
     * Creating Streams
     */
    private static void createStreams() {
        Stream<String> nameStream = Stream.of("Ken", "Kunta", "Kinte", "Jane", "Samuel");

        String nameStr = "ken,kunta,kinte,jane,samuel";
        String[] nameArr = nameStr.split(",");
        Stream<String> nameStream2 = Stream.of(nameArr);

        Stream.Builder<String> strStreamBuilder = Stream.builder();
        Stream<String> strStream = Stream.<String>builder()
                .add("ken")
                .add("samuel")
                .build();

        IntStream oneToFive = IntStream.range(1, 6);
        IntStream oneToSix = IntStream.rangeClosed(1, 6);

        Stream<String> empty = Stream.empty();
        DoubleStream emptyDoubleStream = DoubleStream.empty();

        Stream<Long> longStream = Stream.iterate(1l, n -> n * 2);
        Stream.iterate(1L, n -> n + 2)
                .limit(10)
                .forEach(System.out::println);

        System.out.println("///////////////");

        /**
         * use the static method "next" as the infinite source of the Stream
         */
        Stream.iterate(2l, PrimeProvider::next)
                .limit(6)
                .forEach(System.out::println);

        System.out.println("///////////////");

        Stream.iterate(2l, n -> n + 1)
                .filter(PrimeProvider::isPrime)
                .skip(100)
                .limit(6)
                .forEach(System.out::println);

        System.out.println("///////////////");

        Stream.generate(new PrimeProvider()::next)
                .skip(100)
                .limit(5)
                .forEach(System.out::println);

        System.out.println("///////////////");

        new Random().longs()
                .limit(5)
                .forEach(System.out::println);

        ArrayList<String> strList = new ArrayList<>();
        new Random().longs()
                        .limit(5)
                                .forEach(n -> strList.add(String.valueOf(n)));
        System.out.println("strList = " + strList);

        System.out.println("///////////////");

        Stream.generate(new Random()::nextInt)
                .limit(5)
                .forEach(System.out::println);

        System.out.println("///////////////");

        IntStream.generate(() -> 7)
                .limit(3)
                .forEach(System.out::print);

        System.out.println("\n");

        IntStream s = Arrays.stream(new int[]{3, 2, 4, 5, 6});
        Stream<String> s2 = Arrays.stream(new String[]{"ken", "jane"});

        /**
         * Use file or directory as the source of Stream
         */
        String filePath = "C:\\dev\\workspace\\springbootdemo\\src\\test\\StreamTestFile.txt";
        try {
            FileStream.readFileByLine(filePath)
                    .forEach(System.out::println);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        System.out.println("///////////////");
        String dirPath = "C:\\dev\\workspace\\springbootdemo\\src\\test\\java\\org\\javabin\\demo";
        try {
            FileStream.readDirectory(dirPath)
                    .forEach(System.out::println);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        System.out.println("///////////////");

        String strAppleNOranges = "5 apples and 25 \t oranges";
        strAppleNOranges.chars()
                /**
                 * Character.isSpaceChar() can only identify the space,
                 * whereas Character.isWhitespace() can identify both space and other whitespace chars, such as "\t"
                 */
                .filter(n -> !Character.isDigit(n) && !Character.isSpaceChar(n) && !Character.isWhitespace(n) )
                .forEach(n -> System.out.print((char)n));

        System.out.println("\n");

        String nameStr2 = "ken,jane,kunta,kinte";
        Pattern.compile(",")
                .splitAsStream(nameStr2)
                .forEach(System.out::println);
    }

    /**
     * Representing an Optional Value
     */
    private static void optionalValue() {
        //// Optional Value ////
        Optional<String> maxStr = Stream.of("ken", "jane", "christopher")
                .max(Comparator.comparingInt(String::length));
        if(maxStr.isPresent()) {
            System.out.println("maxStr = " + maxStr.get());
        } else {
            System.out.println("max was not found.");
        }

        Optional<Integer> maxOddInt = Stream.of(2, 20, 30, 40,33, 21)
                .filter(n -> n % 2 == 1)
                .max(Comparator.naturalOrder());
        if(maxOddInt.isPresent()) {
            System.out.println("maxOddInt = " + maxOddInt.get());
        } else {
            System.out.println("maxOddInt was not found.");
        }
    }

    /**
     * Applying Operations on Streams
     */
    private static void operationsOnStreams() {
        //// Operations on Streams ////
        /**
         * peek : Debugging a stream
         */
        Integer sum = Stream.of(1, 2, 3, 4, 5)
                .peek(n -> System.out.println("Taking Integer : " + n))
                .filter(n -> n % 2 == 1)
                .peek(n -> System.out.println("Filtered Integer : " + n))
                .map(n -> n * n)
                .peek(n -> System.out.println("Mapped Integer : " + n))
                .reduce(0, Integer::sum);
        System.out.println("sum = " + sum);

        System.out.println("///////////////");

        /**
         * forEach
         */
        Employee.employees().stream()
                .filter(Employee::isFemale)
                .map(Employee::getName)
                .forEach(System.out::println);

        System.out.println("///////////////");

        /**
         * map : one-to-one mapping
         */
        Employee.employees().stream()
                .map(Employee::getName)
                .forEach(System.out::println);

        System.out.println("///////////////");

        /**
         * map : one-to-many mapping
         */
        Stream.of(1, 2, 3)
                .map(n -> Stream.of(n, n * n))
                .forEach(stream -> stream.forEach(System.out::println));
        Stream.of(1, 2, 3)
                .flatMap(n -> Stream.of(n, n * n))
                .forEach(System.out::println);

        System.out.println("///////////////");

        Stream<Character> c1 = Stream.of('c', 'a');

        long count = Stream.of("ken", "jane", "Ellen")
                .map(name -> name.chars())
                .flatMap(intStream -> intStream.mapToObj(c -> (char) c))
                .filter(ch -> ch == 'e' || ch == 'E')
                .count();
        System.out.println("count = " + count);

        System.out.println("///////////////");

        long count2 = Stream.of("ken", "jane", "Ellen")
                .flatMap(name -> IntStream.range(0, name.length()).mapToObj(name::charAt))
                .filter(ch -> ch == 'e' || ch == 'E')
                .count();
        System.out.println("count2 = " + count2);

        int count3 = Stream.of("ken", "jane", "Ellen")
                .map(name -> name.chars())
                .flatMap(intStream -> intStream.mapToObj(c -> (char) c))
                .filter(ch -> ch == 'e' || ch == 'E')
                .mapToInt(c -> 1)
                .sum();
        System.out.println("count3 = " + count3);

        System.out.println("///////////////");

        /**
         * filter
         */
        Employee.employees().stream()
                .filter(Employee::isMale)
                .filter(emp -> emp.getSalary() > 2900.0)
                .map(Employee::getName)
                .forEach(System.out::println);

        System.out.println("///////////////");

        /**
         * reduce
         */
        Double sumOfSalary = Employee.employees().stream()
                .filter(Employee::isMale)
                .map(Employee::getSalary)
                .reduce(0.0, Double::sum);
        System.out.println("sumOfSalary = " + sumOfSalary);
        Double sumOfSalary2 = Employee.employees().parallelStream()
                .filter(Employee::isFemale)
                // the last parameter "Double::sum" is used only with the parallel stream.
                .reduce(0.0, (partialSum, employee) -> partialSum + employee.getSalary(), Double::sum);
        System.out.println("sumOfSalary2 = " + sumOfSalary2);

        double sumOfSalary3 = Employee.employees().stream()
                .filter(Employee::isFemale)
                .mapToDouble(Employee::getSalary)
                .sum();
        System.out.println("sumOfSalary3 = " + sumOfSalary3);

        System.out.println("///////////////");

        double sum2 = Employee.employees()
                .parallelStream()
                .reduce(0.0,
                        (Double partialSum, Employee emp) -> {
                            double accumulated = partialSum + emp.getSalary();
                            System.out.println(Thread.currentThread().getName() +
                                    " - Accumulator: partialSum = " +
                                    partialSum + ", employee = " + emp +
                                    ", accumulated = " + accumulated);
                            return accumulated;
                        },
                        (a, b) -> {
                            double combined = a + b;
                            System.out.println(Thread.currentThread().getName() +
                                    " - Combiner: a = " + a + ", b = " + b +
                                    ", combined = " + combined);
                            return combined;
                        });
        System.out.println("sum2 = " + sum2);

        System.out.println("///////////////");

        /**
         * Sometimes you cannot specify a default value for a reduce operation. Suppose you want to get maximum integer
         * value from a stream of integers. If the stream is empty, you cannot default the maximum value to 0. In such a case, the
         * result is not defined. The third version of the reduce(BinaryOperator<T> accumulator) method is used to perform
         * such a reduction operation.
         */
        Optional<Integer> max = Stream.<Integer>empty()
                .reduce(Integer::max);
        if(max.isPresent()) {
            System.out.println("max.get() = " + max.get());
        } else {
            System.out.println("Max value is not found.");
        }

        System.out.println("///////////////");

        double totalSalary = Employee.employees().stream()
                .mapToDouble(Employee::getSalary)
                .sum();
        System.out.println("totalSalary = " + totalSalary);

        Optional<Employee> maxSalaryEmployee = Employee.employees().stream()
                .max(Comparator.comparing(Employee::getSalary));
        if(maxSalaryEmployee.isPresent()) {
            System.out.println("maxSalaryEmployee.get() = " + maxSalaryEmployee.get());
        } else {
            System.out.println("Max salary Employee is not found.");
        }

        /**
         * 4 methods to count the employee
         */
        long employeeCount = Employee.employees().stream().count();
        System.out.println("employeeCount = " + employeeCount);

        employeeCount = Employee.employees().stream()
                .mapToLong(emp -> 1L)
                .sum();
        System.out.println("employeeCount = " + employeeCount);

        employeeCount = Employee.employees().stream()
                .mapToLong(emp -> 1L)
                .reduce(0l, Long::sum);

        OptionalLong optionalSum = Employee.employees().stream()
                .mapToLong(emp -> 1L)
                .reduce(Long::sum);
        System.out.println("optionalSum.getAsLong() = " + optionalSum.getAsLong());

        System.out.println("///////////////");

        /**
         * sort
         */
        Comparator<Employee> comparator = Comparator.comparing(Employee::getSalary);
        Employee.employees().stream()
                .sorted(comparator);
        //.forEach(System.out::println);
        Employee.employees().stream()
                .sorted(comparator.reversed())
                .forEach(System.out::println);
    }

    /**
     * Collecting data on Streams
     */
    private static void collectDataOnStreams() {
        //// Collecting data on Streams ////
        Supplier<ArrayList<String>> supplier = () -> new ArrayList();
        Supplier<ArrayList<String>> supplier2 = ArrayList::new;

        BiConsumer<ArrayList<String>, String> accumulator = (list, name) -> list.add(name);
        BiConsumer<ArrayList<String>, String> accumulator2 = ArrayList::add;

        BiConsumer<ArrayList<String>, ArrayList<String>> combiner = (list1, list2) -> list1.addAll(list2);
        BiConsumer<ArrayList<String>, ArrayList<String>> combiner2 = ArrayList::addAll;

        ArrayList<String> nameList = Employee.employees().stream()
                .filter(Employee::isFemale)
                .map(Employee::getName)
                .collect(() -> new ArrayList<String>(),
                        (ArrayList<String> list, String name) -> list.add(name),
                        (ArrayList<String> list1, ArrayList<String> list2) -> list1.addAll(list2));
        System.out.println("nameList = " + nameList);

        ArrayList<String> nameList2 = Employee.employees().stream()
                .filter(Employee::isFemale)
                .map(Employee::getName)
                .collect(supplier2, accumulator2, combiner2);
        nameList2.forEach(System.out::println);

        System.out.println("///////////////");

        List<String> nameList3 = Employee.employees().stream()
                .filter(Employee::isFemale)
                .map(Employee::getName)
                .collect(Collectors.toList());
        nameList3.forEach(System.out::println);

        System.out.println("///////////////");

        LinkedHashSet<String> orderedNameSet = Employee.employees().stream()
                .filter(Employee::isFemale)
                .map(Employee::getName)
                .collect(Collectors.toCollection(LinkedHashSet::new));
        orderedNameSet.forEach(System.out::println);
    }

    /**
     * Collecting data in Maps
     */
    private static void collectDataInMaps() {
        //// Collecting data in Maps ////
        Map<Long, String> employeeMap = Employee.employees().stream()
                .collect(Collectors.toMap(Employee::getId, Employee::getName));
        System.out.println("employeeMap = " + employeeMap);

        Map<Employee.Gender, String> employeeMap2 = Employee.employees().stream()
                .collect(Collectors.toMap(
                        Employee::getGender,
                        Employee::getName,
                        (oldValue, newValue) -> String.join(", ", oldValue, newValue)));
        System.out.println("employeeMap2 = " + employeeMap2);

        Map<Employee.Gender, Long> employeeMap3 = Employee.employees().stream()
                .collect(Collectors.toMap(
                        Employee::getGender,
                        emp -> 1L,
                        (oldv, newv) -> oldv++
                ));
        System.out.println("employeeMap3 = " + employeeMap3);

        Map<Long, Employee> employeeMap4 = Employee.employees().stream()
                .collect(Collectors.toMap(
                        Employee::getId,
                        emp -> emp
                ));
        System.out.println("employeeMap4 = " + employeeMap4);

        Map<Employee.Gender, Employee> employeeMap5 = Employee.employees().stream()
                .collect(Collectors.toMap(
                        Employee::getGender,
                        Function.identity(),    // same as "emp -> emp"
                        (oldEmp, newEmp) -> newEmp.getSalary() > oldEmp.getSalary() ? newEmp : oldEmp
                ));
        System.out.println("employeeMap5 = " + employeeMap5);
    }

    /**
     * Collecting Summary Statistics
     */
    private static void collectSummaryStatistics() {
        //// Summary Statistics ////
        DoubleSummaryStatistics stats = new DoubleSummaryStatistics();
        IntSummaryStatistics intStats = new IntSummaryStatistics();
        LongSummaryStatistics longStats = new LongSummaryStatistics();

        stats.accept(100.0);
        stats.accept(500.0);
        stats.accept(400.0);
        long countStat = stats.getCount();
        double sumStat = stats.getSum();
        double minStat = stats.getMin();
        double avgStat = stats.getAverage();
        double maxStat = stats.getMax();
        System.out.printf("count=%d, sum=%.2f, min=%.2f, average=%.2f, max=%.2f%n",
                countStat, sumStat, minStat, maxStat, avgStat);

        System.out.println("///////////////");

        DoubleSummaryStatistics statistics = Employee.employees().stream()
                .map(Employee::getSalary)
                .collect(
                        DoubleSummaryStatistics::new,
                        DoubleSummaryStatistics::accept,
                        DoubleSummaryStatistics::combine);

        statistics = Employee.employees().stream()
                .collect(Collectors.summarizingDouble(Employee::getSalary));
        System.out.println("statistics = " + statistics);
    }

    /**
     * Joining Strings Using Collectors
     */
    private static void joinStringUsingCollectors() {
        String nameStr = Employee.employees().stream()
                .map(Employee::getName)
                .collect(Collectors.joining(", "));
        System.out.println("nameStr = " + nameStr);

        String prefixedNameStr = Employee.employees().stream()
                .map(Employee::getName)
                .collect(Collectors.joining(", ", "Hello, ", ", how are you?"));
        System.out.println("prefixedNameStr = " + prefixedNameStr);
    }

    /**
     * Grouping Data
     */
    private static void groupingData() {
        Map<Employee.Gender, List<Employee>> groupByGender = Employee.employees().stream()
                .collect(Collectors.groupingBy(Employee::getGender));
        System.out.println("groupByGender = " + groupByGender);

        Map<Employee.Gender, Long> countByGender = Employee.employees().stream()
                .collect(Collectors.groupingBy(Employee::getGender, Collectors.counting()));
        System.out.println("countByGender = " + countByGender);

        Map<Employee.Gender, String> nameMap = Employee.employees().stream()
                .collect(Collectors.groupingBy(
                        Employee::getGender,
                        Collectors.mapping(
                                Employee::getName,
                                Collectors.joining(", ")
                                //or Collectors.toList()
                        )
                ));
        System.out.println("nameMap = " + nameMap);

        Map<Employee.Gender, Map<Month, String>> nameMap2 = Employee.employees().stream()
                .collect(Collectors.groupingBy(
                        Employee::getGender,
                        Collectors.groupingBy(
                                emp -> emp.getDateOfBirth().getMonth(),
                                Collectors.mapping(
                                        Employee::getName,
                                        Collectors.joining(", ")
                                )
                        )
                ));
        System.out.println("nameMap2 = " + nameMap2);

        Map<Employee.Gender, DoubleSummaryStatistics> salaryMap = Employee.employees().stream()
                .collect(Collectors.groupingBy(
                        Employee::getGender,
                        Collectors.summarizingDouble(Employee::getSalary)
                ));
        System.out.println("salaryMap = " + salaryMap);
    }

    /**
     * Partitioning Data
     */
    private static void partitioningData() {
        Map<Boolean, List<Employee>> employeeGroup = Employee.employees().stream()
                .collect(Collectors.partitioningBy(Employee::isMale));
        System.out.println("employeeGroup = " + employeeGroup);

        Map<Boolean, String> employeeGroup2 = Employee.employees().stream()
                .collect(Collectors.partitioningBy(
                        Employee::isFemale,
                        Collectors.mapping(
                                Employee::getName,
                                Collectors.joining(", "))
                ));
        System.out.println("employeeGroup2 = " + employeeGroup2);
    }

    /**
     * Adapting the Collector Results
     */
    private static void adaptCollectorResult() {
        List<String> names = Employee.employees().stream()
                .map(Employee::getName)
                .collect(Collectors.collectingAndThen(
                        Collectors.toList(),
                        result -> Collections.unmodifiableList(result)
                ));
        System.out.println("names = " + names);

        Map<Month, String> mapByMonth = Employee.employees().stream()
                .collect(Collectors.groupingBy(
                        emp -> emp.getDateOfBirth().getMonth(),
                        Collectors.mapping(
                                Employee::getName,
                                Collectors.joining(", ")
                        )
                ));
        //mapByMonth.entrySet().forEach(System.out::println);

        Map<Month, String> mapByMonth2 = Employee.employees().stream()
                .collect(Collectors.collectingAndThen(
                        Collectors.groupingBy(
                                emp -> emp.getDateOfBirth().getMonth(),
                                Collectors.mapping(
                                        Employee::getName,
                                        Collectors.joining(", ")
                                )
                        ),
                        result -> {
                            for (Month m : Month.values()) {
                                result.putIfAbsent(m, "None");
                            }
                            return Collections.unmodifiableMap(new TreeMap<>(result));
                        }
                ));
        mapByMonth2.entrySet().forEach(System.out::println);
    }

    /**
     * Finding and Matching in Streams
     */
    private static void findAndMatch() {
        List<Employee> employees = Employee.employees();

        boolean allMale = employees.stream()
                .allMatch(Employee::isMale);
        System.out.println("allMale = " + allMale);

        boolean anyFemale = employees.stream()
                .anyMatch(Employee::isFemale);
        System.out.println("anyFemale = " + anyFemale);

        boolean anyAprilBorn = employees.stream()
                .anyMatch(emp -> emp.getDateOfBirth().getMonth() == Month.APRIL);
        System.out.println("anyAprilBorn = " + anyAprilBorn);

        Optional<Employee> anyHighSalary = employees.stream()
                .filter(emp -> emp.getSalary() > 5000)
                .findAny();
        if(anyHighSalary.isPresent()) {
            System.out.println("anyHighSalary.get() = " + anyHighSalary.get());
        } else {
            System.out.println("No high salary employee found.");
        }

        Optional<Employee> firstMale = employees.stream()
                .filter(Employee::isMale)
                .findFirst();
        if(firstMale.isPresent()) {
            System.out.println("firstMale.get() = " + firstMale.get());
        } else {
            System.out.println("No male found in the list.");
        }
    }

    /**
     * Parallel Streams
     */
    private static void parallelStreams() {
        List<Employee> employees = Employee.employees();
        String namesForFemale = employees
                .parallelStream()
                .filter(Employee::isFemale)
                .map(Employee::getName)
                .collect(Collectors.joining(", "));
        System.out.println("namesForFemale = " + namesForFemale);

        String namesForMale = employees.stream()
                .filter(Employee::isMale)
                // change the stream to a parallel stream
                .parallel()
                .map(Employee::getName)
                .collect(Collectors.joining(", "));
        System.out.println("namesForMale = " + namesForMale);
    }
}
