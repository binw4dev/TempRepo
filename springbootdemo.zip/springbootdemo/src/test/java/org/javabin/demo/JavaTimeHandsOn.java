package org.javabin.demo;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class JavaTimeHandsOn {

    private static void localDateTimeAPI() {

    }

    private static void javatimeLocalDateTime() {
        // the current date
        LocalDate date = LocalDate.now();
        System.out.println("the current date is " + date);
        // the current time
        LocalTime time = LocalTime.now();
        System.out.println("the current time is " + time);
        // will give us the current time and date
        LocalDateTime current = LocalDateTime.now();
        System.out.println("current date and time : " + current);
        // to print in a particular format
        DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
        String formatedDateTime = current.format(format);
        System.out.println("in formatted manner " + formatedDateTime);
        // printing months days and seconds
        Month month = current.getMonth();
        int day = current.getDayOfMonth();
        int seconds = current.getSecond();
        System.out.println("Month : "+month+" day : " + day+" seconds : " + seconds);
        // printing some specified date
        LocalDate date2 = LocalDate.of(1950,1,26);
        System.out.println("the republic day :"+date2);
        // printing date with current time.
        LocalDateTime specificDate = current.withDayOfMonth(24).withYear(2016);
        System.out.println("specific date with " + "current time : "+specificDate);

        LocalDateTime dt1 = LocalDateTime.of(date, time);
        LocalDateTime dt2 = LocalDateTime.of(1981, Month.DECEMBER, 13, 9, 10, 10);

        ///////////////////////////////////////////////////

        Instant instant = dt1.atZone(ZoneId.systemDefault()).toInstant();
        Date dateUtil = Date.from(instant);

        instant = dateUtil.toInstant();
        dt1 = LocalDateTime.ofInstant(instant, ZoneId.systemDefault());

        ///////////////////////////////////////////////////
    }

    private static void javautilDate() {
        long currentTimeMillis = System.currentTimeMillis();
        Date date = new Date(currentTimeMillis);
        System.out.println("Current Date and Time: " + date);
        long timeMillis = date.getTime();
        long days = TimeUnit.MILLISECONDS.toDays(date.getTime());
        long hours = TimeUnit.MILLISECONDS.toHours(timeMillis);
        System.out.println("days = " + days);
        System.out.println("hours = " + hours);
    }

    public static void main(String[] args) {
        localDateTimeAPI();
    }
}
