package org.javabin.demo;

import java.lang.reflect.Constructor;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.concurrent.ConcurrentHashMap;

public class JavaArrayAlgorithmHandsOn {

    /**
     * Given an array arr[], the task is to find the subarray that has the maximum sum and return its sum.
     *
     * Examples:
     *
     * Input: arr[] = {2, 3, -8, 7, -1, 2, 3}
     * Output: 11
     * Explanation: Te subarray {7h, -1, 2, 3} has the largest sum 11.
     *
     *
     * Input: arr[] = {-2, -4}
     * Output: –2
     * Explanation: The subarray {-2} has the largest sum -2.
     *
     *
     * Input: arr[] = {5, 4, 1, 7, 8}
     * Output: 25
     * Explanation: The subarray {5, 4, 1, 7, 8} has the largest sum 25.
     */
    public static int[] findSubArrayWithMaxSum(int[] arr) {
        int currSum = arr[0];
        int maxSum = currSum;
        int start = 0;
        int end = 0;
        int currStart = 0;
        for(int i = 1, n = arr.length; i < n; i++) {
            if(currSum < 0) {
                currSum = arr[i];
                currStart = i;
            } else {
                currSum += arr[i];
            }
            if(currSum >= maxSum) {
                maxSum = currSum;
                end = i;
                start = currStart;
            }
            // this checking is critical, we reset curr values only when the currSum less than 0.
            else if(currSum < 0){
                currSum = 0;
                currStart = i + 1;
            }
        }
        int[] subArr = new int[end - start + 1];
        int count = 0;
        for(int i = start; i <= end; i++) {
            subArr[count++] = arr[i];
        }
        return subArr;
    }
    public static int findMaxSumOfSubArray(int[] arr) {
        int maxSum = arr[0];
        int currSum = arr[0];
        for(int i = 1, n = arr.length; i < n; i++) {
            currSum = Math.max(currSum + arr[i], arr[i]);
            maxSum = Math.max(currSum, maxSum);
        }
        return maxSum;
    }

    /**
     * Given an array arr[] of size n-1 with integers in the range of [1, n], the task is to find the missing number from the first n integers.
     */
    public static int findMissingNumber(int[] arr) {
        int len = arr.length;
        int sum = (len + 1) * (len + 2) / 2;
        int sumArr = Arrays.stream(arr).sum();
        return sum - sumArr;
    }

    /**
     * Trapping Rainwater Problem:
     * Given an array of n non-negative integers arr[] representing an elevation map where the width of each bar is 1, compute how much water it can trap after rain.
     *
     * Examples:
     *
     * Input: arr[] = {3, 0, 1, 0, 4, 0, 2}
     * Output: 10
     * Explanation: The expected rainwater to be trapped is shown in the above image.
     *
     * Input: arr[]   = {3, 0, 2, 0, 4}
     * Output: 7
     * Explanation: We trap 0 + 3 + 1 + 3 + 0 = 7 units.
     *
     * Input: arr[] = {1, 2, 3, 4}
     * Output: 0
     * Explanation : We cannot trap water as there is no height bound on both sides
     *
     * Input: arr[] = {2, 1, 5, 3, 1, 0, 4}
     * Output: 9
     * Explanation : We trap 0 + 1 + 0 + 1 + 3 + 4 + 0 = 9 units of water.
     */
    public static int trapRainWaterMyOwn(int[] arr) {
        int leftHeight = 0;
        int rightHeight = 0;
        int left = 0;
        int right = 0;
        int rainWater = 0;
        for(int i = 0, n = arr.length; i < n; i++) {
            right = i;
            rightHeight = arr[i];
            if(rightHeight >= leftHeight) {
                for(int j = left + 1; j < right; j++) {
                    rainWater += (leftHeight - arr[j]);
                }
                leftHeight = rightHeight;
                left = right;
            }
        }
        int height = 0;
        if(rightHeight >= leftHeight) {
            height = leftHeight;
        } else {
            height = rightHeight;
        }
        for(int j = left + 1; j < right; j++) {
            if(height > arr[j]) {
                rainWater += (height - arr[j]);
            }
        }
        return rainWater;
    }

    /**
     * Computing prefix and suffix max for every index – O(n) Time and O(n) Space.
     *
     * For every element we first calculate and store the highest bar on the left and on the right (say stored in arrays left[] and right[]).
     * Then iterate the array and use the calculated values to find the amount of water stored in this index,
     * which is the same as ( min(left[i], right[i]) – arr[i] )
     *
     * Consider arr[] = {3, 0, 2, 0, 4}
     *
     * Therefore, left[] = {3, 3, 3, 3, 4} and right[] = {4, 4, 4, 4, 4}
     * Now consider iterating using i from 0 to end and compute water stored at every index as min(left[i], right[i]) – arr[i]) and if it is greater than 0, then add it to the result.
     *
     * Initialize : res = 0
     * For i = 0:  res = 0  + 0 = 0
     * For i = 1:  res = 0 + 3 = 3
     * For i = 2:  res = 3 + 1 = 4
     * For i = 3:  res = 4 + 3 = 7
     * For i = 4:  res = 7 + 0 = 7
     *
     *
     * So total rain water trapped = 7
     */
    public static int trapRainWaterByPrefixSuffix(int[] arr) {
        int n = arr.length;
        // Left[i] contains height of tallest bar to the
        // left of i'th bar including itself
        int[] left = new int[n];
        // Right[i] contains height of tallest bar to
        // the right of i'th bar including itself
        int[] right = new int[n];
        // Initialize result
        int res = 0;
        // Fill left array
        left[0] = arr[0];
        for (int i = 1; i < n; i++) {
            left[i] = Math.max(left[i - 1], arr[i]);
        }
        // Fill right array
        right[n - 1] = arr[n - 1];
        for (int i = n - 2; i >= 0; i--) {
            right[i] = Math.max(right[i + 1], arr[i]);
        }
        // Calculate the accumulated water element by element
        for (int i = 1; i < n - 1; i++) {
            int minOf2 = Math.min(left[i - 1], right[i + 1]);
            if (minOf2 > arr[i]) {
                res += minOf2 - arr[i];
            }
        }
        return res;
    }

    /**
     * Best Approach : see the notes in Data Structures and Algorithm -> Array Algorithm -> Trapping Rain Water.
     * Trapping Rain Water Problem using two pointers.
     *
     * The approach is mainly based on the following facts:
     *
     * 1. If we consider a subarray arr[left…right], we can decide the amount of water either for arr[left] or arr[right] if we know the left max (max element in arr[0…left-1]) and right max (max element in arr[right+1…n-1].
     * 2. If left max is less than the right max, then we can decide for arr[left]. Else we can decide for arr[right]
     * 3. If we decide for arr[left], then the amount of water would be left max – arr[left]
     */
    public static int trapRainWaterBest(int[] arr) {
        int left = 1;
        int right = arr.length - 2;
        // lMax : Maximum in subarray arr[0..left-1]
        // rMax : Maximum in subarray arr[right+1..n-1]
        int lMax = arr[left - 1];
        int rMax = arr[right + 1];
        int res = 0;
        while (left <= right) {
            // If rMax is smaller, then we can decide the amount of water for arr[right]
            if (rMax <= lMax) {
                // Add the water for arr[right]
                res += Math.max(0, rMax - arr[right]);
                // Update right max
                rMax = Math.max(rMax, arr[right]);
                // Update right pointer as we have decided the amount of water for this
                right -= 1;
            } else {
                // Add the water for arr[left]
                res += Math.max(0, lMax - arr[left]);
                // Update left max
                lMax = Math.max(lMax, arr[left]);
                // Update left pointer as we have decided water for this
                left += 1;
            }
        }
        return res;
    }

    /**
     * Maximum Product Subarray
     *
     * Given an integer array, the task is to find the maximum product of any subarray.
     *
     * Examples:
     *
     * Input: arr[] = {-2, 6, -3, -10, 0, 2}
     * Output: 180
     * Explanation: The subarray with maximum product is {6, -3, -10} with product = 6 * (-3) * (-10) = 180
     *
     * Input: arr[] = {-1, -3, -10, 0, 60}
     * Output: 60
     * Explanation: The subarray with maximum product is {60}.
     *
     * Method 1: Using minimum and maximum product ending at any index – O(n) Time and O(1) Space
     *
     * Let’s assume that the input array has only positive elements. Then, we can simply iterate from left to right keeping track of the maximum running product ending at any index. The maximum product would be the product ending at the last index. The problem arises when we encounter zero or a negative element.
     * If we encounter zero, then all the subarrays containing this zero will have product = 0, so zero simply resets the product of the subarray.
     * If we encounter a negative number, we need to keep track of the minimum product as well as the maximum product ending at the previous index. This is because when we multiply the minimum product with a negative number, it can give us the maximum product. So, keeping track of minimum product ending at any index is important as it can lead to the maximum product on encountering a negative number.
     *
     * Step-by-step algorithm:
     *
     * Create 3 variables, currMin, currMax and maxProd initialized to the first element of the array.
     * Iterate the indices 0 to N-1 and update the variables:
     *      currMax = maximum(arr[i], currMax * arr[i], currMin * arr[i])
     *      currMin= minimum(arr[i], currMax * arr[i], currMin * arr[i])
     *      update the maxProd with the maximum value for each index.
     * Return maxProd as the result.
     */
    public static int[] maxProductSubarray(int[] arr) {
        int n = arr.length;
        // max product ending at the current index
        int currMax = arr[0];
        // min product ending at the current index
        int currMin = arr[0];
        // Initialize overall max product
        int maxProd = arr[0];
        // left index of the subarray of max product
        int lMax = 0;
        // right index of the subarray of max product
        int rMax = 0;
        // left index of the subarray of min product
        int lMin = 0;
        // right index of the subarray of min product
        int rMin = 0;
        // Iterate through the array
        for (int i = 1; i < n; i++) {
            // find the indexes of the max product
            int lMaxTmp = lMax;
            if(arr[i] > arr[i] * currMax && arr[i] > arr[i] * currMin && arr[i] > maxProd) {
                lMaxTmp = i;
                rMax = i;
            } else if(arr[i] * currMax > arr[i] && arr[i] * currMax > arr[i] * currMin && arr[i] * currMax > maxProd) {
                rMax = i;
            } else if(arr[i] * currMin > arr[i] && arr[i] * currMin > arr[i] * currMax && arr[i] * currMin > maxProd) {
                lMaxTmp = lMin;
                rMax = i;
            }
            // find the indexes of the min product
            if(arr[i] < arr[i] * currMax && arr[i] < arr[i] * currMin) {
                lMin = i;
                rMin = i;
            } else if(arr[i] * currMax < arr[i] && arr[i] * currMax < arr[i] * currMin) {
                lMin = lMax;
                rMin = i;
            } else if(arr[i] * currMin < arr[i] && arr[i] * currMin < arr[i] * currMax) {
                rMin = i;
            }
            lMax = lMaxTmp;

            // Temporary variable to store the maximum product ending
            // at the current index
            int temp = maxInThree(arr[i], arr[i] * currMax, arr[i] * currMin);
            // Update the minimum product ending at the current index
            currMin = minInThree(arr[i], arr[i] * currMax, arr[i] * currMin);
            // Update the maximum product ending at the current index
            currMax = temp;
            // Update the overall maximum product
            maxProd = Math.max(maxProd, currMax);
        }
        int[] maxProductArr = new int[rMax - lMax + 1];
        int currIndex = 0;
        for(int i = lMax; i <= rMax; i++) {
            maxProductArr[currIndex++] = arr[i];
        }
        return maxProductArr;
    }

    public static int maxInThree(int a, int b, int c) {
        return Math.max(a, Math.max(b, c));
    }

    public static int minInThree(int a, int b, int c) {
        return Math.min(a, Math.min(b, c));
    }

    /**
     * Maximum Product Subarray
     *
     * Method 2: By traversing in both directions – O(n) Time and O(1) Space
     *
     * We will follow a simple approach that is to traverse from the start and keep track of the running product and if the running product is greater than the max product, then we update the max product. Also, if we encounter ‘0’ then make product of all elements till now equal to 1 because from the next element, we will start a new subarray.
     * But what is the problem with this approach?
     * Problem will occur when our array will contain odd no. of negative elements. In that case, we have to reject one negative element so that we can even no. of negative elements and their product can be positive. Now, since subarray should be contiguous so we can’t simply reject any one negative element. We have to either reject the first negative element or the last negative element.
     * Now, if we traverse from start then only the last negative element can be rejected and if we traverse from the last then the first negative element can be rejected. So we will traverse from both ends and find the maximum product subarray.
     */
    public static int[] maxProductSubarrayBest(int[] arr) {
        int n = arr.length;
        int maxProd = Integer.MIN_VALUE;
        // leftToRight to store product from left to Right
        int leftToRight = 1;
        // rightToLeft to store product from right to left
        int rightToLeft = 1;
        int leftStart = 0;
        int leftEnd = 0;
        int rightStart = 0;
        int rightEnd = n - 1;
        int lMax = 0;
        int rMax = 0;
        for (int i = 0; i < n; i++) {
            leftEnd = i;
            rightStart = n - i - 1;
            if (leftToRight == 0) {
                leftToRight = 1;
                leftStart = i;
            }
            if (rightToLeft == 0) {
                rightToLeft = 1;
                rightEnd = n - i - 1;
            }
            // calculate product from index left to right
            leftToRight *= arr[i];
            // calculate product from index right to left
            int j = n - i - 1;
            rightToLeft *= arr[j];
            if(leftToRight >= rightToLeft && leftToRight > maxProd) {
                lMax = leftStart;
                rMax = leftEnd;
                maxProd = leftToRight;
            } else if(rightToLeft > leftToRight && rightToLeft > maxProd) {
                lMax = rightStart;
                rMax = rightEnd;
                maxProd = rightToLeft;
            }
            //maxProd = Math.max(leftToRight, Math.max(rightToLeft, maxProd));
        }
        int[] maxProductArr = new int[rMax - lMax + 1];
        int currIndex = 0;
        for(int i = lMax; i <= rMax; i++) {
            maxProductArr[currIndex++] = arr[i];
        }
        return maxProductArr;
    }

    /**
     * Equilibrium index of an array
     *
     * Given an array arr[] of size n, return an equilibrium index (if any) or -1 if no equilibrium index exists. The equilibrium index of an array is an index such that the sum of elements at lower indexes equals the sum of elements at higher indexes.
     * Note: Return equilibrium point in 1-based indexing. Return -1 if no such point exists.
     *
     * Examples:
     *
     * Input: arr[] = {-7, 1, 5, 2, -4, 3, 0}
     * Output: 4
     * Explanation: In 1-based indexing, 4 is an equilibrium index, because: arr[1] + arr[2] + arr[3] = arr[5] + arr[6] + arr[7]
     *
     * Input: arr[] = {1, 2, 3}
     * Output: -1
     * Explanation: There is no equilibrium index in the array.
     */
    public static int equilibriumOfArray(int[] arr) {
        int n = arr.length - 1;
        int eIndex = -1;
        int sum = Arrays.stream(arr).sum();
        for(int i = 1; i < n - 1; i++) {
            int halfSum = (sum - arr[i]) / 2;
            int checkSum = arr[0];
            for(int j = 1; j < i; j++) {
                checkSum += arr[j];
            }
            if(halfSum == checkSum) {
                eIndex = i;
            }
        }
        return eIndex;
    }

    /**
     * Equilibrium index of an array
     *
     * Using Prefix and Suffix Sum Array – O(N) Time and O(N) Space:
     * Precompute the prefix sum array and suffix sum array, and check if the prefix sum of current position is same as suffix sum of the same or not.
     */
    public static int equilibriumOfArrayBetter(int[] arr) {
        int n = arr.length;
        int eIndex = -1;
        int[] prefixSum = new int[n];
        int[] surfixSum = new int[n];
        prefixSum[0] = surfixSum[n - 1] = 0;
        for(int i = 1; i < n - 1; i ++) {
            prefixSum[i] = prefixSum[i - 1] + arr[i - 1];
            surfixSum[n - i - 1] = surfixSum[n - i] + arr[n - i];
        }
        prefixSum[n - 1] = prefixSum[n - 2] + arr[n - 2];
        surfixSum[0] = surfixSum[1] + arr[1];
        for(int i = 0; i < n; i++) {
            if(prefixSum[i] == surfixSum[i]) {
                eIndex = i;
                break;
            }
        }
        return eIndex;
    }

    /**
     * Equilibrium index of an array
     *
     * Using Prefix Sum and Suffix Sum without extra space – O(N) Time and O(1) Space:
     * The idea is that instead of storing the prefix sum and suffix sum for each element in an array, we can simply use the fact that (considering Pivot as the current position):
     *      PrefixSum(Array[0:Pivot – 1]) + Arr[Pivot] + SuffixSum[Pivot + 1: N – 1] = ArraySum
     *
     * To implement this:
     *  Find the Array sum
     *  Iterate through each element of the Array. For each element:
     *      Find prefix sum till the previous element by adding previous element to prefix sum
     *      Find suffix sum by subtracting current element from the array sum
     *      Check if these two sum are equal or not.
     *      If equal, then current pivot is the equilibrium index.
     */
    public static int equilibriumOfArrayBest(int[] arr) {
        int eIndex = -1;
        int left = 0;
        int right = 0;
        int pivot = 0;
        int n = arr.length;
        for(int i = 1; i < n; i++) {
            right += arr[i];
        }
        while(pivot < n - 1 && left != right) {
            pivot++;
            left += arr[pivot - 1];
            right -= arr[pivot];
        }
        if(left == right) {
            eIndex = pivot;
        }
        return eIndex;
    }

    /**
     * Given an array arr[] of size n, the task is to find all the Leaders in the array. An element is a Leader if it is greater than or equal to all the elements to its right side.
     * Note: The rightmost element is always a leader.
     *
     * Examples:
     * Input: arr[] = [16, 17, 4, 3, 5, 2]
     * Output: [17 5 2]
     * Explanation: 17 is greater than all the elements to its right i.e., [4, 3, 5, 2], therefore 17 is a leader. 5 is greater than all the elements to its right i.e., [2], therefore 5 is a leader. 2 has no element to its right, therefore 2 is a leader.
     *
     * Input: arr[] = [1, 2, 3, 4, 5, 2]
     * Output: [5 2]
     * Explanation: 5 is greater than all the elements to its right i.e., [2], therefore 5 is a leader. 2 has no element to its right, therefore 2 is a leader.
     *
     * [Naive Approach] Using Nested Loops – O(n^2) Time and O(1) Space
     */
    public static int[] findLeadersOfArrayNaive(int[] arr) {
        int n = arr.length;
        ArrayList<Integer> leaderList = new ArrayList();
        for(int i = 0; i < n; i++) {
            boolean isLeader = true;
            for(int j = i + 1; j < n; j++) {
                if(arr[i] < arr[j]) {
                    isLeader = false;
                    break;
                }
            }
            if(isLeader) {
                leaderList.add(arr[i]);
            }
        }

        return leaderList.stream().mapToInt(Integer::intValue).toArray();
    }

    /**
     * Given an array arr[] of size n, the task is to find all the Leaders in the array. An element is a Leader if it is greater than or equal to all the elements to its right side.
     * Note: The rightmost element is always a leader.
     *
     * [Expected Approach] Using Suffix Maximum – O(n) Time and O(1) Space:
     * The idea is to scan all the elements from right to left in an array and keep track of the maximum till now. When the maximum changes its value, add it to the result. Finally reverse the result
     */
    public static int[] findLeadersOfArrayBySuffix(int[] arr) {
        int n = arr.length;
        ArrayList<Integer> list = new ArrayList<>();
        int maxRight = arr[n - 1];
        list.add(maxRight);
        for(int i = n - 2; i >= 0; i--) {
            if(arr[i] >= maxRight) {
                maxRight = arr[i];
                list.add(maxRight);
            }
        }
        Collections.reverse(list);
        return list.stream().mapToInt(Integer::intValue).toArray();
    }

    /**
     * Minimum Platforms Required for Given Arrival and Departure Times
     *
     * We are given two arrays that represent the arrival and departure times of trains, the task is to find the minimum number of platforms required so that no train waits.
     *
     * Examples:
     *
     * Input: arr[] = {9:00, 9:40, 9:50, 11:00, 15:00, 18:00}, dep[] = {9:10, 12:00, 11:20, 11:30, 19:00, 20:00}
     * Output: 3
     * Explanation: There are at-most three trains at a time (time between 9:40 to 12:00)
     *
     *
     * Input: arr[] = {9:00, 9:40}, dep[] = {9:10, 12:00}
     * Output: 1
     * Explanation: Only one platform is needed.
     */
    public static int numOfRequiredPlatforms(String[] arrivals, String[] departures) {
        int numRequired = 1;
        int n = arrivals.length;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
        int departureIndex = 0;

        for(int i = 0; i < n - 1; i++) {
            LocalTime arrival = LocalTime.parse(arrivals[i + 1], formatter);
            LocalTime departure = LocalTime.parse(departures[departureIndex], formatter);
            LocalTime lastDeparture = LocalTime.parse(departures[i], formatter);
            if(arrival.isBefore(lastDeparture)) {
                numRequired++;
            }
            while(departureIndex < i) {
                departure = LocalTime.parse(departures[departureIndex], formatter);
                if(arrival.isAfter(departure)) {
                    numRequired--;
                    departureIndex++;
                } else {
                    break;
                }
            }
        }
        
        return numRequired;
    }

    public static void main(String[] args) {
        int[] arr1 = {2, 3, -8, 7, -1, 2, 3};
        int[] arr2 = {-2, -4};
        int[] arr3 = {5, 4, 1, 7, 8};
        int[] arr4 = {-5, -4};
        int[] arr5 = {1, 10, -6, 8, 9, 12, -20, 28, 15, 17};
        int[] subArr = findSubArrayWithMaxSum(arr1);
        Arrays.stream(subArr).forEach(item -> System.out.print(item + " "));
        System.out.println();
        subArr = findSubArrayWithMaxSum(arr2);
        Arrays.stream(subArr).forEach(item -> System.out.print(item + " "));
        System.out.println();
        subArr = findSubArrayWithMaxSum(arr3);
        Arrays.stream(subArr).forEach(item -> System.out.print(item + " "));
        System.out.println();
        subArr = findSubArrayWithMaxSum(arr4);
        Arrays.stream(subArr).forEach(item -> System.out.print(item + " "));
        System.out.println();
        subArr = findSubArrayWithMaxSum(arr5);
        Arrays.stream(subArr).forEach(item -> System.out.print(item + " "));
        System.out.println();
        ///////////////////////////////////////////////////
        int maxSumOfSubArray = findMaxSumOfSubArray(arr1);
        System.out.println("maxSumOfSubArray = " + maxSumOfSubArray);
        maxSumOfSubArray = findMaxSumOfSubArray(arr2);
        System.out.println("maxSumOfSubArray = " + maxSumOfSubArray);
        maxSumOfSubArray = findMaxSumOfSubArray(arr3);
        System.out.println("maxSumOfSubArray = " + maxSumOfSubArray);
        maxSumOfSubArray = findMaxSumOfSubArray(arr4);
        System.out.println("maxSumOfSubArray = " + maxSumOfSubArray);
        maxSumOfSubArray = findMaxSumOfSubArray(arr5);
        System.out.println("maxSumOfSubArray = " + maxSumOfSubArray);
        ///////////////////////////////////////////////////
        int missingNumber = findMissingNumber(
                new int[]{1, 2, 3, 4, 5, 6, 8, 9, 10, 11}
        );
        System.out.println("missingNumber = " + missingNumber);
        ///////////////////////////////////////////////////
        int rainWater = trapRainWaterMyOwn(
                new int[]{3, 0, 1, 0, 4, 0, 2}
        );
        System.out.println("rainWater = " + rainWater);
        rainWater = trapRainWaterMyOwn(
                new int[]{3, 0, 2, 0, 4}
        );
        System.out.println("rainWater = " + rainWater);
        rainWater = trapRainWaterMyOwn(
                new int[]{1, 2, 3, 4}
        );
        System.out.println("rainWater = " + rainWater);
        rainWater = trapRainWaterMyOwn(
                new int[]{2, 1, 5, 3, 1, 0, 4}
        );
        System.out.println("rainWater = " + rainWater);
        rainWater = trapRainWaterMyOwn(
                new int[]{4, 3, 2, 1}
        );
        System.out.println("rainWater = " + rainWater);
        ///////////////////////////////////////////////////
        int[] maxProductSubarray = maxProductSubarray(
                new int[]{-2, 6, -3, -10, -4, -1, 0, 2}
        );
        int maxProduct = Arrays.stream(maxProductSubarray)
                .reduce(1, (n1, n2) -> n1 * n2);
        System.out.println("maxProduct = " + maxProduct);
        maxProductSubarray = maxProductSubarray(
                new int[]{-1, -3, -10, 0, 60}
        );
        maxProduct = Arrays.stream(maxProductSubarray)
                .reduce(1, (n1, n2) -> n1 * n2);
        System.out.println("maxProduct = " + maxProduct);
        ///////////////////////////////////////////////////
        int equilibrium = equilibriumOfArrayBest(
                new int[]{-7, 1, 5, 2, -4, 3, 0}
        );
        System.out.println("equilibrium = " + equilibrium);
        equilibrium = equilibriumOfArrayBest(
                new int[]{-7, 1, 5, 4, 3, 1, 2, 8, -4, 3, 0}
        );
        System.out.println("equilibrium = " + equilibrium);
        equilibrium = equilibriumOfArrayBest(
                new int[]{1, 2, 3}
        );
        System.out.println("equilibrium = " + equilibrium);
        ///////////////////////////////////////////////////
        int[] leadersOfArray = findLeadersOfArrayNaive(new int[]{1, 3, 7, 3, 2, 5, 4});
        System.out.print("The leaders of array is : ");
        Arrays.stream(leadersOfArray).forEach(i -> System.out.print(i + " "));
        System.out.println();

        leadersOfArray = findLeadersOfArrayBySuffix(new int[]{1, 3, 7, 3, 2, 5, 4});
        System.out.print("The leaders of array is : ");
        Arrays.stream(leadersOfArray).forEach(i -> System.out.print(i + " "));
        System.out.println();
        ///////////////////////////////////////////////////
        String[] arrivals = {"09:00", "09:40", "09:50", "11:00", "15:00", "18:00"};
        String[] departure = {"09:10", "12:00", "11:20", "11:30", "19:00", "20:00"};
        int numOfRequiredPlatforms = numOfRequiredPlatforms(arrivals, departure);
        System.out.println("numOfRequiredPlatforms = " + numOfRequiredPlatforms);
    }
}
