package org.javabin.demo;

import org.javabin.entity.Book;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class JavaBasicTests {

    public static void main(String[] args) {

        /**
         * initialize an array
         */
        int[] intArray = new int[5];
        int[] intArray2 = new int[]{1, 2, 3, 4, 5};
        int[] intArray3 = {1, 2, 3, 4, 5};
        Book[] bookArray = new Book[]{
                new Book("1", "book1", 10, "author1"),
                new Book("2", "book2", 10, "author2"),
                new Book("3", "book3", 10, "author3"),
                new Book("4", "book4", 10, "author4"),
                new Book("5", "book5", 10, "author5"),
                new Book("6", "book5", 10, "author5"),
                new Book("7", "book3", 10, "author3"),
        };
        List<Book> bookList = Arrays.asList(bookArray);
        Book[] books = bookList.stream().toArray(Book[]::new);

        /**
         * initialize a list
         */
        // initialize a list with an array
        List<Book> bookList1 = Arrays.asList(bookArray);

        // initialize a list with an IntStream
        LinkedList<Book> bookList2 = new LinkedList<>();
        IntStream.range(1, 6).forEach(i -> {
            bookList2.add(new Book(String.valueOf(i), "book" + i, 10, "author" + i));
        });

        // initialize a list with another list
        ArrayList<Book> bookList3 = new ArrayList<>(bookList1);

        /**
         * initialize a set
         */
        // initialize a set with a list
        Set<Book> bookSet = bookList1.stream().collect(Collectors.toSet());

        /**
         * Operations on a list
         */
        // sorting
        Collections.sort(bookList1, Comparator.comparing(Book::getName));
        bookList1.forEach(System.out::println);
        // inverse
        inverse(bookList1).forEach(System.out::println);

        String /*aa = " Hello, World \n \t \t \n";
        aa.trim();
        System.out.println("aa trim = " + aa);*/
        aa = " Hello, World \n \t \t \n";
        aa.strip();
        System.out.println("aa strip = " + aa);
    }

    public int testMethodOverloading(int a) {
        return -1;
    }

    public String testMethodOverloading(String a) {
        return "";
    }

    /**
     * Inverse the order of the elements in a list
     */
    private static List<Book> inverse(List<Book> bookList) {
        Book[] books = bookList.stream().toArray(Book[]::new);
        for(int i = 0; i < books.length / 2; i++) {
            Book book = books[i];
            books[i] = books[books.length - i - 1];
            books[books.length - i - 1] = book;
        }

        List<Book> list = Arrays.asList(books);
        return list;
    }
}
