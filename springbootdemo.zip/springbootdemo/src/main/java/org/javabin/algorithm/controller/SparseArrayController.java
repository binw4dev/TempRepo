package org.javabin.algorithm.controller;

import org.javabin.algorithm.collections.SparseArray;
import org.javabin.algorithm.domain.SparseItem;
import org.javabin.algorithm.service.SparseArrayService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestController("/algorithm")
@CrossOrigin(origins = "*", allowedHeaders = "*", originPatterns = "*", allowCredentials = "true")
public class SparseArrayController {

    @Autowired
    SparseArrayService sparseService;

    @PostMapping("/getsparse")
    //@CrossOrigin(value = "http://localhost:3000", maxAge = 1800, allowedHeaders = "*")
    public int[][] getSparseArray(@RequestBody Map<String, Object> tableArray) {

        List<List<Integer>> tableList = (List<List<Integer>>) tableArray.get("tableArray");

        int rowcount = tableList.size();
        int columncount = tableList.get(0).size();
        int[][] int2DArray = new int[rowcount][columncount];

        for (int i = 0; i < rowcount; i++) {

            List<Integer> integerList = tableList.get(i);

            for (int j = 0; j < columncount; j++) {
                int2DArray[i][j] = Integer.valueOf(integerList.get(j));
            }
        }

        return SparseArray.chessToSparse(int2DArray);
    }

    @PostMapping("/savesparse")
    //@CrossOrigin(value = "http://localhost:3000", maxAge = 1800, allowedHeaders = "*")
    public void saveSparseArray(@RequestBody Map<String, Object> sparseMap) {

        List<List<Integer>> sparseList = (List<List<Integer>>) sparseMap.get("sparseArray");

        int rowcount = sparseList.size();

        List<SparseItem> saveList = new ArrayList<SparseItem>();

        for (int i = 0; i < rowcount; i++) {

            List<Integer> integerList = sparseList.get(i);

            SparseItem sparseItem = new SparseItem();
            sparseItem.setRow(integerList.get(0));
            sparseItem.setCol(integerList.get(1));

            saveList.add(sparseItem);
        }

        sparseService.deleteAllItems();

        sparseService.addAllItems(saveList);
    }

    @PostMapping("/loadsparse")
    //@CrossOrigin(value = "http://localhost:3000", maxAge = 1800, allowedHeaders = "*")
    public int[][] loadSparseArray() {

        List<SparseItem> loadList = sparseService.getAllItems();

        SparseItem sparseInfo = loadList.get(0);
        int rowcount = sparseInfo.getRow();
        int colcount = sparseInfo.getCol();

        int[][] tableArray = new int[rowcount][colcount];

        for (int i = 1, n = loadList.size(); i < n; i++) {

            SparseItem sparseItem = loadList.get(i);
            int rowIndex = sparseItem.getRow();
            int colIndex = sparseItem.getCol();

            tableArray[rowIndex][colIndex] = 1;
        }

        return tableArray;
    }

    @PostMapping("/testfetch")
    //@CrossOrigin(value = "http://localhost:3000", maxAge = 1800, allowedHeaders = "*")
    public String[] testfetch(@RequestBody Map<String, Object> test) {
        List<String> strList = (List<String>) test.get("test");
        return strList.stream().map((str) -> "Hello, My Test!").toArray(String[]::new);
    }
}

