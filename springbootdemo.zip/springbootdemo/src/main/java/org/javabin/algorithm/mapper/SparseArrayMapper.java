package org.javabin.algorithm.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.javabin.algorithm.domain.SparseItem;

import java.util.List;

@Mapper
public interface SparseArrayMapper {
    int addItem(SparseItem sparseItem);

    List<SparseItem> getAllItems();

    int deleteAllItems();
}
