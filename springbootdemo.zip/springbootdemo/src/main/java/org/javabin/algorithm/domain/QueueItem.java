package org.javabin.algorithm.domain;

import java.util.Random;

public class QueueItem implements DataItem {

    private int value = new Random().nextInt(100);

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

}
