package org.javabin.algorithm.service;

import org.javabin.algorithm.domain.SparseItem;
import org.javabin.algorithm.mapper.SparseArrayMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SparseArrayService {

    @Autowired
    SparseArrayMapper saMapper;

    public int addItem(SparseItem sparseItem) {
        return saMapper.addItem(sparseItem);
    }

    public List<SparseItem> getAllItems() {
        return saMapper.getAllItems();
    }

    public void addAllItems(List<SparseItem> sparseItems) {
        sparseItems.forEach(this::addItem);
    }

    public int deleteAllItems() {
        return saMapper.deleteAllItems();
    }
}
