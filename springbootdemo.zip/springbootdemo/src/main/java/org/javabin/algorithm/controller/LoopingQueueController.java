package org.javabin.algorithm.controller;

import org.javabin.algorithm.collections.LoopingQueue;
import org.javabin.algorithm.service.LoopingQueueService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController("/algorithm")
public class LoopingQueueController {

    @Autowired
    LoopingQueueService loopingQueueService;

    @PostMapping("/initQueue")
    //@CrossOrigin(value = "http://localhost:3000", maxAge = 1800, allowedHeaders = "*")
    public LoopingQueue initQueue(@RequestBody Map<String, Object> input) {
        Integer capacity = Integer.valueOf((String) input.get("queueSize"));
        loopingQueueService.initQueue(capacity.intValue());
        return LoopingQueue.getInstance();
    }

    @GetMapping("/resetLoopingQueue")
    //@CrossOrigin(value = "http://localhost:3000", maxAge = 1800, allowedHeaders = "*")
    public LoopingQueue resetLoopingQueue() {
        loopingQueueService.resetQueue();
        return LoopingQueue.getInstance();
    }

    @PostMapping("/addQueueItem")
    //@CrossOrigin(value = "http://localhost:3000", maxAge = 1800, allowedHeaders = "*")
    public LoopingQueue addQueueItem() {
        loopingQueueService.addItem();
        return loopingQueueService.getLoopingQueue();
    }

    @PostMapping("/removeQueueItem")
    //@CrossOrigin(value = "http://localhost:3000", maxAge = 1800, allowedHeaders = "*")
    public LoopingQueue removeQueueItem() {
        loopingQueueService.pickupItem();
        return loopingQueueService.getLoopingQueue();
    }
}
