package org.javabin.algorithm.domain;

public interface DataItem {
}
