package org.javabin.algorithm.service;

import org.javabin.algorithm.collections.LoopingQueue;
import org.javabin.algorithm.domain.QueueItem;
import org.springframework.stereotype.Service;

@Service
public class LoopingQueueService {

    public void addItem() {

        String msg = "Item added into the queue : ";
        try {
            QueueItem item = new QueueItem();
            LoopingQueue.getInstance().putIn(item);
            msg = msg + item.getValue();
        } catch (Exception e) {
            msg = e.getMessage();
        }
        LoopingQueue.getInstance().setStatusMsg(msg);
    }

    public void pickupItem() {

        String msg = "Item picked up from the queue : ";
        try {
            QueueItem item = (QueueItem) LoopingQueue.getInstance().pickup();
            msg = msg + item.getValue();
        } catch (Exception e) {
            msg = e.getMessage();
        }
        LoopingQueue.getInstance().setStatusMsg(msg);
    }

    public LoopingQueue getLoopingQueue() {
        return LoopingQueue.getInstance();
    }

    public void resetQueue() {
        LoopingQueue.getInstance().resetQueue();
    }

    public void initQueue(int capacity) {
        LoopingQueue.getInstance().initQueue(capacity);
    }
}

