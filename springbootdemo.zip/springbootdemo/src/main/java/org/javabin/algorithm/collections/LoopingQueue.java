package org.javabin.algorithm.collections;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.javabin.algorithm.domain.DataItem;

public class LoopingQueue {

    private static final int DEFAULT_CAPACITY = 12;
    private static final LoopingQueue INSTANCE = new LoopingQueue(DEFAULT_CAPACITY);
    private static final String QUEUE_READY_MSD = "Ready for action";

    private int capacity; // 队列最大容量
    private int modSize; // 队列取模大小
    private int size; // 队列元素个数
    private int front; // 队列头,指向 队头 的元素
    private int rear; // 队列尾，指向 队尾 的下一个元素
    private DataItem arr[]; // 用于存储数据，模拟队列
    private String statusMsg = QUEUE_READY_MSD;

    public String getStatusMsg() {
        return statusMsg;
    }

    public void setStatusMsg(String statusMsg) {
        this.statusMsg = statusMsg;
    }

    public int getCapacity() {
        return capacity;
    }

    public int getModSize() {
        return modSize;
    }

    public int getSize() {
        return size;
    }

    public int getFront() {
        return front;
    }

    public int getRear() {
        return rear;
    }

    public DataItem[] getArr() {
        return arr;
    }

    public LoopingQueue(int arrMaxSize) {
        // arr = new DataItem[] { new QueueItem(), new QueueItem(), new QueueItem(),
        // new QueueItem(), new QueueItem() };
        initQueue(arrMaxSize);
    }

    public void initQueue(int arrMaxSize) {
        if (this.capacity != arrMaxSize) {
            modSize = arrMaxSize + 1;
            capacity = arrMaxSize;
            arr = new DataItem[modSize];
        }
        resetQueue();
    }

    public void resetQueue() {
        front = 0;
        rear = 0;
        statusMsg = QUEUE_READY_MSD;
    }

    public static LoopingQueue getInstance() {
        return INSTANCE;
    }

    /**
     * 取出队列数据
     */
    public DataItem pickup() throws Exception {
        if (isEmpty()) {
            // throw new RuntimeException("队列空");
            throw new Exception("Failed to pickup item - Queue is empty");
        }
        // front 指向的是队首的位置
        DataItem value = arr[front];
        // 需要向后移动，但是由于是环形，同样需要使用取模的方式来计算
        front = (front + 1) % modSize;
        // 更新队列元素个数
        size = (rear + modSize - front) % modSize;

        return value;
    }

    /**
     * 往队列存储数据
     */
    public void putIn(DataItem n) throws Exception {
        if (isFull()) {
            // System.out.println("队列已满");
            throw new Exception("Failed to add new item - Queue is full");
        }
        arr[rear] = n;
        // rear 指向的是下一个位置
        // 由于是环形队列,需要使用取模的形式来唤醒他的下一个位置
        rear = (rear + 1) % modSize;
        // 更新队列元素个数
        size = (rear + modSize - front) % modSize;
    }

    /**
     * 显示队列中的数据
     */
    public void show() {
        if (isEmpty()) {
            System.out.println("队列为空");
            return;
        }
        // 打印的时候，需要从队首开始打印
        // 打印的次数则是：有效的元素个数
        // 获取数据的下标：由于是环形的，需要使用取模的方式来获取
        for (int i = front; i < front + size(); i++) {
            int index = i % modSize;
            System.out.printf("arr[%d] = %d \n", index, arr[index]);
        }
    }

    /**
     * 查看队列的头部数据，注意：不是取出数据，只是查看
     *
     * @return
     */
    public DataItem head() {
        if (isEmpty()) {
            throw new RuntimeException("队列空");
        }
        return arr[front];
    }

    /**
     * 查看队尾数据
     *
     * @return
     */
    public DataItem tail() {
        if (isEmpty()) {
            throw new RuntimeException("队列空");
        }
        // rear - 1 是队尾数据，但是如果是环形收尾相接的时候
        // 那么 0 -1 就是 -1 了，负数时，则是数组的最后一个元素
        return rear - 1 < 0 ? arr[modSize - 1] : arr[rear - 1];
    }

    // 队列是否已满
    private boolean isFull() {
        return (rear + 1) % modSize == front;
    }

    // 队列是否为空
    @JsonIgnore
    public boolean isEmpty() {
        return rear == front;
    }

    // 有效个数
    @JsonIgnore
    public int size() {
        return (rear + modSize - front) % modSize;
    }

    @JsonIgnore
    public DataItem[] getDataArray() {
        return arr;
    }
}
