package org.javabin.springbootdemo.service;

import org.javabin.springbootdemo.domain.Book;
import org.javabin.springbootdemo.mapper.BookMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookService {

    @Autowired
    BookMapper bookMapper;

    public List<Book> getBookList() {
        return bookMapper.getBookList();
    }
}
