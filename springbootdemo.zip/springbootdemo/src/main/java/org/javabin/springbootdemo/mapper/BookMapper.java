package org.javabin.springbootdemo.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.javabin.springbootdemo.domain.Book;
import org.springframework.stereotype.Component;

import java.util.List;

@Mapper
public interface BookMapper {
    List<Book> getBookList();
}
