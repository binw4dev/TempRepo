package org.javabin.springbootdemo.dto;

public class RespBean {
    private String status;
    private String message;
    private Object obj;

    private RespBean(Builder builder) {
        this.status = builder.status;
        this.message = builder.message;
        this.obj = builder.obj;
    }

    public static RespBean ok(String message, Object obj) {
        RespBean bean = new RespBean(new Builder("200").message(message).obj(obj));
        return bean;
    }

    public static RespBean ok(String message) {
        return ok(message, null);
    }

    public static RespBean error(String status, String message, Object obj) {
        RespBean bean = new RespBean(new Builder(status).message(message).obj(obj));
        return bean;
    }

    public static RespBean error(String message, Object obj) {
        return error("400", message, obj);
    }

    public static RespBean error(String message) {
        return error("400", message, null);
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Object getObj() {
        return obj;
    }

    public void setObj(Object obj) {
        this.obj = obj;
    }

    @Override
    public String toString() {
        return "RespBean{" +
                "status=" + status +
                ", message='" + message + '\'' +
                ", obj=" + obj +
                '}';
    }

    public static class Builder {
        private final String status;
        private String message;
        private Object obj;

        public Builder(String status) {
            this.status = status;
        }

        public Builder message(String message) {
            this.message = message;
            return this;
        }

        public Builder obj(Object obj) {
            this.obj = obj;
            return this;
        }
    }
}
