package org.javabin.springbootdemo.controller;

import org.javabin.springbootdemo.domain.Book;
import org.javabin.springbootdemo.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class HelloController {

    @Autowired
    BookService bookService;

    @GetMapping("/hello")
    public String hello() {
        return "Hello, World!";
    }

    @GetMapping("/book")
    public List<Book> getBookList() {
        return bookService.getBookList();
    }
}
