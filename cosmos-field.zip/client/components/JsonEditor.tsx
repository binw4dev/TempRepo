import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { 
  FileText, 
  Save, 
  Copy,
  Download,
  Eye,
  AlertTriangle,
  CheckCircle
} from "lucide-react";

interface JsonFile {
  id: string;
  name: string;
  content: object;
  size: string;
  createdAt: Date;
}

interface JsonEditorProps {
  jsonFile: JsonFile | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (updatedFile: JsonFile) => void;
}

export function JsonEditor({ jsonFile, isOpen, onClose, onSave }: JsonEditorProps) {
  const [editedFile, setEditedFile] = useState<JsonFile | null>(jsonFile);
  const [jsonString, setJsonString] = useState("");
  const [isValidJson, setIsValidJson] = useState(true);
  const [jsonError, setJsonError] = useState("");

  useEffect(() => {
    if (jsonFile) {
      setEditedFile(jsonFile);
      setJsonString(JSON.stringify(jsonFile.content, null, 2));
      setIsValidJson(true);
      setJsonError("");
    }
  }, [jsonFile]);

  const validateJson = (value: string) => {
    try {
      JSON.parse(value);
      setIsValidJson(true);
      setJsonError("");
      return true;
    } catch (error) {
      setIsValidJson(false);
      setJsonError(error instanceof Error ? error.message : "Invalid JSON");
      return false;
    }
  };

  const handleJsonChange = (value: string) => {
    setJsonString(value);
    validateJson(value);
  };

  const handleSave = () => {
    if (editedFile && isValidJson) {
      try {
        const parsedContent = JSON.parse(jsonString);
        const updatedFile = {
          ...editedFile,
          content: parsedContent,
          size: new Blob([jsonString]).size < 1024 
            ? `${new Blob([jsonString]).size} B`
            : `${(new Blob([jsonString]).size / 1024).toFixed(1)} KB`
        };
        onSave(updatedFile);
        onClose();
      } catch (error) {
        setJsonError("Failed to save JSON");
      }
    }
  };

  const handleCopyJson = () => {
    navigator.clipboard.writeText(jsonString);
  };

  const handleDownload = () => {
    if (editedFile) {
      const blob = new Blob([jsonString], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = editedFile.name;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
  };

  const formatJson = () => {
    if (isValidJson) {
      try {
        const parsed = JSON.parse(jsonString);
        setJsonString(JSON.stringify(parsed, null, 2));
      } catch (error) {
        // Error handling already done in validateJson
      }
    }
  };

  if (!editedFile) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-indigo-600" />
            Edit JSON File
          </DialogTitle>
          <DialogDescription>
            Modify your JSON configuration file.
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 space-y-6 overflow-hidden">
          {/* File Info */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Badge variant="secondary" className="bg-indigo-100 text-indigo-700">
                {editedFile.name}
              </Badge>
              <span className="text-sm text-gray-500">
                Size: {editedFile.size}
              </span>
              <div className="flex items-center gap-1">
                {isValidJson ? (
                  <CheckCircle className="w-4 h-4 text-green-500" />
                ) : (
                  <AlertTriangle className="w-4 h-4 text-red-500" />
                )}
                <span className={`text-sm ${isValidJson ? 'text-green-600' : 'text-red-600'}`}>
                  {isValidJson ? 'Valid JSON' : 'Invalid JSON'}
                </span>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                size="sm"
                onClick={formatJson}
                disabled={!isValidJson}
              >
                <Eye className="w-4 h-4" />
                Format
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleCopyJson}
              >
                <Copy className="w-4 h-4" />
                Copy
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleDownload}
              >
                <Download className="w-4 h-4" />
                Download
              </Button>
            </div>
          </div>

          {/* Form Fields */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="name">File Name</Label>
              <Input
                id="name"
                value={editedFile.name}
                onChange={(e) => setEditedFile({ ...editedFile, name: e.target.value })}
                placeholder="Enter file name"
              />
            </div>
            <div>
              <Label htmlFor="type">File Type</Label>
              <select className="w-full px-3 py-2 border border-input rounded-md text-sm">
                <option value="config">Configuration</option>
                <option value="data">Data</option>
                <option value="schema">Schema</option>
                <option value="theme">Theme</option>
                <option value="other">Other</option>
              </select>
            </div>
            <div>
              <Label htmlFor="encoding">Encoding</Label>
              <select className="w-full px-3 py-2 border border-input rounded-md text-sm">
                <option value="utf-8">UTF-8</option>
                <option value="ascii">ASCII</option>
                <option value="base64">Base64</option>
              </select>
            </div>
          </div>

          {/* JSON Editor */}
          <div className="flex-1 flex flex-col">
            <Label htmlFor="json-content" className="mb-2">JSON Content</Label>
            <div className="flex-1 border rounded-md overflow-hidden">
              <Textarea
                id="json-content"
                value={jsonString}
                onChange={(e) => handleJsonChange(e.target.value)}
                className="min-h-[400px] font-mono text-sm border-0 resize-none focus:ring-0 focus:ring-offset-0"
                placeholder="Enter your JSON content here..."
              />
            </div>
            {!isValidJson && jsonError && (
              <p className="text-sm text-red-600 mt-2 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4" />
                {jsonError}
              </p>
            )}
          </div>

          {/* JSON Preview */}
          {isValidJson && (
            <div>
              <Label>Preview</Label>
              <div className="mt-2 p-4 bg-gray-50 rounded-lg border max-h-32 overflow-auto">
                <pre className="text-xs text-gray-600">
                  {JSON.stringify(JSON.parse(jsonString), null, 2).slice(0, 200)}
                  {JSON.stringify(JSON.parse(jsonString), null, 2).length > 200 && '...'}
                </pre>
              </div>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button 
            onClick={handleSave} 
            disabled={!isValidJson}
            className="bg-indigo-600 hover:bg-indigo-700"
          >
            <Save className="w-4 h-4" />
            Save Changes
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
