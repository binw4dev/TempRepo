import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { 
  Figma, 
  ExternalLink, 
  Save, 
  Copy,
  Download,
  Eye,
  Square,
  Circle,
  Type,
  Image,
  MousePointer,
  Move,
  Palette,
  Layers,
  Grid,
  Ruler,
  RotateCcw,
  RotateCw,
  FlipHorizontal,
  FlipVertical,
  AlignLeft,
  AlignCenter,
  AlignRight,
  AlignJustify,
  Minus,
  Plus
} from "lucide-react";

interface FigmaFile {
  id: string;
  name: string;
  url: string;
  thumbnail?: string;
  createdAt: Date;
}

interface FigmaEditorProps {
  figmaFile: FigmaFile | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (updatedFile: FigmaFile) => void;
}

interface DesignElement {
  id: string;
  type: 'rectangle' | 'circle' | 'text' | 'image';
  x: number;
  y: number;
  width: number;
  height: number;
  color: string;
  text?: string;
  fontSize?: number;
  selected: boolean;
}

export function FigmaEditor({ figmaFile, isOpen, onClose, onSave }: FigmaEditorProps) {
  const [editedFile, setEditedFile] = useState<FigmaFile | null>(figmaFile);
  const [selectedTool, setSelectedTool] = useState<string>('select');
  const [elements, setElements] = useState<DesignElement[]>([
    {
      id: '1',
      type: 'rectangle',
      x: 50,
      y: 50,
      width: 200,
      height: 100,
      color: '#8B5CF6',
      selected: false
    },
    {
      id: '2',
      type: 'circle',
      x: 300,
      y: 80,
      width: 80,
      height: 80,
      color: '#06B6D4',
      selected: false
    },
    {
      id: '3',
      type: 'text',
      x: 50,
      y: 200,
      width: 300,
      height: 40,
      color: '#1F2937',
      text: 'Sample Text',
      fontSize: 24,
      selected: false
    }
  ]);
  const [selectedElement, setSelectedElement] = useState<string | null>(null);

  useEffect(() => {
    setEditedFile(figmaFile);
  }, [figmaFile]);

  const handleSave = () => {
    if (editedFile) {
      onSave(editedFile);
      onClose();
    }
  };

  const handleCopyUrl = () => {
    if (editedFile?.url) {
      navigator.clipboard.writeText(editedFile.url);
    }
  };

  const handleViewInFigma = () => {
    if (editedFile?.url) {
      window.open(editedFile.url, '_blank');
    }
  };

  const handleElementClick = (elementId: string) => {
    if (selectedTool === 'select') {
      setElements(prev => prev.map(el => ({
        ...el,
        selected: el.id === elementId
      })));
      setSelectedElement(elementId);
    }
  };

  const handleCanvasClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (selectedTool === 'select') {
      setElements(prev => prev.map(el => ({ ...el, selected: false })));
      setSelectedElement(null);
      return;
    }

    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    if (selectedTool === 'rectangle') {
      const newElement: DesignElement = {
        id: Date.now().toString(),
        type: 'rectangle',
        x: x - 50,
        y: y - 25,
        width: 100,
        height: 50,
        color: '#8B5CF6',
        selected: false
      };
      setElements(prev => [...prev, newElement]);
    } else if (selectedTool === 'circle') {
      const newElement: DesignElement = {
        id: Date.now().toString(),
        type: 'circle',
        x: x - 25,
        y: y - 25,
        width: 50,
        height: 50,
        color: '#06B6D4',
        selected: false
      };
      setElements(prev => [...prev, newElement]);
    } else if (selectedTool === 'text') {
      const newElement: DesignElement = {
        id: Date.now().toString(),
        type: 'text',
        x: x - 50,
        y: y - 10,
        width: 100,
        height: 20,
        color: '#1F2937',
        text: 'New Text',
        fontSize: 16,
        selected: false
      };
      setElements(prev => [...prev, newElement]);
    }
  };

  const handleElementPropertyChange = (property: string, value: any) => {
    if (!selectedElement) return;
    
    setElements(prev => prev.map(el => 
      el.id === selectedElement 
        ? { ...el, [property]: value }
        : el
    ));
  };

  const deleteSelectedElement = () => {
    if (selectedElement) {
      setElements(prev => prev.filter(el => el.id !== selectedElement));
      setSelectedElement(null);
    }
  };

  const duplicateSelectedElement = () => {
    if (selectedElement) {
      const element = elements.find(el => el.id === selectedElement);
      if (element) {
        const newElement: DesignElement = {
          ...element,
          id: Date.now().toString(),
          x: element.x + 20,
          y: element.y + 20,
          selected: false
        };
        setElements(prev => [...prev, newElement]);
      }
    }
  };

  const selectedElementData = selectedElement ? elements.find(el => el.id === selectedElement) : null;

  if (!editedFile) return null;

  const tools = [
    { id: 'select', icon: MousePointer, label: 'Select' },
    { id: 'rectangle', icon: Square, label: 'Rectangle' },
    { id: 'circle', icon: Circle, label: 'Circle' },
    { id: 'text', icon: Type, label: 'Text' },
    { id: 'image', icon: Image, label: 'Image' },
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl max-h-[95vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Figma className="w-5 h-5 text-violet-600" />
            Edit Figma Design - {editedFile.name}
          </DialogTitle>
          <DialogDescription>
            Use the design tools below to edit your Figma design.
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 flex gap-4 overflow-hidden">
          {/* Left Toolbar */}
          <div className="w-16 bg-gray-50 rounded-lg p-2 flex flex-col gap-2">
            {tools.map((tool) => (
              <Button
                key={tool.id}
                variant={selectedTool === tool.id ? "default" : "ghost"}
                size="icon"
                className={`w-12 h-12 ${selectedTool === tool.id ? 'bg-violet-600 text-white' : ''}`}
                onClick={() => setSelectedTool(tool.id)}
                title={tool.label}
              >
                <tool.icon className="w-5 h-5" />
              </Button>
            ))}
            
            <div className="border-t pt-2 mt-2">
              <Button variant="ghost" size="icon" className="w-12 h-12" title="Move">
                <Move className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="icon" className="w-12 h-12" title="Grid">
                <Grid className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="icon" className="w-12 h-12" title="Ruler">
                <Ruler className="w-5 h-5" />
              </Button>
            </div>
          </div>

          {/* Main Canvas Area */}
          <div className="flex-1 flex flex-col">
            {/* Top Toolbar */}
            <div className="h-12 bg-gray-50 rounded-lg mb-4 flex items-center px-4 gap-2">
              <Button variant="outline" size="sm" onClick={() => setElements([])}>
                Clear All
              </Button>
              <Button variant="outline" size="sm" onClick={deleteSelectedElement} disabled={!selectedElement}>
                Delete
              </Button>
              <Button variant="outline" size="sm" onClick={duplicateSelectedElement} disabled={!selectedElement}>
                Duplicate
              </Button>
              
              <div className="border-l mx-2 h-6"></div>
              
              <Button variant="outline" size="icon" title="Rotate Left">
                <RotateCcw className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="icon" title="Rotate Right">
                <RotateCw className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="icon" title="Flip Horizontal">
                <FlipHorizontal className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="icon" title="Flip Vertical">
                <FlipVertical className="w-4 h-4" />
              </Button>

              <div className="border-l mx-2 h-6"></div>

              <Button variant="outline" size="icon" title="Align Left">
                <AlignLeft className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="icon" title="Align Center">
                <AlignCenter className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="icon" title="Align Right">
                <AlignRight className="w-4 h-4" />
              </Button>

              <div className="ml-auto flex gap-2">
                <Button variant="outline" size="sm" onClick={handleViewInFigma}>
                  <ExternalLink className="w-4 h-4" />
                  View in Figma
                </Button>
              </div>
            </div>

            {/* Canvas */}
            <div className="flex-1 bg-white border rounded-lg overflow-hidden relative">
              <div 
                className="w-full h-full relative cursor-crosshair bg-gray-50"
                onClick={handleCanvasClick}
                style={{ minHeight: '400px' }}
              >
                {/* Grid background */}
                <div 
                  className="absolute inset-0 opacity-20"
                  style={{
                    backgroundImage: `
                      linear-gradient(to right, #e5e7eb 1px, transparent 1px),
                      linear-gradient(to bottom, #e5e7eb 1px, transparent 1px)
                    `,
                    backgroundSize: '20px 20px'
                  }}
                />
                
                {/* Design Elements */}
                {elements.map((element) => (
                  <div
                    key={element.id}
                    className={`absolute cursor-pointer border-2 ${
                      element.selected ? 'border-violet-500' : 'border-transparent'
                    } hover:border-violet-300`}
                    style={{
                      left: element.x,
                      top: element.y,
                      width: element.width,
                      height: element.height,
                      backgroundColor: element.type !== 'text' ? element.color : 'transparent',
                      borderRadius: element.type === 'circle' ? '50%' : '4px',
                      color: element.type === 'text' ? element.color : 'transparent',
                      fontSize: element.fontSize || 16,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: element.type === 'text' ? 'flex-start' : 'center',
                      padding: element.type === 'text' ? '4px' : '0'
                    }}
                    onClick={(e) => {
                      e.stopPropagation();
                      handleElementClick(element.id);
                    }}
                  >
                    {element.type === 'text' ? element.text : ''}
                    {element.type === 'image' && (
                      <Image className="w-6 h-6 text-gray-400" />
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Properties Panel */}
          <div className="w-80 bg-gray-50 rounded-lg p-4 overflow-auto">
            <h3 className="font-semibold mb-4 flex items-center gap-2">
              <Layers className="w-4 h-4" />
              Properties
            </h3>

            {selectedElementData ? (
              <div className="space-y-4">
                <div>
                  <Label className="text-sm font-medium">Element Type</Label>
                  <p className="text-sm text-gray-600 capitalize">{selectedElementData.type}</p>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label className="text-xs">X Position</Label>
                    <Input
                      type="number"
                      value={selectedElementData.x}
                      onChange={(e) => handleElementPropertyChange('x', parseInt(e.target.value))}
                      className="h-8 text-xs"
                    />
                  </div>
                  <div>
                    <Label className="text-xs">Y Position</Label>
                    <Input
                      type="number"
                      value={selectedElementData.y}
                      onChange={(e) => handleElementPropertyChange('y', parseInt(e.target.value))}
                      className="h-8 text-xs"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label className="text-xs">Width</Label>
                    <Input
                      type="number"
                      value={selectedElementData.width}
                      onChange={(e) => handleElementPropertyChange('width', parseInt(e.target.value))}
                      className="h-8 text-xs"
                    />
                  </div>
                  <div>
                    <Label className="text-xs">Height</Label>
                    <Input
                      type="number"
                      value={selectedElementData.height}
                      onChange={(e) => handleElementPropertyChange('height', parseInt(e.target.value))}
                      className="h-8 text-xs"
                    />
                  </div>
                </div>

                <div>
                  <Label className="text-xs flex items-center gap-2">
                    <Palette className="w-3 h-3" />
                    Color
                  </Label>
                  <div className="flex gap-2 mt-1">
                    <Input
                      type="color"
                      value={selectedElementData.color}
                      onChange={(e) => handleElementPropertyChange('color', e.target.value)}
                      className="w-12 h-8 p-1 border rounded"
                    />
                    <Input
                      type="text"
                      value={selectedElementData.color}
                      onChange={(e) => handleElementPropertyChange('color', e.target.value)}
                      className="flex-1 h-8 text-xs"
                    />
                  </div>
                </div>

                {selectedElementData.type === 'text' && (
                  <>
                    <div>
                      <Label className="text-xs">Text Content</Label>
                      <Input
                        value={selectedElementData.text || ''}
                        onChange={(e) => handleElementPropertyChange('text', e.target.value)}
                        className="h-8 text-xs"
                      />
                    </div>
                    <div>
                      <Label className="text-xs">Font Size</Label>
                      <Input
                        type="number"
                        value={selectedElementData.fontSize || 16}
                        onChange={(e) => handleElementPropertyChange('fontSize', parseInt(e.target.value))}
                        className="h-8 text-xs"
                      />
                    </div>
                  </>
                )}

                <div className="pt-4 border-t">
                  <h4 className="font-medium text-sm mb-2">Actions</h4>
                  <div className="space-y-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full justify-start"
                      onClick={duplicateSelectedElement}
                    >
                      <Copy className="w-4 h-4 mr-2" />
                      Duplicate
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full justify-start text-red-600 hover:text-red-700"
                      onClick={deleteSelectedElement}
                    >
                      <Minus className="w-4 h-4 mr-2" />
                      Delete
                    </Button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                <Layers className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">Select an element to edit its properties</p>
              </div>
            )}

            {/* Layers List */}
            <div className="mt-6 pt-4 border-t">
              <h4 className="font-medium text-sm mb-2">Layers</h4>
              <div className="space-y-1">
                {elements.map((element) => (
                  <div
                    key={element.id}
                    className={`p-2 rounded text-xs cursor-pointer flex items-center justify-between ${
                      selectedElement === element.id ? 'bg-violet-100 text-violet-700' : 'hover:bg-gray-100'
                    }`}
                    onClick={() => handleElementClick(element.id)}
                  >
                    <span className="capitalize">{element.type}</span>
                    <span className="text-gray-400">#{element.id.slice(-4)}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Design Settings (collapsed by default) */}
        <div className="border-t pt-4 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="name">Design Name</Label>
              <Input
                id="name"
                value={editedFile.name}
                onChange={(e) => setEditedFile({ ...editedFile, name: e.target.value })}
                placeholder="Enter design name"
              />
            </div>
            <div>
              <Label htmlFor="canvas-width">Canvas Width</Label>
              <Input
                id="canvas-width"
                type="number"
                placeholder="1920"
                className="text-sm"
              />
            </div>
            <div>
              <Label htmlFor="canvas-height">Canvas Height</Label>
              <Input
                id="canvas-height"
                type="number"
                placeholder="1080"
                className="text-sm"
              />
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSave} className="bg-violet-600 hover:bg-violet-700">
            <Save className="w-4 h-4" />
            Save Design
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
