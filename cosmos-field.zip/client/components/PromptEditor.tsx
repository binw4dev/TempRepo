import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { 
  Brain, 
  Save, 
  Copy,
  Play,
  Eye,
  Wand2,
  Target
} from "lucide-react";

interface AIPrompt {
  id: string;
  name: string;
  description: string;
  prompt: string;
  category: string;
  createdAt: Date;
}

interface PromptEditorProps {
  aiPrompt: AIPrompt | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (updatedPrompt: AIPrompt) => void;
  onRun?: (prompt: AIPrompt) => void;
}

const categories = [
  "Landing Pages",
  "Dashboards", 
  "Components",
  "Forms",
  "Navigation",
  "E-commerce",
  "Admin Panels",
  "Portfolio",
  "Blog",
  "Other"
];

const promptTemplates = [
  {
    name: "Component Generator",
    template: "Create a modern React component for [COMPONENT_TYPE] with the following features:\n- [FEATURE_1]\n- [FEATURE_2]\n- [FEATURE_3]\n\nUse Tailwind CSS for styling and ensure it's responsive and accessible."
  },
  {
    name: "Page Layout",
    template: "Design a [PAGE_TYPE] page with:\n- Header with navigation\n- Main content area\n- Footer\n- Responsive design for mobile and desktop\n- Modern styling using Tailwind CSS"
  },
  {
    name: "Dashboard Template",
    template: "Create a comprehensive dashboard with:\n- Sidebar navigation\n- Header with user profile\n- Data visualization charts\n- Statistics cards\n- Tables with data\n- Responsive layout"
  }
];

export function PromptEditor({ aiPrompt, isOpen, onClose, onSave, onRun }: PromptEditorProps) {
  const [editedPrompt, setEditedPrompt] = useState<AIPrompt | null>(aiPrompt);

  useEffect(() => {
    if (aiPrompt) {
      setEditedPrompt(aiPrompt);
    } else {
      // Create new prompt
      setEditedPrompt({
        id: Date.now().toString(),
        name: "",
        description: "",
        prompt: "",
        category: "Other",
        createdAt: new Date()
      });
    }
  }, [aiPrompt]);

  const handleSave = () => {
    if (editedPrompt && editedPrompt.name.trim() && editedPrompt.prompt.trim()) {
      onSave(editedPrompt);
      onClose();
    }
  };

  const handleCopyPrompt = () => {
    if (editedPrompt?.prompt) {
      navigator.clipboard.writeText(editedPrompt.prompt);
    }
  };

  const handleRunPrompt = () => {
    if (editedPrompt && onRun) {
      onRun(editedPrompt);
    }
  };

  const handleUseTemplate = (template: string) => {
    if (editedPrompt) {
      setEditedPrompt({
        ...editedPrompt,
        prompt: template
      });
    }
  };

  const getCharacterCount = () => {
    return editedPrompt?.prompt.length || 0;
  };

  const getWordCount = () => {
    return editedPrompt?.prompt.trim().split(/\s+/).filter(word => word).length || 0;
  };

  if (!editedPrompt) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Brain className="w-5 h-5 text-emerald-600" />
            {aiPrompt ? 'Edit AI Prompt' : 'Create AI Prompt'}
          </DialogTitle>
          <DialogDescription>
            {aiPrompt ? 'Modify your AI prompt configuration.' : 'Create a new AI prompt for UI generation.'}
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 space-y-6 overflow-auto">
          {/* Quick Actions */}
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              size="sm"
              onClick={handleCopyPrompt}
              disabled={!editedPrompt.prompt}
            >
              <Copy className="w-4 h-4" />
              Copy Prompt
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              onClick={handleRunPrompt}
              disabled={!editedPrompt.prompt.trim()}
              className="bg-emerald-50 border-emerald-200 text-emerald-700 hover:bg-emerald-100"
            >
              <Play className="w-4 h-4" />
              Test Run
            </Button>
          </div>

          {/* Basic Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="name">Prompt Name</Label>
              <Input
                id="name"
                value={editedPrompt.name}
                onChange={(e) => setEditedPrompt({ ...editedPrompt, name: e.target.value })}
                placeholder="Enter prompt name"
              />
            </div>
            <div>
              <Label htmlFor="category">Category</Label>
              <select 
                id="category"
                value={editedPrompt.category}
                onChange={(e) => setEditedPrompt({ ...editedPrompt, category: e.target.value })}
                className="w-full px-3 py-2 border border-input rounded-md text-sm"
              >
                {categories.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={editedPrompt.description}
              onChange={(e) => setEditedPrompt({ ...editedPrompt, description: e.target.value })}
              placeholder="Describe what this prompt generates..."
              rows={2}
            />
          </div>

          {/* Prompt Templates */}
          <div>
            <Label className="flex items-center gap-2 mb-3">
              <Wand2 className="w-4 h-4" />
              Prompt Templates
            </Label>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {promptTemplates.map((template, index) => (
                <Button
                  key={index}
                  variant="outline"
                  size="sm"
                  onClick={() => handleUseTemplate(template.template)}
                  className="h-auto p-3 text-left flex flex-col items-start"
                >
                  <span className="font-medium text-sm">{template.name}</span>
                  <span className="text-xs text-gray-500 mt-1">Click to use this template</span>
                </Button>
              ))}
            </div>
          </div>

          {/* Prompt Content */}
          <div className="flex-1 flex flex-col">
            <div className="flex items-center justify-between mb-2">
              <Label htmlFor="prompt" className="flex items-center gap-2">
                <Target className="w-4 h-4" />
                AI Prompt
              </Label>
              <div className="flex gap-4 text-sm text-gray-500">
                <span>{getWordCount()} words</span>
                <span>{getCharacterCount()} characters</span>
              </div>
            </div>
            
            <Textarea
              id="prompt"
              value={editedPrompt.prompt}
              onChange={(e) => setEditedPrompt({ ...editedPrompt, prompt: e.target.value })}
              placeholder="Write your AI prompt here... Be specific about what you want to generate.

Example:
Create a modern landing page for a SaaS product with:
- Hero section with gradient background
- Feature cards in a 3-column grid
- Testimonials section
- Pricing table with 3 tiers
- Footer with company links

Use Tailwind CSS and make it fully responsive."
              className="min-h-[250px] font-mono text-sm"
            />
          </div>

          {/* Prompt Tips */}
          <div className="bg-emerald-50 p-4 rounded-lg">
            <h4 className="text-sm font-medium text-emerald-900 mb-2 flex items-center gap-2">
              <Eye className="w-4 h-4" />
              Prompt Writing Tips:
            </h4>
            <ul className="text-xs text-emerald-700 space-y-1">
              <li>• Be specific about layout, components, and styling</li>
              <li>• Include details about responsive behavior</li>
              <li>• Mention specific UI libraries or frameworks to use</li>
              <li>• Describe interactions and states (hover, active, etc.)</li>
              <li>• Include accessibility requirements if needed</li>
            </ul>
          </div>

          {/* Preview Section */}
          {editedPrompt.prompt && (
            <div>
              <Label>Prompt Preview</Label>
              <div className="mt-2 p-4 bg-gray-50 rounded-lg border max-h-32 overflow-auto">
                <p className="text-sm text-gray-700 whitespace-pre-wrap">
                  {editedPrompt.prompt.slice(0, 300)}
                  {editedPrompt.prompt.length > 300 && '...'}
                </p>
              </div>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button 
            onClick={handleSave}
            disabled={!editedPrompt.name.trim() || !editedPrompt.prompt.trim()}
            className="bg-emerald-600 hover:bg-emerald-700"
          >
            <Save className="w-4 h-4" />
            {aiPrompt ? 'Save Changes' : 'Create Prompt'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
