import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { 
  Upload, 
  Figma, 
  Link as LinkIcon,
  AlertCircle,
  CheckCircle
} from "lucide-react";

interface FigmaFile {
  id: string;
  name: string;
  url: string;
  thumbnail?: string;
  createdAt: Date;
}

interface FigmaUploaderProps {
  isOpen: boolean;
  onClose: () => void;
  onUpload: (file: FigmaFile) => void;
}

export function FigmaUploader({ isOpen, onClose, onUpload }: FigmaUploaderProps) {
  const [figmaUrl, setFigmaUrl] = useState("");
  const [designName, setDesignName] = useState("");
  const [isValidUrl, setIsValidUrl] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const validateFigmaUrl = (url: string) => {
    const figmaUrlPattern = /^https:\/\/(www\.)?figma\.com\/(file|proto)\/[A-Za-z0-9]+/;
    return figmaUrlPattern.test(url);
  };

  const handleUrlChange = (url: string) => {
    setFigmaUrl(url);
    setIsValidUrl(validateFigmaUrl(url));
    
    // Auto-extract design name from URL if possible
    if (validateFigmaUrl(url) && !designName) {
      const match = url.match(/\/([^\/]+)(?:\?|$)/);
      if (match) {
        const extractedName = match[1].replace(/[-_]/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
        setDesignName(extractedName.slice(0, 50));
      }
    }
  };

  const handleImport = async () => {
    if (!isValidUrl || !designName.trim()) return;

    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));

    const newFile: FigmaFile = {
      id: Date.now().toString(),
      name: designName.trim(),
      url: figmaUrl,
      createdAt: new Date()
    };

    onUpload(newFile);
    setIsLoading(false);
    handleClose();
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Handle .fig file upload
      const newFile: FigmaFile = {
        id: Date.now().toString(),
        name: file.name.replace('.fig', ''),
        url: `file://${file.name}`,
        createdAt: new Date()
      };
      onUpload(newFile);
      handleClose();
    }
  };

  const handleClose = () => {
    setFigmaUrl("");
    setDesignName("");
    setIsValidUrl(false);
    setIsLoading(false);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Figma className="w-5 h-5 text-violet-600" />
            Import Figma Design
          </DialogTitle>
          <DialogDescription>
            Import your Figma designs by URL or upload a .fig file.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* URL Import */}
          <div className="space-y-4">
            <div>
              <Label htmlFor="figma-url" className="flex items-center gap-2">
                <LinkIcon className="w-4 h-4" />
                Figma URL
              </Label>
              <div className="relative">
                <Input
                  id="figma-url"
                  value={figmaUrl}
                  onChange={(e) => handleUrlChange(e.target.value)}
                  placeholder="https://www.figma.com/file/..."
                  className={`pr-10 ${
                    figmaUrl && !isValidUrl ? 'border-red-300 focus:border-red-500' : 
                    isValidUrl ? 'border-green-300 focus:border-green-500' : ''
                  }`}
                />
                <div className="absolute inset-y-0 right-0 flex items-center pr-3">
                  {figmaUrl && (
                    isValidUrl ? 
                      <CheckCircle className="w-4 h-4 text-green-500" /> :
                      <AlertCircle className="w-4 h-4 text-red-500" />
                  )}
                </div>
              </div>
              {figmaUrl && !isValidUrl && (
                <p className="text-sm text-red-600 mt-1">
                  Please enter a valid Figma URL
                </p>
              )}
            </div>

            <div>
              <Label htmlFor="design-name">Design Name</Label>
              <Input
                id="design-name"
                value={designName}
                onChange={(e) => setDesignName(e.target.value)}
                placeholder="Enter a name for this design"
                maxLength={100}
              />
            </div>
          </div>

          {/* Divider */}
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-background px-2 text-muted-foreground">Or</span>
            </div>
          </div>

          {/* File Upload */}
          <div className="space-y-4">
            <Label className="flex items-center gap-2">
              <Upload className="w-4 h-4" />
              Upload .fig File
            </Label>
            <div
              className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-violet-400 transition-colors cursor-pointer"
              onClick={() => fileInputRef.current?.click()}
            >
              <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
              <p className="text-sm text-gray-600 mb-1">
                Click to upload or drag and drop
              </p>
              <p className="text-xs text-gray-500">
                Supports .fig files up to 50MB
              </p>
              <input
                ref={fileInputRef}
                type="file"
                accept=".fig"
                onChange={handleFileUpload}
                className="hidden"
              />
            </div>
          </div>

          {/* Import Tips */}
          <div className="bg-violet-50 p-4 rounded-lg">
            <h4 className="text-sm font-medium text-violet-900 mb-2">
              Import Tips:
            </h4>
            <ul className="text-xs text-violet-700 space-y-1">
              <li>• Make sure your Figma file is public or shared</li>
              <li>• Component libraries work best for UI generation</li>
              <li>• Organize your frames clearly for better results</li>
            </ul>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={handleClose}>
            Cancel
          </Button>
          <Button 
            onClick={handleImport}
            disabled={!isValidUrl || !designName.trim() || isLoading}
            className="bg-violet-600 hover:bg-violet-700"
          >
            {isLoading ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                Importing...
              </>
            ) : (
              <>
                <Figma className="w-4 h-4" />
                Import Design
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
