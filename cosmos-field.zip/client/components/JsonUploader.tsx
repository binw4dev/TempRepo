import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { 
  Upload, 
  FileText, 
  AlertCircle,
  CheckCircle,
  Code
} from "lucide-react";

interface JsonFile {
  id: string;
  name: string;
  content: object;
  size: string;
  createdAt: Date;
}

interface JsonUploaderProps {
  isOpen: boolean;
  onClose: () => void;
  onUpload: (file: JsonFile) => void;
}

export function JsonUploader({ isOpen, onClose, onUpload }: JsonUploaderProps) {
  const [fileName, setFileName] = useState("");
  const [jsonContent, setJsonContent] = useState("");
  const [isValidJson, setIsValidJson] = useState(false);
  const [jsonError, setJsonError] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const validateJson = (value: string) => {
    if (!value.trim()) {
      setIsValidJson(false);
      setJsonError("");
      return false;
    }
    
    try {
      JSON.parse(value);
      setIsValidJson(true);
      setJsonError("");
      return true;
    } catch (error) {
      setIsValidJson(false);
      setJsonError(error instanceof Error ? error.message : "Invalid JSON");
      return false;
    }
  };

  const handleJsonChange = (value: string) => {
    setJsonContent(value);
    validateJson(value);
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const content = e.target?.result as string;
        setJsonContent(content);
        setFileName(file.name);
        validateJson(content);
      };
      reader.readAsText(file);
    }
  };

  const handleImport = async () => {
    if (!isValidJson || !fileName.trim()) return;

    setIsLoading(true);
    
    // Simulate processing
    await new Promise(resolve => setTimeout(resolve, 1000));

    try {
      const parsedContent = JSON.parse(jsonContent);
      const size = new Blob([jsonContent]).size < 1024 
        ? `${new Blob([jsonContent]).size} B`
        : `${(new Blob([jsonContent]).size / 1024).toFixed(1)} KB`;

      const newFile: JsonFile = {
        id: Date.now().toString(),
        name: fileName.trim(),
        content: parsedContent,
        size,
        createdAt: new Date()
      };

      onUpload(newFile);
      setIsLoading(false);
      handleClose();
    } catch (error) {
      setJsonError("Failed to process JSON file");
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    setFileName("");
    setJsonContent("");
    setIsValidJson(false);
    setJsonError("");
    setIsLoading(false);
    onClose();
  };

  const formatJson = () => {
    if (isValidJson) {
      try {
        const parsed = JSON.parse(jsonContent);
        setJsonContent(JSON.stringify(parsed, null, 2));
      } catch (error) {
        // Error already handled in validateJson
      }
    }
  };

  const loadSampleJson = () => {
    const sample = {
      "name": "Sample Configuration",
      "version": "1.0.0",
      "settings": {
        "theme": "dark",
        "language": "en",
        "notifications": true
      },
      "features": ["authentication", "dashboard", "analytics"]
    };
    const formatted = JSON.stringify(sample, null, 2);
    setJsonContent(formatted);
    setFileName("sample-config.json");
    validateJson(formatted);
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-indigo-600" />
            Import JSON File
          </DialogTitle>
          <DialogDescription>
            Upload a JSON file or paste JSON content directly.
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 space-y-6 overflow-hidden">
          {/* File Upload Section */}
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="file-name">File Name</Label>
                <Input
                  id="file-name"
                  value={fileName}
                  onChange={(e) => setFileName(e.target.value)}
                  placeholder="Enter file name (e.g., config.json)"
                />
              </div>
              <div className="flex items-end gap-2">
                <Button
                  variant="outline"
                  onClick={() => fileInputRef.current?.click()}
                  className="flex-1"
                >
                  <Upload className="w-4 h-4" />
                  Upload File
                </Button>
                <Button
                  variant="outline"
                  onClick={loadSampleJson}
                >
                  <Code className="w-4 h-4" />
                  Sample
                </Button>
              </div>
            </div>

            <input
              ref={fileInputRef}
              type="file"
              accept=".json,.txt"
              onChange={handleFileUpload}
              className="hidden"
            />
          </div>

          {/* JSON Editor */}
          <div className="flex-1 flex flex-col">
            <div className="flex items-center justify-between mb-2">
              <Label htmlFor="json-input">JSON Content</Label>
              <div className="flex items-center gap-2">
                {jsonContent && (
                  <div className="flex items-center gap-1">
                    {isValidJson ? (
                      <CheckCircle className="w-4 h-4 text-green-500" />
                    ) : (
                      <AlertCircle className="w-4 h-4 text-red-500" />
                    )}
                    <span className={`text-sm ${isValidJson ? 'text-green-600' : 'text-red-600'}`}>
                      {isValidJson ? 'Valid JSON' : 'Invalid JSON'}
                    </span>
                  </div>
                )}
                {isValidJson && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={formatJson}
                  >
                    Format
                  </Button>
                )}
              </div>
            </div>
            
            <div className="flex-1 border rounded-md overflow-hidden">
              <Textarea
                id="json-input"
                value={jsonContent}
                onChange={(e) => handleJsonChange(e.target.value)}
                placeholder='Paste your JSON content here...\n\nExample:\n{\n  "name": "My Config",\n  "version": "1.0.0"\n}'
                className="min-h-[300px] font-mono text-sm border-0 resize-none focus:ring-0 focus:ring-offset-0"
              />
            </div>
            
            {!isValidJson && jsonError && (
              <p className="text-sm text-red-600 mt-2 flex items-center gap-2">
                <AlertCircle className="w-4 h-4" />
                {jsonError}
              </p>
            )}
          </div>

          {/* Preview Section */}
          {isValidJson && jsonContent && (
            <div>
              <Label>File Preview</Label>
              <div className="mt-2 p-4 bg-indigo-50 rounded-lg border">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-indigo-700">
                    {fileName || "untitled.json"}
                  </span>
                  <span className="text-xs text-indigo-600">
                    {new Blob([jsonContent]).size < 1024 
                      ? `${new Blob([jsonContent]).size} B`
                      : `${(new Blob([jsonContent]).size / 1024).toFixed(1)} KB`}
                  </span>
                </div>
                <div className="max-h-20 overflow-auto">
                  <pre className="text-xs text-indigo-600">
                    {JSON.stringify(JSON.parse(jsonContent), null, 2).slice(0, 150)}
                    {JSON.stringify(JSON.parse(jsonContent), null, 2).length > 150 && '...'}
                  </pre>
                </div>
              </div>
            </div>
          )}

          {/* Import Tips */}
          <div className="bg-gray-50 p-4 rounded-lg">
            <h4 className="text-sm font-medium text-gray-900 mb-2">
              Import Tips:
            </h4>
            <ul className="text-xs text-gray-600 space-y-1">
              <li>• Ensure your JSON is properly formatted and valid</li>
              <li>• Supported file types: .json, .txt</li>
              <li>• Maximum file size: 10MB</li>
              <li>• Use meaningful file names for better organization</li>
            </ul>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={handleClose}>
            Cancel
          </Button>
          <Button 
            onClick={handleImport}
            disabled={!isValidJson || !fileName.trim() || isLoading}
            className="bg-indigo-600 hover:bg-indigo-700"
          >
            {isLoading ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                Importing...
              </>
            ) : (
              <>
                <FileText className="w-4 h-4" />
                Import JSON
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
