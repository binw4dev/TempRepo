import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { FigmaEditor } from "@/components/FigmaEditor";
import { FigmaUploader } from "@/components/FigmaUploader";
import { JsonEditor } from "@/components/JsonEditor";
import { JsonUploader } from "@/components/JsonUploader";
import { PromptEditor } from "@/components/PromptEditor";
import { PromptRunner } from "@/components/PromptRunner";
import {
  Upload,
  FileText,
  Brain,
  Edit2,
  Trash2,
  Play,
  Plus,
  Figma,
  Code2,
  Sparkles,
  CheckSquare,
  Square
} from "lucide-react";

interface FigmaFile {
  id: string;
  name: string;
  url: string;
  thumbnail?: string;
  createdAt: Date;
}

interface JsonFile {
  id: string;
  name: string;
  content: object;
  size: string;
  createdAt: Date;
}

interface AIPrompt {
  id: string;
  name: string;
  description: string;
  prompt: string;
  category: string;
  createdAt: Date;
}

export default function Index() {
  const [selectedFigmaFile, setSelectedFigmaFile] = useState<FigmaFile | null>(null);
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [isUploaderOpen, setIsUploaderOpen] = useState(false);

  const [selectedJsonFile, setSelectedJsonFile] = useState<JsonFile | null>(null);
  const [isJsonEditorOpen, setIsJsonEditorOpen] = useState(false);
  const [isJsonUploaderOpen, setIsJsonUploaderOpen] = useState(false);

  const [selectedPrompt, setSelectedPrompt] = useState<AIPrompt | null>(null);
  const [isPromptEditorOpen, setIsPromptEditorOpen] = useState(false);
  const [isPromptRunnerOpen, setIsPromptRunnerOpen] = useState(false);

  // Selection state for files - pre-select the money transfer JSON
  const [selectedFigmaIds, setSelectedFigmaIds] = useState<string[]>([]);
  const [selectedJsonIds, setSelectedJsonIds] = useState<string[]>(["1"]); // Pre-select money transfer JSON

  const [figmaFiles, setFigmaFiles] = useState<FigmaFile[]>([
    {
      id: "1",
      name: "Mobile App Design",
      url: "https://figma.com/file/example1",
      createdAt: new Date("2024-01-15")
    },
    {
      id: "2", 
      name: "Dashboard Layout",
      url: "https://figma.com/file/example2",
      createdAt: new Date("2024-01-10")
    }
  ]);

  const [jsonFiles, setJsonFiles] = useState<JsonFile[]>([
    {
      id: "1",
      name: "money-transfer-app.json",
      content: {
        "info": {
          "title": "Send Money Worldwide",
          "description": "Fast, secure, and reliable money transfers",
          "version": "1.0"
        },
        "Module": [
          {
            "name": "Pricing",
            "input": {
              "section": [
                {
                  "title": "Get Pricing",
                  "description": "Provide payout country and amount information",
                  "fields": [
                    {
                      "label": "Payout Country",
                      "type": "list",
                      "listvalue": ["Mexico", "India", "Canada"],
                      "required": "mandatory"
                    },
                    {
                      "label": "Payout Method",
                      "type": "list",
                      "listvalue": ["Cash Pickup", "Bank Deposit", "Mobile Wallet"],
                      "required": "mandatory"
                    },
                    {
                      "label": "Amount Information",
                      "type": "subsection",
                      "required": "optional"
                    },
                    {
                      "label": "Send Amount",
                      "type": "amount",
                      "required": "mandatory",
                      "subsection": "Amount Information",
                      "placeholder": "0.00"
                    },
                    {
                      "label": "Payout Amount",
                      "type": "amount",
                      "required": "optional",
                      "subsection": "Amount Information",
                      "placeholder": "0.00"
                    }
                  ]
                }
              ]
            },
            "output_sample_data": {
              "Exchange Rate": "1 USD = 20.15 MXN",
              "Transfer Fee": "$4.99",
              "Maximum Transfer Limit": "$10,000 USD per transaction"
            }
          },
          {
            "name": "Order Create",
            "input": {
              "section": [
                {
                  "title": "Sender Details",
                  "description": "Your personal information",
                  "input_fields": [
                    {
                      "label": "First Name",
                      "type": "text",
                      "required": "mandatory",
                      "placeholder": "Enter first name"
                    },
                    {
                      "label": "Paternal Name",
                      "type": "text",
                      "required": "mandatory",
                      "placeholder": "Enter paternal name"
                    },
                    {
                      "label": "Phone Number",
                      "type": "text",
                      "required": "mandatory",
                      "placeholder": "Enter phone number"
                    },
                    {
                      "label": "Email",
                      "type": "text",
                      "required": "optional",
                      "placeholder": "Enter email address"
                    },
                    {
                      "label": "Address Information",
                      "type": "subsection",
                      "required": "optional"
                    },
                    {
                      "label": "Address Line 1",
                      "type": "text",
                      "placeholder": "Enter street address",
                      "subsection": "Address Information",
                      "required": "mandatory"
                    },
                    {
                      "label": "City",
                      "type": "text",
                      "placeholder": "Enter city",
                      "subsection": "Address Information",
                      "required": "mandatory"
                    },
                    {
                      "label": "Country",
                      "type": "list",
                      "subsection": "Address Information",
                      "listvalue": ["United States", "Canada", "Mexico", "India"],
                      "required": "mandatory"
                    }
                  ]
                },
                {
                  "title": "Receiver Details",
                  "description": "Recipient Information",
                  "fields": [
                    {
                      "label": "First Name",
                      "type": "text",
                      "required": "mandatory",
                      "placeholder": "Enter first name"
                    },
                    {
                      "label": "Relationship to Sender",
                      "type": "list",
                      "listvalue": ["Spouse", "Parent", "Child", "Sibling", "Friend"],
                      "required": "optional"
                    }
                  ]
                }
              ]
            },
            "output_sample_data": {
              "Exchange Rate": "1 USD = 20.15 MXN",
              "Transfer Fee": "$4.99"
            }
          },
          {
            "name": "Order Confirm",
            "input": {
              "section": [
                {
                  "title": "Review & Confirm",
                  "description": "Please review your transfer details",
                  "fields": [
                    {
                      "label": "Transfer Summary",
                      "type": "label",
                      "required": "mandatory"
                    }
                  ]
                }
              ]
            },
            "output_sample_data": {
              "Order Number": "MT1234567890"
            }
          }
        ]
      },
      size: "15.2 KB",
      createdAt: new Date("2024-01-15")
    },
    {
      id: "2",
      name: "theme-config.json",
      content: { colors: { primary: "#2563EB", secondary: "#10B981", accent: "#F59E0B" } },
      size: "1.8 KB",
      createdAt: new Date("2024-01-08")
    }
  ]);

  const [aiPrompts, setAIPrompts] = useState<AIPrompt[]>([
    {
      id: "1",
      name: "Money Transfer Application",
      description: "Creates a complete money transfer platform with multi-step forms",
      prompt: "Create a professional money transfer application with tab-based navigation. Build a multi-step form interface where users progress through Pricing, Order Create, and Order Confirm tabs. Each tab should contain structured sections with various field types including text inputs, dropdowns, amount fields with currency selectors, date pickers, and organized subsections. Implement form validation requiring all mandatory fields before proceeding. Include proper error handling with visual feedback for missing required fields. Display sample output data like exchange rates and transfer fees after form submission. Use a clean, modern design with responsive layout optimized for financial transactions. Ensure secure, professional appearance suitable for handling sensitive financial information. Include proper navigation controls with back/continue buttons and disabled tab switching until forms are completed.",
      category: "Financial",
      createdAt: new Date("2024-01-15")
    },
    {
      id: "2",
      name: "Dashboard Creator",
      description: "Generates admin dashboards with charts and data tables",
      prompt: "Build a comprehensive dashboard with sidebar navigation, data charts...",
      category: "Dashboards",
      createdAt: new Date("2024-01-11")
    }
  ]);

  const handleDeleteFigma = (id: string) => {
    setFigmaFiles(prev => prev.filter(file => file.id !== id));
  };

  const handleEditFigma = (file: FigmaFile) => {
    setSelectedFigmaFile(file);
    setIsEditorOpen(true);
  };

  const handleSaveFigma = (updatedFile: FigmaFile) => {
    setFigmaFiles(prev => prev.map(file =>
      file.id === updatedFile.id ? updatedFile : file
    ));
  };

  const handleUploadFigma = (newFile: FigmaFile) => {
    setFigmaFiles(prev => [...prev, newFile]);
  };

  const handleDeleteJson = (id: string) => {
    setJsonFiles(prev => prev.filter(file => file.id !== id));
  };

  const handleEditJson = (file: JsonFile) => {
    setSelectedJsonFile(file);
    setIsJsonEditorOpen(true);
  };

  const handleSaveJson = (updatedFile: JsonFile) => {
    setJsonFiles(prev => prev.map(file =>
      file.id === updatedFile.id ? updatedFile : file
    ));
  };

  const handleUploadJson = (newFile: JsonFile) => {
    setJsonFiles(prev => [...prev, newFile]);
  };

  const handleDeletePrompt = (id: string) => {
    setAIPrompts(prev => prev.filter(prompt => prompt.id !== id));
  };

  const handleRunPrompt = (prompt: AIPrompt) => {
    setSelectedPrompt(prompt);
    setIsPromptRunnerOpen(true);
  };

  const handleEditPrompt = (prompt: AIPrompt) => {
    setSelectedPrompt(prompt);
    setIsPromptEditorOpen(true);
  };

  const handleCreatePrompt = () => {
    setSelectedPrompt(null);
    setIsPromptEditorOpen(true);
  };

  const handleSavePrompt = (updatedPrompt: AIPrompt) => {
    setAIPrompts(prev => {
      const existing = prev.find(p => p.id === updatedPrompt.id);
      if (existing) {
        return prev.map(p => p.id === updatedPrompt.id ? updatedPrompt : p);
      } else {
        return [...prev, updatedPrompt];
      }
    });
  };

  const handleToggleFigmaSelection = (fileId: string) => {
    setSelectedFigmaIds(prev =>
      prev.includes(fileId)
        ? prev.filter(id => id !== fileId)
        : [...prev, fileId]
    );
  };

  const handleToggleJsonSelection = (fileId: string) => {
    setSelectedJsonIds(prev =>
      prev.includes(fileId)
        ? prev.filter(id => id !== fileId)
        : [...prev, fileId]
    );
  };

  const handleSelectAllFigma = () => {
    setSelectedFigmaIds(figmaFiles.map(f => f.id));
  };

  const handleDeselectAllFigma = () => {
    setSelectedFigmaIds([]);
  };

  const handleSelectAllJson = () => {
    setSelectedJsonIds(jsonFiles.map(f => f.id));
  };

  const handleDeselectAllJson = () => {
    setSelectedJsonIds([]);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-50 via-white to-indigo-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-r from-violet-600 to-indigo-600 rounded-lg flex items-center justify-center">
                <Code2 className="w-6 h-6 text-white" />
              </div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-violet-600 to-indigo-600 bg-clip-text text-transparent">
                UI Builder
              </h1>
            </div>
            <div className="flex items-center gap-4">
              <Link to="/about">
                <Button variant="ghost" size="sm">
                  About
                </Button>
              </Link>
              <Badge variant="secondary" className="bg-violet-100 text-violet-700 border-violet-200">
                v1.0.0
              </Badge>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-8 space-y-8">
        {/* Hero Section */}
        <section className="text-center py-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Build Beautiful UIs with
            <span className="bg-gradient-to-r from-violet-600 to-indigo-600 bg-clip-text text-transparent"> AI Power</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Import Figma designs, manage JSON configurations, and use AI prompts to generate stunning user interfaces.
          </p>
        </section>

        {/* Figma Import Section */}
        <section>
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <Figma className="w-6 h-6 text-violet-600" />
              <h3 className="text-2xl font-semibold text-gray-900">Figma Imports</h3>
              <Badge variant="secondary" className="bg-violet-100 text-violet-700">
                {selectedFigmaIds.length} selected
              </Badge>
            </div>
            <div className="flex items-center gap-2">
              {figmaFiles.length > 0 && (
                <div className="flex gap-2 mr-4">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleSelectAllFigma}
                    disabled={selectedFigmaIds.length === figmaFiles.length}
                  >
                    Select All
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleDeselectAllFigma}
                    disabled={selectedFigmaIds.length === 0}
                  >
                    Deselect All
                  </Button>
                </div>
              )}
              <Button
                className="bg-violet-600 hover:bg-violet-700"
                onClick={() => setIsUploaderOpen(true)}
              >
                <Plus className="w-4 h-4" />
                Import Figma Design
              </Button>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {figmaFiles.map((file) => (
              <Card key={file.id} className={`hover:shadow-md transition-all ${selectedFigmaIds.includes(file.id) ? 'ring-2 ring-violet-500 bg-violet-50' : ''}`}>
                <CardHeader className="pb-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3 flex-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 mt-1"
                        onClick={() => handleToggleFigmaSelection(file.id)}
                      >
                        {selectedFigmaIds.includes(file.id) ? (
                          <CheckSquare className="w-5 h-5 text-violet-600" />
                        ) : (
                          <Square className="w-5 h-5 text-gray-400" />
                        )}
                      </Button>
                      <div className="flex-1">
                        <CardTitle className="text-lg">{file.name}</CardTitle>
                        <CardDescription>
                          Imported {file.createdAt.toLocaleDateString()}
                        </CardDescription>
                        {selectedFigmaIds.includes(file.id) && (
                          <Badge variant="secondary" className="bg-violet-100 text-violet-700 text-xs mt-2">
                            Selected for AI generation
                          </Badge>
                        )}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => handleEditFigma(file)}
                      >
                        <Edit2 className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-red-600 hover:text-red-700"
                        onClick={() => handleDeleteFigma(file.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="w-full h-32 bg-gradient-to-br from-violet-100 to-indigo-100 rounded-lg flex items-center justify-center mb-4">
                    <Figma className="w-12 h-12 text-violet-400" />
                  </div>
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => handleEditFigma(file)}
                  >
                    <Edit2 className="w-4 h-4" />
                    Edit Design
                  </Button>
                </CardContent>
              </Card>
            ))}
            
            {/* Upload Card */}
            <Card className="border-dashed border-2 border-violet-200 hover:border-violet-300 transition-colors">
              <CardContent className="flex flex-col items-center justify-center h-full py-12">
                <Upload className="w-12 h-12 text-violet-400 mb-4" />
                <h4 className="font-medium text-gray-900 mb-2">Upload Figma Design</h4>
                <p className="text-sm text-gray-500 text-center mb-4">
                  Drag and drop or click to upload your Figma file
                </p>
                <Button
                  variant="outline"
                  className="border-violet-200 text-violet-600 hover:bg-violet-50"
                  onClick={() => setIsUploaderOpen(true)}
                >
                  Choose File
                </Button>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* JSON Files Section */}
        <section>
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <FileText className="w-6 h-6 text-indigo-600" />
              <h3 className="text-2xl font-semibold text-gray-900">JSON Files</h3>
              <Badge variant="secondary" className="bg-indigo-100 text-indigo-700">
                {selectedJsonIds.length} selected
              </Badge>
            </div>
            <div className="flex items-center gap-2">
              {jsonFiles.length > 0 && (
                <div className="flex gap-2 mr-4">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleSelectAllJson}
                    disabled={selectedJsonIds.length === jsonFiles.length}
                  >
                    Select All
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleDeselectAllJson}
                    disabled={selectedJsonIds.length === 0}
                  >
                    Deselect All
                  </Button>
                </div>
              )}
              <Button
                className="bg-indigo-600 hover:bg-indigo-700"
                onClick={() => setIsJsonUploaderOpen(true)}
              >
                <Plus className="w-4 h-4" />
                Import JSON File
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {jsonFiles.map((file) => (
              <Card key={file.id} className={`hover:shadow-md transition-all ${selectedJsonIds.includes(file.id) ? 'ring-2 ring-indigo-500 bg-indigo-50' : ''}`}>
                <CardHeader className="pb-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3 flex-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 mt-1"
                        onClick={() => handleToggleJsonSelection(file.id)}
                      >
                        {selectedJsonIds.includes(file.id) ? (
                          <CheckSquare className="w-5 h-5 text-indigo-600" />
                        ) : (
                          <Square className="w-5 h-5 text-gray-400" />
                        )}
                      </Button>
                      <div className="flex-1">
                        <CardTitle className="text-lg">{file.name}</CardTitle>
                        <CardDescription>
                          {file.size} • {file.createdAt.toLocaleDateString()}
                        </CardDescription>
                        {selectedJsonIds.includes(file.id) && (
                          <Badge variant="secondary" className="bg-indigo-100 text-indigo-700 text-xs mt-2">
                            Selected for AI generation
                          </Badge>
                        )}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => handleEditJson(file)}
                      >
                        <Edit2 className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-red-600 hover:text-red-700"
                        onClick={() => handleDeleteJson(file.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="w-full p-4 bg-gray-50 rounded-lg mb-4 font-mono text-sm">
                    <code>{JSON.stringify(file.content, null, 2).slice(0, 100)}...</code>
                  </div>
                  <div className="space-y-2">
                    <Button
                      variant="outline"
                      className="w-full"
                      onClick={() => handleEditJson(file)}
                    >
                      <Edit2 className="w-4 h-4" />
                      Edit JSON
                    </Button>
                    <div className="text-xs text-gray-500 text-center">
                      Ready for AI generation
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}

            {/* Upload Card */}
            <Card className="border-dashed border-2 border-indigo-200 hover:border-indigo-300 transition-colors">
              <CardContent className="flex flex-col items-center justify-center h-full py-12">
                <FileText className="w-12 h-12 text-indigo-400 mb-4" />
                <h4 className="font-medium text-gray-900 mb-2">Upload JSON File</h4>
                <p className="text-sm text-gray-500 text-center mb-4">
                  Import configuration or data files
                </p>
                <Button
                  variant="outline"
                  className="border-indigo-200 text-indigo-600 hover:bg-indigo-50"
                  onClick={() => setIsJsonUploaderOpen(true)}
                >
                  Choose File
                </Button>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* AI Prompts Section */}
        <section>
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <Brain className="w-6 h-6 text-emerald-600" />
              <h3 className="text-2xl font-semibold text-gray-900">AI Prompt Library</h3>
            </div>
            <Button
              className="bg-emerald-600 hover:bg-emerald-700"
              onClick={handleCreatePrompt}
            >
              <Plus className="w-4 h-4" />
              Create Prompt
            </Button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {aiPrompts.map((prompt) => (
              <Card key={prompt.id} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <CardTitle className="text-lg">{prompt.name}</CardTitle>
                        <Badge variant="secondary" className="bg-emerald-100 text-emerald-700 border-emerald-200">
                          {prompt.category}
                        </Badge>
                      </div>
                      <CardDescription>{prompt.description}</CardDescription>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => handleEditPrompt(prompt)}
                      >
                        <Edit2 className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-red-600 hover:text-red-700"
                        onClick={() => handleDeletePrompt(prompt.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="p-4 bg-gray-50 rounded-lg mb-4">
                    <p className="text-sm text-gray-600 line-clamp-3">
                      {prompt.prompt}
                    </p>
                  </div>
                  <div className="mb-4 text-xs text-gray-500 bg-emerald-50 p-2 rounded border border-emerald-200">
                    💡 This prompt will use your uploaded JSON files ({jsonFiles.length}) and Figma designs ({figmaFiles.length}) to generate personalized UI
                  </div>
                  <div className="flex gap-2">
                    <Button
                      className="flex-1 bg-emerald-600 hover:bg-emerald-700"
                      onClick={() => handleRunPrompt(prompt)}
                    >
                      <Play className="w-4 h-4" />
                      Run with Data
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => handleEditPrompt(prompt)}
                    >
                      <Edit2 className="w-4 h-4" />
                      Edit
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}

            {/* Create Card */}
            <Card className="border-dashed border-2 border-emerald-200 hover:border-emerald-300 transition-colors">
              <CardContent className="flex flex-col items-center justify-center h-full py-12">
                <Sparkles className="w-12 h-12 text-emerald-400 mb-4" />
                <h4 className="font-medium text-gray-900 mb-2">Create AI Prompt</h4>
                <p className="text-sm text-gray-500 text-center mb-4">
                  Design custom prompts for UI generation
                </p>
                <Button
                  variant="outline"
                  className="border-emerald-200 text-emerald-600 hover:bg-emerald-50"
                  onClick={handleCreatePrompt}
                >
                  Get Started
                </Button>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>

      {/* Dialogs */}
      <FigmaEditor
        figmaFile={selectedFigmaFile}
        isOpen={isEditorOpen}
        onClose={() => setIsEditorOpen(false)}
        onSave={handleSaveFigma}
      />

      <FigmaUploader
        isOpen={isUploaderOpen}
        onClose={() => setIsUploaderOpen(false)}
        onUpload={handleUploadFigma}
      />

      <JsonEditor
        jsonFile={selectedJsonFile}
        isOpen={isJsonEditorOpen}
        onClose={() => setIsJsonEditorOpen(false)}
        onSave={handleSaveJson}
      />

      <JsonUploader
        isOpen={isJsonUploaderOpen}
        onClose={() => setIsJsonUploaderOpen(false)}
        onUpload={handleUploadJson}
      />

      <PromptEditor
        aiPrompt={selectedPrompt}
        isOpen={isPromptEditorOpen}
        onClose={() => setIsPromptEditorOpen(false)}
        onSave={handleSavePrompt}
        onRun={handleRunPrompt}
      />

      <PromptRunner
        prompt={selectedPrompt}
        isOpen={isPromptRunnerOpen}
        onClose={() => setIsPromptRunnerOpen(false)}
        figmaFiles={figmaFiles}
        jsonFiles={jsonFiles}
        preSelectedFigmaIds={selectedFigmaIds}
        preSelectedJsonIds={selectedJsonIds}
      />
    </div>
  );
}
