import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowLeft,
  Eye,
  Code,
  Download,
  Settings,
  Activity,
  Calendar,
  FileText,
  Monitor,
  ExternalLink,
  Copy,
  CheckCircle,
  Shield,
  Zap,
  RefreshCw
} from "lucide-react";

export default function ProjectDashboard() {
  const { projectId } = useParams();
  const [generationData, setGenerationData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Load generation data from sessionStorage
  useEffect(() => {
    if (projectId) {
      console.log('Loading project dashboard for ID:', projectId);
      
      // Try multiple storage key patterns
      const possibleKeys = [
        `generation_${projectId}`,
        `generation_${projectId.replace('proj_', '')}`,
        `generation_${projectId.replace('proj_ui_', '')}`,
        `generation_proj_${projectId.replace('proj_', '')}`,
        `generation_ui_${projectId.replace('proj_ui_', '')}`,
        `generation_${projectId.replace('ui_', '')}`,
        ...Object.keys(sessionStorage).filter(key => 
          key.includes('generation_') && (
            key.includes(projectId) || 
            key.includes(projectId.replace('proj_', '')) ||
            key.includes(projectId.slice(-8))
          )
        )
      ];

      console.log('Searching for data with keys:', possibleKeys);

      let foundData = null;
      for (const key of possibleKeys) {
        const data = sessionStorage.getItem(key);
        if (data) {
          console.log('Found data with key:', key);
          try {
            foundData = JSON.parse(data);
            break;
          } catch (error) {
            console.error('Failed to parse data from key:', key, error);
          }
        }
      }

      if (foundData) {
        setGenerationData(foundData);
      } else {
        console.log('No generation data found, using default project structure');
        // Create default project structure for demonstration
        setGenerationData({
          prompt: {
            name: "Generated TSX Project",
            description: "AI-generated React TypeScript components",
            prompt: "Generated through AI prompt runner"
          },
          generatedAt: new Date().toISOString(),
          outputFormat: "react-typescript",
          tsxComponents: {
            totalComponents: 1,
            mainComponent: "App.tsx",
            hasIDVerification: false
          },
          projectStructure: {
            name: projectId?.replace('proj_', '') || 'generated-project',
            type: 'react-typescript',
            components: ['App.tsx'],
            totalFiles: 5
          }
        });
      }
      
      setIsLoading(false);
    }
  }, [projectId]);

  // Generate TSX project files for download
  const generateTSXProject = () => {
    if (!generationData) return {};

    const projectName = generationData?.prompt?.name?.toLowerCase().replace(/\s+/g, '-') || 'generated-project';
    
    return {
      'package.json': JSON.stringify({
        name: projectName,
        version: "1.0.0",
        private: true,
        dependencies: {
          "react": "^18.2.0",
          "react-dom": "^18.2.0",
          "@types/react": "^18.2.0",
          "@types/react-dom": "^18.2.0",
          "typescript": "^5.0.0",
          "lucide-react": "^0.263.1"
        },
        scripts: {
          "start": "react-scripts start",
          "build": "react-scripts build",
          "test": "react-scripts test",
          "eject": "react-scripts eject"
        },
        devDependencies: {
          "react-scripts": "5.0.1",
          "@types/node": "^16.0.0"
        }
      }, null, 2),
      
      'src/App.tsx': `import React from 'react';
import './App.css';
${generationData.tsxComponents?.mainComponent ? `import { MainComponent } from './components/MainComponent';` : ''}

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>${generationData.prompt?.name || 'Generated App'}</h1>
        <p>${generationData.prompt?.description || 'AI-generated React TypeScript application'}</p>
      </header>
      <main>
        ${generationData.tsxComponents?.mainComponent ? '<MainComponent />' : '<div>Generated TSX content will appear here</div>'}
      </main>
    </div>
  );
}

export default App;`,

      'src/components/MainComponent.tsx': `import React, { useState } from 'react';

interface MainComponentProps {
  title?: string;
}

export const MainComponent: React.FC<MainComponentProps> = ({ 
  title = "${generationData.prompt?.name || 'Generated Component'}" 
}) => {
  const [isActive, setIsActive] = useState(false);

  return (
    <div className="main-component">
      <h2>{title}</h2>
      <p>This is a generated TSX component based on your AI prompt and JSON data.</p>
      <button 
        onClick={() => setIsActive(!isActive)}
        className={isActive ? 'active' : ''}
      >
        {isActive ? 'Active' : 'Inactive'}
      </button>
      {isActive && (
        <div className="active-content">
          <p>Component is now active!</p>
        </div>
      )}
    </div>
  );
};

export default MainComponent;`,

      'src/App.css': `.App {
  text-align: center;
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.App-header {
  background-color: #282c34;
  padding: 40px;
  color: white;
  border-radius: 8px;
  margin-bottom: 30px;
}

.main-component {
  background: #f5f5f5;
  padding: 30px;
  border-radius: 8px;
  margin: 20px 0;
  border: 1px solid #ddd;
}

.main-component h2 {
  color: #333;
  margin-bottom: 15px;
}

.main-component button {
  background: #007bff;
  color: white;
  border: none;
  padding: 10px 20px;
  border-radius: 4px;
  cursor: pointer;
  transition: background 0.3s ease;
}

.main-component button:hover {
  background: #0056b3;
}

.main-component button.active {
  background: #28a745;
}

.active-content {
  margin-top: 20px;
  padding: 15px;
  background: #d4edda;
  border: 1px solid #c3e6cb;
  border-radius: 4px;
  color: #155724;
}`,

      'src/index.tsx': `import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';

const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);`,

      'src/index.css': `body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  background-color: #f8f9fa;
}

code {
  font-family: source-code-pro, Menlo, Monaco, Consolas, 'Courier New',
    monospace;
}

* {
  box-sizing: border-box;
}`,

      'tsconfig.json': JSON.stringify({
        compilerOptions: {
          target: "es5",
          lib: ["dom", "dom.iterable", "es6"],
          allowJs: true,
          skipLibCheck: true,
          esModuleInterop: true,
          allowSyntheticDefaultImports: true,
          strict: true,
          forceConsistentCasingInFileNames: true,
          noFallthroughCasesInSwitch: true,
          module: "esnext",
          moduleResolution: "node",
          resolveJsonModule: true,
          isolatedModules: true,
          noEmit: true,
          jsx: "react-jsx"
        },
        include: ["src"]
      }, null, 2),

      'README.md': `# ${generationData.prompt?.name || 'Generated TSX Project'}

${generationData.prompt?.description || 'AI-generated React TypeScript application'}

## 🚀 Generated with AI

This project was created using AI prompt processing with:
- **Framework**: React + TypeScript
- **Generated**: ${new Date(generationData.generatedAt).toLocaleString()}
- **Components**: ${generationData.tsxComponents?.totalComponents || 1} TSX components

## 🛠️ Getting Started

1. Install dependencies:
   \`\`\`bash
   npm install
   \`\`\`

2. Start the development server:
   \`\`\`bash
   npm start
   \`\`\`

3. Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

## 📁 Project Structure

- \`src/App.tsx\` - Main application component
- \`src/components/\` - Generated TSX components
- \`src/App.css\` - Styling for the application

## 🔧 Available Scripts

- \`npm start\` - Runs the app in development mode
- \`npm run build\` - Builds the app for production
- \`npm test\` - Launches the test runner

## Generated Features

This application was generated based on your AI prompt and includes:
- TypeScript interfaces and components
- React functional components with hooks
- Responsive CSS styling
- Component interaction logic

---
*Generated by AI Prompt Runner*`
    };
  };

  const handleDownloadTSX = () => {
    const projectFiles = generateTSXProject();
    
    // Create a simple zip-like download
    Object.entries(projectFiles).forEach(([filename, content]) => {
      const blob = new Blob([content], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    });
  };

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <RefreshCw className="w-8 h-8 animate-spin mx-auto mb-4 text-blue-600" />
          <h3 className="text-lg font-semibold mb-2">Loading Project Dashboard...</h3>
          <p className="text-gray-600">Loading TSX project data for {projectId}</p>
        </div>
      </div>
    );
  }

  if (!generationData) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h3 className="text-lg font-semibold mb-2">Project Not Found</h3>
          <p className="text-gray-600 mb-4">Could not load project data for {projectId}</p>
          <Link to="/">
            <Button variant="outline" className="gap-2">
              <ArrowLeft className="w-4 h-4" />
              Back to Home
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  const projectFiles = generateTSXProject();

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-4">
              <Link to="/">
                <Button variant="ghost" size="sm" className="gap-2">
                  <ArrowLeft className="w-4 h-4" />
                  Back to UI Builder
                </Button>
              </Link>
              <div className="border-l pl-4">
                <h1 className="text-xl font-semibold text-gray-900">
                  {generationData.prompt?.name || 'TSX Project'}
                </h1>
                <p className="text-sm text-gray-500">
                  Project ID: {projectId} • React TypeScript
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Badge variant="secondary" className="gap-1">
                <Code className="w-3 h-3" />
                TSX Project
              </Badge>
              <Badge variant="secondary" className="gap-1">
                <CheckCircle className="w-3 h-3" />
                Ready
              </Badge>
              <Link to={`/preview/${projectId?.replace('proj_', '')}`}>
                <Button size="sm" className="gap-2">
                  <Eye className="w-4 h-4" />
                  Preview
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Project Overview */}
        <div className="mb-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Project Stats */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Activity className="w-5 h-5 text-blue-600" />
                  Project Stats
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Framework</span>
                  <Badge variant="outline">React + TypeScript</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Components</span>
                  <Badge variant="secondary">{generationData.tsxComponents?.totalComponents || 1}</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Status</span>
                  <Badge className="bg-green-100 text-green-800">Ready</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Generated</span>
                  <span className="text-sm text-gray-500">
                    {new Date(generationData.generatedAt).toLocaleDateString()}
                  </span>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Zap className="w-5 h-5 text-purple-600" />
                  Quick Actions
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Link to={`/preview/${projectId?.replace('proj_', '')}`} className="block">
                  <Button className="w-full justify-start gap-2" variant="outline">
                    <Eye className="w-4 h-4" />
                    Preview TSX App
                  </Button>
                </Link>
                <Button 
                  className="w-full justify-start gap-2" 
                  variant="outline"
                  onClick={handleDownloadTSX}
                >
                  <Download className="w-4 h-4" />
                  Download TSX Project
                </Button>
                <Button className="w-full justify-start gap-2" variant="outline">
                  <ExternalLink className="w-4 h-4" />
                  Open in CodeSandbox
                </Button>
              </CardContent>
            </Card>

            {/* Project Info */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-green-600" />
                  Project Info
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <span className="text-sm text-gray-600">Name</span>
                  <p className="font-medium">{generationData.prompt?.name || 'Generated Project'}</p>
                </div>
                <div>
                  <span className="text-sm text-gray-600">Description</span>
                  <p className="font-medium text-sm">{generationData.prompt?.description || 'AI-generated TSX components'}</p>
                </div>
                <div>
                  <span className="text-sm text-gray-600">Type</span>
                  <p className="font-medium">React TypeScript</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* TSX Code Preview */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* File Structure */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <FileText className="w-5 h-5 text-orange-600" />
                Project Structure
              </CardTitle>
              <CardDescription>Generated TSX project files</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {Object.keys(projectFiles).map((filename) => (
                  <div 
                    key={filename}
                    className="flex items-center justify-between p-2 border rounded hover:bg-gray-50"
                  >
                    <div className="flex items-center gap-2">
                      <FileText className="w-4 h-4 text-gray-500" />
                      <span className="font-mono text-sm">{filename}</span>
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleCopyCode(projectFiles[filename])}
                    >
                      <Copy className="w-3 h-3" />
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Main Component Preview */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Code className="w-5 h-5 text-blue-600" />
                App.tsx Preview
              </CardTitle>
              <CardDescription>Main application component</CardDescription>
            </CardHeader>
            <CardContent>
              <pre className="bg-gray-900 text-gray-100 p-4 rounded-lg overflow-auto max-h-96 text-sm">
                <code>{projectFiles['src/App.tsx']}</code>
              </pre>
              <div className="mt-3 flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleCopyCode(projectFiles['src/App.tsx'])}
                >
                  <Copy className="w-3 h-3 mr-2" />
                  Copy Code
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Download Section */}
        <div className="mt-8">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Download className="w-5 h-5 text-green-600" />
                Download TSX Project
              </CardTitle>
              <CardDescription>
                Get your complete React TypeScript project with all components and configuration
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg border border-green-200">
                <div>
                  <h4 className="font-medium text-green-900">Ready for Download</h4>
                  <p className="text-sm text-green-700">
                    Complete React TypeScript project with {Object.keys(projectFiles).length} files
                  </p>
                </div>
                <Button onClick={handleDownloadTSX} className="bg-green-600 hover:bg-green-700">
                  <Download className="w-4 h-4 mr-2" />
                  Download All Files
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
