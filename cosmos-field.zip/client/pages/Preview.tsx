import { useState, useEffect } from "react";
import { useParams, useSearchParams, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowLeft,
  Monitor,
  Smartphone,
  Tablet,
  Maximize,
  Download,
  Share,
  Loader2,
  ExternalLink,
  Code,
  RefreshCw
} from "lucide-react";

export default function Preview() {
  const { generationId } = useParams();
  const [searchParams] = useSearchParams();
  const view = searchParams.get('view') || 'desktop';
  const [isLoading, setIsLoading] = useState(true);
  const [generationData, setGenerationData] = useState<any>(null);
  const [TSXComponent, setTSXComponent] = useState<React.ComponentType | null>(null);

  // Load generation data and create TSX component
  useEffect(() => {
    const loadGenerationData = async () => {
      if (!generationId) return;

      console.log('Loading preview for generation ID:', generationId);
      
      // Try to get generation data from sessionStorage
      const possibleKeys = [
        `generation_${generationId}`,
        `generation_proj_${generationId}`,
        `generation_ui_${generationId}`,
        ...Object.keys(sessionStorage).filter(key => 
          key.includes('generation_') && key.includes(generationId)
        )
      ];

      let foundData = null;
      for (const key of possibleKeys) {
        const data = sessionStorage.getItem(key);
        if (data) {
          try {
            foundData = JSON.parse(data);
            console.log('Found generation data with key:', key);
            break;
          } catch (error) {
            console.error('Failed to parse data from key:', key, error);
          }
        }
      }

      if (foundData) {
        setGenerationData(foundData);
        
        // Generate TSX component based on the data
        const component = generateTSXComponent(foundData);
        setTSXComponent(() => component);
      } else {
        console.log('No generation data found, creating default preview');
        // Create default preview data
        const defaultData = {
          prompt: {
            name: "Preview Application",
            description: "Generated TSX component preview",
            prompt: "Show preview of generated component"
          },
          generatedAt: new Date().toISOString(),
          outputFormat: "react-typescript"
        };
        
        setGenerationData(defaultData);
        setTSXComponent(() => generateTSXComponent(defaultData));
      }
      
      setIsLoading(false);
    };

    // Simulate loading time
    const timer = setTimeout(loadGenerationData, 1000);
    return () => clearTimeout(timer);
  }, [generationId]);

  // Generate TSX component based on generation data
  const generateTSXComponent = (data: any): React.ComponentType => {
    const promptName = data?.prompt?.name || 'Generated Application';
    const promptDescription = data?.prompt?.description || 'AI-generated TSX component';
    const aiPrompt = data?.prompt?.prompt || data?.fullAIPrompt || '';

    // Extract JSON structure if available
    const jsonFiles = data?.jsonFiles || [];
    const figmaFiles = data?.figmaFiles || [];

    // AI prompt analysis for dynamic styling and behavior
    const analyzeAIPrompt = (prompt: string) => {
      const analysis = {
        theme: 'light',
        colorScheme: 'blue',
        layout: 'single-page',
        style: 'modern',
        isMultiStep: false,
        hasComplexFields: false,
        isDarkTheme: false,
        isProfessional: false
      };

      const lowerPrompt = prompt.toLowerCase();

      // Theme detection
      if (lowerPrompt.includes('dark') || lowerPrompt.includes('night')) {
        analysis.isDarkTheme = true;
        analysis.theme = 'dark';
      }

      // Color scheme detection
      if (lowerPrompt.includes('green')) {
        analysis.colorScheme = 'green';
      } else if (lowerPrompt.includes('purple') || lowerPrompt.includes('violet')) {
        analysis.colorScheme = 'purple';
      } else if (lowerPrompt.includes('red')) {
        analysis.colorScheme = 'red';
      }

      // Layout detection
      if (lowerPrompt.includes('tab') || lowerPrompt.includes('multi-step') || lowerPrompt.includes('wizard')) {
        analysis.isMultiStep = true;
        analysis.layout = 'multi-step';
      }

      // Style detection
      if (lowerPrompt.includes('professional') || lowerPrompt.includes('business') || lowerPrompt.includes('corporate')) {
        analysis.isProfessional = true;
        analysis.style = 'professional';
      }

      // Field complexity detection
      if (lowerPrompt.includes('upload') || lowerPrompt.includes('file') || lowerPrompt.includes('complex')) {
        analysis.hasComplexFields = true;
      }

      return analysis;
    };

    const promptAnalysis = analyzeAIPrompt(aiPrompt);

    // Generate component based on AI prompt and data
    return function GeneratedTSXComponent() {
      const [activeTab, setActiveTab] = useState(0);
      const [formData, setFormData] = useState<Record<string, any>>({});
      const [isSubmitting, setIsSubmitting] = useState(false);
      const [showSuccess, setShowSuccess] = useState(false);

      // Extract modules/sections from JSON data with enhanced parsing
      const modules = jsonFiles.length > 0 && jsonFiles[0]?.content?.Module
        ? jsonFiles[0].content.Module
        : [
            {
              name: "Generated Module",
              description: "AI-generated module based on your prompt",
              input: {
                section: [{
                  title: "Generated Section",
                  description: "This section was generated based on your AI prompt",
                  fields: [
                    {
                      label: "Sample Input",
                      type: "text",
                      placeholder: "Enter value",
                      required: "optional"
                    }
                  ]
                }]
              }
            }
          ];

      const handleFieldChange = (fieldName: string, value: any) => {
        setFormData(prev => ({ ...prev, [fieldName]: value }));
      };

      const renderField = (field: any, index: number) => {
        const fieldKey = `field-${index}-${field.label}`;
        const isRequired = field.required === 'mandatory';
        
        switch (field.type) {
          case 'list':
            return (
              <div key={fieldKey} className="space-y-2">
                <label className="block text-sm font-medium ${styling.textPrimary}">
                  {field.label} {isRequired && <span className="text-red-500">*</span>}
                </label>
                <select
                  value={formData[field.label] || ''}
                  onChange={(e) => handleFieldChange(field.label, e.target.value)}
                  className={`w-full px-3 py-2 border ${styling.border} rounded-lg ${styling.inputBg} ${styling.textPrimary} ${styling.colors.ring} focus:ring-2 focus:border-transparent`}
                  required={isRequired}
                >
                  <option value="">Select {field.label}</option>
                  {(field.listvalue || []).map((value: string, i: number) => (
                    <option key={i} value={value}>{value}</option>
                  ))}
                </select>
              </div>
            );
          
          case 'amount':
            return (
              <div key={fieldKey} className="space-y-2">
                <label className="block text-sm font-medium ${styling.textPrimary}">
                  {field.label} {isRequired && <span className="text-red-500">*</span>}
                </label>
                <div className="flex">
                  <select className={`w-20 px-2 py-2 border ${styling.border} rounded-l-lg ${styling.inputBg} ${styling.textPrimary} ${styling.colors.ring} focus:ring-2`}>
                    <option>USD</option>
                    <option>EUR</option>
                    <option>GBP</option>
                  </select>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    placeholder={field.placeholder || '0.00'}
                    value={formData[field.label] || ''}
                    onChange={(e) => handleFieldChange(field.label, e.target.value)}
                    className={`flex-1 px-3 py-2 border-l-0 border ${styling.border} rounded-r-lg ${styling.inputBg} ${styling.textPrimary} ${styling.colors.ring} focus:ring-2 focus:border-transparent`}
                    required={isRequired}
                  />
                </div>
              </div>
            );
          
          case 'date':
            return (
              <div key={fieldKey} className="space-y-2">
                <label className="block text-sm font-medium ${styling.textPrimary}">
                  {field.label} {isRequired && <span className="text-red-500">*</span>}
                </label>
                <input
                  type="date"
                  value={formData[field.label] || ''}
                  onChange={(e) => handleFieldChange(field.label, e.target.value)}
                  className={`w-full px-3 py-2 border ${styling.border} rounded-lg ${styling.inputBg} ${styling.textPrimary} ${styling.colors.ring} focus:ring-2 focus:border-transparent`}
                  required={isRequired}
                />
              </div>
            );
          
          case 'email':
            return (
              <div key={fieldKey} className="space-y-2">
                <label className="block text-sm font-medium ${styling.textPrimary}">
                  {field.label} {isRequired && <span className="text-red-500">*</span>}
                </label>
                <input
                  type="email"
                  placeholder={field.placeholder || 'Enter email address'}
                  value={formData[field.label] || ''}
                  onChange={(e) => handleFieldChange(field.label, e.target.value)}
                  className={`w-full px-3 py-2 border ${styling.border} rounded-lg ${styling.inputBg} ${styling.textPrimary} ${styling.colors.ring} focus:ring-2 focus:border-transparent`}
                  required={isRequired}
                />
              </div>
            );
          
          default:
            return (
              <div key={fieldKey} className="space-y-2">
                <label className="block text-sm font-medium ${styling.textPrimary}">
                  {field.label} {isRequired && <span className="text-red-500">*</span>}
                </label>
                <input
                  type="text"
                  placeholder={field.placeholder || `Enter ${field.label.toLowerCase()}`}
                  value={formData[field.label] || ''}
                  onChange={(e) => handleFieldChange(field.label, e.target.value)}
                  className={`w-full px-3 py-2 border ${styling.border} rounded-lg ${styling.inputBg} ${styling.textPrimary} ${styling.colors.ring} focus:ring-2 focus:border-transparent`}
                  required={isRequired}
                />
              </div>
            );
        }
      };

      // Advanced AI prompt-driven styling system
      const getAIPromptStyling = () => {
        const baseStyles = {
          background: promptAnalysis.isDarkTheme
            ? 'bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900'
            : 'bg-gradient-to-br from-gray-50 via-white to-blue-50',
          cardBackground: promptAnalysis.isDarkTheme ? 'bg-gray-800' : 'bg-white',
          textPrimary: promptAnalysis.isDarkTheme ? 'text-white' : 'text-gray-900',
          textSecondary: promptAnalysis.isDarkTheme ? 'text-gray-300' : 'text-gray-600',
          border: promptAnalysis.isDarkTheme ? 'border-gray-700' : 'border-gray-200',
          inputBg: promptAnalysis.isDarkTheme ? 'bg-gray-700' : 'bg-white',
          shadow: promptAnalysis.isDarkTheme ? 'shadow-2xl shadow-gray-900/50' : 'shadow-xl',
        };

        const colorSchemes = {
          blue: {
            primary: promptAnalysis.isDarkTheme ? 'text-blue-400' : 'text-blue-600',
            accent: promptAnalysis.isDarkTheme ? 'bg-blue-500' : 'bg-blue-600',
            accentHover: promptAnalysis.isDarkTheme ? 'hover:bg-blue-600' : 'hover:bg-blue-700',
            ring: 'focus:ring-blue-500',
            secondary: promptAnalysis.isDarkTheme ? 'bg-blue-900/50' : 'bg-blue-50'
          },
          green: {
            primary: promptAnalysis.isDarkTheme ? 'text-green-400' : 'text-green-600',
            accent: promptAnalysis.isDarkTheme ? 'bg-green-500' : 'bg-green-600',
            accentHover: promptAnalysis.isDarkTheme ? 'hover:bg-green-600' : 'hover:bg-green-700',
            ring: 'focus:ring-green-500',
            secondary: promptAnalysis.isDarkTheme ? 'bg-green-900/50' : 'bg-green-50'
          },
          purple: {
            primary: promptAnalysis.isDarkTheme ? 'text-purple-400' : 'text-purple-600',
            accent: promptAnalysis.isDarkTheme ? 'bg-purple-500' : 'bg-purple-600',
            accentHover: promptAnalysis.isDarkTheme ? 'hover:bg-purple-600' : 'hover:bg-purple-700',
            ring: 'focus:ring-purple-500',
            secondary: promptAnalysis.isDarkTheme ? 'bg-purple-900/50' : 'bg-purple-50'
          },
          red: {
            primary: promptAnalysis.isDarkTheme ? 'text-red-400' : 'text-red-600',
            accent: promptAnalysis.isDarkTheme ? 'bg-red-500' : 'bg-red-600',
            accentHover: promptAnalysis.isDarkTheme ? 'hover:bg-red-600' : 'hover:bg-red-700',
            ring: 'focus:ring-red-500',
            secondary: promptAnalysis.isDarkTheme ? 'bg-red-900/50' : 'bg-red-50'
          }
        };

        return {
          ...baseStyles,
          colors: colorSchemes[promptAnalysis.colorScheme as keyof typeof colorSchemes]
        };
      };

      const styling = getAIPromptStyling();

      const handleSubmit = () => {
        setIsSubmitting(true);
        setTimeout(() => {
          setIsSubmitting(false);
          setShowSuccess(true);
        }, 2000);
      };

      const nextStep = () => {
        if (activeTab < modules.length - 1) {
          setActiveTab(activeTab + 1);
        } else {
          handleSubmit();
        }
      };

      const prevStep = () => {
        if (activeTab > 0) {
          setActiveTab(activeTab - 1);
        }
      };

      return (
        <div className={`min-h-screen ${styling.background} py-8`}>
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            {/* Header */}
            <div className="text-center mb-8">
              <h1 className={`text-4xl font-bold ${styling.colors.primary} mb-4`}>
                {promptName}
              </h1>
              <p className={`text-xl ${styling.textSecondary} mb-6`}>
                {promptDescription}
              </p>

              {/* AI Prompt Info */}
              {aiPrompt && (
                <div className={`${styling.cardBackground} backdrop-blur-sm p-4 rounded-lg mb-6 max-w-2xl mx-auto ${styling.shadow} border ${styling.border}`}>
                  <p className={`text-sm ${styling.textPrimary} mb-2`}>
                    <strong>🧠 AI Prompt Analysis:</strong>
                  </p>
                  <p className={`text-sm ${styling.textSecondary} italic`}>
                    "{aiPrompt.slice(0, 200)}{aiPrompt.length > 200 ? '...' : ''}"
                  </p>
                  <div className="flex justify-center gap-2 mt-3">
                    <span className={`${styling.colors.secondary} text-xs px-2 py-1 rounded`}>
                      {promptAnalysis.theme} theme
                    </span>
                    <span className={`${styling.colors.secondary} text-xs px-2 py-1 rounded`}>
                      {promptAnalysis.colorScheme} colors
                    </span>
                    {promptAnalysis.isMultiStep && (
                      <span className={`${styling.colors.secondary} text-xs px-2 py-1 rounded`}>
                        multi-step
                      </span>
                    )}
                  </div>
                </div>
              )}

              {/* Data Sources */}
              {(jsonFiles.length > 0 || figmaFiles.length > 0) && (
                <div className={`${styling.cardBackground} p-4 rounded-lg mb-6 max-w-2xl mx-auto ${styling.shadow} border ${styling.border}`}>
                  <p className={`text-sm ${styling.textPrimary} mb-2`}>Generated using:</p>
                  <div className="flex flex-wrap justify-center gap-2">
                    {jsonFiles.map((file: any, index: number) => (
                      <span key={index} className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs">
                        📄 {file.name}
                      </span>
                    ))}
                    {figmaFiles.map((file: any, index: number) => (
                      <span key={index} className="bg-purple-100 text-purple-800 px-2 py-1 rounded text-xs">
                        🎨 {file.name}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Multi-step Progress */}
              {promptAnalysis.isMultiStep && modules.length > 1 && (
                <div className="flex justify-center mb-8">
                  <div className="flex items-center space-x-4">
                    {modules.map((module: any, index: number) => (
                      <div key={index} className="flex items-center">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                          index <= activeTab
                            ? `${styling.colors.accent} text-white`
                            : `${styling.border} ${styling.textSecondary}`
                        }`}>
                          {index + 1}
                        </div>
                        {index < modules.length - 1 && (
                          <div className={`w-12 h-1 ${
                            index < activeTab ? styling.colors.accent : styling.border
                          }`} />
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Success State */}
            {showSuccess && (
              <div className={`${styling.cardBackground} rounded-2xl ${styling.shadow} overflow-hidden mb-8 border-2 border-green-500`}>
                <div className="p-8 text-center">
                  <div className="text-green-500 text-6xl mb-4">✅</div>
                  <h2 className={`text-2xl font-bold ${styling.textPrimary} mb-4`}>Success!</h2>
                  <p className={`${styling.textSecondary}`}>Your form has been submitted successfully.</p>
                </div>
              </div>
            )}

            {/* Main Content */}
            {!showSuccess && (
              <div className={`${styling.cardBackground} rounded-2xl ${styling.shadow} overflow-hidden border ${styling.border}`}>
                {modules.length > 1 && !promptAnalysis.isMultiStep && (
                  <div className={`${styling.colors.secondary} border-b ${styling.border} px-6 py-4`}>
                    <div className="flex space-x-1 overflow-x-auto">
                      {modules.map((module: any, index: number) => (
                        <button
                          key={index}
                          onClick={() => setActiveTab(index)}
                          className={`px-6 py-3 font-medium rounded-lg transition-all ${
                            activeTab === index
                              ? `${styling.colors.accent} text-white shadow-lg`
                              : `${styling.textSecondary} hover:bg-gray-100`
                          }`}
                        >
                          {module.name}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                <div className="p-8">
                  {modules.map((module: any, moduleIndex: number) => (
                    activeTab === moduleIndex && (
                      <div key={moduleIndex}>
                        <h2 className={`text-3xl font-bold ${styling.colors.primary} mb-6`}>
                          {module.name}
                        </h2>

                        {module.description && (
                          <p className={`${styling.textSecondary} mb-8`}>
                            {module.description}
                          </p>
                        )}

                        {module.input?.section?.map((section: any, sectionIndex: number) => (
                          <div key={sectionIndex} className={`${styling.colors.secondary} rounded-xl p-6 mb-8 border ${styling.border}`}>
                            <h3 className={`text-xl font-semibold ${styling.textPrimary} mb-2`}>
                              {section.title}
                            </h3>
                            {section.description && (
                              <p className={`${styling.textSecondary} mb-6`}>{section.description}</p>
                            )}

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                              {(section.fields || section.input_fields || [])
                                .filter((field: any) => !field.subsection)
                                .map((field: any, fieldIndex: number) =>
                                  renderField(field, fieldIndex)
                                )}
                            </div>

                            {/* Render subsections */}
                            {Array.from(new Set(
                              (section.fields || section.input_fields || [])
                                .filter((f: any) => f.subsection)
                                .map((f: any) => f.subsection)
                            )).map((subsectionName: string) => (
                              <div key={subsectionName} className={`mt-6 ${styling.colors.secondary} rounded-xl p-6 border ${styling.border}`}>
                                <h4 className={`font-semibold ${styling.colors.primary} mb-4`}>
                                  {subsectionName}
                                </h4>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                  {(section.fields || section.input_fields || [])
                                    .filter((f: any) => f.subsection === subsectionName)
                                    .map((field: any, index: number) => renderField(field, index))}
                                </div>
                              </div>
                            ))}
                          </div>
                        ))}

                        {/* Action Buttons */}
                        <div className={`flex ${promptAnalysis.isMultiStep ? 'justify-between' : 'justify-center'} items-center pt-6 border-t ${styling.border}`}>
                          {promptAnalysis.isMultiStep && (
                            <button
                              onClick={prevStep}
                              disabled={activeTab === 0}
                              className={`px-6 py-3 rounded-lg font-medium transition-all ${
                                activeTab === 0
                                  ? 'bg-gray-200 text-gray-400 cursor-not-allowed'
                                  : `bg-gray-500 text-white hover:bg-gray-600`
                              }`}
                            >
                              Previous
                            </button>
                          )}

                          {promptAnalysis.isMultiStep && (
                            <span className={`${styling.textSecondary} text-sm`}>
                              Step {activeTab + 1} of {modules.length}
                            </span>
                          )}

                          <button
                            onClick={promptAnalysis.isMultiStep ? nextStep : handleSubmit}
                            disabled={isSubmitting}
                            className={`px-8 py-3 ${styling.colors.accent} ${styling.colors.accentHover} text-white rounded-lg font-semibold transition-all shadow-lg disabled:opacity-50`}
                          >
                            {isSubmitting ? (
                              <div className="flex items-center">
                                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                                Processing...
                              </div>
                            ) : (
                              moduleIndex === modules.length - 1 ? 'Complete' : 'Continue'
                            )}
                          </button>
                        </div>
                      </div>
                    )
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      );
    };
  };

  const handleDownloadTSX = () => {
    if (!generationData) return;

    const componentCode = `import React, { useState } from 'react';

interface GeneratedComponentProps {
  title?: string;
  description?: string;
}

export const GeneratedComponent: React.FC<GeneratedComponentProps> = ({
  title = "${generationData.prompt?.name || 'Generated Component'}",
  description = "${generationData.prompt?.description || 'AI-generated component'}"
}) => {
  const [formData, setFormData] = useState<Record<string, any>>({});

  const handleFieldChange = (fieldName: string, value: any) => {
    setFormData(prev => ({ ...prev, [fieldName]: value }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-blue-600 mb-4">{title}</h1>
          <p className="text-xl text-gray-600">{description}</p>
        </div>
        
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden p-8">
          <p>Generated TSX component based on your AI prompt and data.</p>
          {/* Component logic would be generated here based on JSON and AI prompt */}
        </div>
      </div>
    </div>
  );
};

export default GeneratedComponent;`;

    const blob = new Blob([componentCode], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `generated-component-${generationId}.tsx`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const getViewportClass = () => {
    switch (view) {
      case 'mobile':
        return 'max-w-sm mx-auto border border-gray-300 rounded-lg overflow-hidden shadow-lg';
      case 'tablet':
        return 'max-w-2xl mx-auto border border-gray-300 rounded-lg overflow-hidden shadow-lg';
      default:
        return 'w-full';
    }
  };

  const getViewportLabel = () => {
    switch (view) {
      case 'mobile':
        return 'Mobile View (375px)';
      case 'tablet':
        return 'Tablet View (768px)';
      default:
        return 'Desktop View';
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Preview Header */}
      <header className="bg-white border-b sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-4">
              <Link to="/">
                <Button variant="ghost" size="sm" className="gap-2">
                  <ArrowLeft className="w-4 h-4" />
                  Back to UI Builder
                </Button>
              </Link>
              <div className="border-l pl-4">
                <h1 className="text-lg font-semibold">
                  {generationData?.prompt?.name || 'TSX Component Preview'}
                </h1>
                <p className="text-sm text-gray-500">
                  ID: {generationId} • React TypeScript
                </p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <Badge variant="secondary">{getViewportLabel()}</Badge>
              
              {/* Viewport Controls */}
              <div className="flex items-center gap-1 border rounded-lg p-1">
                <Link to={`/preview/${generationId}?view=desktop`}>
                  <Button 
                    variant={view === 'desktop' ? 'default' : 'ghost'} 
                    size="sm"
                    className="px-3"
                  >
                    <Monitor className="w-4 h-4" />
                  </Button>
                </Link>
                <Link to={`/preview/${generationId}?view=tablet`}>
                  <Button 
                    variant={view === 'tablet' ? 'default' : 'ghost'} 
                    size="sm"
                    className="px-3"
                  >
                    <Tablet className="w-4 h-4" />
                  </Button>
                </Link>
                <Link to={`/preview/${generationId}?view=mobile`}>
                  <Button 
                    variant={view === 'mobile' ? 'default' : 'ghost'} 
                    size="sm"
                    className="px-3"
                  >
                    <Smartphone className="w-4 h-4" />
                  </Button>
                </Link>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" onClick={handleDownloadTSX}>
                  <Download className="w-4 h-4 mr-2" />
                  Download TSX
                </Button>
                <Button variant="outline" size="sm">
                  <Share className="w-4 h-4 mr-2" />
                  Share
                </Button>
                <Link to={`/project-dashboard/proj_${generationId}`}>
                  <Button variant="outline" size="sm">
                    <Code className="w-4 h-4 mr-2" />
                    TSX Dashboard
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Preview Content */}
      <div className="p-4">
        {isLoading ? (
          <div className="flex items-center justify-center h-96">
            <div className="text-center">
              <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-blue-600" />
              <h3 className="text-lg font-semibold mb-2">Generating TSX Component...</h3>
              <p className="text-gray-600">Creating React TypeScript component from AI prompt and data</p>
            </div>
          </div>
        ) : (
          <div className={getViewportClass()}>
            <div className="w-full bg-white" style={{ minHeight: view === 'mobile' ? '600px' : '800px' }}>
              {TSXComponent && <TSXComponent />}
            </div>
          </div>
        )}
      </div>

      {view !== 'desktop' && (
        <div className="fixed bottom-4 right-4">
          <Link to={`/preview/${generationId}?view=desktop`}>
            <Button className="gap-2">
              <Maximize className="w-4 h-4" />
              Full Screen
            </Button>
          </Link>
        </div>
      )}
    </div>
  );
}
