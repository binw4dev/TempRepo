import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { 
  ArrowLeft,
  Code2,
  Figma,
  FileText,
  Brain,
  Zap,
  Target,
  Rocket
} from "lucide-react";

export default function About() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-50 via-white to-indigo-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-r from-violet-600 to-indigo-600 rounded-lg flex items-center justify-center">
                <Code2 className="w-6 h-6 text-white" />
              </div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-violet-600 to-indigo-600 bg-clip-text text-transparent">
                UI Builder
              </h1>
            </Link>
            <Link to="/">
              <Button variant="outline" className="gap-2">
                <ArrowLeft className="w-4 h-4" />
                Back to Dashboard
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-12">
        {/* Hero Section */}
        <section className="text-center py-12 mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            About
            <span className="bg-gradient-to-r from-violet-600 to-indigo-600 bg-clip-text text-transparent"> UI Builder</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            A comprehensive platform for designing, managing, and generating user interfaces using AI-powered tools and modern design workflows.
          </p>
        </section>

        {/* Features Overview */}
        <section className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <Card className="text-center">
            <CardHeader>
              <div className="w-12 h-12 bg-violet-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Figma className="w-6 h-6 text-violet-600" />
              </div>
              <CardTitle>Figma Integration</CardTitle>
              <CardDescription>
                Import and manage Figma designs with powerful editing tools
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="text-sm text-gray-600 space-y-2">
                <li>• Direct Figma URL import</li>
                <li>• Design editing capabilities</li>
                <li>• Export in multiple formats</li>
                <li>• Real-time preview</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <FileText className="w-6 h-6 text-indigo-600" />
              </div>
              <CardTitle>JSON Management</CardTitle>
              <CardDescription>
                Handle configuration files and data with built-in validation
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="text-sm text-gray-600 space-y-2">
                <li>• JSON editor with syntax validation</li>
                <li>• File upload and import</li>
                <li>• Format and prettify</li>
                <li>• Download and export</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Brain className="w-6 h-6 text-emerald-600" />
              </div>
              <CardTitle>AI Prompt Library</CardTitle>
              <CardDescription>
                Create and manage AI prompts for automated UI generation
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="text-sm text-gray-600 space-y-2">
                <li>• Custom prompt creation</li>
                <li>• Template library</li>
                <li>• External UI generation</li>
                <li>• Multi-format output</li>
              </ul>
            </CardContent>
          </Card>
        </section>

        {/* How It Works */}
        <section className="mb-16">
          <h3 className="text-3xl font-bold text-center text-gray-900 mb-12">How It Works</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-violet-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Figma className="w-8 h-8 text-white" />
              </div>
              <h4 className="text-lg font-semibold mb-2">1. Import Designs</h4>
              <p className="text-gray-600 text-sm">
                Upload your Figma designs or create new ones using our integrated tools
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <FileText className="w-8 h-8 text-white" />
              </div>
              <h4 className="text-lg font-semibold mb-2">2. Configure Data</h4>
              <p className="text-gray-600 text-sm">
                Add JSON configurations, themes, and data structures for your project
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Brain className="w-8 h-8 text-white" />
              </div>
              <h4 className="text-lg font-semibold mb-2">3. Create Prompts</h4>
              <p className="text-gray-600 text-sm">
                Design AI prompts that define exactly what you want to generate
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-gray-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Rocket className="w-8 h-8 text-white" />
              </div>
              <h4 className="text-lg font-semibold mb-2">4. Generate UI</h4>
              <p className="text-gray-600 text-sm">
                Run your prompts to generate production-ready UI code for external projects
              </p>
            </div>
          </div>
        </section>

        {/* Technical Details */}
        <section className="mb-16">
          <div className="bg-gray-50 rounded-xl p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">Technical Specifications</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h4 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                  <Zap className="w-5 h-5 text-emerald-500" />
                  Core Features
                </h4>
                <ul className="space-y-2 text-gray-600">
                  <li>• React 18 + TypeScript</li>
                  <li>• Tailwind CSS for styling</li>
                  <li>• Radix UI components</li>
                  <li>• Real-time validation</li>
                  <li>• Responsive design</li>
                  <li>• Modern file handling</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                  <Target className="w-5 h-5 text-violet-500" />
                  Supported Formats
                </h4>
                <ul className="space-y-2 text-gray-600">
                  <li>• Figma files (.fig) and URLs</li>
                  <li>• JSON configurations</li>
                  <li>• React/Vue/Angular output</li>
                  <li>• TypeScript/JavaScript</li>
                  <li>• Multiple UI frameworks</li>
                  <li>• Export to various formats</li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="text-center py-12">
          <div className="bg-gradient-to-r from-violet-600 to-indigo-600 rounded-xl p-8 text-white">
            <h3 className="text-2xl font-bold mb-4">Ready to Start Building?</h3>
            <p className="text-violet-100 mb-6 max-w-2xl mx-auto">
              Transform your design workflow with our AI-powered UI generation platform. 
              Create, manage, and deploy beautiful interfaces faster than ever.
            </p>
            <Link to="/">
              <Button className="bg-white text-violet-600 hover:bg-gray-100">
                <Rocket className="w-4 h-4" />
                Get Started Now
              </Button>
            </Link>
          </div>
        </section>
      </main>
    </div>
  );
}
